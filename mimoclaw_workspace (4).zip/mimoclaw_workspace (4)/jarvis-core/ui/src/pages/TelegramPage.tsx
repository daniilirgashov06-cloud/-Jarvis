/**
 * Telegram — удалённый доступ через бота: уровни, PIN, уведомления.
 */

import { useEffect } from "react";
import { Badge, Card, Notice, PageHeader } from "../components/ui/panels";
import { SettingsSaveBar } from "../components/SettingsSaveBar";
import { Button, Chip, FieldRow, SelectField, TextField, Toggle } from "../components/ui/controls";
import { useSettingsStore } from "../stores/settingsStore";
import { useSystemStore } from "../stores/systemStore";

export function TelegramPage() {
  const telegram = useSettingsStore((s) => s.data.telegram);
  const loaded = useSettingsStore((s) => s.loaded);
  const patch = useSettingsStore((s) => s.patch);
  const pushEvent = useSystemStore((s) => s.pushEvent);

  useEffect(() => {
    if (!loaded) void useSettingsStore.getState().load();
  }, [loaded]);

  const sendTestEvent = () => {
    pushEvent({
      ts: Date.now() / 1000,
      topic: "ui.test",
      payload: { target: "telegram", note: "тестовое событие панели" },
    });
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Telegram"
        subtitle="Управление ботом: кто и что может делать из мессенджера."
        actions={
          <>
            <Chip accent>
              <span className="uppercase tracking-wider">токен — из .env</span>
            </Chip>
            <Button onClick={sendTestEvent}>Тестовое событие</Button>
          </>
        }
      />

      <Notice tone="warn">
        Токен бота и PIN-код не отображаются в панели и не сохраняются в YAML —
        они читаются из переменных окружения (TELEGRAM_BOT_TOKEN).
      </Notice>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card title="Подключение">
          <FieldRow
            label="Бот включён"
            hint="Принимать команды из Telegram"
            control={<Toggle checked={telegram.enabled} onChange={(v) => patch("telegram", { enabled: v })} />}
          />
          <div className="mt-3">
            <TextField
              label="Chat ID"
              value={telegram.chat_id ?? ""}
              placeholder="например: 123456789"
              onChange={(e) => patch("telegram", { chat_id: e.target.value || null })}
              hint="Разрешённый чат для управления"
            />
          </div>
          <div className="mt-3">
            <SelectField
              label="Уровень доступа"
              value={telegram.access_level}
              onChange={(e) => patch("telegram", { access_level: e.target.value })}
              options={[
                { value: "full", label: "Полный — команды и управление" },
                { value: "view", label: "Просмотр — статус и логи" },
                { value: "notify", label: "Только уведомления" },
              ]}
            />
          </div>
          <div className="mt-4">
            <Badge
              className={
                telegram.enabled ? "border-ok/40 bg-ok/10 text-ok" : "border-line-bright bg-panel-2 text-muted"
              }
              pulse={telegram.enabled}
            >
              {telegram.enabled ? "бот активен" : "бот выключен"}
            </Badge>
          </div>
        </Card>

        <Card title="Безопасность и уведомления" delay={0.05}>
          <FieldRow
            label="PIN для опасных команд"
            hint="Высокий риск требует PIN-код"
            control={
              <Toggle checked={telegram.require_pin_for_high} onChange={(v) => patch("telegram", { require_pin_for_high: v })} />
            }
          />
          <FieldRow
            label="Уведомлять об ошибках"
            hint="Сообщать в чат о сбоях ядра"
            control={<Toggle checked={telegram.notify_errors} onChange={(v) => patch("telegram", { notify_errors: v })} />}
          />
          <div className="mt-4 rounded-xl border border-line bg-panel-2/50 p-3 text-xs text-muted">
            <p>Сценарий: {describeScenario(telegram.access_level)}</p>
          </div>
        </Card>
      </div>

      <SettingsSaveBar />
    </div>
  );
}

function describeScenario(level: string): string {
  if (level === "full") return "бот может отправлять команды ядру (с подтверждениями по политике риска)";
  if (level === "view") return "бот отдаёт статус и ленту событий, команды не выполняет";
  return "бот только присылает уведомления, запросы игнорирует";
}
