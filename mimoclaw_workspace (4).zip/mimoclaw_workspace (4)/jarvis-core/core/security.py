"""
Безопасность JARVIS CORE (ТЗ-6.7, ТЗ-9.2).

``SecurityManager`` — уровни доступа, whitelist/чёрные списки, PIN для
опасных действий, решение «выполнить / подтвердить / запретить» и запись
в аудит-лог (``core/audit_log``).

Уровни риска команд (см. actions/registry):
  - SAFE     -> выполнить без подтверждения
  - MEDIUM   -> запросить подтверждение
  - HIGH     -> подтверждение + PIN
  - FORBIDDEN-> запрещено (только явный whitelist вручную)
"""

from __future__ import annotations

import hmac
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from core.audit_log import AuditLog


class Decision(str, Enum):
    """Вердикт безопасности для действия."""

    ALLOW = "allow"          # выполнить сразу
    CONFIRM = "confirm"      # запросить подтверждение (опц. PIN)
    DENY = "deny"            # запрещено


class AccessLevel(str, Enum):
    """Уровень доступа (напр. для Telegram-бота)."""

    FULL = "full"            # всё
    VIEW = "view"            # только чтение/просмотр
    NOTIFY = "notify"        # только уведомления


# Уровни риска -> вердикт
RISK_DECISION: dict[str, Decision] = {
    "safe": Decision.ALLOW,
    "medium": Decision.CONFIRM,
    "high": Decision.CONFIRM,
    "forbidden": Decision.DENY,
}


@dataclass
class SecurityManager:
    """
    Центр принятия решений безопасности.

    :param pin: PIN для HIGH-действий (хранится как есть; сравнивается hmac).
    :param allowed_users: whitelist идентификаторов пользователей (Chat ID и т.п.).
    :param forbidden_paths: префиксы путей, которые нельзя трогать.
    :param audit: аудит-лог (опционально).
    """

    pin: str | None = None
    allowed_users: list[str] = field(default_factory=list)
    forbidden_paths: list[str] = field(default_factory=list)
    audit: AuditLog | None = None
    max_pin_attempts: int = 5
    _pin_failures: dict[str, int] = field(default_factory=dict)

    # -- решения -------------------------------------------------------------
    def decide(self, risk: str, *, force_allow: bool = False) -> Decision:
        """Вердикт для команды по уровню риска."""
        if risk == "forbidden" and not force_allow:
            return Decision.DENY
        return RISK_DECISION.get(risk, Decision.CONFIRM)

    def needs_pin(self, risk: str) -> bool:
        """Нужен ли PIN для этого уровня риска."""
        return risk == "high"

    # -- PIN -----------------------------------------------------------------
    def verify_pin(self, user_id: str, provided_pin: str | None) -> bool:
        """Проверяет PIN; ведёт счёт неудач и блокирует после порога."""
        if self._pin_failures.get(user_id, 0) >= self.max_pin_attempts:
            return False  # заблокирован
        if self.pin is None:
            return True  # PIN не задан — пропускаем
        ok = provided_pin is not None and hmac.compare_digest(str(self.pin), str(provided_pin))
        if not ok:
            self._pin_failures[user_id] = self._pin_failures.get(user_id, 0) + 1
        else:
            self._pin_failures.pop(user_id, None)
        return ok

    def is_locked_out(self, user_id: str) -> bool:
        return self._pin_failures.get(user_id, 0) >= self.max_pin_attempts

    # -- доступ пользователя -------------------------------------------------
    def authorize(self, user_id: str, required: AccessLevel = AccessLevel.FULL) -> bool:
        """Проверка whitelist + уровня доступа."""
        if self.allowed_users and user_id not in self.allowed_users:
            return False
        # Уровни: notify < view < full. Запрос не выше выданного — упрощённо
        # считаем, что пользователь в whitelist имеет required-уровень.
        return True

    # -- пути ----------------------------------------------------------------
    def check_path(self, path: str) -> bool:
        """False, если путь под запретом (системные директории и т.п.)."""
        from pathlib import Path

        p = str(Path(path).expanduser().resolve())
        for bad in self.forbidden_paths:
            if bad and p.startswith(str(Path(bad).expanduser().resolve())):
                return False
        return True

    # -- исполнение с политикой ---------------------------------------------
    def authorize_action(
        self,
        *,
        user_id: str,
        risk: str,
        command: str,
        args: dict[str, Any] | None = None,
        confirmed: bool = False,
        provided_pin: str | None = None,
    ) -> Decision:
        """
        Полный вердикт: доступ пользователя -> путь -> риск -> PIN.

        Возвращает CONFIRM, если нужно подтверждение; DENY — если запрещено.
        Записывает итог в аудит-лог.
        """
        args = args or {}
        decision = self.decide(risk)

        if not self.authorize(user_id):
            decision = Decision.DENY
            reason = "пользователь не в whitelist"
        elif "path" in args and not self.check_path(str(args["path"])):
            decision = Decision.DENY
            reason = "путь запрещён"
        elif decision is Decision.CONFIRM:
            if not confirmed:
                reason = "требуется подтверждение"
            elif self.needs_pin(risk) and not self.verify_pin(user_id, provided_pin):
                decision = Decision.CONFIRM
                reason = "неверный PIN"
            else:
                decision = Decision.ALLOW
                reason = "подтверждено"
        else:
            reason = "ok" if decision is Decision.ALLOW else "запрещено"

        self._record(user_id, command, risk, decision, reason, args)
        return decision

    def _record(
        self,
        user_id: str,
        command: str,
        risk: str,
        decision: Decision,
        reason: str,
        args: dict[str, Any],
    ) -> None:
        if self.audit is None:
            return
        try:
            self.audit.record_command(
                command,
                decision=decision.value,
                risk=risk,
                actor=user_id,
                params=args,
                detail=reason,
            )
        except Exception:  # noqa: BLE001 — аудит не должен ронять исполнение
            pass
