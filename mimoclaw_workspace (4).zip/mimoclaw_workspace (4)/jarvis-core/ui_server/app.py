"""
Веб-панель JARVIS CORE — FastAPI + WebSocket.

Минимальная панель MVP (разделы «Dashboard» и «Голос»): статус системы,
живая лента событий шины, отправка текстовой команды и получение ответа
оркестратора. Полноценный React-GUI — Этап 2, здесь только рабочий каркас.

Архитектура:
    * ``PanelState`` / ``ClientMessage`` / ``UIServer`` — слой БЕЗ фреймворка:
      тестируется на чистом asyncio, не требует FastAPI;
    * ``create_app(server)`` — тонкая обёртка FastAPI: REST + WebSocket;
    * ``run(server, host, port)`` — запуск через uvicorn (ленивый импорт).

Связь с ядром — через шину ``core.event_bus`` (события ``stt.*``, ``wakeword.*``,
``pipeline.*`` попадают в ленту панели) и через оркестратор (``process_text``).

Приватность: по умолчанию слушаем только ``127.0.0.1`` (локально-first);
удалённый доступ — осознанный выбор оператора, не дефолт.

Протокол (JSON-строки, клиент -> сервер):
    {"type": "text", "text": "поставь громкость 50"}
    {"type": "ping"}
    {"type": "status"}
    {"type": "subscribe", "topics": ["stt.*", "ui.*"]}

Сообщения (сервер -> клиент):
    {"type": "reply", "ok": true, "text": "...", "actions": [...], ...}
    {"type": "event", "topic": "stt.transcript", "payload": {...}}
    {"type": "status", "state": {...}}   {"type": "pong"}
    {"type": "subscribed", "topics": [...]}   {"type": "error", "message": "..."}

Использование:
    server = UIServer(orchestrator=orch)
    app = create_app(server)          # для uvicorn: ui_server.app:app
    run(server, host="127.0.0.1", port=8765)
"""

from __future__ import annotations

import fnmatch
import json
import logging
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Protocol, runtime_checkable

from core.event_bus import EventBus, bus as global_bus
from pydantic import BaseModel, Field

try:  # FastAPI опционален: логика панели (UIServer) тестируется и без него
    from fastapi import FastAPI, WebSocket, WebSocketDisconnect
    from fastapi.responses import HTMLResponse
except ImportError:  # pragma: no cover - зависит от окружения
    FastAPI = WebSocket = WebSocketDisconnect = HTMLResponse = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)

# --- ограничения протокола -------------------------------------------------
MAX_TEXT_LEN = 8000          # максимум символов в команде с панели
DEFAULT_HISTORY_LIMIT = 200  # сколько событий держим в ленте
DEFAULT_HOST = "127.0.0.1"   # локально-first: наружу не торчим по умолчанию
DEFAULT_PORT = 8765

CLIENT_MESSAGE_TYPES: frozenset[str] = frozenset({"text", "ping", "status", "subscribe"})


class ProtocolError(ValueError):
    """Некорректное сообщение клиента (JSON/структура/лимиты)."""


@runtime_checkable
class WSClient(Protocol):
    """Минимальный контракт WebSocket-клиента (у Starlette WebSocket он есть)."""

    async def send_text(self, data: str) -> None: ...


@runtime_checkable
class TextProcessor(Protocol):
    """Контракт обработчика текста (обычно core.orchestrator.Orchestrator)."""

    async def process_text(
        self, user_text: str, history: list[dict[str, Any]] | None = None
    ) -> Any: ...


# ---------------------------------------------------------------------------
# Протокол
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ClientMessage:
    """Распарсенное сообщение клиента."""

    type: str
    text: str = ""
    topics: tuple[str, ...] = ()


def parse_client_message(raw: str) -> ClientMessage:
    """
    Разобрать JSON-сообщение клиента.

    Raises:
        ProtocolError: пустой ввод, не-JSON, не-объект, неизвестный тип,
            пустой ``text`` для команды или нестроковые ``topics``.
    """
    if not isinstance(raw, str) or not raw.strip():
        raise ProtocolError("пустое сообщение")
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ProtocolError(f"некорректный JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ProtocolError("ожидается JSON-объект с полем 'type'")

    mtype = data.get("type")
    if mtype not in CLIENT_MESSAGE_TYPES:
        raise ProtocolError(
            f"неизвестный тип сообщения: {mtype!r} (допустимо: {sorted(CLIENT_MESSAGE_TYPES)})"
        )

    text = data.get("text", "")
    if mtype == "text":
        if not isinstance(text, str) or not text.strip():
            raise ProtocolError("поле 'text' должно быть непустой строкой")
        text = text.strip()
        if len(text) > MAX_TEXT_LEN:
            raise ProtocolError(f"команда длиннее {MAX_TEXT_LEN} символов")
    else:
        text = ""

    topics_raw = data.get("topics", ())
    if not isinstance(topics_raw, (list, tuple)):
        raise ProtocolError("поле 'topics' должно быть списком строк")
    topics: list[str] = []
    for item in topics_raw:
        if not isinstance(item, str) or not item.strip():
            raise ProtocolError("поле 'topics' должно быть списком непустых строк")
        topics.append(item.strip())

    return ClientMessage(type=mtype, text=text, topics=tuple(topics))


def encode_frame(frame: dict[str, Any]) -> str:
    """Сериализовать кадр сервера -> клиент в JSON (UTF-8, без ASCII-эскейпа)."""
    return json.dumps(frame, ensure_ascii=False, default=str)


class TextRequest(BaseModel):
    """Тело POST /api/text (аналог сообщения {"type": "text"} по WS)."""

    text: str = Field(..., min_length=1, max_length=MAX_TEXT_LEN)


# ---------------------------------------------------------------------------
# Состояние панели
# ---------------------------------------------------------------------------
@dataclass
class PanelState:
    """
    Состояние панели: статус пайплайна, счётчики и лента событий.

    Лента — кольцевой буфер фиксированного размера, чтобы панель не росла
    бесконечно при долгой работе.
    """

    theme: str = "jarvis"
    accent_color: str = "#00E5FF"
    state: str = "idle"  # idle | listening | thinking | speaking
    started_at: float = field(default_factory=time.time)
    last_reply: str = ""
    counters: dict[str, int] = field(
        default_factory=lambda: {"events": 0, "commands": 0, "errors": 0}
    )
    history: deque[tuple[float, str, dict[str, Any]]] = field(default_factory=deque)
    history_limit: int = DEFAULT_HISTORY_LIMIT

    def __post_init__(self) -> None:
        self.history = deque(self.history, maxlen=self.history_limit)

    def set_state(self, state: str) -> None:
        """Сменить состояние пайплайна (отражается на Dashboard)."""
        self.state = state

    def record_event(self, topic: str, payload: dict[str, Any]) -> None:
        """Записать событие в ленту (учитывается в счётчике событий)."""
        self.history.append((time.time(), topic, dict(payload)))
        self.counters["events"] += 1

    def record_command(self) -> None:
        """Учесть команду, пришедшую с панели."""
        self.counters["commands"] += 1

    def record_error(self) -> None:
        """Учесть ошибку протокола/оркестратора."""
        self.counters["errors"] += 1

    def recent_events(self, limit: int = 50) -> list[dict[str, Any]]:
        """Последние события ленты (новые в конце)."""
        items = list(self.history)[-max(0, limit):]
        return [{"ts": ts, "topic": topic, "payload": payload} for ts, topic, payload in items]

    def snapshot(self) -> dict[str, Any]:
        """Снимок статуса для Dashboard / GET /api/status."""
        return {
            "state": self.state,
            "theme": self.theme,
            "accent_color": self.accent_color,
            "uptime_s": round(time.time() - self.started_at, 1),
            "counters": dict(self.counters),
            "history_size": len(self.history),
            "last_reply": self.last_reply,
        }


# ---------------------------------------------------------------------------
# Сервер панели (без фреймворка)
# ---------------------------------------------------------------------------
class UIServer:
    """
    Логика веб-панели: протокол, лента событий, рассылка по WebSocket.

    FastAPI не требуется — всё тестируется на фейковых клиентах.
    Шина событий подключается опционально: любое событие ядра попадает
    в ленту и раздаётся подписчикам с фильтром по топикам (wildcard).
    """

    def __init__(
        self,
        orchestrator: TextProcessor | None = None,
        *,
        bus: EventBus | None = None,
        theme: str = "jarvis",
        accent_color: str = "#00E5FF",
        history_limit: int = DEFAULT_HISTORY_LIMIT,
    ) -> None:
        self.orchestrator = orchestrator
        self.state = PanelState(
            theme=theme, accent_color=accent_color, history_limit=history_limit
        )
        self._clients: dict[WSClient, tuple[str, ...]] = {}
        self._bus = bus if bus is not None else global_bus
        # Свои служебные события (ui.*) не слушаем, чтобы не зациклиться.
        self._unsubscribe_bus = self._bus.subscribe("*", self._on_bus_event)

    # -- клиенты -------------------------------------------------------------
    def attach(self, client: WSClient, topics: tuple[str, ...] = ("*",)) -> Callable[[], None]:
        """Подключить клиента. Возвращает функцию отключения."""
        self._clients[client] = topics

        def _detach() -> None:
            self._clients.pop(client, None)

        return _detach

    def clients(self) -> list[WSClient]:
        """Список подключённых клиентов."""
        return list(self._clients)

    def close(self) -> None:
        """Отписаться от шины (вызывать при остановке сервера)."""
        self._unsubscribe_bus()

    async def on_connect(self, client: WSClient) -> list[str]:
        """Начальные кадры для нового клиента: статус + свежая лента."""
        return [
            encode_frame({"type": "status", "state": self._snapshot_with_clients()}),
            encode_frame({"type": "event", "topic": "ui.history", "payload": {
                "events": self.state.recent_events(30),
            }}),
        ]

    # -- входящие сообщения --------------------------------------------------
    async def handle_message(self, raw: str, client: WSClient | None = None) -> list[str]:
        """
        Обработать сообщение клиента и вернуть кадры ответа.

        Кадры отправляет вызывающая стор (WS-эндпоинт), ошибка протокола
        не роняет соединение — клиент получает кадр ``error``.
        """
        try:
            msg = parse_client_message(raw)
        except ProtocolError as exc:
            self.state.record_error()
            return [encode_frame({"type": "error", "message": str(exc)})]

        if msg.type == "ping":
            return [encode_frame({"type": "pong", "ts": time.time()})]

        if msg.type == "status":
            return [encode_frame({"type": "status", "state": self._snapshot_with_clients()})]

        if msg.type == "subscribe":
            if client is not None:
                self._clients[client] = msg.topics or ("*",)
            return [encode_frame({"type": "subscribed", "topics": list(msg.topics or ("*",))})]

        # type == "text": команда -> оркестратор
        self.state.record_command()
        self.state.set_state("thinking")
        try:
            result = await self.process_text(msg.text)
        finally:
            self.state.set_state("idle")

        if result.get("text"):
            self.state.last_reply = str(result["text"])
        # Лента + другие клиенты видят команду и реплику; автор получает reply-кадр.
        await self.publish_event("ui.command", {"text": msg.text}, exclude=client)
        await self.publish_event("ui.reply", result, exclude=client)
        return [encode_frame({"type": "reply", **result})]

    async def process_text(self, text: str) -> dict[str, Any]:
        """
        Прогнать текст через оркестратор и нормализовать результат.

        Без оркестратора работает режим эха (панель живёт и без ядра);
        исключение оркестратора не роняет сокет — возвращается ``ok=False``.
        """
        if self.orchestrator is None:
            return {
                "ok": False,
                "text": f"Оркестратор не подключён, команда принята: «{text}»",
                "actions": [],
                "provider": "",
                "tts": "",
            }
        try:
            raw_result: Any = await self.orchestrator.process_text(text)
        except Exception as exc:  # noqa: BLE001 — ошибка ядра не роняет панель
            logger.exception("Оркестратор упал на команде с панели")
            self.state.record_error()
            return {"ok": False, "text": "", "error": str(exc), "actions": [], "provider": "", "tts": ""}
        return self._normalize_result(raw_result)

    # -- события шины --------------------------------------------------------
    async def _on_bus_event(self, topic: str, payload: dict[str, Any]) -> None:
        """Событие ядра: в ленту + раздача подписчикам панели."""
        if topic.startswith("ui."):
            return  # служебные события панели не транслируем обратно
        await self.publish_event(topic, payload)

    async def publish_event(
        self, topic: str, payload: dict[str, Any], *, exclude: WSClient | None = None
    ) -> int:
        """
        Записать событие в ленту и разослать клиентам (с учётом фильтров).

        ``exclude`` — кому не отправлять (например, автору команды, который
        уже получил собственный reply-кадр).
        """
        self.state.record_event(topic, payload)
        frame = encode_frame({"type": "event", "topic": topic, "payload": payload})
        return await self.broadcast(frame, exclude=exclude)

    async def broadcast(self, frame: str, exclude: WSClient | None = None) -> int:
        """
        Разослать кадр всем клиентам, чей фильтр топиков пропускает событие.

        Отвал клиента при отправке — его проблема: убираем из списка,
        остальным доставка продолжается.
        """
        topic = self._frame_topic(frame)
        delivered = 0
        for client, topics in list(self._clients.items()):
            if client is exclude:
                continue
            if topic is not None and not self._topic_matches(topics, topic):
                continue
            try:
                await client.send_text(frame)
                delivered += 1
            except Exception:  # noqa: BLE001 — отвалившийся клиент не валит рассылку
                logger.debug("Клиент панели отвалился при отправке", exc_info=True)
                self._clients.pop(client, None)
        return delivered

    # -- внутренние ----------------------------------------------------------
    def _snapshot_with_clients(self) -> dict[str, Any]:
        snap = self.state.snapshot()
        snap["clients"] = len(self._clients)
        snap["orchestrator"] = self.orchestrator is not None
        return snap

    @staticmethod
    def _topic_matches(patterns: tuple[str, ...], topic: str) -> bool:
        return any(fnmatch.fnmatch(topic, pat) for pat in patterns)

    @staticmethod
    def _frame_topic(frame: str) -> str | None:
        """Достать топик из кадра-события (для фильтрации подписок)."""
        try:
            data = json.loads(frame)
        except json.JSONDecodeError:
            return None
        if isinstance(data, dict) and data.get("type") == "event":
            topic = data.get("topic")
            return topic if isinstance(topic, str) else None
        return None

    @staticmethod
    def _normalize_result(raw: Any) -> dict[str, Any]:
        """Привести PipelineResult (или что угодно) к JSON-словарю панели."""
        if isinstance(raw, dict):
            return {
                "ok": bool(raw.get("ok", True)),
                "text": str(raw.get("text", "")),
                "error": raw.get("error"),
                "actions": list(raw.get("actions", [])),
                "provider": str(raw.get("provider", "")),
                "tts": str(raw.get("tts", "")),
            }
        actions = []
        for action in getattr(raw, "actions", []) or []:
            actions.append(
                {
                    "name": getattr(action, "name", ""),
                    "ok": bool(getattr(action, "ok", False)),
                    "output": getattr(action, "output", None),
                    "error": getattr(action, "error", None),
                }
            )
        return {
            "ok": True,
            "text": str(getattr(raw, "reply", "") or getattr(raw, "text", "")),
            "error": None,
            "actions": actions,
            "provider": str(getattr(raw, "used_provider", "")),
            "tts": str(getattr(raw, "used_tts", "")),
        }


# ---------------------------------------------------------------------------
# FastAPI-обёртка
# ---------------------------------------------------------------------------
def create_app(server: UIServer) -> Any:
    """
    Собрать FastAPI-приложение поверх ``UIServer``.

    Маршруты:
        GET  /             — минимальная панель (Dashboard / Голос)
        GET  /api/status   — снимок статуса
        GET  /api/history  — лента событий
        POST /api/text     — отправить команду текстом
        WS   /ws           — живые события + команды
    """
    if FastAPI is None or WebSocket is None:
        raise RuntimeError(
            "Для веб-панели нужен FastAPI: pip install fastapi uvicorn[standard]"
        )

    app = FastAPI(title="JARVIS CORE", version="0.1")

    @app.get("/", response_class=HTMLResponse)
    async def index() -> str:
        """Минимальная панель MVP (Dashboard + Голос)."""
        return (
            PANEL_HTML.replace("__ACCENT__", server.state.accent_color)
            .replace("__THEME__", server.state.theme)
        )

    @app.get("/api/status")
    async def api_status() -> dict[str, Any]:
        """Текущий статус панели/пайплайна."""
        return server._snapshot_with_clients()

    @app.get("/api/history")
    async def api_history(limit: int = 50) -> list[dict[str, Any]]:
        """Лента событий (новые в конце)."""
        return server.state.recent_events(limit)

    @app.post("/api/text")
    async def api_text(req: TextRequest) -> dict[str, Any]:
        """Отправить команду текстом (аналог кнопки «Отправить» в разделе Голос)."""
        result = await server.process_text(req.text)
        server.state.record_command()
        server.state.record_event("ui.command", {"text": req.text})
        server.state.record_event("ui.reply", result)
        return result

    @app.websocket("/ws")
    async def ws_endpoint(websocket: WebSocket) -> None:
        """WebSocket: события шины + команды с панели."""
        await websocket.accept()
        detach = server.attach(websocket)
        try:
            for frame in await server.on_connect(websocket):
                await websocket.send_text(frame)
            while True:
                raw = await websocket.receive_text()
                for frame in await server.handle_message(raw, websocket):
                    await websocket.send_text(frame)
        except WebSocketDisconnect:
            pass
        finally:
            detach()

    return app


def run(
    server: UIServer,
    *,
    host: str = DEFAULT_HOST,
    port: int = DEFAULT_PORT,
) -> None:
    """Запустить панель через uvicorn (блокирующий вызов)."""
    try:
        import uvicorn
    except ImportError as exc:  # pragma: no cover - зависит от окружения
        raise RuntimeError("Нужен uvicorn: pip install 'uvicorn[standard]'") from exc
    logger.info("Панель JARVIS: http://%s:%d (ws /ws)", host, port)
    uvicorn.run(create_app(server), host=host, port=port)


# ---------------------------------------------------------------------------
# Минимальная панель (vanilla JS, две вкладки)
# ---------------------------------------------------------------------------
PANEL_HTML = """<!doctype html>
<html lang="ru" data-theme="__THEME__">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>JARVIS CORE</title>
<style>
  :root { --accent: __ACCENT__; --bg: #0a0f14; --card: #101820; --text: #cfe8f2; }
  * { box-sizing: border-box; }
  body { margin: 0; background: var(--bg); color: var(--text);
         font: 14px/1.5 "JetBrains Mono", "Fira Code", monospace; }
  header { display: flex; align-items: center; gap: 12px; padding: 14px 20px;
           border-bottom: 1px solid #1c2a35; }
  header h1 { margin: 0; font-size: 16px; letter-spacing: 2px; color: var(--accent); }
  .dot { width: 10px; height: 10px; border-radius: 50%; background: var(--accent);
         box-shadow: 0 0 8px var(--accent); }
  nav { display: flex; gap: 8px; padding: 10px 20px; }
  nav button { background: var(--card); color: var(--text); border: 1px solid #1c2a35;
               padding: 6px 14px; border-radius: 6px; cursor: pointer; }
  nav button.active { border-color: var(--accent); color: var(--accent); }
  main { padding: 0 20px 20px; }
  section { display: none; } section.visible { display: block; }
  .cards { display: flex; flex-wrap: wrap; gap: 12px; }
  .card { background: var(--card); border: 1px solid #1c2a35; border-radius: 8px;
          padding: 12px 16px; min-width: 150px; }
  .card b { display: block; color: var(--accent); font-size: 12px; letter-spacing: 1px; }
  #log { background: var(--card); border: 1px solid #1c2a35; border-radius: 8px;
         padding: 10px; height: 320px; overflow-y: auto; margin-top: 14px; }
  .row { display: flex; gap: 8px; margin: 12px 0; }
  input[type=text] { flex: 1; background: var(--card); color: var(--text);
                     border: 1px solid #1c2a35; border-radius: 6px; padding: 10px; }
  button.send { background: var(--accent); color: #04121a; border: 0;
                border-radius: 6px; padding: 10px 18px; cursor: pointer; font-weight: bold; }
  .ts { color: #4c6b7a; margin-right: 6px; }
  .topic { color: var(--accent); margin-right: 6px; }
</style>
</head>
<body>
<header><div class="dot"></div><h1>JARVIS CORE</h1><span id="conn">offline</span></header>
<nav>
  <button id="tab-dash" class="active">Dashboard</button>
  <button id="tab-voice">Голос</button>
</nav>
<main>
  <section id="sec-dash" class="visible">
    <div class="cards">
      <div class="card"><b>СОСТОЯНИЕ</b><span id="st-state">—</span></div>
      <div class="card"><b>АПТАЙМ</b><span id="st-uptime">—</span></div>
      <div class="card"><b>КОМАНД</b><span id="st-commands">0</span></div>
      <div class="card"><b>СОБЫТИЙ</b><span id="st-events">0</span></div>
      <div class="card"><b>ОШИБОК</b><span id="st-errors">0</span></div>
      <div class="card"><b>КЛИЕНТОВ</b><span id="st-clients">0</span></div>
    </div>
    <div id="log"></div>
  </section>
  <section id="sec-voice">
    <div class="row">
      <input id="cmd" type="text" placeholder="Текстовая команда, например: поставь громкость 50">
      <button class="send" id="send">Отправить</button>
    </div>
    <div id="replies"></div>
  </section>
</main>
<script>
const log = (topic, payload) => {
  const el = document.createElement('div');
  const ts = new Date().toLocaleTimeString();
  el.innerHTML = '<span class="ts">' + ts + '</span><span class="topic">' + topic + '</span>' +
                 JSON.stringify(payload);
  const box = document.getElementById('log');
  box.appendChild(el); box.scrollTop = box.scrollHeight;
};
const setStatus = (s) => {
  document.getElementById('st-state').textContent = s.state || '—';
  document.getElementById('st-uptime').textContent = (s.uptime_s ?? 0) + ' с';
  document.getElementById('st-clients').textContent = s.clients ?? 0;
  const c = s.counters || {};
  document.getElementById('st-commands').textContent = c.commands ?? 0;
  document.getElementById('st-events').textContent = c.events ?? 0;
  document.getElementById('st-errors').textContent = c.errors ?? 0;
};
const ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws');
ws.onopen = () => {
  document.getElementById('conn').textContent = 'online';
  ws.send(JSON.stringify({type: 'subscribe', topics: ['*']}));
};
ws.onclose = () => { document.getElementById('conn').textContent = 'offline'; };
ws.onmessage = (ev) => {
  const msg = JSON.parse(ev.data);
  if (msg.type === 'status') setStatus(msg.state);
  else if (msg.type === 'event') log(msg.topic, msg.payload);
  else if (msg.type === 'reply' || msg.type === 'error') {
    const el = document.createElement('div');
    el.innerHTML = '<span class="topic">' + (msg.type === 'reply' ? 'JARVIS' : 'ERROR') +
                   '</span>' + (msg.text || msg.message || '');
    const box = document.getElementById('replies');
    box.appendChild(el); box.scrollTop = box.scrollHeight;
    log('ui.' + msg.type, msg.text || msg.message || '');
  }
};
const send = () => {
  const input = document.getElementById('cmd');
  const text = input.value.trim();
  if (!text || ws.readyState !== 1) return;
  ws.send(JSON.stringify({type: 'text', text: text}));
  input.value = '';
};
document.getElementById('send').onclick = send;
document.getElementById('cmd').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') send();
});
const switchTab = (name) => {
  for (const t of ['dash', 'voice']) {
    document.getElementById('sec-' + t).classList.toggle('visible', t === name);
    document.getElementById('tab-' + t).classList.toggle('active', t === name);
  }
};
document.getElementById('tab-dash').onclick = () => switchTab('dash');
document.getElementById('tab-voice').onclick = () => switchTab('voice');
</script>
</body>
</html>
"""
