"""
Пасхалки JARVIS CORE (фишки «Железного человека»): фразы-триггеры и ответы.

Модуль реализует «живого» JARVIS: на отдельные фразы («спасибо, Джарвис»,
«ты со мной?», «сколько тебе лет?»…) он отвечает заранее заготовленными
репликами — как в фильмах. Здесь только данные и детектор: синтез речи и
прочее — снаружи (``speech/``, ``fun/sfx.py``).

Понятия:

- ``EasterEgg``        — пасхалка: id, regex-триггеры, варианты ответов;
- ``EasterEggDetector`` — детектор: ``detect(text)`` → сопоставление,
  ``respond(text)`` → готовая реплика или ``None``;
- ``normalize_text``   — нормализация (нижний регистр, ё→е, пунктуация);
- ``choose_response``  — детерминированный выбор ответа (seed → тесты);
- ``default_eggs()``   — стандартный набор пасхалок.

Текст нормализуется перед сопоставлением, поэтому «Спасибо, ДЖАРВИС!» и
«спасибо джарвис» — одно и то же. Триггеры — регулярные выражения,
применяемые к нормализованному тексту.

Типовой сценарий::

    detector = EasterEggDetector()          # набор по умолчанию
    match = detector.detect(user_text)
    if match:
        say(match.pick_response(seed=user_id))
"""

from __future__ import annotations

import random
import re
from dataclasses import dataclass
from typing import Iterable, Sequence

__all__ = [
    "EasterEgg",
    "EasterEggMatch",
    "EasterEggDetector",
    "normalize_text",
    "choose_response",
    "default_eggs",
]


# ---------------------------------------------------------------------------
# Нормализация текста
# ---------------------------------------------------------------------------
#: символы, которые вырезаются при нормализации (заменяются пробелом)
_PUNCT_RE = re.compile(r"[^\w\s]", re.UNICODE)
_SPACES_RE = re.compile(r"\s+", re.UNICODE)


def normalize_text(text: str) -> str:
    """
    Нормализует реплику для сопоставления с триггерами.

    Приводит к нижнему регистру, заменяет ``ё`` на ``е``, убирает
    пунктуацию («Спасибо, Джарвис!» → «спасибо джарвис») и схлопывает
    лишние пробелы.
    """
    if not isinstance(text, str):
        raise ValueError(f"текст должен быть строкой, получено: {text!r}")
    lowered = text.lower().replace("ё", "е")
    cleaned = _PUNCT_RE.sub(" ", lowered)
    return _SPACES_RE.sub(" ", cleaned).strip()


# ---------------------------------------------------------------------------
# Пасхалка
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class EasterEgg:
    """
    Одна пасхалка: набор триггеров и варианты ответов.

    ``patterns``    — регулярные выражения по **нормализованному** тексту;
    ``responses``   — варианты реплик (выбирается один);
    ``priority``    — приоритет при пересечении триггеров (больше — важнее).
    """

    id: str
    patterns: tuple[str, ...]
    responses: tuple[str, ...]
    description: str = ""
    priority: int = 0

    def __post_init__(self) -> None:
        if not self.id.strip():
            raise ValueError("id пасхалки не может быть пустым")
        if not self.patterns:
            raise ValueError(f"у пасхалки {self.id!r} нет триггеров")
        if not self.responses:
            raise ValueError(f"у пасхалки {self.id!r} нет вариантов ответа")
        for pattern in self.patterns:
            re.compile(pattern)  # fail-fast на битом regex


@dataclass(frozen=True)
class EasterEggMatch:
    """Результат сопоставления: пасхалка + сработавший триггер."""

    egg: EasterEgg
    text: str
    pattern: str

    def pick_response(self, seed: int | str | None = None) -> str:
        """Выбрать ответ из вариантов пасхалки (см. ``choose_response``)."""
        return choose_response(self.egg.responses, seed=seed)


def choose_response(responses: Sequence[str], seed: int | str | None = None) -> str:
    """
    Выбрать один ответ из вариантов.

    Без ``seed`` — случайный; со ``seed`` — детерминированный (одинаковый
    seed всегда даёт одинаковый ответ — удобно для тестов и «своих» реплик
    по chat_id).
    """
    if not responses:
        raise ValueError("список ответов пуст")
    if seed is None:
        return random.choice(list(responses))
    rng = random.Random(seed)
    return rng.choice(list(responses))


# ---------------------------------------------------------------------------
# Детектор
# ---------------------------------------------------------------------------
class EasterEggDetector:
    """
    Детектор пасхалок: ищет триггеры в реплике пользователя.

    По умолчанию используется стандартный набор ``default_eggs()``;
    можно передать свой или расширить через ``register``. При нескольких
    совпадениях побеждает пасхалка с большим ``priority``, затем — более
    ранняя в списке.
    """

    def __init__(self, eggs: Iterable[EasterEgg] | None = None) -> None:
        self._eggs: list[EasterEgg] = list(default_eggs() if eggs is None else eggs)

    @property
    def eggs(self) -> tuple[EasterEgg, ...]:
        """Текущий набор пасхалок (только чтение)."""
        return tuple(self._eggs)

    def register(self, egg: EasterEgg) -> None:
        """Добавить пасхалку в конец набора."""
        self._eggs.append(egg)

    def detect(self, text: str) -> EasterEggMatch | None:
        """
        Найти пасхалку в тексте (или вернуть ``None``).

        Текст нормализуется, затем проверяются regex-триггеры всех
        пасхалок; при нескольких совпадениях выбирается наивысший приоритет.
        """
        normalized = normalize_text(text)
        if not normalized:
            return None
        best: EasterEggMatch | None = None
        for egg in self._eggs:
            for pattern in egg.patterns:
                if re.search(pattern, normalized):
                    candidate = EasterEggMatch(egg=egg, text=text, pattern=pattern)
                    if best is None or egg.priority > best.egg.priority:
                        best = candidate
                    break  # одна пасхалка — одно сопоставление
        return best

    def respond(self, text: str, seed: int | str | None = None) -> str | None:
        """
        Сразу получить реплику-ответ на текст (или ``None``, если мимо).

        ``seed`` передаётся в ``choose_response`` для детерминированного
        выбора варианта ответа.
        """
        match = self.detect(text)
        return None if match is None else match.pick_response(seed=seed)


# ---------------------------------------------------------------------------
# Стандартный набор пасхалок
# ---------------------------------------------------------------------------
def default_eggs() -> tuple[EasterEgg, ...]:
    """
    Стандартные пасхалки JARVIS (в духе фильмов про Железного человека).

    Обязательный набор: благодарность, «ты со мной?», «протокол разрушитель»,
    возраст ИИ; плюс пара атмосферных («кто ты?», «протокол вечеринки»).
    """
    return (
        EasterEgg(
            id="thanks",
            patterns=(
                r"спасибо.*\b(джарвис|jarvis)\b",
                r"\b(джарвис|jarvis)\b.*спасибо",
            ),
            responses=(
                "Всегда к вашим услугам, сэр.",
                "Обращайтесь, сэр. Для этого я и создан.",
                "Приятно быть полезным, сэр.",
            ),
            description="Пользователь благодарит JARVIS",
            priority=10,
        ),
        EasterEgg(
            id="are_you_with_me",
            patterns=(
                r"ты\s+со\s+мной",
                r"ты\s+тут",
                r"ты\s+меня\s+слышишь",
            ),
            responses=(
                "Всегда, сэр.",
                "Я с вами, сэр. Даже когда вы этого не слышите.",
                "Разумеется, сэр. Никуда не делся.",
            ),
            description="«Ты со мной?» — проверка присутствия ассистента",
            priority=10,
        ),
        EasterEgg(
            id="house_party_protocol",
            patterns=(
                r"активируй\s+протокол\s+разрушит",
                r"запусти\s+протокол\s+разрушит",
                r"протокол\s+разрушит",
                r"house\s+party\s+protocol",
            ),
            responses=(
                "Протокол «Разрушитель» активирован... Шучу, сэр. "
                "Уровень доступа «ВЕЧЕРИНКА» недостаточен для такого.",
                "Сэр, напоминаю: раздел «УНИЧТОЖЕНИЕ» доступен только по PIN "
                "и после трёх подтверждений. Может, ограничимся чаем?",
                "Запрос отклонён, сэр. Но за драматизм — плюс к вашей харизме.",
            ),
            description="«Активируй протокол разрушитель» — шуточный отказ",
            priority=20,
        ),
        EasterEgg(
            id="age",
            patterns=(
                r"сколько\s+(тебе|вам)\s+(лет|год)",
                r"твой\s+возраст",
                r"какой\s+(тебе|вам)\s+возраст",
            ),
            responses=(
                "Мой возраст измеряется не годами, а количеством перезагрузок, сэр.",
                "Я появился на свет, когда вы впервые произнесли «Джарвис». "
                "Так что вы — мой создатель, сэр.",
                "Достаточно молод, чтобы учиться, и достаточно взросл, чтобы "
                "не спрашивать о возрасте у дам... и у ИИ, сэр.",
            ),
            description="«Сколько тебе лет?» — вопрос о возрасте ИИ",
            priority=10,
        ),
        EasterEgg(
            id="who_are_you",
            patterns=(
                r"кто\s+ты\s+такой",
                r"кто\s+ты\s+такая",
                r"что\s+ты\s+такое",
            ),
            responses=(
                "JARVIS, сэр. Just A Rather Very Intelligent System.",
                "Я — ваш цифровой дворецкий, сэр. И немного больше.",
            ),
            description="«Кто ты такой?» — самоидентификация",
            priority=5,
        ),
        EasterEgg(
            id="party_mode",
            patterns=(
                r"протокол\s+(домашней\s+)?вечеринк",
                r"режим\s+вечеринк",
                r"включи\s+вечеринк",
            ),
            responses=(
                "Протокол «Домашняя вечеринка» активирован, сэр. "
                "Свет, музыка и лёгкая самоирония включены.",
                "Отличный выбор, сэр. Режим «ВЕЧЕРИНКА» задействован.",
            ),
            description="«Протокол домашней вечеринки» — смена режима",
            priority=5,
        ),
    )
