/**
 * Безопасность — подтверждения, PIN, аудит и правила работы с путями.
 */

import { useEffect, useState } from "react";
import { Card, Notice, PageHeader } from "../components/ui/panels";
import { SettingsSaveBar } from "../components/SettingsSaveBar";
import { FieldRow, TextField, Toggle } from "../components/ui/controls";
import { useSettingsStore } from "../stores/settingsStore";

export function SecurityPage() {
  const security = useSettingsStore((s) => s.data.security);
  const loaded = useSettingsStore((s) => s.loaded);
  const patch = useSettingsStore((s) => s.patch);

  const [whitelist, setWhitelist] = useState(security.whitelist_paths.join("\n"));
  const [forbidden, setForbidden] = useState(security.forbidden_paths.join("\n"));

  useEffect(() => {
    if (!loaded) void useSettingsStore.getState().load();
  }, [loaded]);

  useEffect(() => {
    setWhitelist(security.whitelist_paths.join("\n"));
    setForbidden(security.forbidden_paths.join("\n"));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loaded]);

  const toList = (text: string): string[] =>
    text
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Безопасность"
        subtitle="Политика подтверждений, аудит действий и границы файловой системы."
      />

      <Notice tone="warn">
        Уровень риска команды определяется реестром действий. Здесь задаётся глобальная политика:
        что требует подтверждения, а что — PIN-кода.
      </Notice>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card title="Подтверждения и аудит">
          <FieldRow
            label="Подтверждать средний риск"
            hint="Команды уровня medium ждут одобрения"
            control={
              <Toggle
                checked={security.require_confirmation_medium}
                onChange={(v) => patch("security", { require_confirmation_medium: v })}
              />
            }
          />
          <FieldRow
            label="PIN для высокого риска"
            hint="Команды уровня high требуют PIN"
            control={<Toggle checked={security.pin_for_high} onChange={(v) => patch("security", { pin_for_high: v })} />}
          />
          <FieldRow
            label="Журнал аудита"
            hint="Писать все действия в audit-лог"
            control={<Toggle checked={security.audit_log} onChange={(v) => patch("security", { audit_log: v })} />}
          />
          <FieldRow
            label="Песочница скриптов"
            hint="Разрешить запуск Python/PowerShell"
            control={
              <Toggle
                checked={security.allow_shell_scripts}
                onChange={(v) => patch("security", { allow_shell_scripts: v })}
              />
            }
          />
        </Card>

        <Card title="Файловые границы" subtitle="По одному пути в строке" delay={0.05}>
          <TextField
            label="Доверенные пути (whitelist)"
            multiline
            value={whitelist}
            rows={5}
            onChange={(e) => setWhitelist(e.target.value)}
            onBlur={() => patch("security", { whitelist_paths: toList(whitelist) })}
            hint="Пути, к которым ассистент имеет доступ"
          />
          <div className="mt-3">
            <TextField
              label="Запрещённые пути (forbidden)"
              multiline
              value={forbidden}
              rows={5}
              onChange={(e) => setForbidden(e.target.value)}
              onBlur={() => patch("security", { forbidden_paths: toList(forbidden) })}
              hint="Системные каталоги — доступ запрещён всегда"
            />
          </div>
        </Card>
      </div>

      <SettingsSaveBar />
    </div>
  );
}
