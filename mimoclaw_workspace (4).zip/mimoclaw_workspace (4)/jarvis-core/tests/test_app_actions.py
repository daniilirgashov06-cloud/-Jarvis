"""
Проверка actions/app_actions.py — команды приложений.

Запуск:  python3 tests/test_app_actions.py
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from actions.app_actions import (
    AppActions,
    AppCatalog,
    AppUnavailable,
    DryRunBackend,
    SubprocessAppBackend,
    register_app_actions,
    validate_app_name,
)
from actions.registry import CommandRegistry, RiskLevel


# ---------------------------------------------------------------------------
# Хелперы
# ---------------------------------------------------------------------------
def _raises(exc_type, fn, *args, **kwargs) -> str:
    """Проверяет, что fn бросает exc_type; возвращает текст ошибки."""
    try:
        fn(*args, **kwargs)
    except exc_type as e:
        return str(e)
    raise AssertionError(f"ожидался {exc_type.__name__}, но ошибки не было")


# ---------------------------------------------------------------------------
# Тесты: валидация имён
# ---------------------------------------------------------------------------
def test_validate_app_name() -> None:
    assert validate_app_name("  firefox  ") == "firefox"
    assert validate_app_name("Visual Studio Code") == "Visual Studio Code"
    assert validate_app_name("app-v1.2+beta") == "app-v1.2+beta"

    for bad in ["", "   ", "-rf", "app; rm -rf /", "app && ls", "$(evil)",
                "a" * 65, "app|grep", "`cmd`", None, 42]:
        msg = _raises(ValueError, validate_app_name, bad)
        assert msg, "текст ошибки не должен быть пустым"


# ---------------------------------------------------------------------------
# Тесты: каталог алиасов
# ---------------------------------------------------------------------------
def test_catalog_aliases() -> None:
    cat = AppCatalog()
    assert cat.resolve("Браузер") == "firefox"
    assert cat.resolve("Chrome") == "google-chrome"
    assert cat.resolve("my-app") == "my-app"  # не алиас — как есть

    cat.add("мой редактор", "code")
    assert cat.resolve("МОЙ РЕДАКТОР") == "code"
    _raises(ValueError, cat.add, "bad;name", "code")
    _raises(ValueError, cat.add, "ok", "-rf")


# ---------------------------------------------------------------------------
# Тесты: DryRunBackend + валидация AppActions
# ---------------------------------------------------------------------------
def test_dry_run_launch_close_focus() -> None:
    backend = DryRunBackend()
    svc = AppActions(backend=backend)

    assert "запускаю" in svc.launch_app("my-app").lower()
    assert backend.calls[-1] == ("launch", ("my-app",))
    assert "my-app" in backend.list_running()

    assert "закрываю" in svc.close_app("my-app").lower()
    assert backend.calls[-1] == ("close", ("my-app",))
    assert "my-app" not in backend.list_running()

    assert "фокусирую" in svc.focus_app("browser").lower()
    assert backend.calls[-1] == ("focus", ("firefox",)), "алиас 'browser' должен резолвиться в firefox"


def test_alias_resolution_and_validation() -> None:
    backend = DryRunBackend()
    svc = AppActions(backend=backend)

    svc.launch_app("Браузер")  # алиас → firefox
    assert backend.calls[-1] == ("launch", ("firefox",))

    _raises(ValueError, svc.launch_app, "app; ls")
    _raises(ValueError, svc.close_app, "-rf")
    _raises(ValueError, svc.focus_app, "")
    assert backend.calls[-1] == ("launch", ("firefox",)), "невалидный ввод не должен доходить до backend"


def test_unavailable_backend() -> None:
    svc = AppActions(backend=DryRunBackend(available=False))
    _raises(AppUnavailable, svc.launch_app, "firefox")
    _raises(AppUnavailable, svc.close_app, "firefox")
    _raises(AppUnavailable, svc.list_running_apps)


# ---------------------------------------------------------------------------
# Тесты: SubprocessAppBackend (подменённый runner)
# ---------------------------------------------------------------------------
class RecordingRunner:
    """Фейковый runner: запоминает argv и возвращает заданный stdout."""

    def __init__(self, output: str = "") -> None:
        self.output = output
        self.calls: list[list[str]] = []

    def __call__(self, argv: list[str]) -> str:
        self.calls.append(list(argv))
        return self.output


def test_subprocess_linux_commands() -> None:
    runner = RecordingRunner(output="firefox\nbash\nfirefox\n")
    backend = SubprocessAppBackend(runner=runner, platform_name="Linux")

    assert backend.is_available()
    backend.launch("firefox")
    backend.close("firefox")
    backend.list_running()

    assert runner.calls[0] == ["firefox"]
    assert runner.calls[1] == ["pkill", "-x", "firefox"]
    assert backend.list_running() == ["bash", "firefox"]  # дубликаты схлопываются


def test_subprocess_darwin_windows_commands() -> None:
    mac = RecordingRunner()
    backend = SubprocessAppBackend(runner=mac, platform_name="Darwin")
    backend.launch("Safari")
    backend.close("Safari")
    backend.focus("Safari")
    assert mac.calls[0] == ["open", "-a", "Safari"]
    assert mac.calls[1] == ["osascript", "-e", 'tell application "Safari" to quit']
    assert mac.calls[2] == ["open", "-a", "Safari"]

    win = RecordingRunner(output='"firefox.exe","123","Console"\n"code.exe","456","Console"\n')
    backend = SubprocessAppBackend(runner=win, platform_name="Windows")
    backend.launch("firefox")
    backend.close("firefox")
    assert win.calls[0][0] == "powershell"
    assert win.calls[1] == ["taskkill", "/IM", "firefox.exe", "/F"]
    assert backend.list_running() == ["code", "firefox"]

    unknown = SubprocessAppBackend(runner=RecordingRunner(), platform_name="Plan9")
    assert not unknown.is_available()
    _raises(AppUnavailable, AppActions(backend=unknown).launch_app, "firefox")


# ---------------------------------------------------------------------------
# Тесты: регистрация команд
# ---------------------------------------------------------------------------
def test_register_app_actions() -> None:
    reg = CommandRegistry()
    names = register_app_actions(reg, AppActions(backend=DryRunBackend()))

    expected = {"list_running_apps", "focus_app", "launch_app", "close_app"}
    assert set(names) == expected
    assert set(reg.names()) == expected

    assert reg.get("list_running_apps").risk == RiskLevel.SAFE
    assert not reg.get("list_running_apps").requires_confirmation
    assert reg.get("focus_app").risk == RiskLevel.SAFE
    assert reg.get("launch_app").risk == RiskLevel.MEDIUM
    assert reg.get("launch_app").requires_confirmation
    assert reg.get("close_app").risk == RiskLevel.MEDIUM
    assert reg.get("close_app").requires_confirmation

    tool = reg.get("launch_app").to_tool()
    assert tool.params[0].name == "name"
    assert tool.params[0].type == "string"


def test_commands_run_through_registry() -> None:
    backend = DryRunBackend()
    reg = CommandRegistry()
    register_app_actions(reg, AppActions(backend=backend))

    async def _run() -> None:
        result = await reg.get("launch_app").run(name="editor")
        assert "editor" in result
        apps = await reg.get("list_running_apps").run()
        assert "editor" in apps

    asyncio.run(_run())
    assert ("launch", ("editor",)) in backend.calls
    assert ("list_running", ()) in backend.calls


# ---------------------------------------------------------------------------
# Запуск
# ---------------------------------------------------------------------------
def main() -> int:
    print("JARVIS CORE — проверка actions/app_actions")
    try:
        test_validate_app_name()
        test_catalog_aliases()
        test_dry_run_launch_close_focus()
        test_alias_resolution_and_validation()
        test_unavailable_backend()
        test_subprocess_linux_commands()
        test_subprocess_darwin_windows_commands()
        test_register_app_actions()
        test_commands_run_through_registry()
    except AssertionError as e:
        import traceback

        print(f"\n✗ FAIL: {e}")
        traceback.print_exc()
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модулей прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
