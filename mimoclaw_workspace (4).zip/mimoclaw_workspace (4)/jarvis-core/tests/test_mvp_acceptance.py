"""
Проверка core/mvp_acceptance.py — приёмка MVP «Джарвис» → команда → голосовой ответ».

Сквозной прогон на реальных компонентах ядра (Orchestrator, реестр команд с
DryRunBackend, роутеры STT/TTS/LLM) с подставляемыми краями (детектор,
приёмник звука). Проверяем: цепочка этапов, бюджет <2 сек, поведение при
отказах и пропусках.

Запуск:  python3 tests/test_mvp_acceptance.py
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from actions.registry import CommandRegistry
from actions.system_actions import DryRunBackend, SystemActions, register_system_actions
from ai.llm_router import LLMRouter
from ai.providers.base import BaseLLMProvider, LLMResponse, ToolCall
from audio.wakeword import WakeWordResult
from core.mvp_acceptance import (
    STAGE_ASSISTANT,
    STAGE_PLAYBACK,
    STAGE_STT,
    STAGE_WAKE,
    AcceptanceBudget,
    MvpAcceptance,
)
from core.orchestrator import Orchestrator
from speech.stt_engine import STTEngine, STRouter, STTUnavailable, Transcript
from speech.tts_engine import SpeechAudio, TTSEngine, TTSRouter


# ---------------------------------------------------------------------------
# Подставляемые края (микрофон/динамики/сеть)
# ---------------------------------------------------------------------------
class ScriptedLLM(BaseLLMProvider):
    """Мок-LLM: отдаёт заданную последовательность ответов (как в test_orchestrator)."""

    name = "scripted"

    def __init__(self, responses: list[LLMResponse], delay: float = 0.0) -> None:
        self.responses = responses
        self.delay = delay
        self.calls = 0

    def is_available(self) -> bool:
        return True

    async def complete(self, messages, tools=None, *, temperature=0.7, max_tokens=2048):
        if self.delay:
            await asyncio.sleep(self.delay)
        resp = self.responses[min(self.calls, len(self.responses) - 1)]
        self.calls += 1
        resp.provider = self.name
        return resp


class FakeSTT(STTEngine):
    """Мок-STT: всегда «слышит» заданную фразу."""

    name = "fake_stt"

    def __init__(self, text: str = "поставь громкость 50") -> None:
        self.text = text
        self.calls = 0

    def is_available(self) -> bool:
        return True

    async def transcribe(self, pcm, *, sample_rate=16000, language="auto") -> Transcript:
        self.calls += 1
        return Transcript(text=self.text, language="ru", engine=self.name)


class FailingSTT(STTEngine):
    """Мок-STT, который всегда недоступен (проверка fallback-отказа роутера)."""

    name = "failing_stt"

    def is_available(self) -> bool:
        return True

    async def transcribe(self, pcm, *, sample_rate=16000, language="auto") -> Transcript:
        raise STTUnavailable("модель недоступна")


class FakeTTS(TTSEngine):
    """Мок-TTS: возвращает фиксированный PCM."""

    name = "fake_tts"

    def is_available(self) -> bool:
        return True

    async def synthesize(self, text, *, preset=None) -> SpeechAudio:
        return SpeechAudio(pcm=b"\x00\x01" * 256, engine=self.name)


class FakeWake:
    """Мок детектора ключевого слова (вердикт задаётся снаружи)."""

    def __init__(self, detected: bool = True, word: str = "джарвис") -> None:
        self.detected = detected
        self.word = word
        self.calls = 0

    def detect(self, pcm: bytes, *, sample_rate: int) -> WakeWordResult:
        self.calls += 1
        return WakeWordResult(
            detected=self.detected,
            word=self.word,
            score=0.93 if self.detected else 0.12,
            engine="fake_wake",
        )


class RecordingSink:
    """Мок приёмника звука: записывает всё, что просят сыграть."""

    def __init__(self) -> None:
        self.played: list[bytes] = []

    async def speak(self, pcm: bytes) -> None:
        self.played.append(pcm)


# ---------------------------------------------------------------------------
# Сборка конвейера из РЕАЛЬНЫХ компонентов ядра
# ---------------------------------------------------------------------------
def _make_orchestrator(
    responses: list[LLMResponse],
    *,
    with_tts: bool = True,
    stt: STTEngine | None = None,
    delay: float = 0.0,
):
    """Orchestrator + реальный реестр команд на DryRunBackend (без вреда системе)."""
    backend = DryRunBackend()
    registry = CommandRegistry()
    register_system_actions(registry, SystemActions(backend=backend))

    llm = LLMRouter(
        providers={"scripted": ScriptedLLM(responses, delay=delay)},
        primary="scripted",
        fallback_chain=["scripted"],
    )
    tts = TTSRouter(engines={"fake_tts": FakeTTS()}, primary="fake_tts") if with_tts else None
    stt_engine = stt or FakeSTT()
    stt_router = STRouter(
        engines={stt_engine.name: stt_engine},
        primary=stt_engine.name,
        fallback_chain=[stt_engine.name],
    )
    orch = Orchestrator(
        llm=llm,
        tts=tts,
        stt=stt_router,
        registry=registry,
        speak=True,
    )
    return orch, backend


def _tool_then_text(reply: str = "Готово, сэр. Громкость 50%.") -> list[LLMResponse]:
    """Типичный ответ LLM: вызов команды, затем финальная реплика."""
    return [
        LLMResponse(
            content="",
            tool_calls=[ToolCall(id="c1", name="set_volume", arguments={"level": 50})],
        ),
        LLMResponse(content=reply),
    ]


# ---------------------------------------------------------------------------
# Тесты
# ---------------------------------------------------------------------------
async def test_voice_acceptance_ok() -> None:
    """Полная цепочка «Джарвис» → команда → голосовой ответ укладывается в 2 сек."""
    orch, backend = _make_orchestrator(_tool_then_text())
    wake, sink = FakeWake(), RecordingSink()
    acc = MvpAcceptance(orch, wake=wake, sink=sink)

    report = await acc.run_voice(b"\x00" * 3200)

    assert [s.name for s in report.stages] == [STAGE_WAKE, STAGE_STT, STAGE_ASSISTANT, STAGE_PLAYBACK]
    assert all(s.ok and not s.skipped for s in report.stages), report.summary()
    assert report.ok, report.summary()
    assert report.within_budget and report.total_ms < 2000.0, report.summary()
    assert report.transcript == "поставь громкость 50"
    assert report.reply == "Готово, сэр. Громкость 50%."
    assert report.actions == ["set_volume"]
    assert report.played and sink.played == [b"\x00\x01" * 256]
    assert ("set_volume", (50,)) in backend.calls, "команда дошла до DryRunBackend"
    assert wake.calls == 1
    assert report.stage(STAGE_WAKE).note.startswith("«джарвис»")
    print("  ✓ голос: wake → STT → LLM+действие → TTS → воспроизведение, <2 сек")


async def test_wake_miss_aborts_scenario() -> None:
    """Нет ключевого слова — сценарий останавливается, отчёт фиксирует провал."""
    orch, _ = _make_orchestrator(_tool_then_text())
    sink = RecordingSink()
    acc = MvpAcceptance(orch, wake=FakeWake(detected=False), sink=sink)

    report = await acc.run_voice(b"\x00" * 3200)

    assert not report.ok and report.failures, report.summary()
    assert "wake" in report.failures[0]
    assert report.stage(STAGE_WAKE).ok is False
    assert all(report.stage(n).skipped for n in (STAGE_STT, STAGE_ASSISTANT, STAGE_PLAYBACK))
    assert not sink.played and report.reply == ""
    print("  ✓ голос: нет ключевого слова → отказ, остальные этапы пропущены")


async def test_stt_failure_is_reported_not_raised() -> None:
    """Упавший STT попадает в отчёт как провал этапа, без исключения наружу."""
    orch, _ = _make_orchestrator(_tool_then_text(), stt=FailingSTT())
    acc = MvpAcceptance(orch, wake=FakeWake(), sink=RecordingSink())

    report = await acc.run_voice(b"\x00" * 3200)

    assert not report.ok, report.summary()
    assert report.stage(STAGE_STT).ok is False
    assert any("stt" in f for f in report.failures)
    assert report.stage(STAGE_ASSISTANT).skipped and report.stage(STAGE_PLAYBACK).skipped
    print("  ✓ голос: отказ STT зафиксирован в отчёте, исключение не утекает")


async def test_budget_overrun_detected() -> None:
    """Медленный LLM при жёстком бюджете — приёмка провалена по времени."""
    orch, _ = _make_orchestrator(_tool_then_text(), delay=0.05)
    acc = MvpAcceptance(
        orch,
        wake=FakeWake(),
        sink=RecordingSink(),
        budget=AcceptanceBudget(total_ms=1.0),
    )

    report = await acc.run_voice(b"\x00" * 3200)

    assert not report.within_budget and not report.ok, report.summary()
    assert any("бюджет" in f for f in report.failures)
    assert report.total_ms > 1.0
    print("  ✓ бюджет: превышение суммарного лимита ловится и ведёт к FAIL")


async def test_stage_budget_enforced() -> None:
    """Работает и попутный лимит отдельного этапа."""
    orch, _ = _make_orchestrator(_tool_then_text(), delay=0.05)
    acc = MvpAcceptance(
        orch,
        sink=RecordingSink(),
        budget=AcceptanceBudget(total_ms=2000.0, stage_ms={STAGE_ASSISTANT: 1.0}),
    )

    report = await acc.run_text("поставь громкость 50")

    assert not report.ok, report.summary()
    assert any(f"«{STAGE_ASSISTANT}»" in f and "лимит" in f for f in report.failures)
    print("  ✓ бюджет: лимит этапа assistant тоже контролируется")


async def test_missing_voice_reply_is_failure() -> None:
    """Критерий приёмки — ГОЛОСОвой ответ: TTS молчит → провал playback."""
    orch, _ = _make_orchestrator(_tool_then_text(), with_tts=False)
    sink = RecordingSink()
    acc = MvpAcceptance(orch, wake=FakeWake(), sink=sink)

    report = await acc.run_voice(b"\x00" * 3200)

    assert not report.ok, report.summary()
    stage = report.stage(STAGE_PLAYBACK)
    assert stage.ok is False and "не озвучен" in stage.note
    assert not sink.played and report.reply == "Готово, сэр. Громкость 50%."
    print("  ✓ голос: текст без озвучки — это провал приёмки")


async def test_text_scenario_skips_voice_stages() -> None:
    """run_text: без микрофона — только assistant + playback, всё зелёное."""
    orch, _ = _make_orchestrator(_tool_then_text())
    sink = RecordingSink()
    acc = MvpAcceptance(orch, wake=FakeWake(), sink=sink)

    report = await acc.run_text("поставь громкость 50")

    assert [s.name for s in report.stages] == [STAGE_ASSISTANT, STAGE_PLAYBACK]
    assert report.ok and report.played, report.summary()
    assert report.actions == ["set_volume"]
    assert len(sink.played) == 1
    print("  ✓ текст: run_text проходит без этапов wake/stt")


async def test_headless_edges_skipped() -> None:
    """Без детектора и без динамиков — логика проверяется, края помечены пропуском."""
    orch, _ = _make_orchestrator(_tool_then_text())
    acc = MvpAcceptance(orch)  # wake=None, sink=None

    report = await acc.run_voice(b"\x00" * 3200)

    assert report.ok, report.summary()
    assert report.stage(STAGE_WAKE).skipped
    assert report.stage(STAGE_PLAYBACK).skipped and not report.played
    assert report.stage(STAGE_STT).ok and report.stage(STAGE_ASSISTANT).ok
    print("  ✓ headless: края пропущены, ядро пайплайна зелёное")


def test_summary_format() -> None:
    """summary() — человекочитаемая сводка с этапами и вердиктом."""

    async def _run() -> str:
        orch, _ = _make_orchestrator(_tool_then_text())
        acc = MvpAcceptance(orch, wake=FakeWake(), sink=RecordingSink())
        return (await acc.run_voice(b"\x00" * 3200)).summary()

    text = asyncio.run(_run())
    for marker in ("Приёмка MVP [voice]", "OK", "мс", STAGE_WAKE, STAGE_ASSISTANT, "ответ:"):
        assert marker in text, f"нет маркера {marker!r} в:\n{text}"
    print("  ✓ отчёт: summary() содержит вердикт, этапы и ответ")


def main() -> int:
    print("JARVIS CORE — приёмка MVP (core/mvp_acceptance)")
    try:
        asyncio.run(_run_async())
        test_summary_format()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки приёмки MVP прошли.")
    return 0


async def _run_async() -> None:
    await test_voice_acceptance_ok()
    await test_wake_miss_aborts_scenario()
    await test_stt_failure_is_reported_not_raised()
    await test_budget_overrun_detected()
    await test_stage_budget_enforced()
    await test_missing_voice_reply_is_failure()
    await test_text_scenario_skips_voice_stages()
    await test_headless_edges_skipped()


if __name__ == "__main__":
    raise SystemExit(main())
