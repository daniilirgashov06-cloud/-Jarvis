"""
Суммаризатор памяти JARVIS CORE (ТЗ-5, «вечная память»).

Сжимает длинные тексты, диалоги и накопленные записи памяти в компактные
сводки, которые потом сохраняются как ``MemoryRecord(kind=SUMMARY)`` и
подаются в контекст LLM. Работает по принципу **локально-first**:

- ``ExtractiveSummarizer`` — локальная экстрактивная сводка на чистом Python
  (частотный скоринг предложений + позиционный бонус), без зависимостей и
  без сети — работает всегда, это гарантированный fallback;
- ``LLMSummarizer`` — «умная» абстрактивная сводка через любой LLM-клиент
  (``ai.llm_router.LLMRouter`` или совместимый) — локальная модель (Ollama)
  или облако, по выбору роутера;
- ``SummarizerRouter`` — смена движков (локально ↔ облако) и fallback-цепочка:
  если «умный» движок упал или недоступен, молча переходим к локальному;
- ``MemorySummarizer`` — фасад поверх роутера и ``MemoryStore``: сводка
  текста, записей памяти и диалога + сохранение сводки обратно в память.

Ошибки сводки (``SummaryError`` / ``SummarizerUnavailable``) никогда не
роняют конвейер: роутер при исчерпании цепочки деградирует до встроенной
экстрактивной сводки, а не падает.

Использование:
    from memory.summarizer import MemorySummarizer, default_summarizer_router

    sm = MemorySummarizer(default_summarizer_router(llm=router), store=store)
    result = await sm.summarize_text(длинный_текст, max_sentences=3)
    rec = await sm.summarize_and_store(длинный_текст, tags=["брифинг"])
    digest = await sm.summarize_records(store.list_recent(limit=50))
"""

from __future__ import annotations

import abc
import logging
import math
import re
from dataclasses import dataclass, field
from typing import Any, Iterable, Sequence

from memory.store import MemoryKind, MemoryRecord, MemoryStore

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Константы и валидация
# ---------------------------------------------------------------------------
MAX_INPUT_LEN = 200_000      # максимум символов во входном тексте
MAX_SENTENCES_CAP = 50       # жёсткий потолок числа предложений в сводке
MIN_SUMMARY_CHARS = 40       # минимум символов в max_chars сводки
MAX_OUTPUT_LEN = 8000        # потолок длины сводки (как MAX_CONTENT_LEN в store)

# Управляющие символы, кроме \t и \n (переводы строк в тексте допустимы)
_CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

# Разбиение на предложения: граница после .!?… и перевод строки
_SENT_SPLIT_RE = re.compile(r"(?<=[.!?…])\s+|\n+")

# Слова для частотного скоринга (латиница/кириллица, допускаем дефис)
_WORD_RE = re.compile(r"[0-9a-zA-Zа-яА-ЯёЁ]{2,}")

# Слова-паразиты/служебные — не несут смысла для сводки
_STOPWORDS = frozenset(
    """
    и а но или же бы ли то есть в во на не он она оно они мы вы я ты это тот
    эта эти что как для при из у к с со по о об от до за над под про без между
    же бы ли ну да нет так тоже также ещё еще бы был была было были быть есть
    весь вся все всё свой своя свое свои мой моя мои наш наша наше наши
    the a an and or but if of to in on at for with without from by as is are
    was were be been it this that these those i you he she we they them his her
    its our your their not no yes do does did done have has had will would can
    """.split()
)


def _clean_input(text: str) -> str:
    """Валидация входного текста: str, непустой, в пределах длины, без мусора."""
    if not isinstance(text, str):
        raise ValueError("text: ожидается str")
    cleaned = text.strip()
    if not cleaned:
        raise ValueError("text: пустое значение")
    if len(cleaned) > MAX_INPUT_LEN:
        raise ValueError(f"text: превышена длина {MAX_INPUT_LEN}")
    if _CTRL_RE.search(cleaned):
        raise ValueError("text: недопустимые управляющие символы")
    return cleaned


def _clean_output(text: str, *, max_chars: int) -> str:
    """Нормализация готовой сводки: без мусора, в пределах max_chars."""
    cleaned = _CTRL_RE.sub("", text).strip()
    if not cleaned:
        raise ValueError("сводка пуста")
    if len(cleaned) > max_chars:
        cut = cleaned[: max_chars - 1]
        # Не режем посреди слова — отступаем к последней границе
        boundary = max(cut.rfind(" "), cut.rfind("\n"))
        if boundary > max_chars // 2:
            cut = cut[:boundary]
        cleaned = cut.rstrip(" ,.;:—-") + "…"
    return cleaned


def _validate_params(max_sentences: int, max_chars: int) -> tuple[int, int]:
    """Параметры сводки: целые числа в допустимых диапазонах."""
    if isinstance(max_sentences, bool) or not isinstance(max_sentences, int):
        raise ValueError("max_sentences: ожидается int")
    if not 1 <= max_sentences <= MAX_SENTENCES_CAP:
        raise ValueError(f"max_sentences: вне диапазона [1, {MAX_SENTENCES_CAP}]")
    if isinstance(max_chars, bool) or not isinstance(max_chars, int):
        raise ValueError("max_chars: ожидается int")
    if not MIN_SUMMARY_CHARS <= max_chars <= MAX_OUTPUT_LEN:
        raise ValueError(f"max_chars: вне диапазона [{MIN_SUMMARY_CHARS}, {MAX_OUTPUT_LEN}]")
    return max_sentences, max_chars


def split_sentences(text: str) -> list[str]:
    """Разбить текст на предложения (упрощённо, без библиотек)."""
    parts = (p.strip() for p in _SENT_SPLIT_RE.split(text))
    return [p for p in parts if p]


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class SummaryError(Exception):
    """Базовая ошибка суммаризатора."""


class SummarizerUnavailable(SummaryError):
    """Движок сводки недоступен или упал — нужен fallback."""


# ---------------------------------------------------------------------------
# Сущность результата
# ---------------------------------------------------------------------------
@dataclass
class SummaryResult:
    """Результат сводки: текст + метрики сжатия (для логов и панели)."""

    text: str
    engine: str
    source_chars: int
    source_sentences: int
    used_sentences: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.text = _clean_output(self.text, max_chars=MAX_OUTPUT_LEN)
        if not self.engine or _CTRL_RE.search(self.engine):
            raise ValueError("engine: некорректное имя движка")
        if self.source_chars < 0 or self.source_sentences < 0 or self.used_sentences < 0:
            raise ValueError("метрики сводки не могут быть отрицательными")

    @property
    def ratio(self) -> float:
        """Коэффициент сжатия (длина сводки / длина источника), 0..1."""
        return len(self.text) / self.source_chars if self.source_chars else 0.0

    def to_dict(self) -> dict[str, Any]:
        """Сериализация для панели/логов."""
        return {
            "text": self.text,
            "engine": self.engine,
            "source_chars": self.source_chars,
            "source_sentences": self.source_sentences,
            "used_sentences": self.used_sentences,
            "ratio": round(self.ratio, 3),
            "metadata": dict(self.metadata),
        }


# ---------------------------------------------------------------------------
# Контракт движка
# ---------------------------------------------------------------------------
class SummarizerEngine(abc.ABC):
    """Абстрактный движок сводки (контракт)."""

    name: str = "base"

    def is_available(self) -> bool:
        """Готов ли движок работать прямо сейчас (без сети/зависимостей?)."""
        return True

    def describe(self) -> dict[str, Any]:
        """Статус для панели."""
        return {"name": self.name, "available": self.is_available()}

    @abc.abstractmethod
    async def summarize(
        self, text: str, *, max_sentences: int = 3, max_chars: int = 600
    ) -> SummaryResult:
        """Сжать ``text`` до компактной сводки."""


# ---------------------------------------------------------------------------
# Локальный экстрактивный движок
# ---------------------------------------------------------------------------
class ExtractiveSummarizer(SummarizerEngine):
    """
    Экстрактивная сводка на чистом Python: выбирает самые «содержательные»
    предложения и сохраняет их в исходном порядке.

    Скоринг предложения: средняя частота содержательных слов (нормированная
    на √длины) + бонус за раннюю позицию. Детерминированно, без зависимостей,
    работает офлайн — поэтому это гарантированный fallback всего роутера.
    """

    name = "extractive"

    def __init__(self, *, stopwords: Iterable[str] | None = None) -> None:
        self._stopwords = frozenset(stopwords) if stopwords is not None else _STOPWORDS

    def _score(self, sentences: Sequence[str]) -> list[float]:
        """Частотный скоринг предложений."""
        freq: dict[str, int] = {}
        for sent in sentences:
            for word in _WORD_RE.findall(sent.lower()):
                if word not in self._stopwords:
                    freq[word] = freq.get(word, 0) + 1
        if not freq:
            # Текст из служебных слов — ранжируем по позиции
            return [1.0 / (i + 1) for i in range(len(sentences))]

        scores: list[float] = []
        for i, sent in enumerate(sentences):
            words = [w for w in _WORD_RE.findall(sent.lower()) if w not in self._stopwords]
            if not words:
                scores.append(0.0)
                continue
            total = sum(freq[w] for w in words)
            score = total / (math.sqrt(len(words)) * math.sqrt(len(sentences)))
            score *= 1.15 if i == 0 else 1.0  # первое предложение часто — тезис
            scores.append(score)
        return scores

    async def summarize(
        self, text: str, *, max_sentences: int = 3, max_chars: int = 600
    ) -> SummaryResult:
        """Выбрать top-N предложений по скорингу, сохранив исходный порядок."""
        text = _clean_input(text)
        max_sentences, max_chars = _validate_params(max_sentences, max_chars)

        sentences = split_sentences(text)
        if not sentences:
            raise SummarizerUnavailable("не удалось разобрать текст на предложения")

        if len(sentences) <= max_sentences:
            chosen = list(sentences)
        else:
            scores = self._score(sentences)
            ranked = sorted(range(len(sentences)), key=lambda i: (-scores[i], i))
            chosen = [sentences[i] for i in sorted(ranked[:max_sentences])]

        # Укладываемся в max_chars: добираем по порядку, хвост отбрасываем
        picked: list[str] = []
        used_chars = 0
        for sent in chosen:
            extra = len(sent) + (1 if picked else 0)
            if used_chars + extra > max_chars:
                if not picked:  # одно предложение не влезает — режем его
                    picked.append(_clean_output(sent, max_chars=max_chars))
                    used_chars = max_chars
                break
            picked.append(sent)
            used_chars += extra

        summary = _clean_output("\n".join(picked), max_chars=max_chars)
        return SummaryResult(
            text=summary,
            engine=self.name,
            source_chars=len(text),
            source_sentences=len(sentences),
            used_sentences=len(picked),
        )


# ---------------------------------------------------------------------------
# LLM-движок (локально ↔ облако)
# ---------------------------------------------------------------------------
class LLMSummarizer(SummarizerEngine):
    """
    Абстрактивная сводка через LLM-клиент (``ai.llm_router.LLMRouter`` или
    совместимый объект с ``async ask(messages, ...) -> ответ``).

    Клиент может указывать на локальную модель (Ollama) или облако — движку
    всё равно, он лишь формирует промпт и чистит ответ. Любой сбой клиента
    превращается в ``SummarizerUnavailable`` — дальше сработает fallback
    роутера.
    """

    name = "llm"

    def __init__(
        self,
        llm: Any,
        *,
        system_prompt: str | None = None,
        max_tokens: int = 400,
        temperature: float = 0.3,
    ) -> None:
        if llm is None:
            raise ValueError("llm: клиент не задан")
        if isinstance(max_tokens, bool) or not isinstance(max_tokens, int) or max_tokens < 1:
            raise ValueError("max_tokens: ожидается положительный int")
        self._llm = llm
        self._max_tokens = max_tokens
        self._temperature = temperature
        self._system_prompt = system_prompt or (
            "Ты — суммаризатор памяти ассистента JARVIS. Сожми текст до краткой "
            "сводки на русском языке: только ключевые факты, имена, числа и "
            "решения. Без вступлений и комментариев, максимум 3 предложения."
        )

    def is_available(self) -> bool:
        """Доступен ли у клиента хотя бы один провайдер (если это умеет проверять)."""
        checker = getattr(self._llm, "available_providers", None)
        if callable(checker):
            try:
                return bool(checker())
            except Exception:  # noqa: BLE001 — статус не должен ронять панель
                return False
        return True

    async def summarize(
        self, text: str, *, max_sentences: int = 3, max_chars: int = 600
    ) -> SummaryResult:
        """Отправить текст в LLM и получить абстрактивную сводку."""
        text = _clean_input(text)
        max_sentences, max_chars = _validate_params(max_sentences, max_chars)

        instruction = (
            f"Сводка: не более {max_sentences} предложений и {max_chars} символов."
        )
        try:
            resp = await self._llm.ask(
                [
                    {"role": "system", "content": self._system_prompt},
                    {"role": "user", "content": f"{instruction}\n\nТекст:\n{text}"},
                ],
                max_tokens=self._max_tokens,
                temperature=self._temperature,
            )
        except Exception as exc:  # noqa: BLE001 — любой сбой LLM → fallback
            raise SummarizerUnavailable(f"LLM-сводка не удалась: {exc}") from exc

        raw = resp if isinstance(resp, str) else getattr(resp, "content", "")
        if not isinstance(raw, str) or not raw.strip():
            raise SummarizerUnavailable("LLM вернул пустую сводку")

        try:
            summary = _clean_output(raw, max_chars=max_chars)
        except ValueError as exc:
            raise SummarizerUnavailable(f"некорректный ответ LLM: {exc}") from exc

        return SummaryResult(
            text=summary,
            engine=self.name,
            source_chars=len(text),
            source_sentences=len(split_sentences(text)),
            used_sentences=len(split_sentences(summary)),
        )


# ---------------------------------------------------------------------------
# Роутер: смена движков + fallback
# ---------------------------------------------------------------------------
class SummarizerRouter:
    """
    Маршрутизирует сводку по движкам: смена локально ↔ облако, fallback-цепочка.

    ``engine=`` — явный движок (без fallback): если он упал, ошибка уходит
    наружу. Без явного движка цепочка пробует по очереди все зарегистрированные,
    а при полном отказе деградирует до встроенной экстрактивной сводки —
    сводка **не должна** ронять конвейер памяти.
    """

    def __init__(
        self,
        engines: Sequence[SummarizerEngine] | None = None,
        *,
        primary: str | None = None,
    ) -> None:
        self._engines: dict[str, SummarizerEngine] = {}
        self._order: list[str] = []
        self._primary = primary
        self._last_resort = ExtractiveSummarizer()
        for eng in engines or ():
            self.register(eng)

    # -- управление движками ------------------------------------------------
    @property
    def primary(self) -> str | None:
        """Имя основного движка (или None — тогда порядок регистрации)."""
        return self._primary

    def register(self, engine: SummarizerEngine) -> None:
        """Добавить/заменить движок."""
        self._engines[engine.name] = engine
        if engine.name not in self._order:
            self._order.append(engine.name)
        if self._primary is None:
            self._primary = engine.name

    def set_primary(self, name: str) -> None:
        """Сменить основной движок (локально ↔ облако)."""
        if name not in self._engines:
            raise SummaryError(f"неизвестный движок сводки: {name}")
        self._primary = name

    def available(self) -> list[str]:
        """Имена движков, готовых отвечать прямо сейчас."""
        return [n for n in self._order if self._engines[n].is_available()]

    def engine_status(self) -> list[dict[str, Any]]:
        """Статусы всех движков для панели."""
        return [self._engines[n].describe() for n in self._order]

    def _chain(self, explicit: str | None) -> list[SummarizerEngine]:
        """Цепочка движков: явный выбор или основной + остальные по порядку."""
        if explicit is not None:
            eng = self._engines.get(explicit)
            if eng is None:
                raise SummaryError(f"неизвестный движок сводки: {explicit}")
            return [eng]
        names = list(self._order)
        if self._primary in names:
            names.remove(self._primary)
            names.insert(0, self._primary)
        return [self._engines[n] for n in names]

    # -- сводка --------------------------------------------------------------
    async def summarize(
        self,
        text: str,
        *,
        max_sentences: int = 3,
        max_chars: int = 600,
        engine: str | None = None,
    ) -> SummaryResult:
        """Сводка с fallback-цепочкой (см. докстринг класса)."""
        text = _clean_input(text)
        max_sentences, max_chars = _validate_params(max_sentences, max_chars)

        chain = self._chain(engine)
        last_error: Exception | None = None
        for eng in chain:
            if not eng.is_available():
                logger.debug("Движок '%s' недоступен, пробуем следующий", eng.name)
                last_error = SummarizerUnavailable(f"{eng.name}: недоступен")
                continue
            try:
                return await eng.summarize(
                    text, max_sentences=max_sentences, max_chars=max_chars
                )
            except (SummaryError, ValueError) as exc:
                logger.warning("Движок сводки '%s' упал: %s", eng.name, exc)
                last_error = exc
                continue

        # Явный выбор — без тихих подмен; иначе — гарантированный деградант
        if engine is not None:
            raise SummarizerUnavailable(
                f"Движок '{engine}' не справился. Последняя ошибка: {last_error}"
            )
        logger.warning("Все движки сводки упали (%s) — деградация в extractive", last_error)
        return await self._last_resort.summarize(
            text, max_sentences=max_sentences, max_chars=max_chars
        )


def default_summarizer_router(llm: Any = None) -> SummarizerRouter:
    """
    Фабрика «локально-first»: LLM-сводка (если клиент задан) → локальная
    экстрактивная. Клиент может указывать на Ollama (локально) или облако.
    """
    engines: list[SummarizerEngine] = []
    if llm is not None:
        try:
            engines.append(LLMSummarizer(llm))
        except ValueError:
            logger.debug("LLM-клиент не подошёл для сводки — только extractive")
    engines.append(ExtractiveSummarizer())
    return SummarizerRouter(engines)


# ---------------------------------------------------------------------------
# Фасад для памяти
# ---------------------------------------------------------------------------
class MemorySummarizer:
    """
    Сводка текста/записей/диалога с сохранением результата в память.

    Обёртка над ``SummarizerRouter`` и ``MemoryStore``: собирает сводки для
    утреннего брифинга, «дайджеста за день» и сжатия истории диалога перед
    подачей в контекст LLM.
    """

    def __init__(
        self,
        router: SummarizerRouter | None = None,
        *,
        store: MemoryStore | None = None,
        session_id: str | None = None,
    ) -> None:
        self.router = router if router is not None else default_summarizer_router()
        self.store = store
        self.session_id = session_id

    async def summarize_text(
        self,
        text: str,
        *,
        max_sentences: int = 3,
        max_chars: int = 600,
        engine: str | None = None,
    ) -> SummaryResult:
        """Сжать произвольный текст."""
        return await self.router.summarize(
            text, max_sentences=max_sentences, max_chars=max_chars, engine=engine
        )

    async def summarize_records(
        self,
        records: Iterable[MemoryRecord],
        *,
        max_sentences: int = 5,
        max_chars: int = 800,
        engine: str | None = None,
    ) -> SummaryResult:
        """Сводка по записям памяти («дайджест за день»)."""
        lines: list[str] = []
        for rec in records:
            line = f"[{rec.kind.value}] {rec.content}"
            if rec.tags:
                line += f" (теги: {', '.join(rec.tags)})"
            lines.append(line)
        if not lines:
            raise ValueError("records: пустой список")
        return await self.summarize_text(
            "\n".join(lines),
            max_sentences=max_sentences,
            max_chars=max_chars,
            engine=engine,
        )

    async def summarize_conversation(
        self,
        messages: Iterable[dict[str, Any]],
        *,
        max_sentences: int = 5,
        max_chars: int = 800,
        engine: str | None = None,
    ) -> SummaryResult:
        """Сводка диалога в формате role/content (как история у LLM)."""
        lines: list[str] = []
        for msg in messages:
            if not isinstance(msg, dict):
                raise ValueError("messages: ожидаются словари role/content")
            role = msg.get("role", "user")
            if not isinstance(role, str) or not role.strip():
                raise ValueError("messages: role должен быть непустой строкой")
            content = str(msg.get("content", "")).strip()
            if content:
                lines.append(f"{role}: {content}")
        if not lines:
            raise ValueError("messages: нет сообщений с контентом")
        return await self.summarize_text(
            "\n".join(lines),
            max_sentences=max_sentences,
            max_chars=max_chars,
            engine=engine,
        )

    async def summarize_and_store(
        self,
        text: str,
        *,
        store: MemoryStore | None = None,
        tags: Iterable[str] = (),
        importance: float = 0.6,
        max_sentences: int = 3,
        max_chars: int = 600,
        engine: str | None = None,
    ) -> MemoryRecord:
        """
        Сжать текст и сохранить сводку как ``MemoryRecord(kind=SUMMARY)``.

        Приватность (INCOGNITO и т.п.) — забота хранилища: оно само решит,
        персистить ли запись. Если хранилище не задано нигде — ``SummaryError``.
        """
        target = store if store is not None else self.store
        if target is None:
            raise SummaryError("не задано хранилище памяти (store)")
        result = await self.summarize_text(
            text,
            max_sentences=max_sentences,
            max_chars=max_chars,
            engine=engine,
        )
        # Хранилище не принимает управляющие символы — склеиваем строки сводки
        record = MemoryRecord(
            kind=MemoryKind.SUMMARY,
            content=" ".join(result.text.split()),
            tags=tuple(tags),
            importance=importance,
            session_id=self.session_id,
            metadata=result.to_dict(),
        )
        return target.add(record)
