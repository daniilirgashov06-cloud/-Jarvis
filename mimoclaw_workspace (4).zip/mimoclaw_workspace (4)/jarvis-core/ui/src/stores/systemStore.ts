/**
 * Стор системного состояния: WS-соединение, статус ядра, лента событий,
 * ответы команд, VU-метр и метрики для мини-графиков.
 */

import { create } from "zustand";
import type {
  BusEvent,
  CommandReply,
  ConnectionState,
  StatusSnapshot,
} from "../types/api";

const EVENTS_LIMIT = 300;
const REPLIES_LIMIT = 50;
export const METRIC_POINTS = 40;

export interface MetricsSeries {
  events: number[];
  commands: number[];
  errors: number[];
  vu: number[];
}

interface SystemState {
  connection: ConnectionState;
  status: StatusSnapshot | null;
  events: BusEvent[];
  replies: CommandReply[];
  /** Текущий уровень VU-метра 0..1. */
  vu: number;
  metrics: MetricsSeries;
  lastEventTopic: string;

  setConnection: (connection: ConnectionState) => void;
  setStatus: (status: StatusSnapshot) => void;
  pushEvent: (event: BusEvent) => void;
  pushReply: (reply: CommandReply) => void;
  setVu: (level: number) => void;
  decayVu: () => void;
  sampleMetrics: () => void;
  clearEvents: () => void;
  clearReplies: () => void;
}

function pushBounded<T>(list: T[], item: T, limit: number): T[] {
  const next = [...list, item];
  return next.length > limit ? next.slice(next.length - limit) : next;
}

function pushPoint(series: number[], value: number): number[] {
  const next = [...series, value];
  return next.length > METRIC_POINTS ? next.slice(next.length - METRIC_POINTS) : next;
}

const emptySeries = (): MetricsSeries => ({
  events: [],
  commands: [],
  errors: [],
  vu: [],
});

/** Предыдущие значения счётчиков — для дельт на мини-графиках. */
let prevEvents = -1;
let prevCommands = -1;
let prevErrors = -1;

export const useSystemStore = create<SystemState>((set, get) => ({
  connection: "connecting",
  status: null,
  events: [],
  replies: [],
  vu: 0,
  metrics: emptySeries(),
  lastEventTopic: "",

  setConnection: (connection) => set({ connection }),

  setStatus: (status) => set({ status }),

  pushEvent: (event) =>
    set((state) => ({
      events: pushBounded(state.events, event, EVENTS_LIMIT),
      lastEventTopic: event.topic,
    })),

  pushReply: (reply) => set((state) => ({ replies: pushBounded(state.replies, reply, REPLIES_LIMIT) })),

  setVu: (level) => set({ vu: Math.min(1, Math.max(0, level)) }),

  decayVu: () => set((state) => ({ vu: state.vu * 0.82 })),

  sampleMetrics: () => {
    const { status, vu, metrics } = get();
    const counters = status?.counters ?? { events: 0, commands: 0, errors: 0 };
    const dEvents = prevEvents < 0 ? 0 : Math.max(0, counters.events - prevEvents);
    const dCommands = prevCommands < 0 ? 0 : Math.max(0, counters.commands - prevCommands);
    const dErrors = prevErrors < 0 ? 0 : Math.max(0, counters.errors - prevErrors);
    prevEvents = counters.events;
    prevCommands = counters.commands;
    prevErrors = counters.errors;
    set({
      metrics: {
        events: pushPoint(metrics.events, dEvents),
        commands: pushPoint(metrics.commands, dCommands),
        errors: pushPoint(metrics.errors, dErrors),
        vu: pushPoint(metrics.vu, vu),
      },
    });
  },

  clearEvents: () => set({ events: [] }),
  clearReplies: () => set({ replies: [] }),
}));
