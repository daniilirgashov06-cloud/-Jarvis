/**
 * Мини-helpers оформления и форматирования.
 */

/** Склеить классы: `clsx("a", cond && "b", undefined)` -> "a b". */
export function clsx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

/** Аптайм в человекочитаемый вид: "3д 04:12:09", "04:12:09", "12:09". */
export function formatUptime(seconds: number): string {
  const total = Math.max(0, Math.floor(seconds));
  const d = Math.floor(total / 86400);
  const h = Math.floor((total % 86400) / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const hh = String(h).padStart(2, "0");
  const mm = String(m).padStart(2, "0");
  const ss = String(s).padStart(2, "0");
  if (d > 0) return `${d}д ${hh}:${mm}:${ss}`;
  if (h > 0) return `${hh}:${mm}:${ss}`;
  return `${mm}:${ss}`;
}

/** Время события: "14:03:21". */
export function formatClock(ts: number): string {
  const date = new Date(ts * 1000);
  return date.toLocaleTimeString("ru-RU", { hour12: false });
}

/** Число с разделителями разрядов. */
export function formatNumber(value: number): string {
  return value.toLocaleString("ru-RU");
}
