"""
«Диагностика костюма» — загрузочная анимация JARVIS CORE (фишки «Железного человека»).

Модуль хранит **данные** для анимации запуска (в духе «Инициализация
системы… Проверка реактора…»): строки с таймингами, прогресс, кадры для
рендера. Никакой графики — только таймлайн и состояние, чтобы анимацию
можно было отрисовать чем угодно (терминал, оверлей, TTS-субтитры).

Понятия:

- ``BootLine``      — строка диагностики: текст, пауза перед показом,
  длительность «проверки», тип (info/check/ok/warn);
- ``BootSequence``  — упорядоченный таймлайн строк: ``total_ms``,
  ``progress_at(t)``, ``frame_at(t)`` → ``BootFrame``;
- ``BootFrame``     — кадр анимации в момент времени ``t_ms``: активная
  строка, прогресс её «печати», общий прогресс, флаг завершения;
- ``typed_text``    — «печать по буквам» для текущей строки;
- пресеты: ``suit_diagnostic()`` (полная диагностика Марк-42),
  ``minimal_boot()`` (короткий запуск).

Типовой сценарий (тик 50 мс)::

    seq = suit_diagnostic()
    for frame in seq.frames(tick_ms=50):
        draw(frame)            # или await asyncio.sleep(0.05)
        if frame.complete:
            break
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Iterator

__all__ = [
    "BootLine",
    "BootFrame",
    "BootSequence",
    "typed_text",
    "suit_diagnostic",
    "minimal_boot",
]


# ---------------------------------------------------------------------------
# Строка диагностики
# ---------------------------------------------------------------------------
#: допустимые типы строк (влияют на оформление, не на логику)
LINE_KINDS: tuple[str, ...] = ("info", "check", "ok", "warn")


@dataclass(frozen=True)
class BootLine:
    """
    Одна строка загрузочной диагностики.

    ``delay_ms``    — пауза перед началом показа строки;
    ``duration_ms`` — сколько строка «печатается/проверяется»;
    ``kind``        — тип: info | check | ok | warn.
    """

    text: str
    delay_ms: int = 0
    duration_ms: int = 400
    kind: str = "check"

    def __post_init__(self) -> None:
        if not self.text.strip():
            raise ValueError("текст строки диагностики не может быть пустым")
        if self.delay_ms < 0:
            raise ValueError(f"delay_ms должен быть >= 0, получено: {self.delay_ms!r}")
        if self.duration_ms <= 0:
            raise ValueError(f"duration_ms должен быть > 0, получено: {self.duration_ms!r}")
        if self.kind not in LINE_KINDS:
            raise ValueError(f"kind должен быть одним из {LINE_KINDS}, получено: {self.kind!r}")


# ---------------------------------------------------------------------------
# Кадр анимации
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class BootFrame:
    """
    Кадр загрузочной анимации в момент времени ``t_ms``.

    ``line_index``  — индекс активной строки (``-1`` — ещё не начали);
    ``line``        — сама строка (``None`` до старта и после финиша);
    ``line_progress``  — прогресс «печати» активной строки 0..1;
    ``progress``    — общий прогресс всей диагностики 0..1;
    ``done_count``  — сколько строк уже завершено;
    ``complete``    — True, когда диагностика полностью закончена.
    """

    t_ms: int
    line_index: int
    line: BootLine | None
    line_progress: float
    progress: float
    done_count: int
    complete: bool

    @property
    def text(self) -> str:
        """Текст активной строки с учётом «печати» по буквам (или «»)."""
        if self.line is None:
            return ""
        return typed_text(self.line.text, self.line_progress)


def typed_text(text: str, progress: float) -> str:
    """
    «Печать по буквам»: первые ``progress * len(text)`` символов строки.

    ``progress`` ограничивается 0..1; при 1.0 возвращается текст целиком.
    Любая положительная стадия показывает минимум один символ.
    """
    if progress != progress:  # NaN
        progress = 0.0
    frac = max(0.0, min(1.0, float(progress)))
    n = 0 if frac == 0.0 else min(len(text), math.ceil(frac * len(text)))
    return text[:n]


# ---------------------------------------------------------------------------
# Последовательность загрузки
# ---------------------------------------------------------------------------
@dataclass
class BootSequence:
    """
    Таймлайн загрузочной диагностики: строки + паузы + прогресс.

    Строки идут строго по порядку: перед строкой выжидается ``delay_ms``,
    затем строка «печатается» ``duration_ms``. Общее время — сумма всех
    пауз и длительностей.
    """

    name: str
    lines: list[BootLine] = field(default_factory=list)
    footer: str = "СИСТЕМА ГОТОВА"

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise ValueError("имя последовательности не может быть пустым")

    # -- таймлайн ---------------------------------------------------------
    def timeline(self) -> list[tuple[int, int]]:
        """
        Интервалы ``(start_ms, end_ms)`` показа каждой строки.

        Интервалы строго растут и не пересекаются; паузы между строками
        входят в ``start_ms`` следующей строки.
        """
        out: list[tuple[int, int]] = []
        cursor = 0
        for line in self.lines:
            start = cursor + line.delay_ms
            end = start + line.duration_ms
            out.append((start, end))
            cursor = end
        return out

    @property
    def total_ms(self) -> int:
        """Общая длительность диагностики, мс."""
        spans = self.timeline()
        return spans[-1][1] if spans else 0

    def progress_at(self, t_ms: float) -> float:
        """
        Общий прогресс диагностики 0..1 в момент ``t_ms``.

        Считается по завершённым строкам: полностью отработавшая строка
        даёт полный вклад, активная — пропорционально своей длительности.
        """
        if not self.lines:
            return 1.0
        if t_ms != t_ms:  # NaN
            return 0.0
        t = max(0.0, float(t_ms))
        spans = self.timeline()
        if t >= self.total_ms:
            return 1.0
        done = 0.0
        for (start, end) in spans:
            if t >= end:
                done += 1.0
            elif t > start:
                done += (t - start) / (end - start)
                break
            else:
                break
        return max(0.0, min(1.0, done / len(self.lines)))

    def active_index_at(self, t_ms: float) -> int:
        """
        Индекс активной (текущей или ближайшей) строки в момент ``t_ms``.

        В паузе между строками возвращается индекс следующей строки (её
        показ ещё не начался — прогресс печати равен 0). ``-1`` — диагностика
        ещё не началась; ``len(lines)`` — уже закончена.
        """
        t = max(0.0, float(t_ms))
        spans = self.timeline()
        if not spans:
            return 0
        if t < spans[0][0]:
            return -1
        for i, (_start, end) in enumerate(spans):
            if t < end:
                return i
        return len(self.lines)

    def frame_at(self, t_ms: float) -> BootFrame:
        """Кадр анимации в момент ``t_ms`` (см. ``BootFrame``)."""
        t = max(0.0, float(t_ms))
        idx = self.active_index_at(t)
        spans = self.timeline()
        if 0 <= idx < len(self.lines):
            start, end = spans[idx]
            line_progress = (t - start) / (end - start)
            line: BootLine | None = self.lines[idx]
            done_count = idx
            complete = False
        elif idx >= len(self.lines):
            line_progress = 1.0
            line = None
            done_count = len(self.lines)
            complete = True
        else:  # ещё не начали
            line_progress = 0.0
            line = None
            done_count = 0
            complete = False
        return BootFrame(
            t_ms=int(t),
            line_index=idx,
            line=line,
            line_progress=max(0.0, min(1.0, line_progress)),
            progress=self.progress_at(t),
            done_count=done_count,
            complete=complete or (not self.lines),
        )

    def frames(self, tick_ms: int = 50) -> Iterator[BootFrame]:
        """
        Генератор кадров с шагом ``tick_ms`` (включая финальный кадр).

        Последний кадр всегда ``complete=True`` — цикл гарантированно
        завершается даже при нестандартных таймингах.
        """
        if tick_ms <= 0:
            raise ValueError(f"tick_ms должен быть > 0, получено: {tick_ms!r}")
        t = 0
        while t < self.total_ms:
            yield self.frame_at(t)
            t += tick_ms
        yield self.frame_at(self.total_ms)

    def to_dict(self) -> dict[str, object]:
        """Описание последовательности (для UI/настроек)."""
        return {
            "name": self.name,
            "footer": self.footer,
            "total_ms": self.total_ms,
            "lines": [
                {
                    "text": line.text,
                    "delay_ms": line.delay_ms,
                    "duration_ms": line.duration_ms,
                    "kind": line.kind,
                }
                for line in self.lines
            ],
        }


# ---------------------------------------------------------------------------
# Пресеты
# ---------------------------------------------------------------------------
def suit_diagnostic() -> BootSequence:
    """
    Полная «диагностика костюма» в духе JARVIS: ~6 секунд проверок.

    Строки даны в стиле боевого интерфейса Тони Старка — их можно
    озвучивать через TTS и печатать в HUD.
    """
    return BootSequence(
        name="suit_diagnostic",
        lines=[
            BootLine("ИНИЦИАЛИЗАЦИЯ ЯДРА JARVIS", delay_ms=200, duration_ms=700, kind="info"),
            BootLine("ДИАГНОСТИКА КОСТУМА МАРК 42 ...", delay_ms=150, duration_ms=800, kind="check"),
            BootLine("ПРОВЕРКА ДУГОВОГО РЕАКТОРА ... ОК", delay_ms=150, duration_ms=700, kind="ok"),
            BootLine("КАЛИБРОВКА ГИРОСКОПОВ ... ОК", delay_ms=120, duration_ms=600, kind="ok"),
            BootLine("ТЕПЛОВОЙ ЩИТ ... 98%", delay_ms=120, duration_ms=600, kind="check"),
            BootLine("РЕПУЛЬСОРЫ: ЗАРЯД 100%", delay_ms=120, duration_ms=600, kind="ok"),
            BootLine("ГОЛОСОВОЙ ИНТЕРФЕЙС ... ОНЛАЙН", delay_ms=150, duration_ms=700, kind="ok"),
            BootLine("ВСЕ СИСТЕМЫ В НОРМЕ, СЭР", delay_ms=250, duration_ms=800, kind="info"),
        ],
        footer="ВСЕ СИСТЕМЫ В НОРМЕ, СЭР",
    )


def minimal_boot() -> BootSequence:
    """Короткий запуск без лишних проверок (~1.5 секунды)."""
    return BootSequence(
        name="minimal_boot",
        lines=[
            BootLine("ЗАПУСК JARVIS", delay_ms=100, duration_ms=400, kind="info"),
            BootLine("СИСТЕМЫ ... ОК", delay_ms=80, duration_ms=400, kind="ok"),
            BootLine("ГОТОВ К РАБОТЕ", delay_ms=80, duration_ms=400, kind="info"),
        ],
        footer="ГОТОВ К РАБОТЕ",
    )
