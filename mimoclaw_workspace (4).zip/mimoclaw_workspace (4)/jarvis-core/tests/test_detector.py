"""
Проверка vision/detector.py (детекция объектов на экране).

Запуск:  python3 tests/test_detector.py
"""

from __future__ import annotations

import os
import sys
import urllib.error
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from vision.capture import CaptureRegion, ScreenFrame
from vision.detector import (
    MAX_LABEL_LENGTH,
    DetectionBox,
    DetectionResult,
    DetectorError,
    DetectorRouter,
    DetectorUnavailable,
    HttpDetectorEngine,
    ScreenDetector,
    SyntheticDetectorEngine,
    TemplateDetectorEngine,
    default_detector_router,
    nms,
    normalize_label,
)
from vision.ocr import OCRImage


# ---------------------------------------------------------------------------
# Вспомогательные построители
# ---------------------------------------------------------------------------
def checkerboard(size: int = 4) -> OCRImage:
    """Шахматный шаблон ``size x size`` — высокая дисперсия, годится для ZNCC."""
    data = bytearray()
    for y in range(size):
        for x in range(size):
            data.append(255 if (x + y) % 2 == 0 else 0)
    return OCRImage(size, size, bytes(data), "L")


def blank_image(width: int, height: int, value: int = 128) -> OCRImage:
    return OCRImage(width, height, bytes([value]) * (width * height), "L")


def stamp(canvas: OCRImage, template: OCRImage, x: int, y: int) -> OCRImage:
    """Вклеивает шаблон в растр ``canvas`` в точке ``(x, y)`` (серый режим)."""
    data = bytearray(canvas.data)
    gray = template.to_gray()
    for row in range(gray.height):
        for col in range(gray.width):
            data[(y + row) * canvas.width + (x + col)] = gray.data[
                row * gray.width + col
            ]
    return OCRImage(canvas.width, canvas.height, bytes(data), "L")


def to_frame(image: OCRImage) -> ScreenFrame:
    """Серый растр → RGB-кадр ``ScreenFrame`` (проверка совместимости)."""
    gray = image.to_gray()
    rgb = bytearray()
    for v in gray.data:
        rgb.extend((v, v, v))
    return ScreenFrame(
        width=gray.width,
        height=gray.height,
        pixels=bytes(rgb),
        region=CaptureRegion(0, 0, gray.width, gray.height),
        backend="test",
    )


class FakeResponse:
    """Фейковый HTTP-ответ для ``HttpDetectorEngine``."""

    def __init__(self, payload: bytes) -> None:
        self._payload = payload

    def read(self, _n: int = -1) -> bytes:
        return self._payload

    def __enter__(self) -> "FakeResponse":
        return self

    def __exit__(self, *_exc: object) -> bool:
        return False


def make_opener(payload: bytes, calls: list):
    """Возвращает opener, записывающий запросы в ``calls``."""

    def opener(request, timeout=None):  # noqa: ANN001 — сигнатура urlopen
        calls.append((request, timeout))
        return FakeResponse(payload)

    return opener


def failing_opener(exc: Exception):
    def opener(request, timeout=None):  # noqa: ANN001
        raise exc

    return opener


# ---------------------------------------------------------------------------
# Коробка: валидация и геометрия
# ---------------------------------------------------------------------------
def test_box_validation_and_geometry() -> None:
    box = DetectionBox("кнопка", 10, 20, 30, 40, confidence=88.5)
    assert box.area == 1200
    assert box.center == (25, 40)
    assert box.contains(10, 20) and box.contains(39, 59)
    assert not box.contains(40, 20) and not box.contains(10, 60)
    other = DetectionBox("кнопка", 20, 30, 30, 40, confidence=10.0)
    assert 0.0 < box.iou(other) < 1.0
    assert box.overlaps(other)
    far = DetectionBox("кнопка", 200, 200, 5, 5)
    assert box.iou(far) == 0.0 and not box.overlaps(far)
    assert normalize_label("  Кнопка ") == "кнопка"
    assert normalize_label("кнопОчка") == "кнопочка"
    # валидация
    for bad in [
        ("", 0, 0, 1, 1, 0.0),
        ("   ", 0, 0, 1, 1, 0.0),
        ("x" * (MAX_LABEL_LENGTH + 1), 0, 0, 1, 1, 0.0),
        ("a\nb", 0, 0, 1, 1, 0.0),
        ("ok", -1, 0, 1, 1, 0.0),
        ("ok", 0, -1, 1, 1, 0.0),
        ("ok", 0, 0, 0, 1, 0.0),
        ("ok", 0, 0, 1, 0, 0.0),
        ("ok", 0, 0, 1, 1, -0.1),
        ("ok", 0, 0, 1, 1, 100.1),
        ("ok", True, 0, 1, 1, 0.0),
        ("ok", 0.5, 0, 1, 1, 0.0),  # type: ignore[arg-type]
    ]:
        try:
            DetectionBox(*bad)  # type: ignore[arg-type]
        except ValueError:
            pass
        else:
            raise AssertionError(f"коробка {bad!r} должна быть отклонена")
    try:
        box.iou("nope")  # type: ignore[arg-type]
    except ValueError:
        pass
    else:
        raise AssertionError("iou с не-коробкой должен быть отклонён")
    print("  ✓ box: валидация, центр, contains, IoU, normalize_label")


# ---------------------------------------------------------------------------
# Результат: поиск + NMS
# ---------------------------------------------------------------------------
def test_result_search_and_nms() -> None:
    boxes = (
        DetectionBox("button", 0, 0, 10, 10, 50.0),
        DetectionBox("Button", 1, 1, 10, 10, 90.0),
        DetectionBox("иконка", 40, 40, 8, 8, 70.0),
    )
    result = DetectionResult(boxes=boxes, engine="synthetic", elapsed_ms=1.5)
    assert result.count == 3 and not result.is_empty
    assert result.labels == ("button", "иконка")
    assert len(result.find("button")) == 2  # регистр не важен
    assert result.find("button", min_confidence=60.0) == [boxes[1]]
    assert result.find("  НЕТ ") == []
    assert result.best("button") is boxes[1]
    assert result.best("нет") is None
    assert [b.confidence for b in result.top(2)] == [90.0, 70.0]
    assert DetectionResult().is_empty
    for bad in ["x", -1, True]:
        try:
            result.top(bad)  # type: ignore[arg-type]
        except ValueError:
            pass
        else:
            raise AssertionError(f"top({bad!r}) должен быть отклонён")
    # NMS: дубли одной подписи схлопываются, разные подписи не конкурируют
    merged = nms(boxes, iou_threshold=0.4)
    assert merged == (boxes[1], boxes[2])
    assert nms((), iou_threshold=0.5) == ()
    for bad in [2.0, -0.1, "x", True]:
        try:
            nms(boxes, iou_threshold=bad)  # type: ignore[arg-type]
        except ValueError:
            pass
        else:
            raise AssertionError(f"nms(iou_threshold={bad!r}) должен быть отклонён")
    try:
        nms(["not-a-box"])  # type: ignore[list-item]
    except ValueError:
        pass
    else:
        raise AssertionError("nms с не-коробкой должен быть отклонён")
    print("  ✓ result: find/best/top/labels + NMS")


# ---------------------------------------------------------------------------
# Локальный движок: поиск шаблонов
# ---------------------------------------------------------------------------
def test_template_engine() -> None:
    tpl = checkerboard(4)
    canvas = stamp(blank_image(24, 18, 128), tpl, 7, 5)
    engine = TemplateDetectorEngine({"check": tpl}, min_confidence=70.0)
    assert engine.is_available() and engine.labels == ("check",)
    result = engine.detect(canvas)
    assert result.engine == "template" and result.count >= 1
    best = result.best("check")
    assert best is not None
    assert (best.x, best.y, best.width, best.height) == (7, 5, 4, 4)
    assert best.confidence >= 99.0
    # фильтр подписей
    assert engine.detect(canvas, labels=["другое"]).is_empty
    assert not engine.detect(canvas, labels=["check"]).is_empty
    assert engine.detect(canvas, labels=[]).is_empty
    # жёсткий порог оставляет только точное совпадение
    strict = TemplateDetectorEngine({"check": tpl}, min_confidence=99.0)
    only = strict.detect(canvas)
    assert only.count == 1 and (only.boxes[0].x, only.boxes[0].y) == (7, 5)
    # плоский шаблон не падает (переход на MAD-метрику)
    flat = TemplateDetectorEngine({"flat": blank_image(4, 4, 128)}, min_confidence=70.0)
    flat_result = flat.detect(blank_image(8, 8, 128))
    assert flat_result.count >= 1 and flat_result.boxes[0].confidence == 100.0
    # шаблон больше кадра → просто ничего
    assert engine.detect(blank_image(2, 2)).is_empty
    # предохранитель по объёму работы → уход в fallback
    tiny = TemplateDetectorEngine({"check": tpl}, max_work=100)
    try:
        tiny.detect(canvas)
    except DetectorUnavailable as exc:
        assert "stride" in str(exc)
    else:
        raise AssertionError("превышение max_work должно давать DetectorUnavailable")
    # управление банком шаблонов
    engine.add_template("extra", checkerboard(3))
    assert set(engine.labels) == {"check", "extra"}
    assert engine.remove_template("extra") and not engine.remove_template("extra")
    # валидация конструктора/шаблонов
    for kwargs in [
        {"min_confidence": -1},
        {"min_confidence": 101},
        {"stride": 0},
        {"stride": True},
        {"max_results": 0},
        {"max_results": 999999},
        {"max_work": 0},
    ]:
        try:
            TemplateDetectorEngine({"check": tpl}, **kwargs)  # type: ignore[arg-type]
        except ValueError:
            pass
        else:
            raise AssertionError(f"TemplateDetectorEngine({kwargs!r}) должен быть отклонён")
    try:
        engine.add_template("bad", "not-an-image")  # type: ignore[arg-type]
    except DetectorError:
        pass
    else:
        raise AssertionError("шаблон-не-картинка должен быть отклонён")
    print("  ✓ template: ZNCC-поиск, фильтры, плоский шаблон, max_work, банк")


# ---------------------------------------------------------------------------
# Облачный движок
# ---------------------------------------------------------------------------
def test_http_engine() -> None:
    try:
        HttpDetectorEngine("ftp://bad")
    except ValueError:
        pass
    else:
        raise AssertionError("не-http endpoint должен быть отклонён")
    for kwargs in [{"timeout": 0}, {"timeout": 999}, {"api_key_env": ""}]:
        try:
            HttpDetectorEngine("https://example.test/vision", **kwargs)  # type: ignore[arg-type]
        except ValueError:
            pass
        else:
            raise AssertionError(f"HttpDetectorEngine({kwargs!r}) должен быть отклонён")

    calls: list = []
    payload = (
        b'{"detections": ['
        b'{"label": "button", "confidence": 88, "x": 1, "y": 2, "width": 3, "height": 4},'
        b'{"label": "icon", "confidence": 12.5, "x": 0, "y": 0, "width": 5, "height": 5}'
        b"]}"
    )
    engine = HttpDetectorEngine(
        "https://example.test/vision", opener=make_opener(payload, calls)
    )
    assert engine.is_available()
    os.environ["JARVIS_VISION_API_KEY"] = "secret-xyz-never-logged"
    try:
        result = engine.detect(blank_image(4, 4), labels=["button"])
    finally:
        os.environ.pop("JARVIS_VISION_API_KEY", None)
    assert result.engine == "http" and result.count == 2
    assert result.best("button") is not None
    request, timeout = calls[0]
    assert timeout == 15.0
    assert request.get_header("Authorization") == "Bearer secret-xyz-never-logged"
    body = request.data.decode("utf-8")
    assert '"labels": ["button"]' in body and "secret-xyz" not in body
    # сетевой сбой → DetectorUnavailable (роутер уйдёт дальше)
    down = HttpDetectorEngine(
        "https://example.test/vision", opener=failing_opener(urllib.error.URLError("x"))
    )
    try:
        down.detect(blank_image(4, 4))
    except DetectorUnavailable:
        pass
    else:
        raise AssertionError("сетевой сбой должен давать DetectorUnavailable")
    # кривые ответы
    for payload_bad, exc_type in [
        (b"not json", DetectorError),
        (b"[]", DetectorError),
        (b'{"detections": [{"label": ""}]}', DetectorError),
        (b'{"detections": [{"label": "a", "width": 0}]}', DetectorError),
        (b'{"detections": ["oops"]}', DetectorError),
    ]:
        bad = HttpDetectorEngine(
            "https://example.test/vision", opener=make_opener(payload_bad, calls)
        )
        try:
            bad.detect(blank_image(4, 4))
        except exc_type:
            pass
        else:
            raise AssertionError(f"ответ {payload_bad!r} должен давать {exc_type.__name__}")
    print("  ✓ http: запрос/ответ, ключ из env, сетевые и протокольные ошибки")


# ---------------------------------------------------------------------------
# Синтетический движок + роутер
# ---------------------------------------------------------------------------
def test_synthetic_and_router() -> None:
    static = DetectionBox("панель", 3, 4, 10, 10, 60.0)
    engine = SyntheticDetectorEngine(boxes=(static,))
    result = engine.detect(blank_image(32, 32))
    assert result.count == 1 and result.boxes[0] is static
    assert engine.detect(blank_image(32, 32), labels=["панель"]).count == 1
    assert engine.detect(blank_image(32, 32), labels=["нет"]).is_empty

    def provider(_image: OCRImage) -> DetectionResult:
        return DetectionResult(boxes=(static,), engine="synthetic")

    custom = SyntheticDetectorEngine(provider)
    assert custom.detect(blank_image(8, 8)).count == 1
    try:
        SyntheticDetectorEngine(lambda _img: "nope").detect(blank_image(4, 4))
    except DetectorError:
        pass
    else:
        raise AssertionError("provider с неверным типом должен быть отклонён")
    assert not SyntheticDetectorEngine(available=False).is_available()

    # роутер: падение первого движка → fallback на синтетику
    def broken(_image: OCRImage) -> DetectionResult:
        raise DetectorError("сломался")

    router = DetectorRouter(
        {
            "broken": SyntheticDetectorEngine(broken),
            "synthetic": SyntheticDetectorEngine(boxes=(static,)),
        },
        primary="broken",
        fallback_chain=["broken", "synthetic"],
    )
    assert router.primary == "broken"
    assert router.detect(blank_image(8, 8)).boxes == (static,)
    router.set_primary("synthetic")
    assert router.primary == "synthetic" and "synthetic" in router.available()
    try:
        router.set_primary("нет")
    except DetectorError:
        pass
    else:
        raise AssertionError("set_primary с неизвестным именем должен быть отклонён")
    # все движки недоступны → понятная ошибка
    dead = DetectorRouter(
        {"a": SyntheticDetectorEngine(available=False)}, primary="a"
    )
    try:
        dead.detect(blank_image(4, 4))
    except DetectorError as exc:
        assert "Ни один движок" in str(exc)
    else:
        raise AssertionError("полный отказ движков должен давать DetectorError")
    # явный выбор движка минуя цепочку
    assert router.detect(blank_image(8, 8), engine="synthetic").count == 1
    assert router.describe()["primary"] == "synthetic"
    print("  ✓ synthetic + router: fallback, смена движка, отказ всех")


# ---------------------------------------------------------------------------
# Высокоуровневый сервис
# ---------------------------------------------------------------------------
def test_screen_detector_facade() -> None:
    tpl = checkerboard(4)
    canvas = stamp(blank_image(24, 18, 128), tpl, 7, 5)
    router = default_detector_router(
        templates={"check": tpl, "other": checkerboard(3)}
    )
    det = ScreenDetector(router, preprocess=("gray",), min_confidence=50.0)
    assert det.prepare(canvas).mode == "L"
    result = det.detect(canvas, labels=["check"])
    assert result.count >= 1
    found = det.find(canvas, "CHECK")  # регистр/ё↔е не важны
    assert found and (found[0].x, found[0].y) == (7, 5)
    assert det.locate(canvas, "check") is not None
    assert det.locate(canvas, "нет") is None
    assert det.click_point(canvas, "check") == (9, 7)
    assert det.click_point(canvas, "нет") is None
    # совместимость с кадром ScreenFrame (duck-typing)
    frame = to_frame(canvas)
    assert det.click_point(frame, "check") == (9, 7)
    # порог уверенности отсекает шум
    strict = ScreenDetector(router, preprocess=("gray",), min_confidence=99.0)
    assert strict.detect(canvas, labels=["check"]).count == 1
    # предобработка: масштабирование меняет геометрию и не ломает конвейер
    scaled = ScreenDetector(router, preprocess=("gray", "scale:2.0"))
    assert scaled.prepare(canvas).width == 48
    assert isinstance(scaled.detect(canvas, labels=["check"]), DetectionResult)
    # сквозной поиск после масштаба: шаблон тоже масштабируется
    router2 = default_detector_router(templates={"check": checkerboard(4).scale(2.0)})
    scaled2 = ScreenDetector(
        router2, preprocess=("gray", "scale:2.0"), min_confidence=50.0
    )
    hit = scaled2.locate(canvas, "check")
    assert hit is not None and (hit.x, hit.y, hit.width) == (14, 10, 8)
    assert scaled2.click_point(canvas, "check") == (18, 14)
    assert scaled2.describe()["preprocess"] == ["gray", "scale:2.0"]
    # валидация
    for bad in ["x", ("gray", "wat"), ("scale:9"), ("scale:x"), (1, 2)]:
        try:
            ScreenDetector(router, preprocess=bad)  # type: ignore[arg-type]
        except ValueError:
            pass
        else:
            raise AssertionError(f"preprocess={bad!r} должен быть отклонён")
    try:
        ScreenDetector("not-a-router")  # type: ignore[arg-type]
    except TypeError:
        pass
    else:
        raise AssertionError("не-роутер должен быть отклонён")
    for kwargs in [{"min_confidence": -1}, {"nms_threshold": 2.0}]:
        try:
            ScreenDetector(router, **kwargs)  # type: ignore[arg-type]
        except ValueError:
            pass
        else:
            raise AssertionError(f"ScreenDetector({kwargs!r}) должен быть отклонён")
    print("  ✓ facade: предобработка, find/locate/click_point, ScreenFrame, default_router")


def main() -> int:
    print("JARVIS CORE — проверка vision/detector")
    try:
        test_box_validation_and_geometry()
        test_result_search_and_nms()
        test_template_engine()
        test_http_engine()
        test_synthetic_and_router()
        test_screen_detector_facade()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки vision/detector прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
