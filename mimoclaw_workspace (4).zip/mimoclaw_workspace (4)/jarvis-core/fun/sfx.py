"""
Богатые SFX-звуки JARVIS CORE (сигналы активации, подтверждения и пр.).

Модуль развивает идею ``audio/playback.builtin_sfx``: поверх того же
контракта ``PlaybackClip`` даёт **темы оформления** (SCIFI / CLASSIC /
MINIMAL / ROBOTIC), **сэмплы из WAV-файлов** и более выразительный синтез
(чирпы, гармоники, эхо, огибание без щелчков).

Слои «звука» (сверху вниз):
  1. ``SampleBank``   — локальные WAV-сэмплы ``<event>.wav`` (если положили
     в папку — звучат они, это самый «живой» вариант);
  2. тема ``SfxTheme`` — процедурный синтез по параметрам темы;
  3. ``builtin_sfx``  — простые тоны из audio/playback (гарантированный
     fallback: библиотека **никогда** не остаётся без звука).

Всё локально: ни сетевых запросов, ни облака — звуки синтезируются или
читаются с диска. Готовые клипы кэшируются в ``SfxLibrary``, чтобы
пайплайн «wake-word → ответ» не тратил время на синтез.

Типовой сценарий::

    library = SfxLibrary(SfxConfig(theme=SfxTheme.SCIFI))
    player  = SfxPlayer(audio_player, library)

    await player.play(SfxEvent.ACTIVATE)   # «Джарвис» услышан
    ...
    await player.play(SfxEvent.CONFIRM)    # команда принята
"""

from __future__ import annotations

import logging
import math
import sys
import wave
from array import array
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Sequence

from audio.playback import (
    AudioPlayer,
    PlaybackClip,
    builtin_sfx,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class SfxError(Exception):
    """Ошибка SFX-подсистемы."""


# ---------------------------------------------------------------------------
# Базовый DSP (чистый Python, без numpy; PCM = s16le, моно)
# ---------------------------------------------------------------------------
def _to_samples(pcm: bytes) -> array:
    """bytes s16le → массив ``array('h')`` (с учётом порядка байт)."""
    samples = array("h")
    samples.frombytes(pcm)
    if sys.byteorder == "big":  # pragma: no cover — платформо-зависимо
        samples.byteswap()
    return samples


def _to_bytes(samples: array) -> bytes:
    """Массив ``array('h')`` → bytes s16le."""
    if sys.byteorder == "big":  # pragma: no cover
        samples.byteswap()
    return samples.tobytes()


def silence(duration_s: float, sample_rate: int = 16000) -> bytes:
    """Тишина заданной длительности."""
    n = max(0, int(duration_s * sample_rate))
    return b"\x00\x00" * n


def sine_wave(
    freq_hz: float,
    duration_s: float = 0.15,
    *,
    amplitude: float = 0.5,
    sample_rate: int = 16000,
    phase: float = 0.0,
) -> bytes:
    """
    Чистый синус без огибания (огибание накладывается через ``fade_edges``).

    ``amplitude`` — 0.0..1.0 от полной шкалы int16.
    """
    n = max(0, int(duration_s * sample_rate))
    amp = max(0.0, min(1.0, amplitude)) * 32767.0
    out = array("h")
    for i in range(n):
        out.append(
            int(amp * math.sin(2.0 * math.pi * freq_hz * i / sample_rate + phase))
        )
    return _to_bytes(out)


def chirp(
    freq_start_hz: float,
    freq_end_hz: float,
    duration_s: float = 0.2,
    *,
    amplitude: float = 0.5,
    sample_rate: int = 16000,
) -> bytes:
    """
    Линейная развёртка частоты (чирп) с интегрированием фазы.

    Используется для «жужжания» робота: восходящий чрп = активация,
    нисходящий = ошибка/отмена.
    """
    n = max(0, int(duration_s * sample_rate))
    if n == 0:
        return b""
    amp = max(0.0, min(1.0, amplitude)) * 32767.0
    step = (freq_end_hz - freq_start_hz) / n
    out = array("h")
    phase = 0.0
    for i in range(n):
        freq = freq_start_hz + step * i
        phase += 2.0 * math.pi * freq / sample_rate
        out.append(int(amp * math.sin(phase)))
    return _to_bytes(out)


def fade_edges(pcm: bytes, fade_ms: float = 6.0, sample_rate: int = 16000) -> bytes:
    """
    Плавное огибание начала и конца (fade-in/out) — чтобы не щёлкало.

    Дли fade короче самого звука клип не трогается.
    """
    samples = _to_samples(pcm)
    n = len(samples)
    fade = int(fade_ms * sample_rate / 1000.0)
    if n == 0 or fade <= 0 or 2 * fade >= n:
        return pcm
    for i in range(fade):
        env = i / fade
        samples[i] = int(samples[i] * env)
        samples[n - 1 - i] = int(samples[n - 1 - i] * env)
    return _to_bytes(samples)


def mix_layers(layers: Sequence[tuple[bytes, float]]) -> bytes:
    """
    Смешать слои ``(pcm, gain)``: сумма с выравниванием по длине (pad нулями).

    Переполнение int16 зажимается (хард-лимит) — клик возможен только при
    экстремальных гейнах, обычные миксы укладываются в шкалу.
    """
    if not layers:
        raise SfxError("mix_layers: нечего микшировать (пустой список слоёв)")
    max_len = max(len(_to_samples(pcm)) for pcm, _ in layers)
    mixed = [0.0] * max_len
    for pcm, gain in layers:
        samples = _to_samples(pcm)
        for i, s in enumerate(samples):
            mixed[i] += s * float(gain)
    out = array("h")
    for v in mixed:
        out.append(max(-32768, min(32767, int(v))))
    return _to_bytes(out)


def echo(
    pcm: bytes,
    *,
    delay_ms: float = 90.0,
    decay: float = 0.35,
    repeats: int = 2,
    sample_rate: int = 16000,
) -> bytes:
    """
    Простое эхо (задержанные затухающие копии), удлиняет звук.

    ``decay`` — громкость первого повтора; каждый следующий умножается
    на ``decay`` ещё раз. Параметры ограничиваются разумными пределами.
    """
    if repeats <= 0 or decay <= 0.0:
        return pcm
    repeats = min(int(repeats), 6)
    decay = min(float(decay), 0.9)
    base = _to_samples(pcm)
    out = array("h", base)
    delay = max(1, int(delay_ms * sample_rate / 1000.0))
    gain = decay
    for r in range(1, repeats + 1):
        offset = delay * r
        need = offset + len(base) - len(out)
        if need > 0:
            out.extend([0] * need)
        for i, s in enumerate(base):
            out[offset + i] = max(
                -32768, min(32767, int(out[offset + i] + s * gain))
            )
        gain *= decay
    return _to_bytes(out)


# ---------------------------------------------------------------------------
# События и темы
# ---------------------------------------------------------------------------
class SfxEvent(str, Enum):
    """События ассистента, для которых нужен звук."""

    ACTIVATE = "activate"  # wake-word услышан, слушаю команду
    CONFIRM = "confirm"  # команда принята/выполнена
    ERROR = "error"  # ошибка или отказ
    CANCEL = "cancel"  # действие отменено
    THINKING = "thinking"  # думаю (лёгкий фон при обращении к LLM)
    GREETING = "greeting"  # приветствие при старте
    FAREWELL = "farewell"  # прощание при остановке


class SfxTheme(str, Enum):
    """Темы оформления звуков."""

    SCIFI = "scifi"  # чирпы + гармоники + эхо («железный человек»)
    CLASSIC = "classic"  # простые тоны, близко к builtin_sfx
    MINIMAL = "minimal"  # тихие и короткие одиночные блипы
    ROBOTIC = "robotic"  # расстроенные пары тонов + длинное эхо


@dataclass(frozen=True)
class ThemeSpec:
    """Параметры синтеза темы — «голос» звуков."""

    theme: SfxTheme
    base_freq: float  # базовая частота, Гц
    harmonic_gain: float  # громкость оберточного слоя (0 — выключены)
    detune_cents: float  # расстройка второго тона (центы, 100 = полутон)
    echo_ms: float  # 0 — без эха
    echo_decay: float
    tail_s: float  # длительность «хвоста» (затухание последнего тона)


_THEME_SPECS: dict[SfxTheme, ThemeSpec] = {
    SfxTheme.SCIFI: ThemeSpec(
        theme=SfxTheme.SCIFI,
        base_freq=660.0,
        harmonic_gain=0.25,
        detune_cents=8.0,
        echo_ms=90.0,
        echo_decay=0.32,
        tail_s=0.16,
    ),
    SfxTheme.CLASSIC: ThemeSpec(
        theme=SfxTheme.CLASSIC,
        base_freq=880.0,
        harmonic_gain=0.0,
        detune_cents=0.0,
        echo_ms=0.0,
        echo_decay=0.0,
        tail_s=0.12,
    ),
    SfxTheme.MINIMAL: ThemeSpec(
        theme=SfxTheme.MINIMAL,
        base_freq=740.0,
        harmonic_gain=0.0,
        detune_cents=0.0,
        echo_ms=0.0,
        echo_decay=0.0,
        tail_s=0.08,
    ),
    SfxTheme.ROBOTIC: ThemeSpec(
        theme=SfxTheme.ROBOTIC,
        base_freq=440.0,
        harmonic_gain=0.35,
        detune_cents=14.0,
        echo_ms=140.0,
        echo_decay=0.4,
        tail_s=0.2,
    ),
}


def _semitone_ratio(cents: float) -> float:
    """Отношение частот при расстройке в центах (100 центов = полутон)."""
    return 2.0 ** (cents / 1200.0)


def _note(base_freq: float, semitones: float) -> float:
    """Частота ноты в полутонах от базовой."""
    return base_freq * 2.0 ** (semitones / 12.0)


def _blip(
    freq_hz: float,
    duration_s: float,
    spec: ThemeSpec,
    sample_rate: int,
    *,
    amplitude: float = 0.5,
    sweep_to: float | None = None,
) -> bytes:
    """Одна «нота»: синус или чирп, с огибанием и обертонами по теме."""
    if sweep_to is None:
        fundamental = sine_wave(
            freq_hz, duration_s, amplitude=amplitude, sample_rate=sample_rate
        )
    else:
        fundamental = chirp(
            freq_hz,
            sweep_to,
            duration_s,
            amplitude=amplitude,
            sample_rate=sample_rate,
        )
    layers: list[tuple[bytes, float]] = [(fundamental, 1.0)]

    if spec.detune_cents > 0.0:  # расстроенная пара тонов = «железность»
        detuned = sine_wave(
            freq_hz * _semitone_ratio(spec.detune_cents),
            duration_s,
            amplitude=amplitude,
            sample_rate=sample_rate,
        )
        layers.append((detuned, 0.6))
    if spec.harmonic_gain > 0.0:  # первая гармоника = яркость
        harmonic = sine_wave(
            freq_hz * 2.0,
            duration_s,
            amplitude=amplitude,
            sample_rate=sample_rate,
        )
        layers.append((harmonic, spec.harmonic_gain))

    return fade_edges(mix_layers(layers), sample_rate=sample_rate)


def _place(pcm: bytes, offset_s: float, sample_rate: int) -> bytes:
    """Сдвинуть звук во времени (перед ним — тишина)."""
    if offset_s <= 0.0:
        return pcm
    return silence(offset_s, sample_rate) + pcm


def render_event(event: SfxEvent | str, theme: SfxTheme | str, sample_rate: int = 16000) -> bytes:
    """
    Синтезировать звук события в стиле темы (s16le, моно).

    Композиции событий:
      * ACTIVATE  — восходящий чрп + подтверждающая нота сверху;
      * CONFIRM   — два коротких блипа вверх;
      * ERROR     — нисходящий чрп + низкий гул;
      * CANCEL    — нисходящая пара нот;
      * THINKING  — три мягких низких пульса;
      * GREETING  — восходящее арпеджио из трёх нот;
      * FAREWELL  — нисходящее арпеджио из трёх нот.
    """
    try:
        event = SfxEvent(event)
    except ValueError as e:
        raise SfxError(f"неизвестное SFX-событие: {event!r}") from e
    try:
        theme = SfxTheme(theme)
    except ValueError as e:
        raise SfxError(f"неизвестная SFX-тема: {theme!r}") from e

    spec = _THEME_SPECS[theme]
    base = spec.base_freq
    tail = spec.tail_s
    sr = sample_rate

    if event is SfxEvent.ACTIVATE:
        parts = [
            _blip(base * 0.75, 0.12, spec, sr, amplitude=0.45, sweep_to=base * 1.5),
            _place(
                _blip(_note(base, 7), tail, spec, sr, amplitude=0.4),
                0.13,
                sr,
            ),
        ]
    elif event is SfxEvent.CONFIRM:
        parts = [
            _blip(_note(base, 0), 0.07, spec, sr, amplitude=0.45),
            _place(_blip(_note(base, 5), tail, spec, sr, amplitude=0.45), 0.08, sr),
        ]
    elif event is SfxEvent.ERROR:
        parts = [
            _blip(base * 1.2, 0.16, spec, sr, amplitude=0.5, sweep_to=base * 0.5),
            _place(
                _blip(base * 0.5, tail, spec, sr, amplitude=0.35),
                0.17,
                sr,
            ),
        ]
    elif event is SfxEvent.CANCEL:
        parts = [
            _blip(_note(base, 0), 0.09, spec, sr, amplitude=0.45),
            _place(_blip(_note(base, -5), tail, spec, sr, amplitude=0.4), 0.1, sr),
        ]
    elif event is SfxEvent.THINKING:
        parts = [
            _place(_blip(_note(base, -7), 0.06, spec, sr, amplitude=0.25), off, sr)
            for off in (0.0, 0.12, 0.24)
        ]
    elif event is SfxEvent.GREETING:
        parts = [
            _place(_blip(_note(base, n), 0.09, spec, sr, amplitude=0.4), off, sr)
            for n, off in ((0, 0.0), (4, 0.1), (7, 0.2))
        ]
        parts.append(
            _place(_blip(_note(base, 12), tail, spec, sr, amplitude=0.4), 0.3, sr)
        )
    else:  # FAREWELL
        parts = [
            _place(_blip(_note(base, n), 0.09, spec, sr, amplitude=0.4), off, sr)
            for n, off in ((7, 0.0), (4, 0.1), (0, 0.2))
        ]
        parts.append(
            _place(_blip(_note(base, -5), tail, spec, sr, amplitude=0.35), 0.3, sr)
        )

    pcm = mix_layers([(part, 1.0) for part in parts])
    if spec.echo_ms > 0.0:
        pcm = echo(
            pcm,
            delay_ms=spec.echo_ms,
            decay=spec.echo_decay,
            repeats=2,
            sample_rate=sr,
        )
    return pcm


# ---------------------------------------------------------------------------
# Банк сэмплов (локальные WAV-файлы)
# ---------------------------------------------------------------------------
class SampleBank:
    """
    Локальные WAV-сэмплы ``<event>.wav`` из каталога.

    Поддерживаются PCM WAV: 16 бит/сэмпл, моно или стерео (стерео
    сводится к моно), любая частота дискретизации (пересэмплируется
    линейно). Битые файлы пропускаются с предупреждением — библиотека
    деградирует до процедурного синтеза, а не падает.
    """

    def __init__(self, directory: str | Path, sample_rate: int = 16000) -> None:
        self.directory = Path(directory)
        self.sample_rate = sample_rate
        self._cache: dict[SfxEvent, bytes] = {}
        self._failed: set[SfxEvent] = set()

    def _load_wav(self, path: Path) -> bytes | None:
        """Прочитать WAV и привести к s16le/моно/``sample_rate``."""
        try:
            with wave.open(str(path), "rb") as wf:
                channels = wf.getnchannels()
                width = wf.getsampwidth()
                rate = wf.getframerate()
                frames = wf.readframes(wf.getnframes())
        except (OSError, wave.Error, EOFError) as e:
            logger.warning("SampleBank: не прочитан %s (%s)", path.name, e)
            return None

        if width != 2 or channels not in (1, 2) or rate <= 0:
            logger.warning(
                "SampleBank: %s — неподдерживаемый формат "
                "(width=%d, channels=%d, rate=%d)",
                path.name, width, channels, rate,
            )
            return None

        samples = _to_samples(frames)
        if channels == 2:  # стерео → моно (среднее по каналам)
            mono = array("h")
            for i in range(0, len(samples) - 1, 2):
                mono.append(int((samples[i] + samples[i + 1]) / 2))
            samples = mono

        if rate != self.sample_rate:
            samples = self._resample(samples, rate, self.sample_rate)
        return _to_bytes(samples)

    @staticmethod
    def _resample(samples: array, src_rate: int, dst_rate: int) -> array:
        """Линейная интерполяция (для SFX качества достаточно)."""
        if len(samples) == 0:
            return array("h")
        n_out = max(1, int(len(samples) * dst_rate / src_rate))
        out = array("h")
        for i in range(n_out):
            pos = i * (len(samples) - 1) / max(1, n_out - 1)
            idx = int(pos)
            frac = pos - idx
            a = samples[idx]
            b = samples[min(idx + 1, len(samples) - 1)]
            out.append(int(a + (b - a) * frac))
        return out

    def get(self, event: SfxEvent | str) -> bytes | None:
        """PCM сэмпла события или ``None``, если файла нет/не читается."""
        try:
            event = SfxEvent(event)
        except ValueError as e:
            raise SfxError(f"неизвестное SFX-событие: {event!r}") from e
        if event in self._cache:
            return self._cache[event]
        if event in self._failed:  # файл уже признан нечитаемым
            return None
        path = self.directory / f"{event.value}.wav"
        if not path.is_file():
            return None
        pcm = self._load_wav(path)
        if pcm is not None:
            self._cache[event] = pcm
        else:
            self._failed.add(event)
        return pcm

    def events(self) -> list[SfxEvent]:
        """События, для которых есть читаемый сэмпл."""
        return [ev for ev in SfxEvent if self.get(ev) is not None]

    def describe(self) -> dict[str, Any]:
        return {
            "directory": str(self.directory),
            "sample_rate": self.sample_rate,
            "events": [ev.value for ev in self.events()],
        }


# ---------------------------------------------------------------------------
# Библиотека клипов
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class SfxConfig:
    """Настройки SFX-библиотеки."""

    sample_rate: int = 16000
    volume: float = 1.0  # 0.0..2.0, применяется при сборке клипа
    theme: SfxTheme = SfxTheme.SCIFI
    sample_dir: Path | None = None  # каталог WAV-сэмплов (если есть)
    priority: int = -1  # речь (0) всегда важнее SFX


class SfxLibrary:
    """
    Фабрика SFX-клипов с кэшем: сэмплы → тема → builtin.

    ``clip(event)`` всегда возвращает воспроизводимый ``PlaybackClip``:
    даже без сэмплов и при падении синтеза сработает ``builtin_sfx``.
    """

    def __init__(self, config: SfxConfig | None = None) -> None:
        self.config = config or SfxConfig()
        self.theme = self.config.theme
        self._bank = (
            SampleBank(self.config.sample_dir, self.config.sample_rate)
            if self.config.sample_dir is not None
            else None
        )
        self._cache: dict[SfxEvent, PlaybackClip] = {}

    # -- управление --------------------------------------------------------
    def set_theme(self, theme: SfxTheme | str) -> None:
        """Сменить тему (кэш пересобирается)."""
        try:
            theme = SfxTheme(theme)
        except ValueError as e:
            raise SfxError(f"неизвестная SFX-тема: {theme!r}") from e
        self.theme = theme
        self._cache.clear()
        logger.info("SfxLibrary: тема → %s", theme.value)

    def clear_cache(self) -> None:
        """Сбросить кэш клипов (например, после замены сэмплов)."""
        self._cache.clear()

    def preload(self) -> int:
        """Собрать все клипы заранее; вернуть их количество."""
        for event in SfxEvent:
            self.clip(event)
        return len(self._cache)

    # -- сборка клипа ------------------------------------------------------
    def _render(self, event: SfxEvent) -> tuple[bytes, str]:
        """PCM + источник звука (сэмпл / тема / builtin)."""
        if self._bank is not None:
            sample = self._bank.get(event)
            if sample is not None:
                return sample, "sample"
        try:
            return render_event(event, self.theme, self.config.sample_rate), f"theme:{self.theme.value}"
        except Exception:  # noqa: BLE001 — синтез не должен ронять библиотеку
            logger.exception("SfxLibrary: синтез %s не удался, беру builtin", event.value)
            pcm = builtin_sfx(_BUILTIN_MAP[event], sample_rate=self.config.sample_rate).pcm
            return pcm, "builtin"

    def clip(self, event: SfxEvent | str) -> PlaybackClip:
        """Готовый клип события (с кэшем)."""
        try:
            event = SfxEvent(event)
        except ValueError as e:
            raise SfxError(f"неизвестное SFX-событие: {event!r}") from e
        if event in self._cache:
            return self._cache[event]

        pcm, source = self._render(event)
        volume = max(0.0, min(2.0, float(self.config.volume)))
        if volume != 1.0:
            samples = _to_samples(pcm)
            for i in range(len(samples)):
                samples[i] = max(-32768, min(32767, int(samples[i] * volume)))
            pcm = _to_bytes(samples)

        clip = PlaybackClip(
            pcm=pcm,
            sample_rate=self.config.sample_rate,
            channels=1,
            sample_width=2,
            kind="sfx",
            name=event.value,
            priority=self.config.priority,
        )
        self._cache[event] = clip
        logger.debug("SfxLibrary: клип %r (%s, %.2f c)", event.value, source, clip.duration)
        return clip

    def describe(self) -> dict[str, Any]:
        """Состояние библиотеки (для UI/диагностики)."""
        return {
            "theme": self.theme.value,
            "volume": self.config.volume,
            "sample_rate": self.config.sample_rate,
            "cached": sorted(clip.name for clip in self._cache.values()),
            "samples": self._bank.describe() if self._bank else None,
        }


# builtin_sfx знает лишь 4 события — маппим остальные на ближайшие.
_BUILTIN_MAP: dict[SfxEvent, Any] = {
    SfxEvent.ACTIVATE: "activate",
    SfxEvent.CONFIRM: "confirm",
    SfxEvent.ERROR: "error",
    SfxEvent.CANCEL: "cancel",
    SfxEvent.THINKING: "confirm",
    SfxEvent.GREETING: "activate",
    SfxEvent.FAREWELL: "cancel",
}


# ---------------------------------------------------------------------------
# Плеер сигналов
# ---------------------------------------------------------------------------
class SfxPlayer:
    """
    Тонкая обёртка над ``AudioPlayer``: событие → звук.

    Приоритет клипов отрицательный (``SfxConfig.priority``), поэтому речь
    ассистента всегда важнее сигналов и не откладывается ими.
    """

    def __init__(
        self,
        player: AudioPlayer,
        library: SfxLibrary | None = None,
    ) -> None:
        self.player = player
        self.library = library or SfxLibrary()

    async def play(
        self,
        event: SfxEvent | str,
        *,
        volume: float = 1.0,
        wait: bool = False,
    ) -> None:
        """Сыграть звук события (в очередь плеера)."""
        clip = self.library.clip(event)
        await self.player.play_sfx(clip, volume=volume, wait=wait)

    def stop(self) -> None:
        """Оборвать звук и очистить очередь плеера."""
        self.player.stop()

    def describe(self) -> dict[str, Any]:
        return {"library": self.library.describe()}
