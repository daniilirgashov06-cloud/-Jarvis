/**
 * VUMeter — неоновый индикатор уровня сигнала.
 *
 * Данные — история уровней (0..1): реальные значения из событий шины
 * (`audio.*`, `stt.*`, `tts.*`) либо синтетическая активность состояния.
 */

import { motion } from "framer-motion";
import { clamp } from "../lib/format";

interface VUMeterProps {
  history: number[];
  bars?: number;
  label?: string;
}

export function VUMeter({ history, bars = 32, label = "VU / УРОВЕНЬ СИГНАЛА" }: VUMeterProps) {
  const values = history.slice(-bars);
  const filled: number[] = Array.from({ length: bars - values.length }, () => 0).concat(values);
  const peak = filled.reduce((max, v) => Math.max(max, v), 0);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="hud-title text-xs text-muted">{label}</span>
        <span className="font-heading text-xs tabular-nums text-accent">
          {Math.round(clamp(peak, 0, 1) * 100)}%
        </span>
      </div>
      <div className="flex h-24 items-end gap-[3px] rounded-xl border border-line bg-panel-2/60 p-2">
        {filled.map((value, i) => (
          <motion.div
            key={i}
            animate={{ height: `${Math.max(4, value * 100)}%` }}
            transition={{ duration: 0.18, ease: "easeOut" }}
            className="flex-1 rounded-sm"
            style={{
              background:
                value > 0.82
                  ? "#FF3B30"
                  : value > 0.55
                    ? "#F5A623"
                    : "rgb(var(--accent-rgb) / 0.85)",
              boxShadow: value > 0.6 ? "0 0 8px rgb(var(--accent-rgb) / 0.6)" : undefined,
            }}
          />
        ))}
      </div>
    </div>
  );
}
