"""
Команды мультимедиа JARVIS CORE (ТЗ-6, каталог media).

Управление локальным проигрывателем: воспроизведение, пауза, стоп,
переключение треков и запрос текущего трека. Каждая команда имеет уровень
риска (``RiskLevel``) и регистрируется в ``CommandRegistry``, откуда она
попадает в схемы function calling для LLM.

Архитектура (в стиле ``actions/app_actions.py`` и ``actions/system_actions.py``):

- ``MediaBackend`` — контракт «исполнитель» операций над проигрывателем;
- ``SubprocessMediaBackend`` — локальная реализация через subprocess
  (Linux ``playerctl`` / macOS ``osascript``+Music / Windows media-клавиши),
  команды строятся под платформу;
- ``DryRunMediaBackend`` — безопасный fallback/отладка: ничего не запускает,
  только записывает операции и держит фиктивное состояние (используется в тестах);
- ``MediaInfo`` — нормализованные метаданные текущего трека.

«Локально ↔ облако» здесь неприменимо: всё управление идёт к локальному
проигрывателю. При недоступности исполнителя команда падает контролируемо
(``MediaUnavailable``) без побочных эффектов. Команды воспроизведения
безопасны и обратимы (SAFE) — они не удаляют и не изменяют данные.

Использование:
    from actions.registry import CommandRegistry
    from actions.media_actions import MediaActions, register_media_actions

    registry = CommandRegistry()
    register_media_actions(registry)           # или со своим backend
"""

from __future__ import annotations

import abc
import logging
import platform
from dataclasses import dataclass, field
from typing import Any, Callable

from actions.registry import REQUIRES_CONFIRMATION, Command, CommandRegistry, RiskLevel
from ai.function_calling import ParamSpec

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class MediaError(Exception):
    """Ошибка команды мультимедиа."""


class MediaUnavailable(MediaError):
    """Исполнитель недоступен (нет утилиты/прав/проигрывателя) — можно fallback."""


class MediaUnsupported(MediaError):
    """Операция не поддерживается на текущей платформе."""


# ---------------------------------------------------------------------------
# Статусы воспроизведения
# ---------------------------------------------------------------------------
class PlaybackStatus:
    """Нормализованные статусы проигрывателя."""

    PLAYING = "playing"
    PAUSED = "paused"
    STOPPED = "stopped"
    UNKNOWN = "unknown"


#: допустимые значения статуса (для валидации/документации)
VALID_STATUSES: frozenset[str] = frozenset(
    {PlaybackStatus.PLAYING, PlaybackStatus.PAUSED, PlaybackStatus.STOPPED, PlaybackStatus.UNKNOWN}
)

#: отображаемое имя статуса на русском
_STATUS_RU: dict[str, str] = {
    PlaybackStatus.PLAYING: "играет",
    PlaybackStatus.PAUSED: "пауза",
    PlaybackStatus.STOPPED: "остановлено",
    PlaybackStatus.UNKNOWN: "статус неизвестен",
}


def _normalize_status(raw: Any) -> str:
    """Приводит сырой статус проигрывателя к одному из ``PlaybackStatus``."""
    text = str(raw or "").strip().lower()
    mapping = {
        "playing": PlaybackStatus.PLAYING,
        "play": PlaybackStatus.PLAYING,
        "paused": PlaybackStatus.PAUSED,
        "pause": PlaybackStatus.PAUSED,
        "stopped": PlaybackStatus.STOPPED,
        "stop": PlaybackStatus.STOPPED,
    }
    return mapping.get(text, PlaybackStatus.UNKNOWN)


# ---------------------------------------------------------------------------
# Метаданные текущего трека
# ---------------------------------------------------------------------------
@dataclass
class MediaInfo:
    """Нормализованные метаданные текущего трека."""

    status: str = PlaybackStatus.UNKNOWN
    artist: str = ""
    title: str = ""

    def describe(self) -> str:
        """Человекочитаемое описание для голосового ответа."""
        state = _STATUS_RU.get(self.status, _STATUS_RU[PlaybackStatus.UNKNOWN])
        track = " — ".join(p for p in (self.artist.strip(), self.title.strip()) if p)
        if not track:
            track = "нет данных о треке"
        return f"{state}: {track}"


# ---------------------------------------------------------------------------
# Контракт исполнителя
# ---------------------------------------------------------------------------
class MediaBackend(abc.ABC):
    """Контракт исполнителя операций над проигрывателем."""

    name: str = "base"

    @abc.abstractmethod
    def is_available(self) -> bool: ...

    @abc.abstractmethod
    def play(self) -> None: ...

    @abc.abstractmethod
    def pause(self) -> None: ...

    @abc.abstractmethod
    def stop(self) -> None: ...

    @abc.abstractmethod
    def next_track(self) -> None: ...

    @abc.abstractmethod
    def previous_track(self) -> None: ...

    @abc.abstractmethod
    def now_playing(self) -> MediaInfo | None: ...

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "available": self.is_available()}


# ---------------------------------------------------------------------------
# Реальный исполнитель (subprocess)
# ---------------------------------------------------------------------------
#: Тип «запуск argv -> stdout» (подменяется в тестах)
Runner = Callable[[list[str]], str]


def _default_runner(argv: list[str]) -> str:
    """Выполняет argv и возвращает stdout; ошибки оборачивает в MediaError."""
    import subprocess

    try:
        proc = subprocess.run(  # noqa: S603 — argv формируем сами, shell=False
            argv,
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
    except FileNotFoundError as e:
        raise MediaUnavailable(f"утилита не найдена: {argv[0]}") from e
    except subprocess.TimeoutExpired as e:
        raise MediaError(f"таймаут команды: {' '.join(argv)}") from e
    if proc.returncode != 0:
        raise MediaError(
            f"команда завершилась с кодом {proc.returncode}: {' '.join(argv)}"
            f" ({proc.stderr.strip()[:200]})"
        )
    return proc.stdout


#: разделитель полей в строке now_playing (Linux/macOS формат)
_FIELD_SEP = "|"

#: Windows VK-коды мультимедийных клавиш
_WIN_VK: dict[str, int] = {
    "play_pause": 0xB3,
    "stop": 0xB2,
    "next": 0xB0,
    "previous": 0xB1,
}


@dataclass
class SubprocessMediaBackend(MediaBackend):
    """
    Локальный исполнитель: строит и выполняет команды под текущую ОС.

    runner подменяется в тестах; platform_name позволяет сымитировать
    другую платформу (linux / darwin / windows).
    """

    name: str = "subprocess"
    runner: Runner = field(default=_default_runner)
    platform_name: str = field(default_factory=platform.system)

    def _plat(self) -> str:
        return self.platform_name.lower()

    def is_available(self) -> bool:
        return self._plat() in {"linux", "darwin", "windows"}

    # -- транспорт ---------------------------------------------------------
    def _linux(self, *args: str) -> str:
        return self.runner(["playerctl", *args])

    def _osascript(self, script: str) -> str:
        return self.runner(["osascript", "-e", script])

    def _win_media_key(self, action: str) -> None:
        """Шлёт мультимедийную клавишу через keybd_event (user32)."""
        vk = _WIN_VK[action]
        # keydown + keyup
        script = (
            "$sig='[DllImport(\"user32.dll\")] public static extern void keybd_event("
            "byte bVk,byte bScan,uint dwFlags,UIntPtr dwExtraInfo);';"
            "$k=Add-Type -MemberDefinition $sig -Name U32 -Namespace W -PassThru;"
            f"$k::keybd_event({vk},0,0,[UIntPtr]::Zero);"
            f"$k::keybd_event({vk},0,2,[UIntPtr]::Zero)"
        )
        self.runner(["powershell", "-NoProfile", "-Command", script])

    # -- управление ---------------------------------------------------------
    def play(self) -> None:
        plat = self._plat()
        if plat == "darwin":
            self._osascript('tell application "Music" to play')
        elif plat == "windows":
            self._win_media_key("play_pause")
        else:
            self._linux("play")

    def pause(self) -> None:
        plat = self._plat()
        if plat == "darwin":
            self._osascript('tell application "Music" to pause')
        elif plat == "windows":
            self._win_media_key("play_pause")  # media key = toggle
        else:
            self._linux("pause")

    def stop(self) -> None:
        plat = self._plat()
        if plat == "darwin":
            self._osascript('tell application "Music" to stop')
        elif plat == "windows":
            self._win_media_key("stop")
        else:
            self._linux("stop")

    def next_track(self) -> None:
        plat = self._plat()
        if plat == "darwin":
            self._osascript('tell application "Music" to next track')
        elif plat == "windows":
            self._win_media_key("next")
        else:
            self._linux("next")

    def previous_track(self) -> None:
        plat = self._plat()
        if plat == "darwin":
            self._osascript('tell application "Music" to previous track')
        elif plat == "windows":
            self._win_media_key("previous")
        else:
            self._linux("previous")

    # -- текущий трек ---------------------------------------------------------
    def now_playing(self) -> MediaInfo | None:
        plat = self._plat()
        if plat == "windows":
            raise MediaUnsupported("чтение метаданных на Windows не поддерживается")
        if plat == "darwin":
            out = self._osascript(
                'tell application "Music" to '
                f'player state & "{_FIELD_SEP}" & artist of current track & '
                f'"{_FIELD_SEP}" & name of current track'
            )
        else:
            out = self._linux(
                "metadata",
                "--format",
                "{{status}}" + _FIELD_SEP + "{{artist}}" + _FIELD_SEP + "{{title}}",
            )
        return _parse_now_playing(out)


def _parse_now_playing(raw: str) -> MediaInfo | None:
    """
    Разбирает строку ``статус|исполнитель|название`` в ``MediaInfo``.

    Пустой результат означает, что метаданных нет (проигрыватель молчит).
    """
    line = (raw or "").strip().splitlines()[0] if (raw or "").strip() else ""
    if not line:
        return None
    parts = line.split(_FIELD_SEP)
    # гарантируем три поля, даже если метаданные неполные
    while len(parts) < 3:
        parts.append("")
    status, artist, title = parts[0], parts[1], parts[2]
    return MediaInfo(
        status=_normalize_status(status),
        artist=artist.strip(),
        title=title.strip(),
    )


# ---------------------------------------------------------------------------
# Безопасный исполнитель (fallback / отладка / тесты)
# ---------------------------------------------------------------------------
@dataclass
class DryRunMediaBackend(MediaBackend):
    """
    Ничего не запускает: записывает операции в ``calls`` и держит фиктивное
    состояние проигрывателя. Используется в тестах и как fallback.
    """

    name: str = "dry-run"
    available: bool = True
    status: str = PlaybackStatus.STOPPED
    info: MediaInfo | None = field(
        default_factory=lambda: MediaInfo(status=PlaybackStatus.STOPPED, artist="", title="")
    )
    calls: list[tuple[str, tuple[Any, ...]]] = field(default_factory=list)

    def is_available(self) -> bool:
        return self.available

    def play(self) -> None:
        self.calls.append(("play", ()))
        self.status = PlaybackStatus.PLAYING
        if self.info is not None:
            self.info.status = PlaybackStatus.PLAYING

    def pause(self) -> None:
        self.calls.append(("pause", ()))
        self.status = PlaybackStatus.PAUSED
        if self.info is not None:
            self.info.status = PlaybackStatus.PAUSED

    def stop(self) -> None:
        self.calls.append(("stop", ()))
        self.status = PlaybackStatus.STOPPED
        if self.info is not None:
            self.info.status = PlaybackStatus.STOPPED

    def next_track(self) -> None:
        self.calls.append(("next_track", ()))
        if self.info is not None:
            self.info.title = "next-track"

    def previous_track(self) -> None:
        self.calls.append(("previous_track", ()))
        if self.info is not None:
            self.info.title = "prev-track"

    def now_playing(self) -> MediaInfo | None:
        self.calls.append(("now_playing", ()))
        return self.info


# ---------------------------------------------------------------------------
# Служба команд мультимедиа
# ---------------------------------------------------------------------------
@dataclass
class MediaActions:
    """
    Служба команд мультимедиа: валидация входа + backend.

    При недоступности backend операции падают контролируемо
    (``MediaUnavailable``), без побочных эффектов.
    """

    backend: MediaBackend = field(default_factory=SubprocessMediaBackend)

    def _require_backend(self) -> MediaBackend:
        if not self.backend.is_available():
            raise MediaUnavailable(f"исполнитель '{self.backend.name}' недоступен")
        return self.backend

    # -- команды ------------------------------------------------------------
    def play(self) -> str:
        """Возобновить воспроизведение."""
        self._require_backend().play()
        logger.info("Медиа: play")
        return "Воспроизведение возобновлено."

    def pause(self) -> str:
        """Поставить воспроизведение на паузу."""
        self._require_backend().pause()
        logger.info("Медиа: pause")
        return "Пауза."

    def stop(self) -> str:
        """Остановить воспроизведение."""
        self._require_backend().stop()
        logger.info("Медиа: stop")
        return "Воспроизведение остановлено."

    def next(self) -> str:
        """Переключить на следующий трек."""
        self._require_backend().next_track()
        logger.info("Медиа: next")
        return "Следующий трек."

    def previous(self) -> str:
        """Переключить на предыдущий трек."""
        self._require_backend().previous_track()
        logger.info("Медиа: previous")
        return "Предыдущий трек."

    def now_playing(self) -> str:
        """Описание текущего трека (голосовой ответ)."""
        info = self._require_backend().now_playing()
        if info is None:
            return "Сейчас ничего не воспроизводится."
        return info.describe()


# ---------------------------------------------------------------------------
# Регистрация команд в реестре
# ---------------------------------------------------------------------------
def register_media_actions(
    registry: CommandRegistry,
    actions: MediaActions | None = None,
) -> list[str]:
    """
    Регистрирует команды мультимедиа в ``registry`` (возвращает их имена).

    Уровни риска (ТЗ-6.7): все команды воспроизведения обратимы и не
    изменяют данные → SAFE (без подтверждения).
    """
    svc = actions or MediaActions()

    defs: list[tuple[str, str, list[ParamSpec], str, Callable[..., Any]]] = [
        (
            "media_play",
            "Возобновить воспроизведение медиа",
            [],
            RiskLevel.SAFE,
            svc.play,
        ),
        (
            "media_pause",
            "Поставить воспроизведение медиа на паузу",
            [],
            RiskLevel.SAFE,
            svc.pause,
        ),
        (
            "media_stop",
            "Остановить воспроизведение медиа",
            [],
            RiskLevel.SAFE,
            svc.stop,
        ),
        (
            "media_next",
            "Переключить на следующий трек",
            [],
            RiskLevel.SAFE,
            svc.next,
        ),
        (
            "media_previous",
            "Переключить на предыдущий трек",
            [],
            RiskLevel.SAFE,
            svc.previous,
        ),
        (
            "now_playing",
            "Показать, какой трек сейчас играет",
            [],
            RiskLevel.SAFE,
            svc.now_playing,
        ),
    ]

    names: list[str] = []
    for name, description, params, risk, handler in defs:
        registry.register(
            Command(
                name=name,
                description=description,
                params=params,
                handler=handler,
                risk=risk,
                requires_confirmation=REQUIRES_CONFIRMATION.get(risk, False),
            )
        )
        names.append(name)
    logger.debug("Зарегистрированы команды мультимедиа: %s", ", ".join(names))
    return names
