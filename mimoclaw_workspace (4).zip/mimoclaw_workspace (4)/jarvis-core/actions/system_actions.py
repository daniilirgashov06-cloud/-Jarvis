"""
Системные команды JARVIS CORE (ТЗ-6, каталог system).

Команды уровня «система»: информация о машине, громкость, блокировка,
сон, выключение/перезагрузка, открытие URL. Каждая команда имеет
уровень риска (``RiskLevel``) и регистрируется в ``CommandRegistry``,
откуда она попадает в схемы function calling для LLM.

Архитектура (в стиле ``speech/`` и ``ai/``):

- ``SystemBackend`` — контракт «исполнитель» системных операций;
- ``SubprocessBackend`` — локальная реализация через subprocess
  (Linux / macOS / Windows), команды строятся под платформу;
- ``DryRunBackend`` — безопасный fallback/отладка: ничего не выполняет,
  только записывает операции (используется и в тестах).

«Локально ↔ облако» здесь неприменимо: все операции локальные,
но при недоступности исполнителя команда падает контролируемо
(``SystemUnavailable``) без вредных побочных эффектов.

Использование:
    from actions.registry import CommandRegistry
    from actions.system_actions import SystemActions, register_system_actions

    registry = CommandRegistry()
    register_system_actions(registry)          # или со своим backend
"""

from __future__ import annotations

import abc
import logging
import platform
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Any, Callable
from urllib.parse import urlparse

from actions.registry import REQUIRES_CONFIRMATION, Command, CommandRegistry, RiskLevel
from ai.function_calling import ParamSpec

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class SystemError(Exception):
    """Ошибка системной команды."""


class SystemUnavailable(SystemError):
    """Исполнитель недоступен (нет утилиты/прав) — можно fallback."""


# ---------------------------------------------------------------------------
# Контракт исполнителя
# ---------------------------------------------------------------------------
class SystemBackend(abc.ABC):
    """Контракт исполнителя системных операций."""

    name: str = "base"

    @abc.abstractmethod
    def is_available(self) -> bool: ...

    @abc.abstractmethod
    def system_info(self) -> dict[str, Any]: ...

    @abc.abstractmethod
    def get_volume(self) -> int: ...

    @abc.abstractmethod
    def set_volume(self, level: int) -> None: ...

    @abc.abstractmethod
    def set_mute(self, muted: bool) -> None: ...

    @abc.abstractmethod
    def lock(self) -> None: ...

    @abc.abstractmethod
    def shutdown(self, delay_seconds: int) -> None: ...

    @abc.abstractmethod
    def restart(self, delay_seconds: int) -> None: ...

    @abc.abstractmethod
    def sleep(self) -> None: ...

    @abc.abstractmethod
    def open_url(self, url: str) -> None: ...

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "available": self.is_available()}


# ---------------------------------------------------------------------------
# Реальный исполнитель (subprocess)
# ---------------------------------------------------------------------------
#: Тип «запуск argv -> stdout» (подменяется в тестах)
Runner = Callable[[list[str]], str]


def _default_runner(argv: list[str]) -> str:
    """Выполняет argv и возвращает stdout; ошибки оборачивает в SystemError."""
    try:
        proc = subprocess.run(  # noqa: S603 — argv формируем сами, shell=False
            argv,
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
    except FileNotFoundError as e:
        raise SystemUnavailable(f"утилита не найдена: {argv[0]}") from e
    except subprocess.TimeoutExpired as e:
        raise SystemError(f"таймаут команды: {' '.join(argv)}") from e
    if proc.returncode != 0:
        raise SystemError(
            f"команда завершилась с кодом {proc.returncode}: {' '.join(argv)}"
            f" ({proc.stderr.strip()[:200]})"
        )
    return proc.stdout


@dataclass
class SubprocessBackend(SystemBackend):
    """
    Локальный исполнитель: строит и выполняет команды под текущую ОС.

    runner подменяется в тестах; platform_name позволяет сымитировать
    другую платформу (linux / darwin / windows).
    """

    name: str = "subprocess"
    runner: Runner = field(default=_default_runner)
    platform_name: str = field(default_factory=platform.system)

    def _plat(self) -> str:
        return self.platform_name.lower()

    def is_available(self) -> bool:
        return self._plat() in {"linux", "darwin", "windows"}

    def system_info(self) -> dict[str, Any]:
        info: dict[str, Any] = {
            "platform": platform.platform(),
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
            "python": platform.python_version(),
        }
        try:
            import psutil  # опциональная зависимость

            vm = psutil.virtual_memory()
            info["cpu_percent"] = psutil.cpu_percent(interval=None)
            info["ram_percent"] = vm.percent
            info["ram_used_mb"] = round(vm.used / 1024 / 1024)
            info["ram_total_mb"] = round(vm.total / 1024 / 1024)
        except Exception:  # noqa: BLE001 — psutil не обязателен
            try:
                load1, load5, load15 = __import__("os").getloadavg()
                info["load_avg"] = [load1, load5, load15]
            except (OSError, AttributeError):
                pass
        return info

    # -- громкость ---------------------------------------------------------
    def get_volume(self) -> int:
        plat = self._plat()
        if plat == "darwin":
            out = self.runner(["osascript", "-e", "output volume of (get volume settings)"])
        elif plat == "windows":
            out = self.runner(
                ["powershell", "-NoProfile", "-Command",
                 "(Get-AudioDevice -PlaybackVolume)"]
            )
        else:
            out = self.runner(["amixer", "get", "Master"])
        m = re.search(r"(\d{1,3})\s*%?", out)
        if not m:
            raise SystemError(f"не удалось разобрать уровень громкости: {out[:120]!r}")
        return max(0, min(100, int(m.group(1))))

    def set_volume(self, level: int) -> None:
        plat = self._plat()
        if plat == "darwin":
            self.runner(["osascript", "-e", f"set volume output volume {level}"])
        elif plat == "windows":
            self.runner(
                ["powershell", "-NoProfile", "-Command",
                 f"(Get-AudioDevice -PlaybackVolume {level})"]
            )
        else:
            self.runner(["amixer", "set", "Master", f"{level}%"])

    def set_mute(self, muted: bool) -> None:
        plat = self._plat()
        flag = "true" if muted else "false"
        if plat == "darwin":
            self.runner(["osascript", "-e", f"set volume output muted {flag}"])
        elif plat == "windows":
            self.runner(
                ["powershell", "-NoProfile", "-Command",
                 f"(Get-AudioDevice -PlaybackMute {flag})"]
            )
        else:
            self.runner(["amixer", "set", "Master", "on" if not muted else "mute"])

    # -- питание/сеанс -----------------------------------------------------
    def lock(self) -> None:
        plat = self._plat()
        if plat == "darwin":
            self.runner(["pmset", "displaysleepnow"])
        elif plat == "windows":
            self.runner(["rundll32.exe", "user32.dll,LockWorkStation"])
        else:
            if shutil.which("loginctl"):
                self.runner(["loginctl", "lock-session"])
            else:
                self.runner(["xdg-screensaver", "lock"])

    def shutdown(self, delay_seconds: int) -> None:
        plat = self._plat()
        if plat == "darwin":
            self.runner(["osascript", "-e", f"tell app \"System Events\" to shut down"])
        elif plat == "windows":
            self.runner(["shutdown", "/s", "/t", str(delay_seconds)])
        else:
            self.runner(["shutdown", "-h", f"+{max(0, delay_seconds) // 60}"])

    def restart(self, delay_seconds: int) -> None:
        plat = self._plat()
        if plat == "darwin":
            self.runner(["osascript", "-e", f"tell app \"System Events\" to restart"])
        elif plat == "windows":
            self.runner(["shutdown", "/r", "/t", str(delay_seconds)])
        else:
            self.runner(["shutdown", "-r", f"+{max(0, delay_seconds) // 60}"])

    def sleep(self) -> None:
        plat = self._plat()
        if plat == "darwin":
            self.runner(["pmset", "sleepnow"])
        elif plat == "windows":
            self.runner(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"])
        else:
            self.runner(["systemctl", "suspend"])

    def open_url(self, url: str) -> None:
        plat = self._plat()
        if plat == "darwin":
            self.runner(["open", url])
        elif plat == "windows":
            self.runner(["cmd", "/c", "start", "", url])
        else:
            opener = "xdg-open" if shutil.which("xdg-open") else "sensible-browser"
            self.runner([opener, url])


# ---------------------------------------------------------------------------
# Безопасный исполнитель (fallback / отладка / тесты)
# ---------------------------------------------------------------------------
@dataclass
class DryRunBackend(SystemBackend):
    """
    Ничего не выполняет: записывает операции в ``calls`` и возвращает
    фиктивные значения. Используется как fallback и в тестах.
    """

    name: str = "dry-run"
    volume: int = 50
    muted: bool = False
    available: bool = True
    calls: list[tuple[str, tuple[Any, ...]]] = field(default_factory=list)

    def is_available(self) -> bool:
        return self.available

    def system_info(self) -> dict[str, Any]:
        self.calls.append(("system_info", ()))
        return {"platform": "dry-run", "cpu_percent": 0, "ram_percent": 0}

    def get_volume(self) -> int:
        self.calls.append(("get_volume", ()))
        return self.volume

    def set_volume(self, level: int) -> None:
        self.calls.append(("set_volume", (level,)))
        self.volume = level

    def set_mute(self, muted: bool) -> None:
        self.calls.append(("set_mute", (muted,)))
        self.muted = muted

    def lock(self) -> None:
        self.calls.append(("lock", ()))

    def shutdown(self, delay_seconds: int) -> None:
        self.calls.append(("shutdown", (delay_seconds,)))

    def restart(self, delay_seconds: int) -> None:
        self.calls.append(("restart", (delay_seconds,)))

    def sleep(self) -> None:
        self.calls.append(("sleep", ()))

    def open_url(self, url: str) -> None:
        self.calls.append(("open_url", (url,)))


# ---------------------------------------------------------------------------
# Служба системных команд
# ---------------------------------------------------------------------------
_SAFE_URL_SCHEMES = {"http", "https"}


@dataclass
class SystemActions:
    """
    Служба системных команд: валидация входа + вызов backend.

    При недоступности backend операции падают контролируемо
    (``SystemUnavailable``), без побочных эффектов.
    """

    backend: SystemBackend = field(default_factory=SubprocessBackend)

    def _require_backend(self) -> SystemBackend:
        if not self.backend.is_available():
            raise SystemUnavailable(f"исполнитель '{self.backend.name}' недоступен")
        return self.backend

    # -- информация --------------------------------------------------------
    def system_info(self) -> dict[str, Any]:
        """Сводка о системе (ОС, CPU, RAM)."""
        return self._require_backend().system_info()

    # -- громкость ---------------------------------------------------------
    def get_volume(self) -> int:
        """Текущий уровень громкости (0..100)."""
        return self._require_backend().get_volume()

    def set_volume(self, level: float) -> str:
        """Установить громкость (0..100, дробное округляется)."""
        if not isinstance(level, (int, float)) or isinstance(level, bool):
            raise ValueError(f"уровень громкости должен быть числом, получено: {level!r}")
        value = int(round(float(level)))
        if not 0 <= value <= 100:
            raise ValueError(f"громкость вне диапазона 0..100: {value}")
        self._require_backend().set_volume(value)
        logger.info("Громкость установлена: %d%%", value)
        return f"Громкость установлена на {value}%."

    def set_mute(self, muted: bool) -> str:
        """Включить/выключить звук."""
        if not isinstance(muted, bool):
            raise ValueError(f"muted должен быть bool, получено: {muted!r}")
        self._require_backend().set_mute(muted)
        return "Звук выключен." if muted else "Звук включён."

    # -- питание/сеанс -----------------------------------------------------
    def lock_screen(self) -> str:
        """Заблокировать экран/сеанс."""
        self._require_backend().lock()
        logger.info("Экран заблокирован")
        return "Экран заблокирован."

    def shutdown(self, delay_seconds: int = 0) -> str:
        """Выключить компьютер (с задержкой в секундах)."""
        delay = self._check_delay(delay_seconds)
        self._require_backend().shutdown(delay)
        logger.warning("Запрошено выключение через %d с", delay)
        return f"Выключение через {delay} с." if delay else "Выключение..."

    def restart(self, delay_seconds: int = 0) -> str:
        """Перезагрузить компьютер (с задержкой в секундах)."""
        delay = self._check_delay(delay_seconds)
        self._require_backend().restart(delay)
        logger.warning("Запрошена перезагрузка через %d с", delay)
        return f"Перезагрузка через {delay} с." if delay else "Перезагрузка..."

    def sleep(self) -> str:
        """Усыпить компьютер."""
        self._require_backend().sleep()
        logger.info("Запрошен сон системы")
        return "Усыпляю компьютер..."

    def open_url(self, url: str) -> str:
        """Открыть ссылку в браузере (только http/https)."""
        if not isinstance(url, str) or not url.strip():
            raise ValueError("URL должен быть непустой строкой")
        parsed = urlparse(url.strip())
        if parsed.scheme.lower() not in _SAFE_URL_SCHEMES or not parsed.netloc:
            raise ValueError(f"разрешены только http/https-ссылки: {url!r}")
        self._require_backend().open_url(url.strip())
        return f"Открываю {url.strip()}"

    # -- helpers -----------------------------------------------------------
    @staticmethod
    def _check_delay(delay_seconds: int) -> int:
        if not isinstance(delay_seconds, int) or isinstance(delay_seconds, bool):
            raise ValueError(f"задержка должна быть целым числом секунд: {delay_seconds!r}")
        if delay_seconds < 0:
            raise ValueError(f"задержка не может быть отрицательной: {delay_seconds}")
        return delay_seconds


# ---------------------------------------------------------------------------
# Регистрация команд в реестре
# ---------------------------------------------------------------------------
def _spec(name: str, type_: str, description: str, **kw: Any) -> ParamSpec:
    return ParamSpec(
        name=name,
        type=type_,
        description=description,
        required=kw.get("required", True),
        enum=kw.get("enum"),
        default=kw.get("default"),
    )


def register_system_actions(
    registry: CommandRegistry,
    actions: SystemActions | None = None,
) -> list[str]:
    """
    Регистрирует системные команды в ``registry`` (возвращает их имена).

    Уровни риска (ТЗ-6.7):
      - SAFE:     system_info, get_volume, set_volume, set_mute
      - MEDIUM:   open_url, lock_screen, sleep
      - HIGH:     shutdown, restart (требуют подтверждения)
    """
    svc = actions or SystemActions()

    defs: list[tuple[str, str, list[ParamSpec], str, Callable[..., Any]]] = [
        (
            "system_info",
            "Информация о системе: ОС, процессор, память",
            [],
            RiskLevel.SAFE,
            svc.system_info,
        ),
        (
            "get_volume",
            "Текущий уровень громкости (0..100)",
            [],
            RiskLevel.SAFE,
            svc.get_volume,
        ),
        (
            "set_volume",
            "Установить громкость динамиков",
            [_spec("level", "number", "уровень 0..100")],
            RiskLevel.SAFE,
            svc.set_volume,
        ),
        (
            "set_mute",
            "Включить или выключить звук",
            [_spec("muted", "boolean", "true — выключить звук")],
            RiskLevel.SAFE,
            svc.set_mute,
        ),
        (
            "open_url",
            "Открыть ссылку в браузере (только http/https)",
            [_spec("url", "string", "URL для открытия")],
            RiskLevel.MEDIUM,
            svc.open_url,
        ),
        (
            "lock_screen",
            "Заблокировать экран",
            [],
            RiskLevel.MEDIUM,
            svc.lock_screen,
        ),
        (
            "sleep_system",
            "Усыпить компьютер",
            [],
            RiskLevel.MEDIUM,
            svc.sleep,
        ),
        (
            "shutdown_system",
            "Выключить компьютер (после подтверждения)",
            [_spec("delay_seconds", "integer", "задержка в секундах",
                   required=False, default=0)],
            RiskLevel.HIGH,
            svc.shutdown,
        ),
        (
            "restart_system",
            "Перезагрузить компьютер (после подтверждения)",
            [_spec("delay_seconds", "integer", "задержка в секундах",
                   required=False, default=0)],
            RiskLevel.HIGH,
            svc.restart,
        ),
    ]

    names: list[str] = []
    for name, description, params, risk, handler in defs:
        registry.register(
            Command(
                name=name,
                description=description,
                params=params,
                handler=handler,
                risk=risk,
                requires_confirmation=REQUIRES_CONFIRMATION.get(risk, False),
            )
        )
        names.append(name)
    logger.debug("Зарегистрированы системные команды: %s", ", ".join(names))
    return names
