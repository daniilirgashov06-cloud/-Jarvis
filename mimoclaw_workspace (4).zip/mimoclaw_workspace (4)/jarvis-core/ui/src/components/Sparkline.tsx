/**
 * Sparkline — мини-график метрики (SVG, неоновая заливка).
 */

import { METRIC_POINTS } from "../stores/systemStore";

interface SparklineProps {
  data: number[];
  label: string;
  color?: string;
  suffix?: string;
}

export function Sparkline({ data, label, color = "rgb(var(--accent-rgb))", suffix = "" }: SparklineProps) {
  const points = data.slice(-METRIC_POINTS);
  const max = Math.max(1, ...points);
  const width = 100;
  const height = 32;
  const step = points.length > 1 ? width / (points.length - 1) : width;

  const coords = points.map((value, i) => {
    const x = i * step;
    const y = height - (value / max) * (height - 4) - 2;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });

  const line = coords.length > 1 ? `M ${coords.join(" L ")}` : "";
  const area = coords.length > 1 ? `${line} L ${width},${height} L 0,${height} Z` : "";
  const current = points.length > 0 ? points[points.length - 1] : 0;

  return (
    <div className="rounded-xl border border-line bg-panel-2/50 p-3">
      <div className="mb-1.5 flex items-baseline justify-between">
        <span className="hud-title text-[10px] text-muted">{label}</span>
        <span className="font-heading text-sm tabular-nums text-accent">
          {current}
          {suffix}
        </span>
      </div>
      <svg viewBox={`0 0 ${width} ${height}`} className="h-9 w-full" preserveAspectRatio="none">
        <defs>
          <linearGradient id={`grad-${label.replace(/\W/g, "")}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.45} />
            <stop offset="100%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        {area ? <path d={area} fill={`url(#grad-${label.replace(/\W/g, "")})`} /> : null}
        {line ? (
          <path d={line} fill="none" stroke={color} strokeWidth={1.5} strokeLinejoin="round" />
        ) : (
          <text x={2} y={height / 2} fill="#5C7484" fontSize={6}>
            нет данных
          </text>
        )}
      </svg>
    </div>
  );
}
