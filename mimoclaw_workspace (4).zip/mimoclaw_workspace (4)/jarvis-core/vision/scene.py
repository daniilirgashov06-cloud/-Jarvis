"""
Анализ скриншота «vision-моделью» для зрительного конвейера JARVIS CORE.

Единый контракт ``VisionEngine`` + диспетчер ``SceneRouter`` (живая смена
движков + fallback) + высокоуровневый ``ScreenAnalyst``: описание сцены,
вопрос-ответ по экрану, **клик по описанию** и **голосовое редактирование**
(инструкция со слов → структурированный план действия).

Движки:
  - ``OllamaVisionEngine`` — локально, через Ollama (llava и др.):
    кадр уходит в локальный сервер как base64, ответ разбирается как
    текст или JSON ``{"description", "objects", "answer"}``. Данные
    наружу не уходят;
  - ``HttpVisionEngine`` — облако, пользовательский HTTP-endpoint
    (JSON + base64 PNG). Включается только при явно заданном endpoint
    (локально-first);
  - ``SyntheticVisionEngine`` — детерминированные результаты для тестов,
    отладки и аварийного fallback, чтобы пайплайн не падал без модели.

Приватность: облачный движок отправляет фрагмент скриншота на внешний
сервис — используется только осознанно (см. ``HttpVisionEngine``).
Локальные движки (Ollama, синтетика) данные наружу не отдают.

Голосовое редактирование намеренно консервативно: разбирается только
очевидный синтаксис («кликни …», «введи …», «прокрути …»), всё
неоднозначное получает ``needs_confirmation`` и НЕ исполняется
``apply_edit`` без явного подтверждения.
"""

from __future__ import annotations

import abc
import base64
import collections.abc
import dataclasses
import json
import logging
import os
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

from vision.detector import DetectionBox, ScreenDetector, normalize_label
from vision.ocr import OCRImage

logger = logging.getLogger(__name__)

#: максимальная длина описания сцены
MAX_DESCRIPTION_LENGTH: int = 4000

#: максимальная длина вопроса к сцене
MAX_QUESTION_LENGTH: int = 2000

#: максимальная длина голосовой инструкции
MAX_INSTRUCTION_LENGTH: int = 1000

#: максимальное число объектов в анализе сцены (защита от «бомбы»)
MAX_SCENE_OBJECTS: int = 256

#: ограничение на размер ответа движка (байты)
MAX_RESPONSE_BYTES: int = 2_000_000

#: управляющие символы, кроме \t и \n (антиинъекция в промпты/логи)
_CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

#: глаголы голосовых инструкций (ru/en), нормализованные ё→е, нижний регистр
_CLICK_VERBS: tuple[str, ...] = (
    "кликни",
    "клик",
    "нажми",
    "нажать",
    "открой",
    "открыть",
    "выбери",
    "выбрать",
    "перейди",
    "click",
    "press",
    "open",
    "select",
)
_TYPE_VERBS: tuple[str, ...] = (
    "введи",
    "ввести",
    "напечатай",
    "напечатать",
    "набери",
    "набрать",
    "впиши",
    "вписать",
    "type",
    "enter",
    "write",
)
_SCROLL_VERBS: tuple[str, ...] = (
    "прокрути",
    "прокрутить",
    "листай",
    "листать",
    "пролистай",
    "scroll",
    "scroll down",
    "scroll up",
)
_DOWN_WORDS: tuple[str, ...] = ("вниз", "ниже", "down")
_UP_WORDS: tuple[str, ...] = ("вверх", "выше", "up")

#: кавычки, в которых пользователь указывает цель действия
_QUOTED_RE = re.compile(r"[«\"'“](.+?)[»\"'”]")


class SceneError(Exception):
    """Ошибка анализа сцены."""


class SceneUnavailable(SceneError):
    """Движок недоступен (нет модели/сети/ресурсов) — можно fallback."""


# ---------------------------------------------------------------------------
# Валидация текста
# ---------------------------------------------------------------------------
def normalize_description(text: str) -> str:
    """Нормализация текста сцены: ё→е, схлопывание пробелов, нижний регистр."""
    if not isinstance(text, str):
        raise ValueError("text должен быть str")
    return " ".join(text.lower().replace("ё", "е").split())


def _validate_text(
    value: str, *, name: str, limit: int, allow_empty: bool = False
) -> str:
    """Проверяет текстовый параметр (длина, управляющие символы)."""
    if not isinstance(value, str):
        raise ValueError(f"{name} должен быть str")
    if not allow_empty and not value.strip():
        raise ValueError(f"{name} не может быть пустым")
    if len(value) > limit:
        raise ValueError(f"{name} слишком длинный (лимит {limit})")
    if _CTRL_RE.search(value):
        raise ValueError(f"{name} не может содержать управляющие символы")
    return value


def _as_image(image: OCRImage) -> OCRImage:
    """Проверяет, что передан растр ``OCRImage``."""
    if not isinstance(image, OCRImage):
        raise SceneError(f"image должен быть OCRImage, получено: {type(image).__name__}")
    return image


# ---------------------------------------------------------------------------
# Результат анализа сцены
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class SceneAnalysis:
    """
    Итог анализа сцены: описание, ответ на вопрос, объекты и метаданные.

    ``objects`` — коробки в тех же координатах, что и кадр (см.
    ``vision.detector.DetectionBox``), чтобы «клик по описанию» переиспользовал
    готовую геометрию.
    """

    description: str = ""
    objects: tuple[DetectionBox, ...] = ()
    answer: str = ""
    question: str = ""
    engine: str = ""
    elapsed_ms: float = 0.0

    def __post_init__(self) -> None:
        if not isinstance(self.objects, tuple):
            object.__setattr__(self, "objects", tuple(self.objects))
        if len(self.objects) > MAX_SCENE_OBJECTS:
            raise SceneError(f"слишком много объектов сцены (лимит {MAX_SCENE_OBJECTS})")
        for name in ("description", "answer", "question", "engine"):
            value = getattr(self, name)
            if not isinstance(value, str):
                raise SceneError(f"{name} должен быть str")
        if _CTRL_RE.search(self.description) or _CTRL_RE.search(self.answer):
            raise SceneError("описание/ответ не могут содержать управляющие символы")
        if isinstance(self.elapsed_ms, bool) or not isinstance(
            self.elapsed_ms, (int, float)
        ):
            raise SceneError("elapsed_ms должен быть числом")

    # -- поиск объектов ---------------------------------------------------
    def find(self, label: str, *, min_confidence: float = 0.0) -> list[DetectionBox]:
        """Коробки объектов с подписью ``label`` (нормализованный поиск ё↔е/регистр)."""
        wanted = normalize_label(label)
        return [
            box
            for box in self.objects
            if normalize_label(box.label) == wanted and box.confidence >= min_confidence
        ]

    def best(self, label: str) -> DetectionBox | None:
        """Самая уверенная коробка объекта ``label`` либо ``None``."""
        matches = self.find(label)
        return max(matches, key=lambda b: b.confidence) if matches else None

    @property
    def labels(self) -> tuple[str, ...]:
        """Уникальные подписи объектов сцены (по порядку появления)."""
        seen: list[str] = []
        for box in self.objects:
            if box.label not in seen:
                seen.append(box.label)
        return tuple(seen)

    # -- выдача -----------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        """Словарь для JSON/логов/сериализации."""
        return {
            "description": self.description,
            "answer": self.answer,
            "question": self.question,
            "engine": self.engine,
            "elapsed_ms": round(self.elapsed_ms, 3),
            "objects": [
                {
                    "label": b.label,
                    "x": b.x,
                    "y": b.y,
                    "width": b.width,
                    "height": b.height,
                    "confidence": b.confidence,
                }
                for b in self.objects
            ],
        }

    def to_prompt_text(self) -> str:
        """Компактное представление сцены для контекста LLM (см. ``ai.context_builder``)."""
        lines = [f"Сцена: {self.description or '(без описания)'}"]
        if self.question:
            lines.append(f"Вопрос: {self.question}")
        if self.answer:
            lines.append(f"Ответ: {self.answer}")
        if self.objects:
            rendered = ", ".join(
                f"{b.label} ({b.confidence:.0f}%) {b.width}x{b.height}"
                for b in self.objects[:16]
            )
            lines.append(f"Объекты: {rendered}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# План голосового редактирования
# ---------------------------------------------------------------------------
#: допустимые действия плана
EDIT_ACTIONS: frozenset[str] = frozenset({"click", "type", "scroll", "unknown"})


@dataclass(frozen=True)
class EditPlan:
    """
    Структурированный план голосового редактирования сцены.

    ``action`` — ``click`` / ``type`` / ``scroll`` / ``unknown``;
    ``point`` — разрешённая точка клика (абсолютные координаты кадра);
    ``needs_confirmation`` — план не исполняется без явного подтверждения.
    """

    action: str = "unknown"
    target: str = ""
    text: str = ""
    point: tuple[int, int] | None = None
    needs_confirmation: bool = True

    def __post_init__(self) -> None:
        if self.action not in EDIT_ACTIONS:
            raise SceneError(f"неизвестное действие плана: {self.action!r}")
        _validate_text(self.target, name="target", limit=200, allow_empty=True)
        _validate_text(
            self.text, name="text", limit=MAX_INSTRUCTION_LENGTH, allow_empty=True
        )
        if self.point is not None:
            if (
                not isinstance(self.point, tuple)
                or len(self.point) != 2
                or any(isinstance(v, bool) or not isinstance(v, int) for v in self.point)
                or any(v < 0 for v in self.point)
            ):
                raise SceneError("point должен быть кортежем (x, y) из неотрицательных int")
        if not isinstance(self.needs_confirmation, bool):
            raise SceneError("needs_confirmation должен быть bool")

    def to_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "target": self.target,
            "text": self.text,
            "point": list(self.point) if self.point else None,
            "needs_confirmation": self.needs_confirmation,
        }


def parse_edit_instruction(instruction: str) -> EditPlan:
    """
    Разбирает голосовую инструкцию (текст из STT) в план ``EditPlan``.

    Локальная эвристика без внешних вызовов: глагол действия + цель
    (в кавычках либо остаток фразы). Всё неоднозначное → ``unknown``
    с ``needs_confirmation=True`` — исполнять такое нельзя.
    """
    text = _validate_text(
        instruction, name="instruction", limit=MAX_INSTRUCTION_LENGTH
    )
    # плоская нормализация той же длины (lower + ё→е) — позиции глаголов
    # совпадают с исходной фразой, остаток фразы режем точно
    flat = text.lower().replace("ё", "е")
    quoted = _QUOTED_RE.search(text)
    quoted_target = quoted.group(1).strip() if quoted else ""

    def _find_verb(verbs: Sequence[str]) -> re.Match[str] | None:
        """Первый (по позиции) глагол из ``verbs`` во фразе."""
        found: re.Match[str] | None = None
        for verb in verbs:
            m = re.search(rf"\b{re.escape(verb)}\b", flat)
            if m is not None and (found is None or m.start() < found.start()):
                found = m
        return found

    for verbs, action in (
        (_CLICK_VERBS, "click"),
        (_TYPE_VERBS, "type"),
        (_SCROLL_VERBS, "scroll"),
    ):
        match = _find_verb(verbs)
        if match is None:
            continue
        tail = text[match.end() :].strip(" ,:-")
        if action == "scroll":
            direction = (
                "down"
                if any(w in flat for w in _DOWN_WORDS)
                else "up"
                if any(w in flat for w in _UP_WORDS)
                else "down"
            )
            return EditPlan(
                action="scroll",
                target=direction,
                text="",
                needs_confirmation=False,
            )
        if action == "type":
            # для ввода текстом цель — сам вводимый текст
            payload = quoted_target or tail
            return EditPlan(
                action="type",
                target="",
                text=payload,
                needs_confirmation=not bool(payload.strip()),
            )
        target = quoted_target or tail
        return EditPlan(
            action="click",
            target=target,
            needs_confirmation=not bool(target.strip()),
        )
    return EditPlan(action="unknown", target=text[:200], needs_confirmation=True)


# ---------------------------------------------------------------------------
# Контракт движка
# ---------------------------------------------------------------------------
class VisionEngine(abc.ABC):
    """Контракт «vision-модели»: анализ кадра (описание / вопрос-ответ / объекты)."""

    name: str = "vision"

    @abc.abstractmethod
    def is_available(self) -> bool:
        """Движок готов принимать запросы (без проверки сети/модели)."""

    @abc.abstractmethod
    def analyze(
        self, image: OCRImage, *, question: str | None = None
    ) -> SceneAnalysis:
        """Анализирует кадр и возвращает ``SceneAnalysis``."""

    def describe(self) -> dict[str, Any]:
        """Самоописание для диагностики (``ui_server`` / логи)."""
        return {"name": self.name, "available": self.is_available()}


# ---------------------------------------------------------------------------
# Общие разборщики ответа
# ---------------------------------------------------------------------------
def _parse_objects(raw: Any) -> tuple[DetectionBox, ...]:
    """Разбирает список объектов из JSON-ответа движка (строгая геометрия)."""
    if raw is None:
        return ()
    if not isinstance(raw, list):
        raise SceneError("objects должен быть списком")
    boxes: list[DetectionBox] = []
    for item in raw[:MAX_SCENE_OBJECTS]:
        if not isinstance(item, dict):
            raise SceneError("некорректный элемент objects в ответе")
        try:
            boxes.append(
                DetectionBox(
                    label=str(item["label"]),
                    x=int(item.get("x", 0)),
                    y=int(item.get("y", 0)),
                    width=int(item.get("width", 0)),
                    height=int(item.get("height", 0)),
                    confidence=float(item.get("confidence", 0.0)),
                )
            )
        except (ValueError, TypeError, KeyError) as exc:
            raise SceneError(f"некорректный объект сцены в ответе: {exc}") from exc
    return tuple(boxes)


def _extract_json_block(content: str) -> dict[str, Any] | None:
    """Достаёт первый JSON-объект из свободного текста модели (или ``None``)."""
    start = content.find("{")
    end = content.rfind("}")
    if start < 0 or end <= start:
        return None
    try:
        doc = json.loads(content[start : end + 1])
    except ValueError:
        return None
    return doc if isinstance(doc, dict) else None


# ---------------------------------------------------------------------------
# Локально: Ollama (llava и другие vision-модели)
# ---------------------------------------------------------------------------
class OllamaVisionEngine(VisionEngine):
    """
    Локальная «vision-модель» через Ollama (``/api/chat``, ``images`` в base64).

    Ответ модели — свободный текст либо JSON
    ``{"description": ..., "objects": [...], "answer": ...}``.
    Неструктурированный ответ не ошибка: он становится ``description``.
    Сетевые/протокольные сбои → ``SceneUnavailable`` (роутер уйдёт в fallback).
    """

    name = "ollama"

    def __init__(
        self,
        *,
        endpoint: str = "http://127.0.0.1:11434",
        model: str = "llava",
        timeout: float = 60.0,
        prompt: str = (
            "Опиши, что изображено на экране. Если возможно, ответь строго JSON: "
            '{"description": "...", "objects": [{"label", "x", "y", "width", '
            '"height", "confidence"}], "answer": "..."}'
        ),
        opener: Callable[..., Any] | None = None,
    ) -> None:
        if not isinstance(endpoint, str) or not endpoint.startswith(
            ("http://", "https://")
        ):
            raise ValueError("endpoint должен быть http(s)-URL")
        if not isinstance(model, str) or not model.strip():
            raise ValueError("model должен быть непустой строкой")
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)):
            raise ValueError("timeout должен быть числом")
        if not 0.1 <= float(timeout) <= 600.0:
            raise ValueError("timeout должен быть в диапазоне 0.1..600 секунд")
        _validate_text(prompt, name="prompt", limit=MAX_QUESTION_LENGTH)
        self._endpoint = endpoint.rstrip("/")
        self._model = model.strip()
        self._timeout = float(timeout)
        self._prompt = prompt
        self._opener = opener or urllib.request.urlopen

    def is_available(self) -> bool:
        return True

    def analyze(
        self, image: OCRImage, *, question: str | None = None
    ) -> SceneAnalysis:
        img = _as_image(image)
        if question is not None:
            _validate_text(question, name="question", limit=MAX_QUESTION_LENGTH)
        content = self._prompt if question is None else f"{self._prompt}\nВопрос: {question}"
        payload = json.dumps(
            {
                "model": self._model,
                "stream": False,
                "messages": [
                    {
                        "role": "user",
                        "content": content,
                        "images": [base64.b64encode(img.to_png()).decode("ascii")],
                    }
                ],
            }
        ).encode("utf-8")
        request = urllib.request.Request(
            f"{self._endpoint}/api/chat",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        started = time.monotonic()
        try:
            with self._opener(request, timeout=self._timeout) as resp:
                raw = resp.read(MAX_RESPONSE_BYTES)
        except (urllib.error.URLError, OSError) as exc:
            raise SceneUnavailable(f"Ollama недоступна: {exc}") from exc
        except Exception as exc:  # noqa: BLE001 — кастомные opener в тестах
            raise SceneUnavailable(f"Ollama недоступна: {exc}") from exc
        try:
            doc = json.loads(raw.decode("utf-8", "replace"))
        except (ValueError, UnicodeDecodeError) as exc:
            raise SceneError(f"Ollama вернула не JSON: {exc}") from exc
        if not isinstance(doc, dict):
            raise SceneError("Ollama вернула не объект JSON")
        message = doc.get("message")
        text = message.get("content") if isinstance(message, dict) else None
        if not isinstance(text, str) or not text.strip():
            raise SceneError("Ollama вернула пустой ответ модели")
        structured = _extract_json_block(text)
        if structured is not None:
            description = str(structured.get("description") or text)[:MAX_DESCRIPTION_LENGTH]
            answer = str(structured.get("answer") or "")[:MAX_DESCRIPTION_LENGTH]
            objects = _parse_objects(structured.get("objects"))
        else:
            description, answer, objects = text[:MAX_DESCRIPTION_LENGTH], "", ()
        return SceneAnalysis(
            description=description.strip(),
            answer=answer.strip(),
            question=question or "",
            objects=objects,
            engine=self.name,
            elapsed_ms=(time.monotonic() - started) * 1000.0,
        )

    def describe(self) -> dict[str, Any]:
        info = super().describe()
        info.update({"endpoint": self._endpoint, "model": self._model})
        return info


# ---------------------------------------------------------------------------
# Облако: пользовательский HTTP-endpoint (опционально)
# ---------------------------------------------------------------------------
class HttpVisionEngine(VisionEngine):
    """
    Облачная «vision-модель» через пользовательский HTTP-endpoint (JSON + base64).

    Запрос:  ``POST {"image": <base64>, "question": <str|null>}``
    Ответ:   ``{"description": "...", "answer": "...", "objects": [...]}``

    ⚠️ Отправляет фрагмент скриншота на внешний сервис — включайте осознанно.
    Ключ берётся из переменной окружения ``api_key_env`` (заголовок
    ``Authorization: Bearer ...``) и никуда не логируется.
    """

    name = "http"

    def __init__(
        self,
        endpoint: str,
        *,
        api_key_env: str = "JARVIS_VISION_API_KEY",
        timeout: float = 30.0,
        opener: Callable[..., Any] | None = None,
    ) -> None:
        if not isinstance(endpoint, str) or not endpoint.startswith(
            ("http://", "https://")
        ):
            raise ValueError("endpoint должен быть http(s)-URL")
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)):
            raise ValueError("timeout должен быть числом")
        if not 0.1 <= float(timeout) <= 120.0:
            raise ValueError("timeout должен быть в диапазоне 0.1..120 секунд")
        if not isinstance(api_key_env, str) or not api_key_env:
            raise ValueError("api_key_env должен быть непустой строкой")
        self._endpoint = endpoint
        self._api_key_env = api_key_env
        self._timeout = float(timeout)
        self._opener = opener or urllib.request.urlopen

    def is_available(self) -> bool:
        # доступность = настроенный endpoint (сеть проверяется в момент запроса)
        return True

    def analyze(
        self, image: OCRImage, *, question: str | None = None
    ) -> SceneAnalysis:
        img = _as_image(image)
        if question is not None:
            _validate_text(question, name="question", limit=MAX_QUESTION_LENGTH)
        payload = json.dumps(
            {
                "image": base64.b64encode(img.to_png()).decode("ascii"),
                "question": question,
            }
        ).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        key = os.environ.get(self._api_key_env, "")
        if key:
            headers["Authorization"] = f"Bearer {key}"
        request = urllib.request.Request(self._endpoint, data=payload, headers=headers)
        started = time.monotonic()
        try:
            with self._opener(request, timeout=self._timeout) as resp:
                raw = resp.read(MAX_RESPONSE_BYTES)
        except (urllib.error.URLError, OSError) as exc:
            raise SceneUnavailable(f"облачная vision-модель недоступна: {exc}") from exc
        except Exception as exc:  # noqa: BLE001 — кастомные opener в тестах
            raise SceneUnavailable(f"облачная vision-модель недоступна: {exc}") from exc
        try:
            doc = json.loads(raw.decode("utf-8", "replace"))
        except (ValueError, UnicodeDecodeError) as exc:
            raise SceneError(f"облачная vision-модель вернула не JSON: {exc}") from exc
        if not isinstance(doc, dict):
            raise SceneError("облачная vision-модель вернула не объект JSON")
        return SceneAnalysis(
            description=str(doc.get("description") or "")[:MAX_DESCRIPTION_LENGTH],
            answer=str(doc.get("answer") or "")[:MAX_DESCRIPTION_LENGTH],
            question=question or "",
            objects=_parse_objects(doc.get("objects")),
            engine=self.name,
            elapsed_ms=(time.monotonic() - started) * 1000.0,
        )

    def describe(self) -> dict[str, Any]:
        info = super().describe()
        info.update({"endpoint": self._endpoint, "api_key_env": self._api_key_env})
        return info


# ---------------------------------------------------------------------------
# Синтетика: тесты / отладка / аварийный fallback
# ---------------------------------------------------------------------------
@dataclass
class SyntheticVisionEngine(VisionEngine):
    """
    Детерминированные результаты для тестов, отладки и аварийного fallback.

    Не обращается ни к сети, ни к моделям: описание/объекты задаются при
    создании, ответ на вопрос — по шаблону. Гарантирует, что пайплайн
    «опиши экран» не падает даже без единой vision-модели.
    """

    description: str = "Синтетическая сцена"
    objects: tuple[DetectionBox, ...] = ()
    answer_template: str = "Синтетический ответ на вопрос: {question}"
    name: str = "synthetic"

    def is_available(self) -> bool:
        return True

    def analyze(
        self, image: OCRImage, *, question: str | None = None
    ) -> SceneAnalysis:
        _as_image(image)
        if question is not None:
            _validate_text(question, name="question", limit=MAX_QUESTION_LENGTH)
        answer = (
            self.answer_template.format(question=question)[:MAX_DESCRIPTION_LENGTH]
            if question
            else ""
        )
        return SceneAnalysis(
            description=self.description[:MAX_DESCRIPTION_LENGTH],
            answer=answer,
            question=question or "",
            objects=self.objects,
            engine=self.name,
            elapsed_ms=0.0,
        )


# ---------------------------------------------------------------------------
# Диспетчер: смена движков + fallback
# ---------------------------------------------------------------------------
class SceneRouter:
    """Диспетчер «vision-моделей»: смена движков + fallback по цепочке."""

    def __init__(
        self,
        engines: Mapping[str, VisionEngine] | None = None,
        primary: str = "ollama",
        fallback_chain: Sequence[str] | None = None,
    ) -> None:
        self._engines = dict(engines or {})
        self._primary = primary
        self._fallback_chain = list(fallback_chain) if fallback_chain else [primary]

    @property
    def primary(self) -> str:
        return self._primary

    def set_primary(self, name: str) -> None:
        if name not in self._engines:
            raise SceneError(f"Неизвестная vision-модель: {name}")
        self._primary = name
        self._fallback_chain = [name] + [e for e in self._fallback_chain if e != name]
        logger.info("Vision-модель переключена на '%s'", name)

    def available(self) -> list[str]:
        return [n for n, e in self._engines.items() if e.is_available()]

    def _chain(self, explicit: str | None) -> list[str]:
        if explicit:
            return [explicit]
        order = self._fallback_chain or list(self._engines.keys())
        chain = [self._primary] + [n for n in order if n != self._primary]
        chain += [n for n in self._engines if n not in chain]
        return chain

    def analyze(
        self,
        image: OCRImage,
        *,
        question: str | None = None,
        engine: str | None = None,
    ) -> SceneAnalysis:
        """Анализ сцены с обходом цепочки fallback при отказах движков."""
        last_err: Exception | None = None
        for name in self._chain(engine):
            eng = self._engines.get(name)
            if eng is None or not eng.is_available():
                last_err = SceneUnavailable(f"{name}: недоступен")
                continue
            try:
                return eng.analyze(image, question=question)
            except SceneError as exc:
                last_err = exc
                logger.warning("Vision-модель '%s' не справилась: %s", name, exc)
                continue
        raise SceneError(
            f"Ни одна vision-модель не справилась. Последняя ошибка: {last_err}"
        )

    def describe(self) -> dict[str, Any]:
        return {
            "primary": self._primary,
            "available": self.available(),
            "engines": {n: e.describe() for n, e in self._engines.items()},
        }


# ---------------------------------------------------------------------------
# Высокоуровневый сервис: сцена → описание / вопрос / клик / редактирование
# ---------------------------------------------------------------------------
class ScreenAnalyst:
    """
    Готовый конвейер работы со сценой: ``SceneRouter`` (+ опционально
    ``ScreenDetector`` для точной геометрии) → описание, вопрос-ответ,
    клик «по описанию» и голосовое редактирование.

    Клик выполняется только через инжектируемый колбэк ``click(x, y)`` —
    модуль сам не трогает ОС-ввод (это ``actions/input_actions.py``),
    поэтому он детерминированно тестируем и безопасен.
    """

    def __init__(
        self,
        router: SceneRouter,
        *,
        detector: ScreenDetector | None = None,
    ) -> None:
        if not isinstance(router, SceneRouter):
            raise TypeError("router должен быть SceneRouter")
        if detector is not None and not isinstance(detector, ScreenDetector):
            raise TypeError("detector должен быть ScreenDetector либо None")
        self._router = router
        self._detector = detector

    # -- анализ -----------------------------------------------------------
    def describe(self, image: OCRImage) -> SceneAnalysis:
        """Описание сцены (без вопроса)."""
        return self._router.analyze(image)

    def ask(self, image: OCRImage, question: str) -> SceneAnalysis:
        """Вопрос-ответ по экрану: «что за окно открыто?», «сколько вкладок?» …"""
        _validate_text(question, name="question", limit=MAX_QUESTION_LENGTH)
        return self._router.analyze(image, question=question)

    # -- клик по описанию -------------------------------------------------
    def locate(self, image: OCRImage, description: str) -> DetectionBox | None:
        """
        Коробка объекта «по описанию».

        Сначала — точный локальный поиск ``ScreenDetector`` (если подключён);
        если он ничего не нашёл — vision-модель. ``None`` — объект не найден,
        ничего не выдумываем.
        """
        _validate_text(description, name="description", limit=MAX_QUESTION_LENGTH)
        if self._detector is not None:
            try:
                box = self._detector.locate(image, description)
            except Exception as exc:  # noqa: BLE001 — детектор не должен валить сцену
                logger.warning("Детектор не справился с описанием '%s': %s", description, exc)
                box = None
            if box is not None:
                return box
        analysis = self._router.analyze(image, question=f"Где на экране: {description}")
        return analysis.best(description)

    def click_point(self, image: OCRImage, description: str) -> tuple[int, int] | None:
        """Готовая точка клика по описанию либо ``None``."""
        box = self.locate(image, description)
        return box.center if box is not None else None

    def click(
        self,
        image: OCRImage,
        description: str,
        *,
        click: Callable[[int, int], Any],
    ) -> bool:
        """
        Клик по описанию: находит объект и передаёт его центр в колбэк ``click``.

        ``True`` — клик выполнен; ``False`` — объект не найден (ничего не делаем).
        """
        if not callable(click):
            raise ValueError("click должен быть вызываемым")
        point = self.click_point(image, description)
        if point is None:
            logger.info("Объект '%s' не найден — клик пропущен", description)
            return False
        click(*point)
        return True

    # -- голосовое редактирование ----------------------------------------
    def plan_edit(self, image: OCRImage, instruction: str) -> EditPlan:
        """
        Голосовая инструкция → план ``EditPlan`` с разрешённой точкой клика.

        Для ``click``/``type`` точка ищется через ``click_point``; если объект
        не найден, план остаётся с ``needs_confirmation`` — исполнять нечего.
        """
        plan = parse_edit_instruction(instruction)
        if plan.action in ("click", "type") and plan.target:
            point = self.click_point(image, plan.target)
            if point is not None:
                return dataclasses.replace(plan, point=point, needs_confirmation=False)
            return dataclasses.replace(plan, needs_confirmation=True)
        return plan
    def apply_edit(
        self,
        image: OCRImage,
        plan: EditPlan,
        *,
        click: Callable[[int, int], Any] | None = None,
        type_text: Callable[[str], Any] | None = None,
        scroll: Callable[[str], Any] | None = None,
    ) -> bool:
        """
        Исполняет план голосового редактирования через инжектируемые колбэки.

        Планы с ``needs_confirmation`` и ``unknown`` НЕ исполняются — возврат
        ``False`` (никаких «сам решу, что имел в виду пользователь»).
        """
        if not isinstance(plan, EditPlan):
            raise TypeError("plan должен быть EditPlan")
        if plan.needs_confirmation or plan.action == "unknown":
            logger.info("План %r требует подтверждения — не исполняется", plan.action)
            return False
        if plan.action == "scroll":
            if not callable(scroll):
                raise ValueError("для scroll нужен колбэк scroll")
            scroll(plan.target or "down")
            return True
        point = plan.point
        if point is None and plan.target:
            point = self.click_point(image, plan.target)
        if plan.action == "click":
            if point is None or not callable(click):
                return False
            click(*point)
            return True
        if plan.action == "type":
            if not callable(type_text):
                raise ValueError("для type нужен колбэк type_text")
            if point is not None:
                if not callable(click):
                    return False
                click(*point)
            type_text(plan.text)
            return True
        return False


# ---------------------------------------------------------------------------
# Сборка по умолчанию (локально-first)
# ---------------------------------------------------------------------------
def default_scene_router(
    *,
    cloud_endpoint: str | None = None,
    ollama_model: str = "llava",
    synthetic_description: str = "Синтетическая сцена",
) -> SceneRouter:
    """
    Стандартная сборка: локальная Ollama → опционально облако → синтетика.

    ``cloud_endpoint`` включает облачный fallback (см. приватность в описании
    модуля); без него цепочка полностью локальная.
    """
    engines: dict[str, VisionEngine] = {
        "ollama": OllamaVisionEngine(model=ollama_model),
    }
    chain = ["ollama"]
    if cloud_endpoint:
        engines["http"] = HttpVisionEngine(cloud_endpoint)
        chain.append("http")
    engines["synthetic"] = SyntheticVisionEngine(description=synthetic_description)
    chain.append("synthetic")
    return SceneRouter(engines, primary="ollama", fallback_chain=chain)
