# JARVIS CORE — голосовой ИИ-ассистент с управлением ПК

Проект по ТЗ: персональный голосовой ассистент в духе «Железного человека»
для Windows (с перспективой Linux/macOS). Ядро — **Python 3.11+**.

> 📌 **Текущий статус:** готов и протестирован **MVP-бэкенд** (ядро пайплайна).
> Веб-панель (GUI), зрение, память (RAG), Telegram, фишки и упаковка — следующие этапы
> (см. `ROADMAP.md`).

---

## Что уже работает (протестировано)
- **Конфигурация** — Pydantic-модели всех настроек (`config/settings.py` + `default.yaml`),
  секреты из переменных окружения/`.env`.
- **Шина событий** `core/event_bus.py` (pub/sub, wildcard) — модули общаются без связки.
- **AI-ядро** `ai/` — 4 LLM-провайдера (**Ollama локально**, OpenAI, Anthropic, Gemini)
  за единым `LLMRouter` с **живой сменой локально↔облако**, fallback-цепочкой и бюджетом.
  Персоны JARVIS/FRIDAY/Custom, function calling.
- **STT/TTS** `speech/` — `STTRouter`/`TTSRouter` со сменой локально↔облако и fallback
  (faster-whisper / ElevenLabs + локальные fallback), пресеты голосов.
- **Аудио-стек** `audio/` — захват (16 кГц/моно/20 мс), VAD, wake-word «Джарвис/Пятница»,
  детектор хлопков, воспроизведение.
- **Оркестратор** `core/orchestrator.py` — сквозной пайплайн:
  `речь → STT → контекст → LLM (function calling) → действие → ответ → TTS`.
- **Команды** `actions/` — реестр с уровнями риска (SAFE/MEDIUM/HIGH/FORBIDDEN) и
  подтверждениями; готовы system/app/media/productivity (28 команд).
- **Точка входа** `main.py` — режимы `--text` / `--headless` / `--ui`.

Всё покрыто тестами: `tests/` — **12 suite, все зелёные** (pytest не обязателен,
каждый файл запускается `python3 tests/<name>.py`).

---

## Установка и запуск
```bash
pip install -r requirements.txt          # ядро; тяжёлые пакеты — по секциям в файле
cp config/.env.example config/.env       # впишите ключи (опционально)

# Быстрая проверка пайплайна без микрофона:
python main.py --text "поставь громкость 50"

# Фон (голосовой цикл, нужен микрофон):
python main.py --headless

# Веб-панель настроек:
python main.py --ui                       # http://127.0.0.1:8765
```

**Локально-first:** без ключей работает через **Ollama** (`ollama serve` + `ollama pull llama3`).
Облако — опционально, добавьте ключи в `config/.env`:
`OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GEMINI_API_KEY`, `ELEVENLABS_API_KEY`.

---

## Архитектура (кратко)
```
main.py ──> config/settings (Pydantic) + config/logging (loguru)
        ──> core/orchestrator ──┬─ ai/llm_router (4 провайдера, смена/фallback)
                                ├─ speech/stt_engine, speech/tts_engine
                                ├─ ai/context_builder (персона+ПК+RAG+история)
                                └─ actions/registry (команды + риски)
core/event_bus ──> связь всех подсистем (pub/sub)
audio/ ──> capture → vad → wakeword/clap → playback
```
Принципы: модульность через шину, конфиг без хардкода, всё типизировано,
обработка ошибок на каждом уровне (приложение не падает, а сообщает и продолжает).

---

## Ключевые инженерные решения (зафиксированы по ТЗ)
1. **MVP-first** — как требует ТЗ-14: сначала рабочее ядро
   «микрофон → STT → LLM → TTS + базовые команды + панель», никаких «TODO в критичных
   путях»; GUI, зрение, память, Telegram и фишки — только после приёмки MVP.
2. **Локально-first для ИИ/речи** — по умолчанию Ollama + faster-whisper + локальный TTS,
   чтобы запускалось без ключей и без интернета; облако (OpenAI/Anthropic/Gemini/ElevenLabs)
   — опционально и **переключается на лету** через единые роутеры с fallback-цепочкой.
3. **Провайдеры/движки за единым роутером** (`LLMRouter`, `STTRouter`, `TTSRouter`) —
   автопереключение/fallback; добавление нового провайдера не требует правки роутера.
4. **GUI — веб-панель (React+Vite+Tailwind) за FastAPI+WS** — сразу работает в браузере
   и тестируется; Tauri 2 — обёртка для нативного .exe на этапе упаковки.
5. **Модульность через `core/event_bus`** — подсистемы и плагины общаются через шину
   (pub/sub, wildcard) и добавляются без правки ядра.
6. **Конфиг только через Pydantic + `config/default.yaml`** — без хардкода; секреты —
   из переменных окружения/`config/.env` (шаблон `config/.env.example`, в git не попадает).
7. **Разработка на Linux, запуск на Windows** — логика юнит-тестится здесь (`tests/`),
   аппаратные/OS-части (микрофон, трей, win-управление) проверяются на ПК пользователя.
8. **Голоса — стилизация, не клонирование** реальных актёров (юридически чисто, по примечанию ТЗ).

Дополнительно: **команды через реестр** `register_<group>_actions(registry)` с уровнями
риска SAFE/MEDIUM/HIGH/FORBIDDEN и подтверждениями; LLM получает их схемы автоматически
(function calling).

---

## Как продолжать разработку
1. Смотри `ROADMAP.md` — там чек-лист по этапам, что готово и что дальше.
2. Модули `actions/*` регистрируют команды функцией `register_<group>_actions(registry)`;
   `main.py` вызывает её при старте (см. `_load_action_modules`).
3. Каждый модуль — с тестом в `tests/`; прогоняй все перед коммитом:
   `for t in tests/test_*.py; do python3 "$t"; done`
4. Дальше по приоритету (см. ROADMAP): Этап 2 — React-панель настроек → Этап 3 —
   полный каталог команд → vision → memory → telegram → fun → упаковка.

## Тесты
```bash
for t in tests/test_*.py; do python3 "$t"; done   # все suite
python3 tests/test_ai_core.py                      # или по одному
```

---
*Сгенерировано как рабочая основа. Проект модульный, задокументирован и запускается
одной командой. Статус этапов — в `ROADMAP.md`.*
