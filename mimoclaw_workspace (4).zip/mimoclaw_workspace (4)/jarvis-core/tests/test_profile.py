"""
Проверка memory/profile.py — профиль пользователя: эвристическая и
LLM-экстракция фактов, роутер с fallback, слияние фактов, персистентность
(JSON), обучение из текста/записей памяти и приватность.

Запуск:  python3 tests/test_profile.py
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from memory.profile import (
    MAX_MULTI_VALUES,
    HeuristicProfileExtractor,
    InMemoryProfileStore,
    JsonProfileStore,
    LLMProfileExtractor,
    ProfileBuilder,
    ProfileEntry,
    ProfileError,
    ProfileExtractorRouter,
    ProfileUnavailable,
    UserProfile,
    default_profile_extractor_router,
)
from memory.store import MemoryKind, MemoryRecord, PrivacyMode

# ---------------------------------------------------------------------------
# Тестовые данные
# ---------------------------------------------------------------------------
SAMPLE_TEXT = (
    "Меня зовут Иван, я живу в Москве и работаю инженером. "
    "Я люблю чай без сахара и обожаю кофе. "
    "Не люблю брокколи и ненавижу лук. "
    "Ещё я знаю многое о погоде."
)


class FakeResponse:
    """Мини-ответ LLM (как LLMResponse из ai.providers)."""

    def __init__(self, content: str) -> None:
        self.content = content


class FakeLLM:
    """Клиент LLM с настраиваемым поведением (для тестов)."""

    def __init__(self, reply: str = '{"name": "Иван"}', fail: bool = False) -> None:
        self.reply = reply
        self.fail = fail
        self.calls: list[list[dict]] = []

    async def ask(self, messages, **kw) -> FakeResponse:
        self.calls.append(list(messages))
        if self.fail:
            raise RuntimeError("сеть недоступна")
        return FakeResponse(self.reply)

    def available_providers(self) -> list[str]:
        return ["fake"]


# ---------------------------------------------------------------------------
# Эвристическая экстракция
# ---------------------------------------------------------------------------
def test_heuristic_extraction(tmp: Path) -> None:
    eng = HeuristicProfileExtractor()
    entries = asyncio.run(eng.extract(SAMPLE_TEXT))
    by_key: dict[str, list[ProfileEntry]] = {}
    for e in entries:
        by_key.setdefault(e.key, []).append(e)

    assert by_key["name"][0].value == "Иван", entries
    assert by_key["city"][0].value == "Москве", entries
    assert by_key["job"][0].value == "инженером", entries
    assert [e.value for e in by_key["likes"]] == ["чай без сахара", "кофе"], entries
    assert [e.value for e in by_key["dislikes"]] == ["брокколи", "лук"], entries
    # Негатив не попадает в likes, «я знаю» — не имя
    like_values = " ".join(e.value for e in by_key["likes"])
    assert "брокколи" not in like_values, like_values
    assert by_key["name"][0].source == "heuristic"
    assert all(0.0 <= e.confidence <= 1.0 for e in entries)


def test_heuristic_empty_and_noise(tmp: Path) -> None:
    eng = HeuristicProfileExtractor()
    # Ничего личного — пустой список, без исключений
    assert asyncio.run(eng.extract("Сегодня хорошая погода, будет дождь.")) == []
    # Одно имя из двух — берётся первое
    entries = asyncio.run(eng.extract("Меня зовут Пётр. Меня зовут Иван."))
    assert [e.value for e in entries if e.key == "name"] == ["Пётр"], entries


def test_input_and_entry_validation(tmp: Path) -> None:
    eng = HeuristicProfileExtractor()
    for bad_text in ("", "   ", "привет\x00мир", "а" * 60000):
        try:
            asyncio.run(eng.extract(bad_text))
        except ValueError:
            pass
        else:
            raise AssertionError(f"ожидался ValueError для {bad_text[:20]!r}")

    for kwargs in (
        {"key": "na me", "value": "Иван"},        # пробел в ключе
        {"key": "", "value": "Иван"},            # пустой ключ
        {"key": 123, "value": "Иван"},           # ключ не строка
        {"key": "name!", "value": "Иван"},      # недопустимый символ в ключе
        {"key": "name", "value": "  "},           # пустое значение
        {"key": "name", "value": "а" * 300},      # длинное значение
        {"key": "name", "value": "Иван\x00"},     # управляющий символ
        {"key": "name", "value": "Иван", "confidence": 1.5},
        {"key": "name", "value": "Иван", "confidence": True},
    ):
        try:
            ProfileEntry(**kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError(f"ожидался ValueError для {kwargs}")


# ---------------------------------------------------------------------------
# LLM-экстракция
# ---------------------------------------------------------------------------
def test_llm_extractor_success(tmp: Path) -> None:
    llm = FakeLLM(reply='```json\n{"name": "Иван", "city": "Москва", "likes": "чай"}\n```')
    eng = LLMProfileExtractor(llm)
    entries = asyncio.run(eng.extract(SAMPLE_TEXT))

    assert [e.key for e in entries] == ["name", "city", "likes"], entries
    assert all(e.source == "llm" and e.confidence == 0.7 for e in entries)
    assert entries[1].value == "Москва"
    assert eng.is_available() is True
    assert eng.describe() == {"name": "llm", "available": True}


def test_llm_extractor_failures(tmp: Path) -> None:
    # Сбой клиента → ProfileUnavailable (дальше сработает fallback)
    broken = LLMProfileExtractor(FakeLLM(fail=True))
    for engine in (
        broken,
        LLMProfileExtractor(FakeLLM(reply="не json совсем")),
        LLMProfileExtractor(FakeLLM(reply="{}")),
        LLMProfileExtractor(FakeLLM(reply='{"nested": {"a": 1}}')),
    ):
        try:
            asyncio.run(engine.extract(SAMPLE_TEXT))
        except ProfileUnavailable:
            pass
        else:
            raise AssertionError(f"ожидался ProfileUnavailable: {engine}")

    # Мусорные поля пропускаются, валидные остаются
    mixed = LLMProfileExtractor(
        FakeLLM(reply='{"name": 123, "ok key": "x", "city": "Москва"}')
    )
    entries = asyncio.run(mixed.extract(SAMPLE_TEXT))
    assert [e.value for e in entries] == ["Москва"], entries

    try:
        LLMProfileExtractor(None)
    except ValueError:
        pass
    else:
        raise AssertionError("ожидался ValueError для llm=None")


# ---------------------------------------------------------------------------
# Роутер
# ---------------------------------------------------------------------------
def test_router_fallback_and_switch(tmp: Path) -> None:
    class UnavailableLLM(FakeLLM):
        """Клиент без доступных провайдеров (is_available → False)."""

        def available_providers(self) -> list[str]:
            return []

    llm_bad = LLMProfileExtractor(UnavailableLLM(fail=True), system_prompt="x")
    router = ProfileExtractorRouter([llm_bad, HeuristicProfileExtractor()])

    # LLM падает → молча деградируем в эвристику
    entries = asyncio.run(router.extract(SAMPLE_TEXT))
    assert any(e.key == "name" and e.value == "Иван" for e in entries), entries

    # Явный движок: его ошибка уходит наружу (без fallback)
    try:
        asyncio.run(router.extract(SAMPLE_TEXT, engine="llm"))
    except ProfileUnavailable:
        pass
    else:
        raise AssertionError("ожидался ProfileUnavailable при явном движке")

    # Смена основного движка (локально ↔ облако) и статусы
    router.set_primary("heuristic")
    assert router.primary == "heuristic"
    assert {d["name"] for d in router.engine_status()} == {"llm", "heuristic"}
    assert router.available() == ["heuristic"], router.available()
    try:
        router.set_primary("nope")
    except ProfileError:
        pass
    else:
        raise AssertionError("ожидался ProfileError для неизвестного движка")

    # Фабрика «локально-first»: без LLM — эвристика, с LLM — он основной
    assert default_profile_extractor_router().primary == "heuristic"
    assert default_profile_extractor_router(FakeLLM()).primary == "llm"


# ---------------------------------------------------------------------------
# Профиль: слияние и сериализация
# ---------------------------------------------------------------------------
def test_profile_merge_policy(tmp: Path) -> None:
    profile = UserProfile()
    profile.merge(ProfileEntry(key="name", value="Иван", confidence=0.9))
    # Одиночный ключ: более уверенный факт побеждает, менее уверенный — нет
    profile.merge(ProfileEntry(key="name", value="Пётр", confidence=0.5))
    assert profile.get("name").value == "Иван", profile.entries()
    profile.merge(ProfileEntry(key="name", value="Пётр", confidence=0.9))
    assert profile.get("name").value == "Пётр"

    # Множественный ключ: значения копятся с дедупликацией (ё↔е/регистр)
    profile.merge(ProfileEntry(key="likes", value="чай"))
    profile.merge(ProfileEntry(key="likes", value="Чай; кофе"))
    assert profile.get("likes").value == "чай; кофе", profile.get("likes")

    # Потолок значений множественного ключа
    for i in range(MAX_MULTI_VALUES + 5):
        profile.merge(ProfileEntry(key="likes", value=f"еда{i}"))
    assert len(profile.get("likes").value.split("; ")) == MAX_MULTI_VALUES
    # remove / clear / len / contains
    assert "name" in profile and "nope" not in profile
    assert len(profile) == 2, profile.keys()
    assert profile.remove("name") is True and profile.remove("name") is False
    assert profile.clear() == 1 and len(profile) == 0

    # to_dict / from_dict roundtrip + устойчивость к мусору
    profile.merge(ProfileEntry(key="city", value="Москва", confidence=0.8))
    data = profile.to_dict()
    restored = UserProfile.from_dict(data)
    assert restored.get("city").value == "Москва"
    dirty = UserProfile.from_dict({"entries": [{"key": "bad key!", "value": ""},
                                               "мусор", data["entries"][0]]})
    assert len(dirty) == 1, dirty.entries()


def test_profile_prompt_and_overflow(tmp: Path) -> None:
    profile = UserProfile()
    assert profile.to_prompt_text() == ""
    profile.merge(ProfileEntry(key="name", value="Иван"))
    profile.merge(ProfileEntry(key="likes", value="чай"))
    text = profile.to_prompt_text()
    assert "имя: Иван" in text and "любит: чай" in text, text

    for i in range(98):  # 2 факта уже есть → добиваем ровно до MAX_ENTRIES=100
        profile.merge(ProfileEntry(key=f"custom{i}", value="x"))
    assert len(profile) == 100
    try:
        profile.merge(ProfileEntry(key="custom_overflow", value="x"))
    except ProfileError:
        pass
    else:
        raise AssertionError("ожидался ProfileError при переполнении профиля")


# ---------------------------------------------------------------------------
# Хранилища
# ---------------------------------------------------------------------------
def test_json_store(tmp: Path) -> None:
    path = tmp / "sub" / "profile.json"
    store = JsonProfileStore(path)

    assert len(store.load()) == 0  # файла ещё нет — пустой профиль
    profile = UserProfile([ProfileEntry(key="name", value="Иван", confidence=0.9)])
    store.save(profile)
    assert path.exists() and not path.with_name("profile.json.tmp").exists()
    restored = store.load()
    assert restored.get("name").value == "Иван"

    # Битый файл не роняет загрузку — начинаем с пустого профиля
    path.write_text("{сломанный json", encoding="utf-8")
    assert len(store.load()) == 0

    store.clear()
    assert not path.exists() and len(store.load()) == 0

    # InMemoryProfileStore: ничего не пишет на диск
    mem = InMemoryProfileStore()
    mem.save(profile)
    assert mem.load().get("name").value == "Иван"
    mem.clear()
    assert len(mem.load()) == 0


# ---------------------------------------------------------------------------
# Фасад: обучение профиля
# ---------------------------------------------------------------------------
def test_builder_learn_and_persist(tmp: Path) -> None:
    path = tmp / "profile.json"
    builder = ProfileBuilder(
        extractor=HeuristicProfileExtractor(),
        store=JsonProfileStore(path),
    )
    applied = asyncio.run(builder.learn_from_text(SAMPLE_TEXT))
    assert builder.get("name").value == "Иван", applied
    assert builder.get("likes").value == "чай без сахара; кофе"
    assert path.exists()  # persist=True по умолчанию

    # Пересоздание билдера — профиль подхватывается с диска
    builder2 = ProfileBuilder(store=JsonProfileStore(path))
    assert builder2.get("name").value == "Иван"
    assert "имя: Иван" in builder2.to_prompt_text()
    assert builder2.describe()["entries"] == 5

    # reload / forget («забудь всё»)
    builder2.get("name")
    assert builder2.forget() == 5
    assert builder2.get("name") is None and not path.exists()
    try:
        ProfileBuilder().reload()
    except ProfileError:
        pass
    else:
        raise AssertionError("ожидался ProfileError без хранилища")


def test_builder_records_and_privacy(tmp: Path) -> None:
    builder = ProfileBuilder(extractor=HeuristicProfileExtractor())
    records = [
        MemoryRecord(kind=MemoryKind.FACT, content="Меня зовут Иван", importance=0.8),
        MemoryRecord(kind=MemoryKind.PREFERENCE, content="Я люблю кофе", importance=0.6),
        MemoryRecord(kind=MemoryKind.SUMMARY, content="Я люблю шоколад", importance=0.3),
    ]
    applied = asyncio.run(builder.learn_from_records(records))
    assert builder.get("name").value == "Иван", applied
    assert builder.get("likes").value == "кофе"
    # Сводки не участвуют в обучении — «шоколад» не попал в профиль
    assert "шоколад" not in builder.to_prompt_text()

    try:
        asyncio.run(builder.learn_from_records(["не запись"]))  # type: ignore[list-item]
    except ValueError:
        pass
    else:
        raise AssertionError("ожидался ValueError для не-MemoryRecord")

    # INCOGNITO: профиль живёт только в памяти — файл не создаётся
    secret = tmp / "incognito.json"
    incognito = ProfileBuilder(
        extractor=HeuristicProfileExtractor(),
        store=JsonProfileStore(secret),
        privacy_mode=PrivacyMode.INCOGNITO,
    )
    asyncio.run(incognito.learn_from_text(SAMPLE_TEXT))
    assert incognito.get("name").value == "Иван"
    assert incognito.save() is False
    assert not secret.exists(), "INCOGNITO не должен писать на диск"

    # forget в INCOGNITO не трогает диск (нечего трогать), но чистит память
    assert incognito.forget() == 5
    assert incognito.get("name") is None and not secret.exists()


if __name__ == "__main__":
    import tempfile
    import traceback

    tests = [(k, v) for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    base = Path(".openclaw/tmp")
    base.mkdir(parents=True, exist_ok=True)
    for name, fn in tests:
        try:
            if fn.__code__.co_argcount == 0:
                fn()
            else:
                fn(Path(tempfile.mkdtemp(dir=base)))
            print(f"  ok  {name}")
        except Exception:
            failed += 1
            print(f"FAIL  {name}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
