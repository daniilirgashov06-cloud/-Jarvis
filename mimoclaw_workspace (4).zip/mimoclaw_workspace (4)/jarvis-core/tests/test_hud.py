"""
Проверка модуля fun/hud: кольцо, осциллограмма, реактор, статус, снимок HUD.

Запуск:  python3 tests/test_hud.py
"""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fun.hud import (
    ActivityLevel,
    HudState,
    HudTheme,
    ReactorMeter,
    RingState,
    StatusItem,
    StatusLevel,
    SystemStatus,
    VoiceWaveform,
    arc_polyline,
)


# ---------------------------------------------------------------------------
# Тесты: геометрия дуги и кольцо
# ---------------------------------------------------------------------------
def test_arc_polyline() -> None:
    """Дуга строится корректно и валидирует аргументы."""
    pts = arc_polyline(0.0, 0.0, 100.0, start_deg=0.0, sweep_deg=90.0, segments=8)
    assert len(pts) == 9, f"ожидалось 9 точек, получено {len(pts)}"
    x0, y0 = pts[0]
    assert abs(x0 - 100.0) < 1e-6 and abs(y0 - 0.0) < 1e-6, f"начало дуги неверно: {pts[0]}"
    x1, y1 = pts[-1]
    assert abs(x1 - 0.0) < 1e-6 and abs(y1 - 100.0) < 1e-6, f"конец дуги неверно: {pts[-1]}"
    for x, y in pts:
        assert abs(math.hypot(x, y) - 100.0) < 1e-6, f"точка не на окружности: {(x, y)}"

    try:
        arc_polyline(0, 0, 10, 0, 360, segments=0)
        raise AssertionError("ожидалась ошибка при segments=0")
    except ValueError as e:
        assert "segments" in str(e)

    try:
        arc_polyline(0, 0, -5, 0, 360, segments=4)
        raise AssertionError("ожидалась ошибка при radius<0")
    except ValueError as e:
        assert "radius" in str(e)
    print("  ✓ arc_polyline: геометрия и валидация")


def test_ring_state() -> None:
    """Кольцо ограничивает прогресс и строит полилинию."""
    ring = RingState()
    assert ring.set_progress(1.5) == 1.0, "прогресс должен ограничиваться сверху"
    assert ring.set_progress(-0.2) == 0.0, "прогресс должен ограничиваться снизу"
    assert ring.polyline() == [], "нулевой прогресс → пустая дуга"

    ring.set_progress(0.5)
    pts = ring.polyline(cx=10.0, cy=20.0, radius=50.0, segments=16)
    assert pts, "половинный прогресс → непустая дуга"
    assert ring.to_dict()["sweep_deg"] == 180.0, "пол прогресса → 180° дуги"
    print("  ✓ RingState: прогресс, полилиния, снимок")


# ---------------------------------------------------------------------------
# Тесты: осциллограмма голоса
# ---------------------------------------------------------------------------
def test_voice_waveform() -> None:
    """Буфер сэмплов: ограничение, RMS, точки для осциллографа."""
    wave = VoiceWaveform(capacity=8)
    wave.push([0.5, -2.0, 3.0, float("nan")])
    samples = wave.samples()
    assert samples == [0.5, -1.0, 1.0, 0.0], f"клампинг/NaN неверен: {samples}"
    assert wave.peak == 1.0, f"пик неверен: {wave.peak}"
    assert 0.0 < wave.level <= 1.0, f"уровень вне диапазона: {wave.level}"

    wave.clear()
    assert wave.level == 0.0 and wave.peak == 0.0, "после clear уровень должен быть нулевым"

    pts = wave.points(width=100.0, height=50.0)
    assert len(pts) == 8, f"точек должно быть по capacity, получено {len(pts)}"
    xs = [p[0] for p in pts]
    assert xs == sorted(xs) and xs[0] == 0.0 and abs(xs[-1] - 100.0) < 1e-6, f"x неверен: {xs}"
    assert all(abs(y - 25.0) < 1e-6 for _, y in pts), "пустой буфер → линия по центру"

    wave.push([1.0] * 8)
    pts = wave.points(width=100.0, height=50.0)
    assert all(abs(y - 0.0) < 1e-6 for _, y in pts), "полная амплитуда → верх графика (y=0)"

    try:
        VoiceWaveform(capacity=1)
        raise AssertionError("ожидалась ошибка при capacity<2")
    except ValueError as e:
        assert "capacity" in str(e)

    try:
        wave.points(width=0)
        raise AssertionError("ожидалась ошибка при width<=0")
    except ValueError as e:
        assert "width" in str(e)
    print("  ✓ VoiceWaveform: буфер, уровень, точки")


# ---------------------------------------------------------------------------
# Тесты: реактор
# ---------------------------------------------------------------------------
def test_reactor_meter() -> None:
    """Реактор: фазы активности, сглаживание, пульсация."""
    meter = ReactorMeter()
    assert meter.set_activity(ActivityLevel.THINKING) == 0.85, "цель по фазе THINKING"
    assert meter.activity is ActivityLevel.THINKING

    for _ in range(200):
        meter.update(0.1)
    assert abs(meter.level - 0.85) < 1e-6, f"сглаживание не сошлось: {meter.level}"

    meter.set_target(2.0)
    assert meter.target == 1.0, "цель должна ограничиваться"
    meter.update(10.0)
    assert meter.level == 1.0, "большой шаг → мгновенное достижение цели"

    for t in (0.0, 0.37, 1.23):
        g = meter.glow(t)
        assert 0.0 <= g <= 1.0, f"свечение вне диапазона: {g}"

    try:
        meter.update(-0.1)
        raise AssertionError("ожидалась ошибка при dt_s<0")
    except ValueError as e:
        assert "dt_s" in str(e)

    assert ActivityLevel("listening") is ActivityLevel.LISTENING
    print("  ✓ ReactorMeter: активность, EMA, пульсация")


# ---------------------------------------------------------------------------
# Тесты: статус системы
# ---------------------------------------------------------------------------
def test_system_status() -> None:
    """Пункты статуса: пороги уровней и сводка."""
    status = SystemStatus.from_metrics(cpu_percent=50.0, memory_percent=80.0, disk_percent=97.0)
    levels = {item.name: item.level for item in status.items}
    assert levels["CPU"] is StatusLevel.OK, f"CPU при 50% должен быть OK: {levels}"
    assert levels["Память"] is StatusLevel.WARN, f"память при 80% должна быть WARN: {levels}"
    assert levels["Диск"] is StatusLevel.CRIT, f"диск при 97% должен быть CRIT: {levels}"
    assert status.overall() is StatusLevel.CRIT, "общий уровень — худший из пунктов"

    empty = SystemStatus()
    assert empty.overall() is StatusLevel.OK, "пустой статус → OK"
    empty.add(StatusItem("Сеть", 12, "мс", StatusLevel.WARN))
    assert empty.overall() is StatusLevel.WARN

    data = status.to_dict()
    assert data["overall"] == "crit" and len(data["items"]) == 3, f"снимок неверен: {data}"
    json.dumps(data, ensure_ascii=False)  # сериализуемость
    print("  ✓ SystemStatus: пороги, сводка, снимок")


# ---------------------------------------------------------------------------
# Тесты: единый снимок HUD
# ---------------------------------------------------------------------------
def test_hud_state_snapshot() -> None:
    """HudState собирает снимок всех элементов в JSON."""
    hud = HudState(theme=HudTheme(accent="#FF0000"))
    hud.waveform.push([0.1, -0.1, 0.2])
    hud.ring.set_progress(0.25)
    hud.reactor.set_activity(ActivityLevel.SPEAKING)
    hud.status.add(StatusItem("CPU", 12.5, "%"))
    hud.subtitles = "Слушаю, сэр"

    snap = hud.snapshot(now=123.0, t_s=0.5)
    assert snap["updated_at"] == 123.0, "метка времени должна попадать в снимок"
    assert snap["theme"]["accent"] == "#FF0000"
    assert snap["ring"]["progress"] == 0.25
    assert snap["reactor"]["activity"] == "speaking"
    assert snap["waveform"]["level"] > 0.0 and len(snap["waveform"]["points"]) == 512
    assert snap["status"]["overall"] == "ok"
    assert snap["subtitles"] == "Слушаю, сэр"

    text = hud.to_json(now=123.0, t_s=0.5)
    parsed = json.loads(text)
    assert parsed == snap, "to_json должен сериализовать тот же снимок"
    print("  ✓ HudState: снимок и JSON")


def main() -> int:
    print("Проверка fun/hud ...")
    try:
        test_arc_polyline()
        test_ring_state()
        test_voice_waveform()
        test_reactor_meter()
        test_system_status()
        test_hud_state_snapshot()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модуля прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
