"""
Проверка memory/store.py — запись, поиск, CRUD, экспорт, приватность,
деградация в память, потокобезопасность.

Запуск:  python3 tests/test_memory_store.py
"""

from __future__ import annotations

import json
import sys
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from memory.store import (
    InMemoryMemoryStore,
    MemoryKind,
    MemoryRecord,
    MemoryUnavailable,
    PrivacyError,
    PrivacyMode,
    SQLiteMemoryStore,
    default_memory_store,
)


# ---------------------------------------------------------------------------
# Утилиты
# ---------------------------------------------------------------------------
def _rec(content: str, kind: MemoryKind = MemoryKind.FACT, **kw) -> MemoryRecord:
    return MemoryRecord(kind=kind, content=content, **kw)


# ---------------------------------------------------------------------------
# Сущность: валидация
# ---------------------------------------------------------------------------
def test_record_validation(tmp: Path) -> None:
    # Пустой контент / управляющие символы
    for bad in ("", "   ", "привет\x00мир"):
        try:
            _rec(bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"ожидался ValueError для content={bad!r}")

    # Важность вне диапазона
    try:
        _rec("ок", importance=1.5)
    except ValueError:
        pass
    else:
        raise AssertionError("ожидался ValueError для importance=1.5")

    # Нормализация тегов: дедупликация ё↔е/регистр
    rec = _rec("чай", tags=("Еда", "еда", "ЕДА", "напиток"))
    assert rec.tags == ("Еда", "напиток"), rec.tags

    # to_dict / from_dict round-trip
    d = rec.to_dict()
    back = MemoryRecord.from_dict(d)
    assert back.content == rec.content and back.kind is rec.kind
    assert back.tags == rec.tags


# ---------------------------------------------------------------------------
# InMemory: CRUD + поиск
# ---------------------------------------------------------------------------
def test_inmemory_crud_and_search(tmp: Path) -> None:
    store = InMemoryMemoryStore()
    r1 = store.add(_rec("пользователь любит чай без сахара", tags=("предпочтение", "еда"), importance=0.9))
    r2 = store.add(_rec("вчера была встреча с командой", kind=MemoryKind.EVENT))
    assert r1.id and r1.created_at and r1.persisted
    assert store.count() == 2

    assert store.get(r1.id).content.startswith("пользователь")
    assert store.get("нету") is None

    # Поиск: подстрока, регистр/ё↔е, фильтры
    assert [r.id for r in store.search("чай")] == [r1.id]
    assert [r.id for r in store.search("ЧАЙ")] == [r1.id]
    assert [r.id for r in store.search("встреча", kind=MemoryKind.EVENT)] == [r2.id]
    assert [r.id for r in store.search("чай", tag="еда")] == [r1.id]
    assert store.search("чай", tag="спорт") == []

    # Обновление
    upd = store.update(r2.id, content="встреча перенесена", importance=0.7)
    assert upd.content == "встреча перенесена" and upd.importance == 0.7
    assert store.update("нету") is None

    # Удаление + «забудь всё»
    assert store.delete(r2.id) is True
    assert store.delete(r2.id) is False
    assert store.count() == 1
    assert store.clear() == 1
    assert store.count() == 0


# ---------------------------------------------------------------------------
# SQLite: персистентность между экземплярами + экспорт
# ---------------------------------------------------------------------------
def test_sqlite_persistence_and_export(tmp: Path) -> None:
    db = tmp / "sub" / "jarvis.db"
    store = SQLiteMemoryStore(db)
    r1 = store.add(_rec("люблю кино в жанре фантастика", tags=("предпочтение",), importance=0.8))
    r2 = store.add(_rec("день рождения 12 марта", kind=MemoryKind.EVENT, tags=("дата",)))
    store.close()

    # Переоткрываем БД — данные на месте
    store2 = SQLiteMemoryStore(db)
    assert store2.count() == 2
    assert store2.get(r1.id).content.startswith("люблю")
    recent = store2.list_recent(limit=1)
    assert len(recent) == 1 and recent[0].id == r2.id  # created_at больше

    assert [r.id for r in store2.search("фантастика", tag="предпочтение")] == [r1.id]
    assert [r.id for r in store2.search("март", kind=MemoryKind.EVENT)] == [r2.id]

    # Экспорт json + jsonl
    out_json = tmp / "mem.json"
    n = store2.export(out_json, fmt="json")
    assert n == 2
    data = json.loads(out_json.read_text(encoding="utf-8"))
    assert isinstance(data, list) and len(data) == 2 and {"id", "content"} <= set(data[0])

    out_jsonl = tmp / "mem.jsonl"
    n = store2.export(out_jsonl, fmt="jsonl")
    assert n == 2
    lines = [json.loads(x) for x in out_jsonl.read_text(encoding="utf-8").splitlines()]
    assert len(lines) == 2

    # Невалидный путь/формат экспорта
    for bad_path, bad_fmt in ((tmp / "-evil.json", "json"), (tmp / "mem.exe", "json"), (out_json, "csv")):
        try:
            store2.export(bad_path, fmt=bad_fmt)
        except ValueError:
            pass
        else:
            raise AssertionError("ожидался ValueError для битого экспорта")

    # «Забудь всё»
    assert store2.clear() == 2
    assert store2.count() == 0
    store2.close()


# ---------------------------------------------------------------------------
# Приватность: INCOGNITO не персистится, экспорт запрещён
# ---------------------------------------------------------------------------
def test_privacy_incognito(tmp: Path) -> None:
    db = tmp / "jarvis.db"
    store = default_memory_store(db, privacy_mode=PrivacyMode.INCOGNITO)
    # Используется память, диск не трогается
    assert isinstance(store, InMemoryMemoryStore)
    rec = store.add(_rec("секретный факт"))
    assert rec.persisted is False
    assert not db.exists(), "INCOGNITO не должен писать на диск"

    try:
        store.export(tmp / "x.json")
    except PrivacyError:
        pass
    else:
        raise AssertionError("ожидался PrivacyError на экспорте в INCOGNITO")

    # Явный SQLite в INCOGNITO тоже не пишет на диск
    sq = SQLiteMemoryStore(db, privacy_mode=PrivacyMode.INCOGNITO)
    rec2 = sq.add(_rec("ещё секрет"))
    assert rec2.persisted is False
    assert sq.count() == 0  # на диске пусто
    try:
        sq.export(tmp / "y.json")
    except PrivacyError:
        pass
    else:
        raise AssertionError("ожидался PrivacyError на экспорте в INCOGNITO")
    sq.close()


# ---------------------------------------------------------------------------
# Деградация: битый путь → fallback в память
# ---------------------------------------------------------------------------
def test_degradation_to_memory(tmp: Path) -> None:
    # Путь-«папка» вместо файла БД → sqlite не откроется
    dirpath = tmp / "this_is_a_dir"
    dirpath.mkdir()
    # dirpath — директория: sqlite не сможет открыть её как файл БД
    store = default_memory_store(dirpath)
    assert isinstance(store, InMemoryMemoryStore) and store.degraded is True

    # Без fallback — та же ошибка всплывает
    try:
        SQLiteMemoryStore(dirpath)
    except MemoryUnavailable:
        pass
    else:
        raise AssertionError("ожидался MemoryUnavailable для пути-директории")


# ---------------------------------------------------------------------------
# Потокобезопасность
# ---------------------------------------------------------------------------
def test_thread_safety(tmp: Path) -> None:
    store = SQLiteMemoryStore(tmp / "jarvis.db")
    n = 60

    def worker(base: int) -> None:
        for i in range(n):
            store.add(_rec(f"запись {base}-{i}"))

    threads = [threading.Thread(target=worker, args=(k,)) for k in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert store.count() == 4 * n
    assert len(store.list_recent(limit=1000)) == 4 * n
    store.close()


if __name__ == "__main__":
    import tempfile
    import traceback

    tests = [(k, v) for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    base = Path(".openclaw/tmp")
    base.mkdir(parents=True, exist_ok=True)
    for name, fn in tests:
        try:
            if fn.__code__.co_argcount == 0:
                fn()
            else:
                fn(Path(tempfile.mkdtemp(dir=base)))
            print(f"  ok  {name}")
        except Exception:
            failed += 1
            print(f"FAIL  {name}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
