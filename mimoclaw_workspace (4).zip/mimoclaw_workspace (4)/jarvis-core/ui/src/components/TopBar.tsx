/**
 * Верхняя панель: часы, живое состояние пайплайна, персона JARVIS/FRIDAY,
 * индикатор соединения.
 */

import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { clsx } from "../lib/format";
import { useSystemStore } from "../stores/systemStore";
import { useUiStore, type Persona } from "../stores/uiStore";

const STATE_LABEL: Record<string, string> = {
  idle: "ОЖИДАНИЕ",
  listening: "СЛУШАЮ",
  thinking: "ДУМАЮ",
  speaking: "ГОВОРЮ",
};

function useClock(): string {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);
  return now.toLocaleTimeString("ru-RU", { hour12: false });
}

export function TopBar() {
  const clock = useClock();
  const state = useSystemStore((s) => s.status?.state ?? "idle");
  const connection = useSystemStore((s) => s.connection);
  const persona = useUiStore((s) => s.persona);
  const setPersona = useUiStore((s) => s.setPersona);

  return (
    <header className="sticky top-0 z-10 flex items-center justify-between gap-4 border-b border-line bg-abyss/80 px-6 py-3.5 backdrop-blur-xl">
      <div className="flex items-center gap-3">
        <motion.span
          animate={{ opacity: [1, 0.4, 1] }}
          transition={{ duration: 1.8, repeat: Infinity }}
          className="h-2 w-2 rounded-full bg-accent"
          style={{ boxShadow: "0 0 10px rgb(var(--accent-rgb))" }}
        />
        <span className="hud-title text-xs text-accent">{STATE_LABEL[state] ?? String(state).toUpperCase()}</span>
        <span className="hidden text-xs text-muted sm:inline">
          / {persona === "jarvis" ? "JARVIS" : "FRIDAY"}
        </span>
      </div>

      <div className="flex items-center gap-3">
        {/* Персона */}
        <div className="flex items-center rounded-xl border border-line bg-panel-2/60 p-1">
          {(["jarvis", "friday"] as Persona[]).map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => setPersona(p)}
              className={clsx(
                "relative rounded-lg px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.22em] transition-colors",
                persona === p
                  ? p === "jarvis"
                    ? "text-abyss"
                    : "text-white"
                  : "text-muted hover:text-text",
              )}
            >
              {persona === p ? (
                <motion.span
                  layoutId="persona-pill"
                  className="absolute inset-0 rounded-lg"
                  style={{
                    background: p === "jarvis" ? "#00E5FF" : "#FF3B30",
                    boxShadow: p === "jarvis" ? "0 0 18px #00E5FF88" : "0 0 18px #FF3B3088",
                  }}
                  transition={{ type: "spring", stiffness: 400, damping: 32 }}
                />
              ) : null}
              <span className="relative z-10">{p}</span>
            </button>
          ))}
        </div>

        {/* Связь */}
        <div className="flex items-center gap-2 rounded-xl border border-line bg-panel-2/60 px-3 py-1.5">
          <span
            className={clsx(
              "h-2 w-2 rounded-full",
              connection === "online"
                ? "bg-ok shadow-[0_0_8px_#2ECC71]"
                : connection === "connecting"
                  ? "bg-warn shadow-[0_0_8px_#F5A623]"
                  : "bg-danger shadow-[0_0_8px_#FF3B30]",
            )}
          />
          <span className="text-[11px] text-muted">
            WS {connection === "online" ? "127.0.0.1:8765" : connection}
          </span>
        </div>

        <span className="font-heading text-sm tabular-nums text-text">{clock}</span>
      </div>
    </header>
  );
}
