"""
Детекция голосовой активности (VAD) JARVIS CORE.

Единый контракт ``VADEngine`` + диспетчер ``VADRouter`` с **живой сменой**
движков и fallback (как в ``speech/stt_engine.STRouter``). Доступные движки:

  * ``WebRTCVAD``  — webrtcvad (быстрый, C, агрессивность 0–3);
  * ``SileroVAD``  — silero-vad (нейросеть, вероятность речи 0..1);
  * ``EnergyVAD``  — чистый Python по RMS/уровню (всегда доступен, fallback).

Всё локально: VAD работает на устройстве, аудио в облако не уходит.

Поверх движков — ``VoiceActivityDetector``: конечный автомат сегментации
речи (подтверждение начала, «хвост» тишины, pre-roll, защита от бесконечной
речи). Отдаёт события ``speech_start`` / ``speech_end`` с готовым PCM-фрагментом
фразы — то, что нужно ``AudioCapture.record_until`` и оркестратору.
"""

from __future__ import annotations

import abc
import logging
import math
from array import array
from collections import deque
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class VADError(Exception):
    """Ошибка детекции голосовой активности."""


class VADUnavailable(VADError):
    """Движок VAD недоступен (нет библиотеки/модели) — можно fallback."""


# ---------------------------------------------------------------------------
# Конфигурация и результат
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class VADConfig:
    """Параметры VAD. Дефолты — «тихий» порог и мягкая сегментация."""

    sample_rate: int = 16000
    frame_ms: int = 20
    #: Порог вероятности/уровня голоса (0..1), см. ``config/settings.vad_threshold``.
    threshold: float = 0.5
    #: Сколько кадров речи подряд нужно для подтверждения начала фразы.
    min_speech_ms: int = 200
    #: Сколько тишины подряд означает конец фразы.
    min_silence_ms: int = 500
    #: Сколько звука «до начала речи» включать во фрагмент (защита от обрезки).
    preroll_ms: int = 200
    #: Предельная длительность одной фразы (защита от залипания).
    max_speech_ms: int = 15000

    @property
    def frame_samples(self) -> int:
        """Число сэмплов на кадр (20 мс @ 16 кГц = 320)."""
        return self.sample_rate * self.frame_ms // 1000

    @property
    def frame_bytes(self) -> int:
        """Размер кадра PCM s16le в байтах (320 × 2 = 640)."""
        return self.frame_samples * 2

    def ms_to_frames(self, ms: int) -> int:
        """Перевести миллисекунды в целое число кадров (минимум 1)."""
        return max(1, round(ms / self.frame_ms))


@dataclass(frozen=True)
class VADResult:
    """Вердикт движка по одному куску PCM."""

    is_speech: bool
    score: float = 0.0
    engine: str = ""

    def __post_init__(self) -> None:
        # Держим score в [0..1] — единая шкала для всех движков.
        if not 0.0 <= self.score <= 1.0:
            object.__setattr__(self, "score", min(1.0, max(0.0, float(self.score))))


# ---------------------------------------------------------------------------
# Контракт движка
# ---------------------------------------------------------------------------
class VADEngine(abc.ABC):
    """Контракт движка VAD: синхронный вердикт по куску PCM s16le."""

    name: str = "base"

    @abc.abstractmethod
    def is_available(self) -> bool:
        """Движок можно использовать в этой среде?"""

    @abc.abstractmethod
    def detect(self, pcm: bytes, *, sample_rate: int = 16000) -> VADResult:
        """Определить, есть ли речь в куске PCM."""

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "available": self.is_available()}


# ---------------------------------------------------------------------------
# Движки
# ---------------------------------------------------------------------------
class WebRTCVAD(VADEngine):
    """VAD на webrtcvad (Google WebRTC). Быстрый, бинарный вердикт."""

    name = "webrtcvad"

    def __init__(self, aggressiveness: int = 2, config: VADConfig | None = None) -> None:
        if not 0 <= aggressiveness <= 3:
            raise VADError("Агрессивность webrtcvad должна быть 0..3")
        self.aggressiveness = aggressiveness
        self.config = config or VADConfig()
        self._vad: Any = None

    def is_available(self) -> bool:
        try:
            import webrtcvad  # noqa: F401

            return True
        except ImportError:
            return False

    def _load(self) -> Any:
        if self._vad is None:
            try:
                import webrtcvad
            except ImportError as exc:  # pragma: no cover
                raise VADUnavailable("webrtcvad не установлен") from exc
            self._vad = webrtcvad.Vad(self.aggressiveness)
        return self._vad

    def detect(self, pcm: bytes, *, sample_rate: int = 16000) -> VADResult:
        if not self.is_available():
            raise VADUnavailable("webrtcvad не установлен")
        vad = self._load()
        frame_bytes = self.config.frame_bytes
        if frame_bytes <= 0 or len(pcm) < frame_bytes:
            raise VADError(f"Кусок PCM меньше одного кадра ({frame_bytes} байт)")
        # webrtcvad требует точные кадры 10/20/30 мс — режем и агрегируем.
        votes = total = 0
        for off in range(0, len(pcm) - frame_bytes + 1, frame_bytes):
            chunk = pcm[off : off + frame_bytes]
            try:
                votes += 1 if vad.is_speech(chunk, sample_rate) else 0
            except Exception as exc:  # noqa: BLE001 — кривой формат кадра
                raise VADError(f"webrtcvad: некорректный кадр: {exc}") from exc
            total += 1
        score = votes / total if total else 0.0
        return VADResult(is_speech=score >= 0.5, score=score, engine=self.name)


class SileroVAD(VADEngine):
    """Нейросетевой VAD silero-vad (вероятность речи 0..1). Локально, без облака."""

    name = "silero"

    def __init__(
        self,
        threshold: float = 0.5,
        config: VADConfig | None = None,
    ) -> None:
        self.threshold = threshold
        self.config = config or VADConfig()
        self._model: Any = None

    def is_available(self) -> bool:
        try:
            import torch  # noqa: F401

            return True
        except ImportError:
            return False

    def _load(self) -> Any:
        """Ленивая загрузка модели (тяжёлая; сеть — только при первом вызове)."""
        if self._model is not None:
            return self._model
        try:
            from silero_vad import load_silero_vad

            self._model = load_silero_vad()
        except Exception:  # noqa: BLE001 — пакета нет, пробуем torch.hub
            try:
                import torch

                self._model = torch.hub.load("snakers4/silero-vad", "silero_vad")
            except Exception as exc:  # noqa: BLE001
                raise VADUnavailable(f"silero-vad недоступен: {exc}") from exc
        return self._model

    def detect(self, pcm: bytes, *, sample_rate: int = 16000) -> VADResult:
        if not self.is_available():
            raise VADUnavailable("torch не установлен")
        try:
            import numpy as np
            import torch
        except ImportError as exc:  # pragma: no cover
            raise VADUnavailable("нужны numpy и torch") from exc

        model = self._load()
        audio = torch.from_numpy(
            np.frombuffer(pcm, dtype=np.int16).astype(np.float32) / 32768.0
        )
        try:
            with torch.no_grad():
                prob = model(audio, sample_rate)
        except Exception as exc:  # noqa: BLE001
            raise VADError(f"silero-vad: ошибка инференса: {exc}") from exc
        # Модель может вернуть тензор вероятностей по окнам — берём последнее.
        score = float(prob[-1]) if getattr(prob, "numel", lambda: 1)() > 1 else float(prob)
        return VADResult(is_speech=score >= self.threshold, score=score, engine=self.name)


class EnergyVAD(VADEngine):
    """Энергетический VAD на RMS (чистый Python, без зависимостей).

    Работает всегда — эталонный fallback, когда webrtcvad/silero не установлены.
    Порог — по дБ относительно полной шкалы; шумовой пол адаптируется
    (``adapt=True``) и держится в разумных границах.
    """

    name = "energy"

    def __init__(
        self,
        threshold: float = 0.5,
        noise_floor_db: float = -50.0,
        adapt: bool = True,
        config: VADConfig | None = None,
    ) -> None:
        self.threshold = threshold
        self.adapt = adapt
        self.config = config or VADConfig()
        self._noise_floor_db = noise_floor_db

    def is_available(self) -> bool:
        return True  # только stdlib — работает везде

    @property
    def noise_floor_db(self) -> float:
        """Текущий оценённый уровень шума, дБ."""
        return self._noise_floor_db

    @staticmethod
    def _rms_db(pcm: bytes) -> float:
        """RMS-уровень куска PCM s16le в дБ (−120 при тишине)."""
        samples = array("h")
        samples.frombytes(pcm[: len(pcm) - (len(pcm) % 2)])
        if not samples:
            return -120.0
        mean_sq = sum(s * s for s in samples) / len(samples)
        if mean_sq <= 0.0:
            return -120.0
        return 20.0 * math.log10(math.sqrt(mean_sq) / 32768.0)

    def detect(self, pcm: bytes, *, sample_rate: int = 16000) -> VADResult:
        if len(pcm) < 2:
            raise VADError("Слишком маленький кусок PCM")
        db = self._rms_db(pcm)
        floor = self._noise_floor_db
        if db <= floor:
            score = 0.0
        else:
            # Линейная шкала: пол шума → 0, 0 дБФС → 1.
            score = min(1.0, (db - floor) / (0.0 - floor)) if floor < 0 else 1.0
        if self.adapt:
            # Быстро вниз (внезапная тишина), медленно вверх (речь не тянет пол).
            alpha = 0.3 if db < floor else 0.01
            self._noise_floor_db = min(-20.0, max(-90.0, floor + alpha * (db - floor)))
        return VADResult(is_speech=score >= self.threshold, score=score, engine=self.name)


# ---------------------------------------------------------------------------
# Диспетчер движков
# ---------------------------------------------------------------------------
class VADRouter:
    """Диспетчер VAD: смена движков + fallback (по образцу STRouter)."""

    def __init__(
        self,
        engines: dict[str, VADEngine] | None = None,
        primary: str = "energy",
        fallback_chain: list[str] | None = None,
    ) -> None:
        self._engines = engines or {}
        self._primary = primary
        self._fallback_chain = fallback_chain or [primary]

    @property
    def primary(self) -> str:
        return self._primary

    def set_primary(self, name: str) -> None:
        if name not in self._engines:
            raise VADError(f"Неизвестный VAD-движок: {name}")
        self._primary = name
        self._fallback_chain = [name] + [e for e in self._fallback_chain if e != name]
        logger.info("VAD-движок переключён на '%s'", name)

    def available(self) -> list[str]:
        return [n for n, e in self._engines.items() if e.is_available()]

    def _chain(self, explicit: str | None) -> list[str]:
        if explicit:
            return [explicit]
        order = self._fallback_chain or list(self._engines.keys())
        chain = [self._primary] + [n for n in order if n != self._primary]
        chain += [n for n in self._engines if n not in chain]
        return chain

    def detect(
        self,
        pcm: bytes,
        *,
        sample_rate: int = 16000,
        engine: str | None = None,
    ) -> VADResult:
        """Вердикт с fallback: несработавший движок пропускаем дальше по цепочке."""
        last_err: Exception | None = None
        for name in self._chain(engine):
            eng = self._engines.get(name)
            if eng is None or not eng.is_available():
                last_err = VADUnavailable(f"{name}: недоступен")
                continue
            try:
                return eng.detect(pcm, sample_rate=sample_rate)
            except (VADUnavailable, VADError) as exc:
                last_err = exc
                continue
        raise VADError(f"Ни один VAD-движок не справился. Последняя ошибка: {last_err}")


def create_default_router(config: VADConfig | None = None) -> VADRouter:
    """Стандартный комплект: webrtcvad → silero → energy (всё локально)."""
    cfg = config or VADConfig()
    return VADRouter(
        engines={
            "webrtcvad": WebRTCVAD(config=cfg),
            "silero": SileroVAD(threshold=cfg.threshold, config=cfg),
            "energy": EnergyVAD(threshold=cfg.threshold, config=cfg),
        },
        primary="webrtcvad",
        fallback_chain=["webrtcvad", "silero", "energy"],
    )


# ---------------------------------------------------------------------------
# Сегментация речи (конечный автомат поверх движка)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class VADEvent:
    """Событие сегментации: начало или конец фразы."""

    kind: str  # "speech_start" | "speech_end"
    score: float = 0.0
    #: Для ``speech_end`` — весь PCM фразы (с учётом pre-roll).
    pcm: bytes = b""

    @property
    def is_start(self) -> bool:
        return self.kind == "speech_start"

    @property
    def is_end(self) -> bool:
        return self.kind == "speech_end"


@dataclass
class _Utterance:
    """Собираемая фраза (внутреннее состояние детектора)."""

    chunks: list[bytes] = field(default_factory=list)
    frames: int = 0

    def add(self, frame: bytes) -> None:
        self.chunks.append(frame)
        self.frames += 1

    @property
    def pcm(self) -> bytes:
        return b"".join(self.chunks)


class VoiceActivityDetector:
    """Конечный автомат сегментации: кадры PCM → события ``speech_start/end``.

    Правила (настраиваются через ``VADConfig``):
      * начало фразы подтверждается после ``min_speech_ms`` речи подряд;
        во фрагмент попадает и ``preroll_ms`` звука до первого «горячего» кадра;
      * конец фразы — после ``min_silence_ms`` тишины подряд (в хвост фрагмента
        эта тишина тоже попадает — естественное завершение);
      * фраза длиннее ``max_speech_ms`` принудительно закрывается.
    """

    def __init__(
        self,
        router: VADRouter | None = None,
        config: VADConfig | None = None,
        engine: str | None = None,
    ) -> None:
        self.config = config or VADConfig()
        self.router = router or create_default_router(self.config)
        self.engine = engine  # None = цепочка fallback
        self.reset()

    # -- состояние ---------------------------------------------------------
    @property
    def in_speech(self) -> bool:
        """Идёт подтверждённая речь?"""
        return self._utterance is not None

    @property
    def current_pcm(self) -> bytes:
        """PCM текущей (ещё не закрытой) фразы."""
        return self._utterance.pcm if self._utterance else b""

    def reset(self) -> None:
        """Сбросить автомат (новая сессия прослушивания)."""
        self._utterance: _Utterance | None = None
        self._hot_frames = 0
        self._silent_frames = 0
        self._pending: list[bytes] = []  # «горячие» кадры до подтверждения начала
        self._preroll: deque[bytes] = deque(
            maxlen=self.config.ms_to_frames(self.config.preroll_ms)
        )

    # -- основной вход -----------------------------------------------------
    def feed(self, pcm: bytes) -> list[VADEvent]:
        """Скормить кусок PCM (любого размера). Вернуть события, если были."""
        frame_bytes = self.config.frame_bytes
        events: list[VADEvent] = []
        for off in range(0, len(pcm) - frame_bytes + 1, frame_bytes):
            events.extend(self._feed_frame(pcm[off : off + frame_bytes]))
        return events

    def flush(self) -> list[VADEvent]:
        """Закрыть незавершённую фразу (конец потока/отключение микрофона)."""
        if self._utterance is None:
            return []
        event = VADEvent(kind="speech_end", score=1.0, pcm=self._utterance.pcm)
        self._utterance = None
        self._hot_frames = 0
        self._silent_frames = 0
        self._pending.clear()
        return [event]

    # -- внутренняя логика -------------------------------------------------
    def _feed_frame(self, frame: bytes) -> list[VADEvent]:
        cfg = self.config
        result = self.router.detect(frame, sample_rate=cfg.sample_rate, engine=self.engine)
        hot = result.is_speech
        events: list[VADEvent] = []

        if hot:
            self._silent_frames = 0
            self._hot_frames += 1
            if self._utterance is None:
                self._pending.append(frame)
                if self._hot_frames >= cfg.ms_to_frames(cfg.min_speech_ms):
                    # Речь подтверждена: до-кадры (pre-roll) + всё накопленное.
                    utter = _Utterance()
                    for pre in self._preroll:
                        utter.add(pre)
                    for pending in self._pending:
                        utter.add(pending)
                    self._utterance = utter
                    self._pending.clear()
                    self._preroll.clear()
                    events.append(VADEvent(kind="speech_start", score=result.score))
            else:
                self._utterance.add(frame)
        else:
            self._hot_frames = 0
            self._pending.clear()
            if self._utterance is None:
                self._preroll.append(frame)
            else:
                self._silent_frames += 1
                self._utterance.add(frame)  # хвост тишины тоже во фрагменте
                if self._silent_frames >= cfg.ms_to_frames(cfg.min_silence_ms):
                    events.append(
                        VADEvent(kind="speech_end", score=result.score, pcm=self._utterance.pcm)
                    )
                    self._utterance = None
                    self._silent_frames = 0

        # Защита от «залипшей» речи.
        if (
            self._utterance is not None
            and self._utterance.frames * cfg.frame_ms >= cfg.max_speech_ms
        ):
            events.append(
                VADEvent(kind="speech_end", score=result.score, pcm=self._utterance.pcm)
            )
            self._utterance = None
            self._hot_frames = 0
            self._silent_frames = 0
            self._pending.clear()
        return events
