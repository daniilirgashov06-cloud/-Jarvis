"""
Детекция объектов на экране для зрительного конвейера JARVIS CORE.

Единый контракт ``DetectorEngine`` + диспетчер ``DetectorRouter``
(живая смена движков + fallback) + высокоуровневый ``ScreenDetector``
(предобработка → поиск → точка клика «по описанию»).

Движки:
  - ``TemplateDetectorEngine`` — локально, чистый Python: поиск эталона
    (шаблона) по кадру методом ZNCC (нормированная кросс-корреляция с
    вычетом среднего). Без внешних зависимостей, детерминированно, данные
    наружу не уходят. Стоимость ~ O(W·H·w·h/stride²) — для больших кадров
    задайте ``stride`` > 1 либо используйте облачный движок;
  - ``HttpDetectorEngine`` — облако, пользовательский HTTP-endpoint
    (JSON + base64 PNG): «vision-модель» ищет объекты по подписи
    (``labels``). Включается только при явно заданном endpoint (локально-first);
  - ``SyntheticDetectorEngine`` — детерминированные результаты для
    тестов/отладки, аварийный fallback, чтобы пайплайн не падал без детектора.

Приватность: облачный движок отправляет фрагмент скриншота на внешний
сервис — используется только осознанно (см. ``HttpDetectorEngine``).
Локальный поиск шаблонов данные наружу не отдаёт.

Пересечения дублей схлопываются через ``nms`` (non-maximum suppression).
"""

from __future__ import annotations

import abc
import base64
import collections.abc
import json
import logging
import math
import os
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

from vision.ocr import OCRImage

logger = logging.getLogger(__name__)

#: максимальное число коробок в результате (защита от «бомбы» детекций)
MAX_DETECTIONS: int = 4096

#: максимальная длина подписи объекта
MAX_LABEL_LENGTH: int = 128

#: предохранитель: примерная оценка работы локального поиска шаблонов (операций)
MAX_TEMPLATE_WORK: int = 20_000_000

#: управляющие символы в подписи (антиинъекция в подписи/логи/LLM)
_CTRL_RE = re.compile(r"[\x00-\x1f\x7f]")


class DetectorError(Exception):
    """Ошибка детекции объектов."""


class DetectorUnavailable(DetectorError):
    """Движок недоступен (нет библиотеки/сети/ресурсов) — можно fallback."""


# ---------------------------------------------------------------------------
# Подписи (метки классов)
# ---------------------------------------------------------------------------
def normalize_label(label: str) -> str:
    """Нормализация подписи: нижний регистр, ё→е, схлопывание пробелов."""
    if not isinstance(label, str):
        raise ValueError("label должен быть str")
    return " ".join(label.lower().replace("ё", "е").split())


def _validate_label(label: str) -> str:
    """Проверяет подпись и возвращает её в исходном виде (без обрезки смысла)."""
    if not isinstance(label, str):
        raise ValueError("label должен быть str")
    if not label.strip():
        raise ValueError("label не может быть пустым")
    if len(label) > MAX_LABEL_LENGTH:
        raise ValueError(f"label слишком длинный (лимит {MAX_LABEL_LENGTH})")
    if _CTRL_RE.search(label):
        raise ValueError("label не может содержать управляющие символы")
    return label


# ---------------------------------------------------------------------------
# Коробка объекта
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class DetectionBox:
    """Найденный объект: подпись, геометрия (абсолютные координаты) и уверенность."""

    label: str
    x: int
    y: int
    width: int
    height: int
    confidence: float = 0.0

    def __post_init__(self) -> None:
        _validate_label(self.label)
        for name, value in (
            ("x", self.x),
            ("y", self.y),
            ("width", self.width),
            ("height", self.height),
        ):
            if isinstance(value, bool) or not isinstance(value, int):
                raise ValueError(f"{name} должен быть int, получено: {value!r}")
        if self.x < 0 or self.y < 0:
            raise ValueError("x/y не могут быть отрицательными")
        if self.width <= 0 or self.height <= 0:
            raise ValueError("width/height должны быть положительными")
        if isinstance(self.confidence, bool) or not isinstance(
            self.confidence, (int, float)
        ):
            raise ValueError("confidence должен быть числом")
        if not 0.0 <= float(self.confidence) <= 100.0:
            raise ValueError("confidence должен быть в диапазоне 0..100")

    # -- геометрия ---------------------------------------------------------
    @property
    def area(self) -> int:
        """Площадь коробки в пикселях."""
        return self.width * self.height

    @property
    def center(self) -> tuple[int, int]:
        """Центр коробки — готовая точка клика."""
        return (self.x + self.width // 2, self.y + self.height // 2)

    def contains(self, px: int, py: int) -> bool:
        """True, если точка ``(px, py)`` попадает в коробку (границы включены слева)."""
        if isinstance(px, bool) or not isinstance(px, int):
            raise ValueError("px должен быть int")
        if isinstance(py, bool) or not isinstance(py, int):
            raise ValueError("py должен быть int")
        return self.x <= px < self.x + self.width and self.y <= py < self.y + self.height

    def iou(self, other: "DetectionBox") -> float:
        """Intersection over Union с другой коробкой (0.0..1.0)."""
        if not isinstance(other, DetectionBox):
            raise ValueError("other должен быть DetectionBox")
        ix = max(0, min(self.x + self.width, other.x + other.width) - max(self.x, other.x))
        iy = max(0, min(self.y + self.height, other.y + other.height) - max(self.y, other.y))
        inter = ix * iy
        if inter == 0:
            return 0.0
        union = self.area + other.area - inter
        return inter / union if union else 0.0

    def overlaps(self, other: "DetectionBox") -> bool:
        """True, если коробки пересекаются хотя бы одним пикселем."""
        return self.iou(other) > 0.0


# ---------------------------------------------------------------------------
# Результат детекции
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class DetectionResult:
    """Итог детекции: коробки объектов, движок и время работы."""

    boxes: tuple[DetectionBox, ...] = ()
    engine: str = ""
    elapsed_ms: float = 0.0

    def __post_init__(self) -> None:
        if not isinstance(self.boxes, tuple):
            object.__setattr__(self, "boxes", tuple(self.boxes))
        if len(self.boxes) > MAX_DETECTIONS:
            raise DetectorError(f"слишком много детекций (лимит {MAX_DETECTIONS})")

    @property
    def count(self) -> int:
        """Число найденных объектов."""
        return len(self.boxes)

    @property
    def is_empty(self) -> bool:
        """True, если ничего не найдено."""
        return not self.boxes

    @property
    def labels(self) -> tuple[str, ...]:
        """Уникальные подписи в порядке появления (дубли — по нормализованному виду)."""
        seen: dict[str, str] = {}
        for box in self.boxes:
            seen.setdefault(normalize_label(box.label), box.label)
        return tuple(seen.values())

    def find(
        self, label: str, *, min_confidence: float = 0.0
    ) -> list[DetectionBox]:
        """
        Коробки с подписью ``label`` (без учёта регистра/ё↔е/пробелов).

        ``min_confidence`` дополнительно отсекает неуверенные совпадения.
        """
        needle = normalize_label(label)
        if not needle:
            return []
        if isinstance(min_confidence, bool) or not isinstance(
            min_confidence, (int, float)
        ):
            raise ValueError("min_confidence должен быть числом")
        if not 0.0 <= float(min_confidence) <= 100.0:
            raise ValueError("min_confidence должен быть в диапазоне 0..100")
        return [
            b
            for b in self.boxes
            if normalize_label(b.label) == needle
            and b.confidence >= float(min_confidence)
        ]

    def best(self, label: str) -> DetectionBox | None:
        """Самая уверенная коробка с подписью ``label`` либо ``None``."""
        matches = self.find(label)
        return max(matches, key=lambda b: b.confidence) if matches else None

    def top(self, n: int = 5) -> list[DetectionBox]:
        """Топ-``n`` коробок по убыванию уверенности (стабильно по порядку)."""
        if isinstance(n, bool) or not isinstance(n, int):
            raise ValueError("n должен быть int")
        if n < 0:
            raise ValueError("n не может быть отрицательным")
        indexed = sorted(
            enumerate(self.boxes), key=lambda t: (-t[1].confidence, t[0])
        )
        return [box for _, box in indexed[:n]]


def nms(
    boxes: Sequence[DetectionBox], *, iou_threshold: float = 0.4
) -> tuple[DetectionBox, ...]:
    """
    Non-maximum suppression: схлопывает пересекающиеся дубли одной подписи.

    Жадно оставляются самые уверенные коробки; коробки с разными подписями
    не конкурируют (могут легитимно пересекаться).
    """
    if isinstance(boxes, (str, bytes)) or not isinstance(
        boxes, collections.abc.Sequence
    ):
        raise ValueError("boxes должен быть последовательностью DetectionBox")
    for box in boxes:
        if not isinstance(box, DetectionBox):
            raise ValueError("boxes должен содержать только DetectionBox")
    if isinstance(iou_threshold, bool) or not isinstance(iou_threshold, (int, float)):
        raise ValueError("iou_threshold должен быть числом")
    if not 0.0 <= float(iou_threshold) <= 1.0:
        raise ValueError("iou_threshold должен быть в диапазоне 0..1")
    threshold = float(iou_threshold)
    ordered = sorted(
        enumerate(boxes), key=lambda t: (-t[1].confidence, t[0])
    )
    kept: list[DetectionBox] = []
    for _, box in ordered:
        key = normalize_label(box.label)
        if any(
            normalize_label(k.label) == key and k.iou(box) > threshold for k in kept
        ):
            continue
        kept.append(box)
    return tuple(kept)


# ---------------------------------------------------------------------------
# Контракт движка
# ---------------------------------------------------------------------------
class DetectorEngine(abc.ABC):
    """Контракт движка детекции объектов."""

    name: str = "engine"

    @abc.abstractmethod
    def is_available(self) -> bool:
        """Движок готов к работе (есть зависимости/сеть/ресурсы)."""

    @abc.abstractmethod
    def detect(
        self, image: OCRImage, *, labels: Sequence[str] | None = None
    ) -> DetectionResult:
        """Ищет объекты на растре; ошибки — ``DetectorError``/``DetectorUnavailable``."""

    def describe(self) -> dict[str, Any]:
        """Метадвижка для диагностики."""
        return {"name": self.name, "available": self.is_available()}


def _as_image(obj: Any) -> OCRImage:
    """
    Приводит вход к ``OCRImage``.

    Принимает и ``ScreenFrame`` (vision.capture) — по «утиной» типизации,
    без жёсткой зависимости между модулями.
    """
    if isinstance(obj, OCRImage):
        return obj
    if hasattr(obj, "pixels") and hasattr(obj, "width") and hasattr(obj, "height"):
        try:
            return OCRImage.from_frame(obj)
        except Exception as exc:  # noqa: BLE001 — деградация без vision.capture
            raise DetectorError(f"не удалось преобразовать кадр: {exc}") from exc
    raise DetectorError(f"ожидалась OCRImage/ScreenFrame, получено: {type(obj).__name__}")


def _filter_labels(labels: Sequence[str] | None) -> tuple[str, ...] | None:
    """Проверяет список подписей и возвращает кортеж (или ``None`` = «все»)."""
    if labels is None:
        return None
    if isinstance(labels, (str, bytes)) or not isinstance(
        labels, collections.abc.Sequence
    ):
        raise DetectorError("labels должен быть последовательностью подписей")
    out: list[str] = []
    for item in labels:
        try:
            out.append(_validate_label(item))
        except ValueError as exc:
            raise DetectorError(f"недопустимая подпись {item!r}: {exc}") from exc
    return tuple(out)


# ---------------------------------------------------------------------------
# Локально: поиск шаблонов (ZNCC), чистый Python
# ---------------------------------------------------------------------------
class TemplateDetectorEngine(DetectorEngine):
    """
    Локальный детектор эталонов (шаблонов) без внешних зависимостей.

    Для каждого шаблона (``label -> OCRImage``) выполняется скользящий поиск
    по кадру со счётом ``score`` = 0..100:
      - основная метрика — ZNCC (нормированная кросс-корреляция с вычетом
        среднего): ``100 * (zncc + 1) / 2``;
      - если шаблон или окно «плоские» (нулевая дисперсия) — метрика
        ``100 * (1 - MAD / 255)`` по среднему абсолютному расхождению.

    ``stride`` — шаг сканирования (≥1): больше шаг → быстрее, но грубее.
    ``max_work`` — предохранитель на примерное число операций; при превышении
    кадр считается слишком большим для локального поиска (``DetectorUnavailable``)
    и роутер уходит в облачный движок.
    """

    name = "template"

    def __init__(
        self,
        templates: Mapping[str, OCRImage] | None = None,
        *,
        min_confidence: float = 70.0,
        stride: int = 1,
        max_results: int = 64,
        max_work: int = MAX_TEMPLATE_WORK,
    ) -> None:
        if isinstance(min_confidence, bool) or not isinstance(
            min_confidence, (int, float)
        ):
            raise ValueError("min_confidence должен быть числом")
        if not 0.0 <= float(min_confidence) <= 100.0:
            raise ValueError("min_confidence должен быть в диапазоне 0..100")
        if isinstance(stride, bool) or not isinstance(stride, int) or stride < 1:
            raise ValueError("stride должен быть int >= 1")
        if isinstance(max_results, bool) or not isinstance(max_results, int):
            raise ValueError("max_results должен быть int")
        if not 1 <= max_results <= MAX_DETECTIONS:
            raise ValueError(f"max_results должен быть в диапазоне 1..{MAX_DETECTIONS}")
        if isinstance(max_work, bool) or not isinstance(max_work, int) or max_work < 1:
            raise ValueError("max_work должен быть int >= 1")
        self._min_confidence = float(min_confidence)
        self._stride = stride
        self._max_results = max_results
        self._max_work = max_work
        self._templates: dict[str, tuple[int, int, tuple[int, ...], float, float]] = {}
        for label, image in (templates or {}).items():
            self.add_template(label, image)

    # -- банк шаблонов -----------------------------------------------------
    @staticmethod
    def _prepare(image: OCRImage) -> tuple[int, int, tuple[int, ...], float, float]:
        """Серый растр → плоский кортеж пикселей + среднее/дисперсия шаблона."""
        gray = image.to_gray()
        pixels = tuple(gray.data)
        n = len(pixels)
        mean = sum(pixels) / n
        var = sum((v - mean) ** 2 for v in pixels) / n
        return (gray.width, gray.height, pixels, mean, var)

    def add_template(self, label: str, image: OCRImage) -> None:
        """Добавляет/заменяет шаблон объекта с подписью ``label``."""
        label = _validate_label(label)
        if not isinstance(image, OCRImage):
            raise DetectorError(f"шаблон должен быть OCRImage, получено: {type(image).__name__}")
        self._templates[label] = self._prepare(image)

    def remove_template(self, label: str) -> bool:
        """Удаляет шаблон; ``True`` — если шаблон был."""
        return self._templates.pop(_validate_label(label), None) is not None

    @property
    def labels(self) -> tuple[str, ...]:
        """Подписи доступных шаблонов."""
        return tuple(self._templates)

    def is_available(self) -> bool:
        return bool(self._templates)

    # -- поиск -------------------------------------------------------------
    def _score_at(
        self,
        data: tuple[int, ...],
        width: int,
        x: int,
        y: int,
        tpl: tuple[int, ...],
        tw: int,
        th: int,
        mean_t: float,
        var_t: float,
    ) -> float:
        """Оценивает совпадение шаблона с окном кадра в точке ``(x, y)`` (0..100)."""
        n = tw * th
        sum_i = 0
        sum_i2 = 0
        sum_ti = 0
        idx = 0
        for row in range(th):
            base = (y + row) * width + x
            for col in range(tw):
                val = data[base + col]
                sum_i += val
                sum_i2 += val * val
                sum_ti += val * tpl[idx]
                idx += 1
        mean_i = sum_i / n
        var_i = sum_i2 / n - mean_i * mean_i
        if var_t <= 1e-9 or var_i <= 1e-9:
            # плоский шаблон или плоское окно — метрика по среднему расхождению
            mad = self._mad_at(data, width, x, y, tpl, tw, th)
            return 100.0 * (1.0 - mad / 255.0)
        num = sum_ti - n * mean_t * mean_i
        den = math.sqrt(var_t * n * (var_i * n))
        zncc = 0.0 if den <= 1e-9 else max(-1.0, min(1.0, num / den))
        return 50.0 * (zncc + 1.0)

    @staticmethod
    def _mad_at(
        data: tuple[int, ...],
        width: int,
        x: int,
        y: int,
        tpl: tuple[int, ...],
        tw: int,
        th: int,
    ) -> float:
        """Среднее абсолютное расхождение окна и шаблона (0..255)."""
        total = 0
        idx = 0
        for row in range(th):
            base = (y + row) * width + x
            for col in range(tw):
                total += abs(data[base + col] - tpl[idx])
                idx += 1
        return total / (tw * th)

    def detect(
        self, image: OCRImage, *, labels: Sequence[str] | None = None
    ) -> DetectionResult:
        img = _as_image(image)
        wanted = _filter_labels(labels)
        if wanted is not None and not wanted:
            return DetectionResult(boxes=(), engine=self.name, elapsed_ms=0.0)
        gray = img.to_gray()
        data = tuple(gray.data)
        width, height = gray.width, gray.height
        started = time.monotonic()
        found: list[DetectionBox] = []
        for label, (tw, th, tpl, mean_t, var_t) in self._templates.items():
            if wanted is not None and label not in wanted:
                continue
            if tw > width or th > height:
                continue
            positions_x = (width - tw) // self._stride + 1
            positions_y = (height - th) // self._stride + 1
            work = positions_x * positions_y * tw * th
            if work > self._max_work:
                raise DetectorUnavailable(
                    f"кадр {width}x{height} слишком велик для локального поиска "
                    f"шаблона '{label}' (~{work} операций > {self._max_work}); "
                    f"увеличьте stride или используйте облачный детектор"
                )
            for oy in range(0, height - th + 1, self._stride):
                for ox in range(0, width - tw + 1, self._stride):
                    score = self._score_at(
                        data, width, ox, oy, tpl, tw, th, mean_t, var_t
                    )
                    if score < self._min_confidence:
                        continue
                    found.append(
                        DetectionBox(
                            label=label,
                            x=ox,
                            y=oy,
                            width=tw,
                            height=th,
                            confidence=round(score, 4),
                        )
                    )
        merged = nms(found, iou_threshold=0.3)[: self._max_results]
        return DetectionResult(
            boxes=merged,
            engine=self.name,
            elapsed_ms=(time.monotonic() - started) * 1000.0,
        )

    def describe(self) -> dict[str, Any]:
        info = super().describe()
        info.update(
            {
                "labels": list(self._templates),
                "min_confidence": self._min_confidence,
                "stride": self._stride,
                "max_results": self._max_results,
            }
        )
        return info


# ---------------------------------------------------------------------------
# Облако: пользовательский HTTP-endpoint (опционально)
# ---------------------------------------------------------------------------
class HttpDetectorEngine(DetectorEngine):
    """
    Облачная «vision-модель» через пользовательский HTTP-endpoint (JSON + base64).

    Запрос:  ``POST {"image": <base64>, "labels": [...]}``
    Ответ:   ``{"detections": [{"label", "confidence", "x", "y",
               "width", "height"}]}``

    ⚠️ Отправляет фрагмент скриншота на внешний сервис — включайте осознанно.
    Ключ берётся из переменной окружения ``api_key_env`` (заголовок
    ``Authorization: Bearer ...``) и никуда не логируется.
    """

    name = "http"

    def __init__(
        self,
        endpoint: str,
        *,
        api_key_env: str = "JARVIS_VISION_API_KEY",
        timeout: float = 15.0,
        opener: Callable[..., Any] | None = None,
    ) -> None:
        if not isinstance(endpoint, str) or not endpoint.startswith(
            ("http://", "https://")
        ):
            raise ValueError("endpoint должен быть http(s)-URL")
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)):
            raise ValueError("timeout должен быть числом")
        if not 0.1 <= float(timeout) <= 120.0:
            raise ValueError("timeout должен быть в диапазоне 0.1..120 секунд")
        if not isinstance(api_key_env, str) or not api_key_env:
            raise ValueError("api_key_env должен быть непустой строкой")
        self._endpoint = endpoint
        self._api_key_env = api_key_env
        self._timeout = float(timeout)
        self._opener = opener or urllib.request.urlopen

    def is_available(self) -> bool:
        # доступность = настроенный endpoint (сеть проверяется в момент запроса)
        return True

    def detect(
        self, image: OCRImage, *, labels: Sequence[str] | None = None
    ) -> DetectionResult:
        img = _as_image(image)
        wanted = _filter_labels(labels)
        payload = json.dumps(
            {
                "image": base64.b64encode(img.to_png()).decode("ascii"),
                "labels": list(wanted) if wanted is not None else None,
            }
        ).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        key = os.environ.get(self._api_key_env, "")
        if key:
            headers["Authorization"] = f"Bearer {key}"
        request = urllib.request.Request(self._endpoint, data=payload, headers=headers)
        started = time.monotonic()
        try:
            with self._opener(request, timeout=self._timeout) as resp:
                raw = resp.read(MAX_DETECTIONS * 512)
        except (urllib.error.URLError, OSError) as exc:
            raise DetectorUnavailable(f"облачный детектор недоступен: {exc}") from exc
        except Exception as exc:  # noqa: BLE001 — кастомные opener в тестах
            raise DetectorUnavailable(f"облачный детектор недоступен: {exc}") from exc
        try:
            doc = json.loads(raw.decode("utf-8", "replace"))
        except (ValueError, UnicodeDecodeError) as exc:
            raise DetectorError(f"облачный детектор вернул не JSON: {exc}") from exc
        if not isinstance(doc, dict):
            raise DetectorError("облачный детектор вернул не объект JSON")
        boxes: list[DetectionBox] = []
        for item in doc.get("detections") or []:
            if not isinstance(item, dict):
                raise DetectorError("некорректный элемент detections в ответе")
            try:
                boxes.append(
                    DetectionBox(
                        label=str(item["label"]),
                        x=int(item.get("x", 0)),
                        y=int(item.get("y", 0)),
                        width=int(item.get("width", 0)),
                        height=int(item.get("height", 0)),
                        confidence=float(item.get("confidence", 0.0)),
                    )
                )
            except (ValueError, TypeError, KeyError) as exc:
                raise DetectorError(f"некорректная детекция в ответе: {exc}") from exc
            if len(boxes) >= MAX_DETECTIONS:
                break
        return DetectionResult(
            boxes=tuple(boxes),
            engine=self.name,
            elapsed_ms=(time.monotonic() - started) * 1000.0,
        )

    def describe(self) -> dict[str, Any]:
        info = super().describe()
        info.update({"endpoint": self._endpoint, "timeout": self._timeout})
        return info


# ---------------------------------------------------------------------------
# Синтетика: тесты/отладка/аварийный fallback
# ---------------------------------------------------------------------------
class SyntheticDetectorEngine(DetectorEngine):
    """
    Детерминированный движок без внешних зависимостей.

    ``provider`` — вызываемый объект ``OCRImage -> DetectionResult``; без него
    возвращается статический набор ``boxes`` (по умолчанию пустой), чтобы
    пайплайн не падал без детектора.
    """

    name = "synthetic"

    def __init__(
        self,
        provider: Callable[[OCRImage], DetectionResult] | None = None,
        *,
        boxes: Sequence[DetectionBox] = (),
        available: bool = True,
    ) -> None:
        if provider is not None and not callable(provider):
            raise ValueError("provider должен быть вызываемым")
        if isinstance(boxes, (str, bytes)) or not isinstance(
            boxes, collections.abc.Sequence
        ):
            raise ValueError("boxes должен быть последовательностью DetectionBox")
        for box in boxes:
            if not isinstance(box, DetectionBox):
                raise ValueError("boxes должен содержать только DetectionBox")
        self._provider = provider
        self._boxes = tuple(boxes)
        self._available = available

    def is_available(self) -> bool:
        return self._available

    def detect(
        self, image: OCRImage, *, labels: Sequence[str] | None = None
    ) -> DetectionResult:
        img = _as_image(image)
        wanted = _filter_labels(labels)
        started = time.monotonic()
        if self._provider is not None:
            result = self._provider(img)
            if not isinstance(result, DetectionResult):
                raise DetectorError("provider должен возвращать DetectionResult")
            return result
        boxes = self._boxes
        if wanted is not None:
            keys = {normalize_label(w) for w in wanted}
            boxes = tuple(b for b in boxes if normalize_label(b.label) in keys)
        return DetectionResult(
            boxes=boxes,
            engine=self.name,
            elapsed_ms=(time.monotonic() - started) * 1000.0,
        )

    def describe(self) -> dict[str, Any]:
        info = super().describe()
        info.update({"static_boxes": len(self._boxes)})
        return info


# ---------------------------------------------------------------------------
# Диспетчер: смена движков + fallback
# ---------------------------------------------------------------------------
class DetectorRouter:
    """Диспетчер движков детекции: смена + fallback по цепочке."""

    def __init__(
        self,
        engines: Mapping[str, DetectorEngine] | None = None,
        primary: str = "template",
        fallback_chain: Sequence[str] | None = None,
    ) -> None:
        self._engines = dict(engines or {})
        self._primary = primary
        self._fallback_chain = list(fallback_chain) if fallback_chain else [primary]

    @property
    def primary(self) -> str:
        return self._primary

    def set_primary(self, name: str) -> None:
        if name not in self._engines:
            raise DetectorError(f"Неизвестный движок детекции: {name}")
        self._primary = name
        self._fallback_chain = [name] + [e for e in self._fallback_chain if e != name]
        logger.info("Движок детекции переключён на '%s'", name)

    def available(self) -> list[str]:
        return [n for n, e in self._engines.items() if e.is_available()]

    def _chain(self, explicit: str | None) -> list[str]:
        if explicit:
            return [explicit]
        order = self._fallback_chain or list(self._engines.keys())
        chain = [self._primary] + [n for n in order if n != self._primary]
        chain += [n for n in self._engines if n not in chain]
        return chain

    def detect(
        self,
        image: OCRImage,
        *,
        labels: Sequence[str] | None = None,
        engine: str | None = None,
    ) -> DetectionResult:
        """Ищет объекты, обходя цепочку fallback при отказах движков."""
        last_err: Exception | None = None
        for name in self._chain(engine):
            eng = self._engines.get(name)
            if eng is None or not eng.is_available():
                last_err = DetectorUnavailable(f"{name}: недоступен")
                continue
            try:
                return eng.detect(image, labels=labels)
            except DetectorError as exc:
                last_err = exc
                logger.warning("Детектор '%s' не справился: %s", name, exc)
                continue
        raise DetectorError(
            f"Ни один движок детекции не справился. Последняя ошибка: {last_err}"
        )

    def describe(self) -> dict[str, Any]:
        return {
            "primary": self._primary,
            "available": self.available(),
            "engines": {n: e.describe() for n, e in self._engines.items()},
        }


# ---------------------------------------------------------------------------
# Высокоуровневый сервис
# ---------------------------------------------------------------------------
class ScreenDetector:
    """
    Готовый конвейер детекции: предобработка → ``DetectorRouter`` → поиск/клик.

    ``preprocess`` — цепочка преобразований растра (как в ``vision.ocr``):
    ``"gray"``, ``"binary"``, ``"invert"``, ``"scale:2.0"`` (по порядку).
    """

    def __init__(
        self,
        router: DetectorRouter,
        *,
        preprocess: Sequence[str] = ("gray",),
        min_confidence: float = 0.0,
        nms_threshold: float = 0.4,
    ) -> None:
        if not isinstance(router, DetectorRouter):
            raise TypeError("router должен быть DetectorRouter")
        if isinstance(preprocess, (str, bytes)) or not isinstance(
            preprocess, collections.abc.Sequence
        ):
            raise ValueError("preprocess должен быть последовательностью строк")
        for step in preprocess:
            self._validate_step(step)
        if isinstance(min_confidence, bool) or not isinstance(
            min_confidence, (int, float)
        ):
            raise ValueError("min_confidence должен быть числом")
        if not 0.0 <= float(min_confidence) <= 100.0:
            raise ValueError("min_confidence должен быть в диапазоне 0..100")
        if isinstance(nms_threshold, bool) or not isinstance(
            nms_threshold, (int, float)
        ):
            raise ValueError("nms_threshold должен быть числом")
        if not 0.0 <= float(nms_threshold) <= 1.0:
            raise ValueError("nms_threshold должен быть в диапазоне 0..1")
        self._router = router
        self._preprocess = tuple(preprocess)
        self._min_confidence = float(min_confidence)
        self._nms_threshold = float(nms_threshold)

    @staticmethod
    def _validate_step(step: str) -> None:
        if not isinstance(step, str):
            raise ValueError("шаг предобработки должен быть строкой")
        if step in ("gray", "binary", "invert"):
            return
        if step.startswith("scale:"):
            try:
                factor = float(step.split(":", 1)[1])
            except ValueError as exc:
                raise ValueError(f"некорректный шаг масштаба: {step!r}") from exc
            if not 0.1 <= factor <= 4.0:
                raise ValueError(f"масштаб вне 0.1..4.0: {step!r}")
            return
        raise ValueError(f"неизвестный шаг предобработки: {step!r}")

    def prepare(self, image: OCRImage) -> OCRImage:
        """Применяет настроенную цепочку предобработки к растру."""
        img = _as_image(image)
        current = img
        for step in self._preprocess:
            if step == "gray":
                current = current.to_gray()
            elif step == "binary":
                current = current.binarize()
            elif step == "invert":
                current = current.invert()
            elif step.startswith("scale:"):
                current = current.scale(float(step.split(":", 1)[1]))
        return current

    def detect(
        self, image: OCRImage, *, labels: Sequence[str] | None = None
    ) -> DetectionResult:
        """Полный конвейер: предобработка + детекция + NMS + порог уверенности."""
        result = self._router.detect(self.prepare(image), labels=labels)
        boxes = [b for b in result.boxes if b.confidence >= self._min_confidence]
        merged = nms(boxes, iou_threshold=self._nms_threshold)
        return DetectionResult(
            boxes=merged,
            engine=result.engine,
            elapsed_ms=result.elapsed_ms,
        )

    def find(
        self,
        image: OCRImage,
        label: str,
        *,
        labels: Sequence[str] | None = None,
        min_confidence: float = 0.0,
    ) -> list[DetectionBox]:
        """Коробки объектов с подписью ``label`` (нормализованный поиск)."""
        result = self.detect(image, labels=labels)
        return result.find(label, min_confidence=min_confidence)

    def locate(self, image: OCRImage, label: str) -> DetectionBox | None:
        """Самая уверенная коробка объекта ``label`` либо ``None``."""
        return self.detect(image).best(label)

    def click_point(self, image: OCRImage, label: str) -> tuple[int, int] | None:
        """
        Центр объекта ``label`` — готовая точка клика «по описанию».

        Если объект не найден — ``None`` (кликовать некуда, ничего не выдумываем).
        """
        box = self.locate(image, label)
        return box.center if box is not None else None

    def describe(self) -> dict[str, Any]:
        return {
            "preprocess": list(self._preprocess),
            "min_confidence": self._min_confidence,
            "nms_threshold": self._nms_threshold,
            "router": self._router.describe(),
        }


# ---------------------------------------------------------------------------
# Сборка по умолчанию (локально-first)
# ---------------------------------------------------------------------------
def default_detector_router(
    *,
    cloud_endpoint: str | None = None,
    templates: Mapping[str, OCRImage] | None = None,
) -> DetectorRouter:
    """
    Стандартная сборка: локальные шаблоны → опционально облако → синтетика.

    ``cloud_endpoint`` включает облачный fallback (см. приватность в описании
    модуля); без него цепочка полностью локальная.
    """
    engines: dict[str, DetectorEngine] = {
        "template": TemplateDetectorEngine(templates)
    }
    chain = ["template"]
    if cloud_endpoint:
        engines["http"] = HttpDetectorEngine(cloud_endpoint)
        chain.append("http")
    engines["synthetic"] = SyntheticDetectorEngine()
    chain.append("synthetic")
    return DetectorRouter(engines, primary="template", fallback_chain=chain)
