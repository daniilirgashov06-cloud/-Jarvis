"""
Отслеживание изменений экрана для зрительного конвейера (vision) JARVIS CORE.

Модуль отвечает на вопросы «что изменилось на экране?», «экран вообще живой?»
и «сработала ли наблюдаемая область (часы, чат, окно кода)?».

Состав:
  - ``FrameDiff`` / ``ScreenChange`` / ``RegionEvent`` — результаты сравнения;
  - контракт ``ChangeDetector`` + движки:
      * ``PixelChangeDetector`` — локально, чистый Python: попиксельное
        сравнение с допуском по каналу, сетка ячеек, ограничитель объёма
        работы ``max_work``;
      * ``HashChangeDetector`` — локально, быстрый путь: одинаковые отпечатки
        (SHA-1) → ноль работы, иначе делегирует внутреннему детектору;
  - ``ScreenTracker`` — наблюдатель: история изменений, наблюдаемые регионы
    с cooldown, маскирование приватных регионов, отчёт активности и «простой».

Приватность: регионы ``ignore_regions`` (парольные поля, личные окна)
заливаются чёрным до сравнения — их мигание курсора не порождает событий.
Область применения — только локально: кадры никуда не отправляются.

Сравнение идёт с базовым кадром; база обновляется после каждого
зарегистрированного изменения — постепенные дрейфы накапливаются
и не теряются между кадрами.
"""

from __future__ import annotations

import abc
import enum
import logging
import math
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Iterable, Sequence

from vision.capture import CaptureRegion, ScreenFrame, mask_frame

logger = logging.getLogger(__name__)

#: порог доли изменённых пикселей для уровня MODERATE
MODERATE_RATIO: float = 0.08

#: порог доли изменённых пикселей для уровня MAJOR
MAJOR_RATIO: float = 0.35

#: размер ячейки сетки изменения по умолчанию, пиксели
DEFAULT_CELL_SIZE: int = 8

#: предохранитель от «памяти-бомбы»: максимум проверяемых пикселей
DEFAULT_MAX_WORK: int = 4_000_000


class ScreenTrackerError(Exception):
    """Ошибка отслеживания изменений экрана."""


class TrackerUnavailable(ScreenTrackerError):
    """Детектор не справился (слишком большой кадр, сбой движка)."""


# ---------------------------------------------------------------------------
# Уровень изменения
# ---------------------------------------------------------------------------
class ChangeLevel(str, enum.Enum):
    """Уровень значимости изменения кадра."""

    NONE = "none"
    MINOR = "minor"
    MODERATE = "moderate"
    MAJOR = "major"

    @property
    def rank(self) -> int:
        """Порядковый номер значимости (NONE=0 … MAJOR=3) — для сравнений."""
        return _LEVEL_RANK[self]

    def at_least(self, other: "ChangeLevel") -> bool:
        """True, если этот уровень не менее значим, чем ``other``."""
        return self.rank >= other.rank


_LEVEL_RANK: dict[ChangeLevel, int] = {
    ChangeLevel.NONE: 0,
    ChangeLevel.MINOR: 1,
    ChangeLevel.MODERATE: 2,
    ChangeLevel.MAJOR: 3,
}


def classify_change(
    ratio: float,
    *,
    moderate: float = MODERATE_RATIO,
    major: float = MAJOR_RATIO,
) -> ChangeLevel:
    """
    Классифицирует долю изменённых пикселей (0.0…1.0) в уровень.

    ``ratio <= 0`` → NONE; иначе MINOR / MODERATE / MAJOR по порогам.
    """
    if not isinstance(ratio, (int, float)) or isinstance(ratio, bool):
        raise ValueError(f"ratio должен быть числом, получено: {ratio!r}")
    if not (0.0 <= moderate < major <= 1.0):
        raise ValueError("пороги должны удовлетворять 0 <= moderate < major <= 1")
    if ratio <= 0.0:
        return ChangeLevel.NONE
    if ratio >= major:
        return ChangeLevel.MAJOR
    if ratio >= moderate:
        return ChangeLevel.MODERATE
    return ChangeLevel.MINOR


# ---------------------------------------------------------------------------
# Результаты сравнения
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class FrameDiff:
    """
    Разница между двумя кадрами.

    ``bounds`` — локальные координаты охватывающего прямоугольника изменения
    (в системе кадра), ``None`` если изменений нет.
    """

    width: int
    height: int
    changed_pixels: int
    changed_cells: int
    total_cells: int
    bounds: CaptureRegion | None
    level: ChangeLevel

    def __post_init__(self) -> None:
        if self.width <= 0 or self.height <= 0:
            raise ValueError("width/height должны быть положительными")
        total = self.width * self.height
        if not 0 <= self.changed_pixels <= total:
            raise ValueError(
                f"changed_pixels вне диапазона 0..{total}: {self.changed_pixels}"
            )
        if not 0 <= self.changed_cells <= self.total_cells:
            raise ValueError(
                f"changed_cells вне диапазона 0..{self.total_cells}: "
                f"{self.changed_cells}"
            )
        if self.total_cells <= 0:
            raise ValueError("total_cells должна быть положительной")
        if (self.changed_pixels == 0) != (self.bounds is None):
            raise ValueError("bounds задаётся тогда и только тогда, когда есть изменения")
        if self.bounds is not None:
            x2 = self.bounds.x + self.bounds.width
            y2 = self.bounds.y + self.bounds.height
            if self.bounds.x < 0 or self.bounds.y < 0 or x2 > self.width or y2 > self.height:
                raise ValueError("bounds выходит за пределы кадра")

    @property
    def total_pixels(self) -> int:
        """Всего пикселей в кадре."""
        return self.width * self.height

    @property
    def changed_ratio(self) -> float:
        """Доля изменённых пикселей (0.0…1.0)."""
        return self.changed_pixels / self.total_pixels

    @property
    def has_changes(self) -> bool:
        """True, если есть хотя бы один изменённый пиксель."""
        return self.changed_pixels > 0

    def to_dict(self) -> dict[str, Any]:
        """Сериализация для панели/логов."""
        return {
            "width": self.width,
            "height": self.height,
            "changed_pixels": self.changed_pixels,
            "changed_ratio": round(self.changed_ratio, 6),
            "changed_cells": self.changed_cells,
            "total_cells": self.total_cells,
            "bounds": (
                None
                if self.bounds is None
                else {
                    "x": self.bounds.x,
                    "y": self.bounds.y,
                    "width": self.bounds.width,
                    "height": self.bounds.height,
                }
            ),
            "level": self.level.value,
        }


@dataclass(frozen=True)
class RegionEvent:
    """Событие наблюдаемой области: внутри региона зафиксировано изменение."""

    name: str
    timestamp: float
    changed_ratio: float
    level: ChangeLevel
    bounds: CaptureRegion | None

    def to_dict(self) -> dict[str, Any]:
        """Сериализация для панели/логов."""
        return {
            "name": self.name,
            "timestamp": self.timestamp,
            "changed_ratio": round(self.changed_ratio, 6),
            "level": self.level.value,
        }


@dataclass(frozen=True)
class ScreenChange:
    """Зарегистрированное значимое изменение экрана."""

    timestamp: float
    diff: FrameDiff
    fingerprint: str
    prev_fingerprint: str
    regions: tuple[RegionEvent, ...] = ()

    @property
    def level(self) -> ChangeLevel:
        """Уровень значимости изменения."""
        return self.diff.level

    @property
    def changed_ratio(self) -> float:
        """Доля изменённых пикселей."""
        return self.diff.changed_ratio

    def to_dict(self) -> dict[str, Any]:
        """Сериализация для панели/логов."""
        return {
            "timestamp": self.timestamp,
            "level": self.level.value,
            "changed_ratio": round(self.changed_ratio, 6),
            "diff": self.diff.to_dict(),
            "regions": [ev.to_dict() for ev in self.regions],
        }


@dataclass(frozen=True)
class ActivityReport:
    """Сводка активности экрана за окно наблюдения."""

    window_s: float
    frames: int
    changes: int
    avg_changed_ratio: float
    max_changed_ratio: float
    last_change_ago_s: float | None
    idle: bool

    def to_dict(self) -> dict[str, Any]:
        """Сериализация для панели/логов."""
        return {
            "window_s": self.window_s,
            "frames": self.frames,
            "changes": self.changes,
            "avg_changed_ratio": round(self.avg_changed_ratio, 6),
            "max_changed_ratio": round(self.max_changed_ratio, 6),
            "last_change_ago_s": self.last_change_ago_s,
            "idle": self.idle,
        }


# ---------------------------------------------------------------------------
# Наблюдаемая область
# ---------------------------------------------------------------------------
def _validate_label(name: str, what: str, max_len: int) -> str:
    """Общая проверка коротких строковых подписей (антиинъекция управляющих)."""
    if not isinstance(name, str) or not name.strip():
        raise ValueError(f"{what} должно быть непустой строкой")
    if len(name) > max_len:
        raise ValueError(f"{what} длиннее {max_len} символов: {name!r}")
    if any(ord(ch) < 32 for ch in name):
        raise ValueError(f"{what} содержит управляющие символы: {name!r}")
    return name.strip()


@dataclass(frozen=True)
class WatchRegion:
    """
    Наблюдаемая область экрана (абсолютные координаты).

    Событие порождается, когда доля изменённых пикселей внутри региона
    достигает ``threshold``; повторные события глушатся на ``cooldown_s``.
    """

    name: str
    region: CaptureRegion
    threshold: float = 0.01
    cooldown_s: float = 5.0

    def __post_init__(self) -> None:
        object.__setattr__(self, "name", _validate_label(self.name, "имя региона", 64))
        if not isinstance(self.region, CaptureRegion):
            raise ValueError(f"region должен быть CaptureRegion: {self.region!r}")
        if not isinstance(self.threshold, (int, float)) or isinstance(self.threshold, bool):
            raise ValueError(f"threshold должен быть числом: {self.threshold!r}")
        if not 0.0 < float(self.threshold) <= 1.0:
            raise ValueError("threshold должен быть в диапазоне (0, 1]")
        if not isinstance(self.cooldown_s, (int, float)) or isinstance(self.cooldown_s, bool):
            raise ValueError(f"cooldown_s должен быть числом: {self.cooldown_s!r}")
        if self.cooldown_s < 0:
            raise ValueError("cooldown_s не может быть отрицательным")


# ---------------------------------------------------------------------------
# Детекторы изменений
# ---------------------------------------------------------------------------
class ChangeDetector(abc.ABC):
    """
    Контракт детектора изменений между двумя кадрами.

    Реализация должна принимать кадры с одинаковой или разной геометрией:
    при смене геометрии возвращается полное изменение (``changed_ratio = 1.0``).
    """

    name: str = "abstract"

    @abc.abstractmethod
    def diff(self, prev: ScreenFrame, curr: ScreenFrame) -> FrameDiff:
        """Сравнивает два кадра и возвращает ``FrameDiff``."""


def _frame_parts(frame: Any) -> tuple[int, int, bytes]:
    """Достаёт (width, height, pixels) из кадра или duck-typed объекта."""
    try:
        width = frame.width
        height = frame.height
        pixels = frame.pixels
    except AttributeError as exc:  # noqa: PERF203 — понятная ошибка контракта
        raise TrackerUnavailable(
            f"объект не похож на кадр ScreenFrame: {type(frame).__name__}"
        ) from exc
    if not isinstance(width, int) or not isinstance(height, int) or width <= 0 or height <= 0:
        raise TrackerUnavailable(f"некорректная геометрия кадра: {width}x{height}")
    if not isinstance(pixels, (bytes, bytearray)):
        raise TrackerUnavailable(f"пиксели кадра должны быть bytes: {type(pixels).__name__}")
    return width, height, bytes(pixels)


@dataclass(frozen=True)
class _PixelStats:
    """Внутренняя агрегация попиксельного сравнения."""

    changed_pixels: int
    min_x: int
    min_y: int
    max_x: int
    max_y: int
    changed_cells: int


class PixelChangeDetector(ChangeDetector):
    """
    Локальный детектор изменений: попиксельное сравнение с допуском.

    Пиксель считается изменённым, если хотя бы один канал отличается
    более чем на ``tolerance``. Считаются ячейки сетки ``cell_size`` (для
    оценки «сколько мест на экране шевельнулось») и охватывающий
    прямоугольник изменения. Работа ограничена ``max_work`` проверяемыми
    пикселями (учитывая ``stride``) — иначе ``TrackerUnavailable``.
    """

    name = "pixel"

    def __init__(
        self,
        *,
        tolerance: int = 2,
        cell_size: int = DEFAULT_CELL_SIZE,
        stride: int = 1,
        max_work: int = DEFAULT_MAX_WORK,
        moderate: float = MODERATE_RATIO,
        major: float = MAJOR_RATIO,
    ) -> None:
        if isinstance(tolerance, bool) or not isinstance(tolerance, int) or not 0 <= tolerance <= 255:
            raise ValueError(f"tolerance должен быть int 0..255: {tolerance!r}")
        if isinstance(cell_size, bool) or not isinstance(cell_size, int) or cell_size < 1:
            raise ValueError(f"cell_size должен быть int >= 1: {cell_size!r}")
        if isinstance(stride, bool) or not isinstance(stride, int) or stride < 1:
            raise ValueError(f"stride должен быть int >= 1: {stride!r}")
        if isinstance(max_work, bool) or not isinstance(max_work, int) or max_work < 1:
            raise ValueError(f"max_work должен быть int >= 1: {max_work!r}")
        if not 0.0 <= moderate < major <= 1.0:
            raise ValueError("пороги должны удовлетворять 0 <= moderate < major <= 1")
        self._tolerance = tolerance
        self._cell_size = cell_size
        self._stride = stride
        self._max_work = max_work
        self._moderate = moderate
        self._major = major

    def diff(self, prev: ScreenFrame, curr: ScreenFrame) -> FrameDiff:
        """Сравнивает кадры попиксельно (с учётом ``tolerance`` и ``stride``)."""
        pw, ph, ppx = _frame_parts(prev)
        cw, ch, cpx = _frame_parts(curr)

        # Быстрый путь: одинаковые отпечатки → изменений нет.
        fp_prev = prev.fingerprint() if hasattr(prev, "fingerprint") else None
        fp_curr = curr.fingerprint() if hasattr(curr, "fingerprint") else None
        if fp_prev is not None and fp_prev == fp_curr:
            return _zero_diff(cw, ch, self._cell_size)

        # Смена геометрии → полное изменение.
        if (pw, ph) != (cw, ch):
            return _full_diff(cw, ch, self._cell_size, self._moderate, self._major)

        total = cw * ch
        work = math.ceil(cw / self._stride) * math.ceil(ch / self._stride)
        if work > self._max_work:
            raise TrackerUnavailable(
                f"кадр {cw}x{ch} при stride={self._stride} требует {work} "
                f"проверок — больше лимита max_work={self._max_work}"
            )

        stats = _scan_pixels(
            cw, ch, ppx, cpx, self._tolerance, self._stride, self._cell_size
        )
        if stats.changed_pixels == 0:
            return _zero_diff(cw, ch, self._cell_size)

        bounds = CaptureRegion(
            stats.min_x,
            stats.min_y,
            stats.max_x - stats.min_x + 1,
            stats.max_y - stats.min_y + 1,
        )
        total_cells = math.ceil(cw / self._cell_size) * math.ceil(ch / self._cell_size)
        ratio = stats.changed_pixels / total
        return FrameDiff(
            width=cw,
            height=ch,
            changed_pixels=stats.changed_pixels,
            changed_cells=stats.changed_cells,
            total_cells=total_cells,
            bounds=bounds,
            level=classify_change(ratio, moderate=self._moderate, major=self._major),
        )


class HashChangeDetector(ChangeDetector):
    """
    Быстрый локальный путь: сравнение по отпечаткам (SHA-1).

    Одинаковые отпечатки → ноль изменений без сканирования; иначе делегирует
    внутреннему детектору (по умолчанию ``PixelChangeDetector``).
    """

    name = "hash"

    def __init__(self, inner: ChangeDetector | None = None) -> None:
        self._inner = inner if inner is not None else PixelChangeDetector()

    def diff(self, prev: ScreenFrame, curr: ScreenFrame) -> FrameDiff:
        """Сравнивает отпечатки; при расхождении — делегирует ``inner``."""
        fp_prev = prev.fingerprint() if hasattr(prev, "fingerprint") else None
        fp_curr = curr.fingerprint() if hasattr(curr, "fingerprint") else None
        if fp_prev is not None and fp_prev == fp_curr:
            cw, ch, _ = _frame_parts(curr)
            cell = getattr(self._inner, "_cell_size", DEFAULT_CELL_SIZE)
            return _zero_diff(cw, ch, cell)
        return self._inner.diff(prev, curr)


# ---------------------------------------------------------------------------
# Внутренние помощники детекторов
# ---------------------------------------------------------------------------
def _zero_diff(width: int, height: int, cell_size: int) -> FrameDiff:
    """Diff «изменений нет»."""
    total_cells = math.ceil(width / cell_size) * math.ceil(height / cell_size)
    return FrameDiff(
        width=width,
        height=height,
        changed_pixels=0,
        changed_cells=0,
        total_cells=total_cells,
        bounds=None,
        level=ChangeLevel.NONE,
    )


def _full_diff(
    width: int,
    height: int,
    cell_size: int,
    moderate: float,
    major: float,
) -> FrameDiff:
    """Diff «всё изменилось» (смена геометрии кадра)."""
    total = width * height
    total_cells = math.ceil(width / cell_size) * math.ceil(height / cell_size)
    return FrameDiff(
        width=width,
        height=height,
        changed_pixels=total,
        changed_cells=total_cells,
        total_cells=total_cells,
        bounds=CaptureRegion(0, 0, width, height),
        level=classify_change(1.0, moderate=moderate, major=major),
    )


def _scan_pixels(
    width: int,
    height: int,
    prev: bytes,
    curr: bytes,
    tolerance: int,
    stride: int,
    cell_size: int,
) -> _PixelStats:
    """Попиксельное сканирование с допуском, stride и агрегацией по ячейкам."""
    changed = 0
    min_x, min_y = width, height
    max_x, max_y = -1, -1
    cells: set[tuple[int, int]] = set()

    for y in range(0, height, stride):
        row = y * width * 3
        cell_y = y // cell_size
        for x in range(0, width, stride):
            off = row + x * 3
            if (
                abs(prev[off] - curr[off]) > tolerance
                or abs(prev[off + 1] - curr[off + 1]) > tolerance
                or abs(prev[off + 2] - curr[off + 2]) > tolerance
            ):
                changed += 1
                cells.add((x // cell_size, cell_y))
                if x < min_x:
                    min_x = x
                if y < min_y:
                    min_y = y
                if x > max_x:
                    max_x = x
                if y > max_y:
                    max_y = y

    return _PixelStats(
        changed_pixels=changed,
        min_x=min_x,
        min_y=min_y,
        max_x=max_x,
        max_y=max_y,
        changed_cells=len(cells),
    )


# ---------------------------------------------------------------------------
# Наблюдатель
# ---------------------------------------------------------------------------
class ScreenTracker:
    """
    Наблюдатель изменений экрана.

    Кормится кадрами ``ScreenFrame`` (обычно из ``vision.capture``):
    ``observe()`` сравнивает кадр с базовым, регистрирует значимые изменения
    (уровень ≥ ``min_level``), порождает события наблюдаемых регионов
    и ведёт историю/сводку активности.

    Приватность: ``ignore_regions`` маскируются чёрным до сравнения.
    Модуль работает только локально — кадры никуда не отправляются.
    """

    def __init__(
        self,
        detector: ChangeDetector | None = None,
        *,
        history: int = 64,
        min_level: ChangeLevel = ChangeLevel.MINOR,
        ignore_regions: Iterable[CaptureRegion] = (),
        watch_regions: Iterable[WatchRegion] = (),
        idle_after_s: float = 60.0,
    ) -> None:
        if not isinstance(min_level, ChangeLevel):
            raise ValueError(f"min_level должен быть ChangeLevel: {min_level!r}")
        if isinstance(history, bool) or not isinstance(history, int) or history < 1:
            raise ValueError(f"history должен быть int >= 1: {history!r}")
        if not isinstance(idle_after_s, (int, float)) or isinstance(idle_after_s, bool):
            raise ValueError(f"idle_after_s должен быть числом: {idle_after_s!r}")
        if idle_after_s <= 0:
            raise ValueError("idle_after_s должен быть положительным")

        self._detector = detector if detector is not None else PixelChangeDetector()
        self._min_level = min_level
        self._ignore_regions: tuple[CaptureRegion, ...] = tuple(ignore_regions)
        for reg in self._ignore_regions:
            if not isinstance(reg, CaptureRegion):
                raise ValueError(f"ignore_regions должен содержать CaptureRegion: {reg!r}")
        self._idle_after_s = float(idle_after_s)
        self._history: deque[ScreenChange] = deque(maxlen=history)
        self._watch: dict[str, WatchRegion] = {}
        self._watch_fired: dict[str, float] = {}
        self._baseline: ScreenFrame | None = None
        self._last_frame_ts: float | None = None
        self._frames_seen = 0

        for region in watch_regions:
            self.watch(region)

    # -- управление наблюдаемыми регионами ---------------------------------
    def watch(self, region: WatchRegion) -> None:
        """Добавляет/заменяет наблюдаемую область."""
        if not isinstance(region, WatchRegion):
            raise ValueError(f"region должен быть WatchRegion: {region!r}")
        self._watch[region.name] = region
        self._watch_fired.pop(region.name, None)

    def unwatch(self, name: str) -> bool:
        """Удаляет наблюдаемую область; True если она была."""
        self._watch_fired.pop(name, None)
        return self._watch.pop(name, None) is not None

    @property
    def watch_regions(self) -> tuple[WatchRegion, ...]:
        """Текущие наблюдаемые области."""
        return tuple(self._watch.values())

    @property
    def min_level(self) -> ChangeLevel:
        """Минимальный уровень, который регистрируется как изменение."""
        return self._min_level

    @property
    def frames_seen(self) -> int:
        """Сколько кадров всего наблюдалось."""
        return self._frames_seen

    @property
    def last_change(self) -> ScreenChange | None:
        """Последнее зарегистрированное изменение или ``None``."""
        return self._history[-1] if self._history else None

    def history(self) -> tuple[ScreenChange, ...]:
        """История изменений (от старых к новым, ограничена ``history``)."""
        return tuple(self._history)

    def reset(self) -> None:
        """Сбрасывает базу, историю и cooldown'ы (например, при смене экрана)."""
        self._baseline = None
        self._history.clear()
        self._watch_fired.clear()
        self._frames_seen = 0
        self._last_frame_ts = None

    # -- наблюдение --------------------------------------------------------
    def observe(self, frame: ScreenFrame) -> ScreenChange | None:
        """
        Наблюдает кадр: возвращает ``ScreenChange`` при значимом изменении
        (уровень ≥ ``min_level``), иначе ``None``.

        Первый кадр задаёт базу и не считается изменением.
        """
        if self._ignore_regions:
            frame = mask_frame(frame, self._ignore_regions)

        self._frames_seen += 1
        self._last_frame_ts = frame.timestamp

        if self._baseline is None:
            self._baseline = frame
            return None

        try:
            diff = self._detector.diff(self._baseline, frame)
        except TrackerUnavailable:
            raise
        except Exception as exc:  # noqa: BLE001 — сбой движка не должен ронять цикл
            raise TrackerUnavailable(f"детектор {self._detector.name} не справился: {exc}") from exc

        if not diff.has_changes or not diff.level.at_least(self._min_level):
            return None

        prev_fp = self._baseline.fingerprint()
        events = self._region_events(frame)
        change = ScreenChange(
            timestamp=frame.timestamp,
            diff=diff,
            fingerprint=frame.fingerprint(),
            prev_fingerprint=prev_fp,
            regions=events,
        )
        self._history.append(change)
        self._baseline = frame
        logger.debug(
            "screen change: level=%s ratio=%.4f regions=%s",
            change.level.value,
            change.changed_ratio,
            [ev.name for ev in events],
        )
        return change

    def _region_events(self, frame: ScreenFrame) -> tuple[RegionEvent, ...]:
        """Считает события наблюдаемых регионов по текущему кадру и базе."""
        if not self._watch or self._baseline is None:
            return ()
        events: list[RegionEvent] = []
        for region in self._watch.values():
            local = region.region.to_local(frame.region)
            if local is None:
                continue
            last_fired = self._watch_fired.get(region.name)
            if last_fired is not None and frame.timestamp - last_fired < region.cooldown_s:
                continue
            prev_crop = _crop_frame(self._baseline, local)
            curr_crop = _crop_frame(frame, local)
            try:
                rdiff = self._detector.diff(prev_crop, curr_crop)
            except TrackerUnavailable:
                continue
            if rdiff.changed_ratio < region.threshold:
                continue
            self._watch_fired[region.name] = frame.timestamp
            events.append(
                RegionEvent(
                    name=region.name,
                    timestamp=frame.timestamp,
                    changed_ratio=rdiff.changed_ratio,
                    level=rdiff.level,
                    bounds=rdiff.bounds,
                )
            )
        return tuple(events)

    # -- активность --------------------------------------------------------
    def is_idle(self, now: float | None = None) -> bool:
        """
        True, если последнее значимое изменение было дольше ``idle_after_s``
        назад (по умолчанию — относительно времени последнего кадра).
        """
        ref = now if now is not None else self._last_frame_ts
        if ref is None or not self._history:
            return True
        return ref - self._history[-1].timestamp >= self._idle_after_s

    def activity(self, window_s: float = 300.0, now: float | None = None) -> ActivityReport:
        """Сводка активности за последние ``window_s`` секунд."""
        if not isinstance(window_s, (int, float)) or isinstance(window_s, bool):
            raise ValueError(f"window_s должен быть числом: {window_s!r}")
        if window_s <= 0:
            raise ValueError("window_s должен быть положительным")
        ref = now if now is not None else self._last_frame_ts
        if ref is None:
            return ActivityReport(
                window_s=float(window_s),
                frames=0,
                changes=0,
                avg_changed_ratio=0.0,
                max_changed_ratio=0.0,
                last_change_ago_s=None,
                idle=True,
            )

        recent = [ch for ch in self._history if ref - window_s <= ch.timestamp <= ref]
        if recent:
            avg = sum(ch.changed_ratio for ch in recent) / len(recent)
            mx = max(ch.changed_ratio for ch in recent)
            last_ago = ref - recent[-1].timestamp
        else:
            avg, mx, last_ago = 0.0, 0.0, None

        return ActivityReport(
            window_s=float(window_s),
            frames=self._frames_seen,
            changes=len(recent),
            avg_changed_ratio=avg,
            max_changed_ratio=mx,
            last_change_ago_s=last_ago,
            idle=self.is_idle(ref),
        )


# ---------------------------------------------------------------------------
# Помощники
# ---------------------------------------------------------------------------
def _crop_frame(frame: ScreenFrame, local: CaptureRegion) -> ScreenFrame:
    """
    Вырезает из кадра локальный регион, возвращая новый кадр
    с абсолютным ``region`` исходного кадра.
    """
    data = bytearray(local.width * local.height * 3)
    stride = frame.width * 3
    out_row = local.width * 3
    for y in range(local.height):
        src = (local.y + y) * stride + local.x * 3
        dst = y * out_row
        data[dst : dst + out_row] = frame.pixels[src : src + out_row]
    abs_region = CaptureRegion(
        frame.region.x + local.x,
        frame.region.y + local.y,
        local.width,
        local.height,
    )
    return ScreenFrame(
        width=local.width,
        height=local.height,
        pixels=bytes(data),
        region=abs_region,
        monitor=frame.monitor,
        backend=frame.backend,
        timestamp=frame.timestamp,
    )


def default_screen_tracker(
    *,
    history: int = 64,
    min_level: ChangeLevel = ChangeLevel.MINOR,
    ignore_regions: Sequence[CaptureRegion] = (),
    watch_regions: Sequence[WatchRegion] = (),
    idle_after_s: float = 60.0,
) -> ScreenTracker:
    """
    Локально-first конфигурация по умолчанию: ``HashChangeDetector``
    (быстрый путь по отпечаткам) над ``PixelChangeDetector``.
    """
    return ScreenTracker(
        HashChangeDetector(PixelChangeDetector()),
        history=history,
        min_level=min_level,
        ignore_regions=ignore_regions,
        watch_regions=watch_regions,
        idle_after_s=idle_after_s,
    )
