#!/usr/bin/env python3
"""
Упаковка проекта jarvis-core в резервный архив (вызывается авто-бэкапом).

Создаёт/обновляет jarvis-core-MVP-backup.zip в корне workspace,
исключая мусор (__pycache__, .pyc, логи, бинарники, node_modules).
Возвращает строку-статус (файлов, размер, время).
"""

from __future__ import annotations

import datetime as dt
import pathlib
import zipfile

WORKSPACE = pathlib.Path(__file__).resolve().parent.parent.parent  # .../workspace
ROOT = WORKSPACE / "jarvis-core"
OUT = WORKSPACE / "jarvis-core-MVP-backup.zip"

SKIP_DIRS = {"__pycache__", ".git", "node_modules", ".venv", "venv"}
SKIP_EXT = {".pyc", ".pyo", ".log", ".db", ".wav", ".mp3", ".so", ".dll", ".exe"}


def pack() -> str:
    count = 0
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(ROOT.rglob("*")):
            if any(sd in p.parts for sd in SKIP_DIRS):
                continue
            if p.suffix in SKIP_EXT:
                continue
            if p.is_file():
                z.write(p, p.as_posix())
                count += 1
    stamp = dt.datetime.now().strftime("%H:%M:%S")
    return f"[{stamp}] файлов: {count}, размер: {OUT.stat().st_size} байт -> {OUT.name}"


if __name__ == "__main__":
    print(pack())
