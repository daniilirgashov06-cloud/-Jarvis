"""
OCR (распознавание текста на экране) для зрительного конвейера JARVIS CORE.

Единый контракт ``OCREngine`` + диспетчер ``OCRRouter`` (живая смена движков
+ fallback) + высокоуровневый ``ScreenOCR`` (предобработка → распознавание →
поиск фразы).

Движки:
  - ``TesseractEngine`` — локально, через CLI ``tesseract`` (stdin/stdout,
    TSV-вывод со словами, боксами и уверенностью) — основной путь;
  - ``HttpOCREngine`` — облако, пользовательский HTTP-endpoint (JSON + base64),
    включается только при явно заданном endpoint (опционально, локально-first);
  - ``SyntheticOCREngine`` — детерминированные результаты для тестов/отладки,
    аварийный fallback, чтобы пайплайн не падал без OCR.

Приватность: облачный движок отправляет фрагмент скриншота на внешний сервис —
используется только осознанно (см. ``HttpOCREngine``). Локальный tesseract
данные наружу не отдаёт.
"""

from __future__ import annotations

import abc
import base64
import collections.abc
import json
import logging
import os
import re
import shutil
import subprocess
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable, Sequence

if TYPE_CHECKING:  # только для аннотаций, без жёсткой зависимости
    from vision.capture import ScreenFrame

logger = logging.getLogger(__name__)

#: предохранитель от «памяти-бомбы»: максимальный размер картинки, Мпикс
MAX_IMAGE_MEGAPIXELS: int = 32

#: допустимые значения psm tesseract (сегментация страницы)
_TESSERACT_PSM: frozenset[int] = frozenset({3, 4, 6, 11, 12})

#: язык tesseract: коды вида ``rus+eng`` (буквы/цифры/подчёркивание/+/-)
_LANG_RE = re.compile(r"^[A-Za-z0-9_+-]{1,64}$")

#: ограничение на вывод tesseract (защита от «бомбы» текста)
MAX_TEXT_CHARS: int = 200_000


class OCRError(Exception):
    """Ошибка распознавания текста."""


class OCRUnavailable(OCRError):
    """Движок недоступен (нет бинарника/сети) — можно fallback."""


# ---------------------------------------------------------------------------
# Картинка для OCR
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class OCRImage:
    """
    Растр для распознавания.

    ``mode`` — ``"L"`` (серый, 1 байт/пиксель) или ``"RGB"`` (3 байта/пиксель);
    ``data`` — сырые байты строкой за строкой.
    """

    width: int
    height: int
    data: bytes
    mode: str = "L"

    def __post_init__(self) -> None:
        for name, value in (("width", self.width), ("height", self.height)):
            if isinstance(value, bool) or not isinstance(value, int):
                raise ValueError(f"{name} должен быть int, получено: {value!r}")
            if value <= 0:
                raise ValueError(f"{name} должен быть положительным")
        if self.width * self.height > MAX_IMAGE_MEGAPIXELS * 1_000_000:
            raise ValueError(
                f"картинка слишком большая: {self.width}x{self.height} "
                f"(лимит {MAX_IMAGE_MEGAPIXELS} Мпикс)"
            )
        if self.mode not in ("L", "RGB"):
            raise ValueError(f"mode должен быть 'L' или 'RGB', получено: {self.mode!r}")
        if not isinstance(self.data, bytes):
            raise ValueError("data должен быть bytes")
        expected = self.width * self.height * self.channels
        if len(self.data) != expected:
            raise ValueError(
                f"размер данных не совпадает с геометрией: "
                f"{len(self.data)} != {self.width}x{self.height}x{self.channels}"
            )

    @property
    def channels(self) -> int:
        """Число каналов: 1 для ``L``, 3 для ``RGB``."""
        return 1 if self.mode == "L" else 3

    # -- конструкторы ------------------------------------------------------
    @classmethod
    def from_frame(cls, frame: "ScreenFrame", *, gray: bool = True) -> "OCRImage":
        """
        Строит растр из кадра захвата ``ScreenFrame`` (vision.capture).

        ``gray=True`` — сразу перекодирует в оттенки серого (луминансность),
        что уменьшает объём и обычно повышает качество OCR.
        """
        img = cls(width=frame.width, height=frame.height, data=frame.pixels, mode="RGB")
        return img.to_gray() if gray else img

    # -- предобработка -----------------------------------------------------
    def to_gray(self) -> "OCRImage":
        """Перевод в оттенки серого (луминансность 0.299R + 0.587G + 0.114B)."""
        if self.mode == "L":
            return self
        out = bytearray(self.width * self.height)
        for i in range(self.width * self.height):
            off = i * 3
            r, g, b = self.data[off], self.data[off + 1], self.data[off + 2]
            out[i] = (299 * r + 587 * g + 114 * b) // 1000
        return OCRImage(self.width, self.height, bytes(out), "L")

    def binarize(self, threshold: int = 128) -> "OCRImage":
        """Чёрно-белая бинаризация по порогу (0..255) — контрастный текст."""
        if isinstance(threshold, bool) or not isinstance(threshold, int):
            raise ValueError("threshold должен быть int")
        if not 0 <= threshold <= 255:
            raise ValueError("threshold должен быть в диапазоне 0..255")
        gray = self.to_gray()
        lut = bytes(0 if v < threshold else 255 for v in range(256))
        return OCRImage(gray.width, gray.height, gray.data.translate(lut), "L")

    def invert(self) -> "OCRImage":
        """Инверсия яркости (светлый текст на тёмном фоне)."""
        lut = bytes(255 - v for v in range(256))
        return OCRImage(self.width, self.height, self.data.translate(lut), self.mode)

    def scale(self, factor: float) -> "OCRImage":
        """
        Масштабирование ближайшим соседом (factor 0.1..4.0).

        Крупный текст (×2) часто распознаётся заметно точнее.
        """
        if isinstance(factor, bool) or not isinstance(factor, (int, float)):
            raise ValueError("factor должен быть числом")
        factor = float(factor)
        if not 0.1 <= factor <= 4.0:
            raise ValueError("factor должен быть в диапазоне 0.1..4.0")
        new_w = max(1, round(self.width * factor))
        new_h = max(1, round(self.height * factor))
        if new_w == self.width and new_h == self.height:
            return self
        ch = self.channels
        out = bytearray(new_w * new_h * ch)
        for y in range(new_h):
            src_y = min(self.height - 1, int(y / factor))
            for x in range(new_w):
                src_x = min(self.width - 1, int(x / factor))
                src = (src_y * self.width + src_x) * ch
                dst = (y * new_w + x) * ch
                out[dst : dst + ch] = self.data[src : src + ch]
        return OCRImage(new_w, new_h, bytes(out), self.mode)

    # -- сериализация -----------------------------------------------------
    def to_png(self) -> bytes:
        """
        Кодирует растр в PNG (переиспользует кодировщик vision.capture).

        Серый растр разворачивается в RGB — tesseract принимает и такой PNG.
        """
        try:
            from vision.capture import CaptureRegion, ScreenFrame, encode_png
        except Exception as exc:  # noqa: BLE001 — деградация без capture
            raise OCRError(f"кодировщик PNG недоступен: {exc}") from exc
        rgb = self.to_gray() if self.mode == "L" else self
        if rgb.mode == "L":
            rgb = OCRImage(
                rgb.width,
                rgb.height,
                b"".join(bytes([v, v, v]) for v in rgb.data),
                "RGB",
            )
        frame = ScreenFrame(
            width=rgb.width,
            height=rgb.height,
            pixels=rgb.data,
            region=CaptureRegion(0, 0, rgb.width, rgb.height),
            backend="ocr",
        )
        return encode_png(frame)


# ---------------------------------------------------------------------------
# Результат распознавания
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class OCRBox:
    """Распознанное слово/фрагмент с геометрией и уверенностью (0..100)."""

    text: str
    x: int
    y: int
    width: int
    height: int
    confidence: float = 0.0

    def __post_init__(self) -> None:
        if not isinstance(self.text, str):
            raise ValueError("text должен быть str")
        for name, value in (
            ("x", self.x),
            ("y", self.y),
            ("width", self.width),
            ("height", self.height),
        ):
            if isinstance(value, bool) or not isinstance(value, int):
                raise ValueError(f"{name} должен быть int, получено: {value!r}")
        if self.width < 0 or self.height < 0:
            raise ValueError("width/height не могут быть отрицательными")
        if isinstance(self.confidence, bool) or not isinstance(self.confidence, (int, float)):
            raise ValueError("confidence должен быть числом")
        if not 0.0 <= float(self.confidence) <= 100.0:
            raise ValueError("confidence должен быть в диапазоне 0..100")


@dataclass(frozen=True)
class OCRResult:
    """
    Итог распознавания: целиковый текст, коробки слов, средняя уверенность.

    ``confidence`` — средняя уверенность, взвешенная длиной слов (0..100).
    """

    text: str
    boxes: tuple[OCRBox, ...] = ()
    lang: str = ""
    engine: str = ""
    elapsed_ms: float = 0.0

    def __post_init__(self) -> None:
        if not isinstance(self.text, str):
            raise ValueError("text должен быть str")
        if len(self.text) > MAX_TEXT_CHARS:
            raise ValueError(f"слишком длинный текст (лимит {MAX_TEXT_CHARS})")
        if not isinstance(self.boxes, tuple):
            object.__setattr__(self, "boxes", tuple(self.boxes))

    @property
    def confidence(self) -> float:
        """Средняя уверенность по словам, взвешенная длиной (0.0 для пустого)."""
        total = sum(len(b.text) for b in self.boxes)
        if total == 0:
            return 0.0
        return sum(b.confidence * len(b.text) for b in self.boxes) / total

    @property
    def is_empty(self) -> bool:
        """True, если текста нет."""
        return not self.text.strip()

    def find(self, query: str) -> list[OCRBox]:
        """
        Коробки, чей текст совпал с ``query`` (без учёта регистра/ё↔е/пробелов).

        Пустой запрос или пустой результат — просто ``[]``.
        """
        needle = normalize_text(query)
        if not needle:
            return []
        return [b for b in self.boxes if normalize_text(b.text) == needle]

    def contains(self, query: str) -> bool:
        """True, если нормализованный запрос встречается в нормализованном тексте."""
        needle = normalize_text(query)
        return bool(needle) and needle in normalize_text(self.text)


def normalize_text(text: str) -> str:
    """Нормализация для поиска: нижний регистр, ё→е, схлопывание пробелов."""
    if not isinstance(text, str):
        raise ValueError("text должен быть str")
    return " ".join(text.lower().replace("ё", "е").split())


# ---------------------------------------------------------------------------
# Разбор TSV-вывода tesseract
# ---------------------------------------------------------------------------
def parse_tsv(tsv: str, *, min_confidence: float = 0.0) -> tuple[OCRBox, ...]:
    """
    Разбирает TSV-вывод tesseract в коробки слов (level == 5).

    Строки с отрицательной уверенностью (не слова) и пустым текстом
    пропускаются; ``min_confidence`` дополнительно отсекает шум.
    """
    if not isinstance(tsv, str):
        raise ValueError("tsv должен быть str")
    if not 0.0 <= float(min_confidence) <= 100.0:
        raise ValueError("min_confidence должен быть в диапазоне 0..100")
    boxes: list[OCRBox] = []
    for i, raw in enumerate(tsv.splitlines()):
        if i == 0 and raw.startswith("level\t"):
            continue  # заголовок
        cols = raw.split("\t")
        if len(cols) < 12:
            continue
        if cols[0].strip() != "5":
            continue
        try:
            conf = float(cols[10])
        except ValueError:
            continue
        if conf < 0 or conf < min_confidence:
            continue
        text = cols[11].strip()
        if not text:
            continue
        try:
            boxes.append(
                OCRBox(
                    text=text,
                    x=int(cols[6]),
                    y=int(cols[7]),
                    width=int(cols[8]),
                    height=int(cols[9]),
                    confidence=min(conf, 100.0),
                )
            )
        except ValueError:
            logger.debug("TSV: некорректная строка пропущена: %r", raw)
            continue
    return tuple(boxes)


# ---------------------------------------------------------------------------
# Контракт движка
# ---------------------------------------------------------------------------
class OCREngine(abc.ABC):
    """Контракт движка распознавания текста."""

    name: str = "engine"

    @abc.abstractmethod
    def is_available(self) -> bool:
        """Движок готов к работе (есть бинарник/сеть/зависимости)."""

    @abc.abstractmethod
    def recognize(self, image: OCRImage, *, lang: str = "rus+eng") -> OCRResult:
        """Распознаёт растр; ошибки — ``OCRError``/``OCRUnavailable``."""

    def describe(self) -> dict[str, Any]:
        """Метадвижка для диагностики."""
        return {"name": self.name, "available": self.is_available()}


# ---------------------------------------------------------------------------
# Локально: tesseract CLI
# ---------------------------------------------------------------------------
class TesseractEngine(OCREngine):
    """
    Локальный OCR через CLI ``tesseract`` (без python-зависимостей).

    Картинка уходит в stdin (PNG), текст/TSV читается из stdout.
    """

    name = "tesseract"

    def __init__(
        self,
        binary: str = "tesseract",
        *,
        psm: int = 3,
        timeout: float = 20.0,
        min_confidence: float = 0.0,
    ) -> None:
        if not isinstance(psm, int) or isinstance(psm, bool) or psm not in _TESSERACT_PSM:
            raise ValueError(f"psm должен быть одним из {sorted(_TESSERACT_PSM)}")
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)):
            raise ValueError("timeout должен быть числом")
        if not 0.1 <= float(timeout) <= 60.0:
            raise ValueError("timeout должен быть в диапазоне 0.1..60 секунд")
        if not 0.0 <= float(min_confidence) <= 100.0:
            raise ValueError("min_confidence должен быть в диапазоне 0..100")
        if not isinstance(binary, str) or not binary.strip():
            raise ValueError("binary должен быть непустой строкой")
        self._binary = binary
        self._psm = psm
        self._timeout = float(timeout)
        self._min_confidence = float(min_confidence)

    def is_available(self) -> bool:
        path = shutil.which(self._binary)
        return path is not None or os.path.isfile(self._binary)

    def recognize(self, image: OCRImage, *, lang: str = "rus+eng") -> OCRResult:
        if not isinstance(image, OCRImage):
            raise OCRError(f"ожидалась OCRImage, получено: {type(image).__name__}")
        if not _LANG_RE.match(lang or ""):
            raise OCRError(f"недопустимый код языка: {lang!r}")
        if not self.is_available():
            raise OCRUnavailable(f"бинарник tesseract не найден: {self._binary}")
        png = image.to_png()
        cmd = [
            self._binary,
            "stdin",
            "stdout",
            "-l",
            lang,
            "--psm",
            str(self._psm),
            "tsv",
        ]
        started = time.monotonic()
        try:
            proc = subprocess.run(
                cmd,
                input=png,
                capture_output=True,
                timeout=self._timeout,
                check=False,
            )
        except FileNotFoundError as exc:
            raise OCRUnavailable(f"бинарник tesseract не найден: {self._binary}") from exc
        except subprocess.TimeoutExpired as exc:
            raise OCRError(f"tesseract не уложился в {self._timeout} с") from exc
        if proc.returncode != 0:
            detail = proc.stderr.decode("utf-8", "replace").strip()[:200]
            raise OCRError(f"tesseract завершился с кодом {proc.returncode}: {detail}")
        tsv = proc.stdout.decode("utf-8", "replace")
        boxes = parse_tsv(tsv, min_confidence=self._min_confidence)
        text = "\n".join(b.text for b in boxes)
        return OCRResult(
            text=text,
            boxes=boxes,
            lang=lang,
            engine=self.name,
            elapsed_ms=(time.monotonic() - started) * 1000.0,
        )

    def describe(self) -> dict[str, Any]:
        info = super().describe()
        info.update({"psm": self._psm, "timeout": self._timeout, "binary": self._binary})
        return info


# ---------------------------------------------------------------------------
# Облако: пользовательский HTTP-endpoint (опционально)
# ---------------------------------------------------------------------------
class HttpOCREngine(OCREngine):
    """
    Облачный OCR через пользовательский HTTP-endpoint (JSON + base64 PNG).

    Запрос:  ``POST {"lang": ..., "image": <base64>}``
    Ответ:   ``{"text": "...", "blocks": [{"text", "confidence", "x", "y",
               "width", "height"}]}`` (blocks опционален).

    ⚠️ Отправляет фрагмент скриншота на внешний сервис — включайте осознанно.
    Ключ берётся из переменной окружения ``api_key_env`` (заголовок
    ``Authorization: Bearer ...``) и никуда не логируется.
    """

    name = "http"

    def __init__(
        self,
        endpoint: str,
        *,
        api_key_env: str = "JARVIS_OCR_API_KEY",
        timeout: float = 15.0,
        opener: Callable[..., Any] | None = None,
    ) -> None:
        if not isinstance(endpoint, str) or not endpoint.startswith(("http://", "https://")):
            raise ValueError("endpoint должен быть http(s)-URL")
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)):
            raise ValueError("timeout должен быть числом")
        if not 0.1 <= float(timeout) <= 120.0:
            raise ValueError("timeout должен быть в диапазоне 0.1..120 секунд")
        if not isinstance(api_key_env, str) or not api_key_env:
            raise ValueError("api_key_env должен быть непустой строкой")
        self._endpoint = endpoint
        self._api_key_env = api_key_env
        self._timeout = float(timeout)
        self._opener = opener or urllib.request.urlopen

    def is_available(self) -> bool:
        # доступность = настроенный endpoint (сеть проверяется в момент запроса)
        return True

    def recognize(self, image: OCRImage, *, lang: str = "rus+eng") -> OCRResult:
        if not isinstance(image, OCRImage):
            raise OCRError(f"ожидалась OCRImage, получено: {type(image).__name__}")
        if not _LANG_RE.match(lang or ""):
            raise OCRError(f"недопустимый код языка: {lang!r}")
        payload = json.dumps(
            {"lang": lang, "image": base64.b64encode(image.to_png()).decode("ascii")}
        ).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        key = os.environ.get(self._api_key_env, "")
        if key:
            headers["Authorization"] = f"Bearer {key}"
        request = urllib.request.Request(self._endpoint, data=payload, headers=headers)
        started = time.monotonic()
        try:
            with self._opener(request, timeout=self._timeout) as resp:
                raw = resp.read(MAX_TEXT_CHARS * 4)
        except (urllib.error.URLError, OSError) as exc:
            raise OCRUnavailable(f"облачный OCR недоступен: {exc}") from exc
        except Exception as exc:  # noqa: BLE001 — кастомные opener в тестах
            raise OCRUnavailable(f"облачный OCR недоступен: {exc}") from exc
        try:
            doc = json.loads(raw.decode("utf-8", "replace"))
        except (ValueError, UnicodeDecodeError) as exc:
            raise OCRError(f"облачный OCR вернул не JSON: {exc}") from exc
        if not isinstance(doc, dict):
            raise OCRError("облачный OCR вернул не объект JSON")
        boxes: list[OCRBox] = []
        for block in doc.get("blocks") or []:
            if not isinstance(block, dict) or not str(block.get("text", "")).strip():
                continue
            try:
                boxes.append(
                    OCRBox(
                        text=str(block["text"]),
                        x=int(block.get("x", 0)),
                        y=int(block.get("y", 0)),
                        width=int(block.get("width", 0)),
                        height=int(block.get("height", 0)),
                        confidence=float(block.get("confidence", 0.0)),
                    )
                )
            except (ValueError, TypeError, KeyError) as exc:
                raise OCRError(f"некорректный блок в ответе OCR: {exc}") from exc
        text = str(doc.get("text", "") or "")
        if not text and boxes:
            text = "\n".join(b.text for b in boxes)
        return OCRResult(
            text=text[:MAX_TEXT_CHARS],
            boxes=tuple(boxes),
            lang=lang,
            engine=self.name,
            elapsed_ms=(time.monotonic() - started) * 1000.0,
        )

    def describe(self) -> dict[str, Any]:
        info = super().describe()
        info.update({"endpoint": self._endpoint, "timeout": self._timeout})
        return info


# ---------------------------------------------------------------------------
# Синтетика: тесты/отладка/аварийный fallback
# ---------------------------------------------------------------------------
class SyntheticOCREngine(OCREngine):
    """
    Детерминированный движок без внешних зависимостей.

    ``provider`` — вызываемый объект ``OCRImage -> OCRResult``; по умолчанию
    возвращается пустой результат (чтобы пайплайн не падал без OCR).
    """

    name = "synthetic"

    def __init__(
        self,
        provider: Callable[[OCRImage], OCRResult] | None = None,
        *,
        available: bool = True,
    ) -> None:
        self._provider = provider
        self._available = available

    def is_available(self) -> bool:
        return self._available

    def recognize(self, image: OCRImage, *, lang: str = "rus+eng") -> OCRResult:
        if not isinstance(image, OCRImage):
            raise OCRError(f"ожидалась OCRImage, получено: {type(image).__name__}")
        started = time.monotonic()
        if self._provider is not None:
            result = self._provider(image)
            if not isinstance(result, OCRResult):
                raise OCRError("provider должен возвращать OCRResult")
            return result
        return OCRResult(text="", boxes=(), lang=lang, engine=self.name,
                         elapsed_ms=(time.monotonic() - started) * 1000.0)


# ---------------------------------------------------------------------------
# Диспетчер: смена движков + fallback
# ---------------------------------------------------------------------------
class OCRRouter:
    """Диспетчер движков OCR: смена + fallback по цепочке."""

    def __init__(
        self,
        engines: dict[str, OCREngine] | None = None,
        primary: str = "tesseract",
        fallback_chain: Sequence[str] | None = None,
    ) -> None:
        self._engines = dict(engines or {})
        self._primary = primary
        self._fallback_chain = list(fallback_chain) if fallback_chain else [primary]

    @property
    def primary(self) -> str:
        return self._primary

    def set_primary(self, name: str) -> None:
        if name not in self._engines:
            raise OCRError(f"Неизвестный движок OCR: {name}")
        self._primary = name
        self._fallback_chain = [name] + [e for e in self._fallback_chain if e != name]
        logger.info("Движок OCR переключён на '%s'", name)

    def available(self) -> list[str]:
        return [n for n, e in self._engines.items() if e.is_available()]

    def _chain(self, explicit: str | None) -> list[str]:
        if explicit:
            return [explicit]
        order = self._fallback_chain or list(self._engines.keys())
        chain = [self._primary] + [n for n in order if n != self._primary]
        chain += [n for n in self._engines if n not in chain]
        return chain

    def recognize(
        self,
        image: OCRImage,
        *,
        lang: str = "rus+eng",
        engine: str | None = None,
    ) -> OCRResult:
        """Распознаёт растр, обходя цепочку fallback при отказах движков."""
        last_err: Exception | None = None
        for name in self._chain(engine):
            eng = self._engines.get(name)
            if eng is None or not eng.is_available():
                last_err = OCRUnavailable(f"{name}: недоступен")
                continue
            try:
                return eng.recognize(image, lang=lang)
            except OCRError as exc:
                last_err = exc
                logger.warning("OCR-движок '%s' не справился: %s", name, exc)
                continue
        raise OCRError(f"Ни один движок OCR не справился. Последняя ошибка: {last_err}")

    def describe(self) -> dict[str, Any]:
        return {
            "primary": self._primary,
            "available": self.available(),
            "engines": {n: e.describe() for n, e in self._engines.items()},
        }


# ---------------------------------------------------------------------------
# Высокоуровневый сервис
# ---------------------------------------------------------------------------
class ScreenOCR:
    """
    Готовый OCR-конвейер: предобработка → ``OCRRouter`` → поиск текста.

    ``preprocess`` — цепочка преобразований растра: ``"gray"``, ``"binary"``,
    ``"invert"``, ``"scale:2.0"`` (применяются по порядку).
    """

    def __init__(
        self,
        router: OCRRouter,
        *,
        lang: str = "rus+eng",
        preprocess: Sequence[str] = ("gray",),
    ) -> None:
        if not isinstance(router, OCRRouter):
            raise TypeError("router должен быть OCRRouter")
        if not isinstance(preprocess, collections.abc.Sequence) or isinstance(
            preprocess, (str, bytes)
        ):
            raise ValueError("preprocess должен быть последовательностью строк")
        for step in preprocess:
            self._validate_step(step)
        self._router = router
        self._lang = lang
        self._preprocess = tuple(preprocess)

    @staticmethod
    def _validate_step(step: str) -> None:
        if not isinstance(step, str):
            raise ValueError("шаг предобработки должен быть строкой")
        if step in ("gray", "binary", "invert"):
            return
        if step.startswith("scale:"):
            try:
                factor = float(step.split(":", 1)[1])
            except ValueError as exc:
                raise ValueError(f"некорректный шаг масштаба: {step!r}") from exc
            if not 0.1 <= factor <= 4.0:
                raise ValueError(f"масштаб вне 0.1..4.0: {step!r}")
            return
        raise ValueError(f"неизвестный шаг предобработки: {step!r}")

    def prepare(self, image: OCRImage) -> OCRImage:
        """Применяет настроенную цепочку предобработки к растру."""
        if not isinstance(image, OCRImage):
            raise OCRError(f"ожидалась OCRImage, получено: {type(image).__name__}")
        current = image
        for step in self._preprocess:
            if step == "gray":
                current = current.to_gray()
            elif step == "binary":
                current = current.binarize()
            elif step == "invert":
                current = current.invert()
            elif step.startswith("scale:"):
                current = current.scale(float(step.split(":", 1)[1]))
        return current

    def recognize(self, image: OCRImage, *, lang: str | None = None) -> OCRResult:
        """Полный конвейер: предобработка + распознавание через роутер."""
        return self._router.recognize(self.prepare(image), lang=lang or self._lang)

    def read_text(self, image: OCRImage, *, lang: str | None = None) -> str:
        """Только текст (без геометрии) — удобно для команд/сценариев."""
        return self.recognize(image, lang=lang).text

    def find_text(
        self, image: OCRImage, query: str, *, lang: str | None = None
    ) -> list[OCRBox]:
        """Коробки слов, совпавших с ``query`` (нормализованный поиск)."""
        return self.recognize(image, lang=lang).find(query)

    def describe(self) -> dict[str, Any]:
        return {
            "lang": self._lang,
            "preprocess": list(self._preprocess),
            "router": self._router.describe(),
        }


# ---------------------------------------------------------------------------
# Сборка по умолчанию (локально-first)
# ---------------------------------------------------------------------------
def default_ocr_router(*, cloud_endpoint: str | None = None) -> OCRRouter:
    """
    Стандартная сборка: tesseract (локально) → опционально облако → синтетика.

    ``cloud_endpoint`` включает облачный fallback (см. приватность в описании
    модуля); без него цепочка полностью локальная.
    """
    engines: dict[str, OCREngine] = {"tesseract": TesseractEngine()}
    chain = ["tesseract"]
    if cloud_endpoint:
        engines["http"] = HttpOCREngine(cloud_endpoint)
        chain.append("http")
    engines["synthetic"] = SyntheticOCREngine()
    chain.append("synthetic")
    return OCRRouter(engines, primary="tesseract", fallback_chain=chain)
