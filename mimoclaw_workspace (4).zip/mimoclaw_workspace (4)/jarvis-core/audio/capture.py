"""
Захват аудио (микрофон) JARVIS CORE.

Контракт ``AudioSource`` + готовые источники:
  * ``MicrophoneSource`` — реальный микрофон через sounddevice
    (16 кГц, моно, s16le, кадры по 20 мс — как в ТЗ);
  * ``WavFileSource``    — чтение WAV/PCM из файла или памяти
    (отладка, тесты, локальное воспроизведение сценариев).

``AudioCapture`` — высокоуровневая обёртка: кадры, запись фиксированного
куска (``record``), запись до условия (``record_until`` — например, до тишины
по VAD), кольцевой буфер последних секунд звука (``recent``) и асинхронный
поток кадров для пайплайна STT.

Всё локально: захват с микрофона в облако не выгружается.
"""

from __future__ import annotations

import abc
import asyncio
import io
import logging
import time
import wave
from collections import deque
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Callable

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class CaptureError(Exception):
    """Ошибка захвата аудио."""


class CaptureUnavailable(CaptureError):
    """Источник недоступен (нет устройства/библиотеки/файла)."""


class CaptureEOF(CaptureError):
    """Источник исчерпан (конец файла при ``loop=False``)."""


# ---------------------------------------------------------------------------
# Конфигурация и кадр
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class CaptureConfig:
    """Параметры захвата. Дефолты — требования ТЗ (16 кГц, моно, 20 мс)."""

    sample_rate: int = 16000
    channels: int = 1
    frame_ms: int = 20
    sample_width: int = 2  # байт на сэмпл (s16le)

    @property
    def frame_samples(self) -> int:
        """Число сэмплов на кадр (20 мс @ 16 кГц = 320)."""
        return self.sample_rate * self.frame_ms // 1000

    @property
    def frame_bytes(self) -> int:
        """Размер кадра в байтах (320 сэмплов × 2 байта = 640)."""
        return self.frame_samples * self.channels * self.sample_width

    def seconds_to_bytes(self, seconds: float) -> int:
        """Сколько байт PCM в ``seconds`` секундах."""
        return int(seconds * self.sample_rate) * self.channels * self.sample_width

    def bytes_to_seconds(self, nbytes: int) -> int | float:
        """Сколько секунд аудио содержится в ``nbytes`` байтах PCM."""
        denom = self.sample_rate * self.channels * self.sample_width
        return nbytes / denom if denom else 0.0


@dataclass
class AudioFrame:
    """Один кадр PCM-аудио (s16le)."""

    pcm: bytes
    sample_rate: int = 16000
    index: int = 0
    timestamp: float = field(default_factory=time.time)

    @property
    def duration(self) -> float:
        """Длительность кадра в секундах."""
        return len(self.pcm) / (2 * self.sample_rate) if self.sample_rate else 0.0


# ---------------------------------------------------------------------------
# Источники аудио
# ---------------------------------------------------------------------------
class AudioSource(abc.ABC):
    """Контракт источника кадров PCM."""

    name: str = "base"
    #: ``True`` — чтение блокирующее (микрофон), ``False`` — мгновенное (файл/тесты).
    blocking: bool = True

    def __init__(self, config: CaptureConfig | None = None) -> None:
        self.config = config or CaptureConfig()

    @abc.abstractmethod
    def is_available(self) -> bool: ...

    @abc.abstractmethod
    def open(self) -> None: ...

    @abc.abstractmethod
    def close(self) -> None: ...

    @abc.abstractmethod
    def read_frame(self) -> AudioFrame:
        """Прочитать ровно один кадр (``config.frame_bytes`` байт)."""

    def describe(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "available": self.is_available(),
            "sample_rate": self.config.sample_rate,
            "frame_ms": self.config.frame_ms,
        }


class MicrophoneSource(AudioSource):
    """Микрофон через sounddevice (16 кГц, моно, блоки по 20 мс)."""

    name = "microphone"
    blocking = True

    def __init__(
        self,
        config: CaptureConfig | None = None,
        device: int | str | None = None,
    ) -> None:
        super().__init__(config)
        self.device = device
        self._stream: Any = None

    def is_available(self) -> bool:
        try:
            import sounddevice  # noqa: F401

            return True
        except Exception:  # noqa: BLE001 — sounddevice падает и без аудио-сервера
            return False

    def open(self) -> None:
        if self._stream is not None:
            return
        if not self.is_available():
            raise CaptureUnavailable("sounddevice недоступен (не установлен или нет аудио-сервера)")
        try:
            import sounddevice as sd

            self._stream = sd.RawInputStream(
                samplerate=self.config.sample_rate,
                channels=self.config.channels,
                dtype="int16",
                blocksize=self.config.frame_samples,
                device=self.device,
            )
            self._stream.start()
        except Exception as exc:  # noqa: BLE001
            self._stream = None
            raise CaptureUnavailable(f"Не удалось открыть микрофон: {exc}") from exc
        logger.info("Микрофон открыт: %s", self.describe())

    def close(self) -> None:
        if self._stream is None:
            return
        try:
            self._stream.stop()
            self._stream.close()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Ошибка при закрытии микрофона: %s", exc)
        finally:
            self._stream = None

    def read_frame(self) -> AudioFrame:
        if self._stream is None:
            self.open()
        try:
            data, overflowed = self._stream.read(self.config.frame_samples)
        except Exception as exc:  # noqa: BLE001
            raise CaptureError(f"Ошибка чтения с микрофона: {exc}") from exc
        if overflowed:
            logger.warning("Переполнение аудио-буфера (кадр потерян)")
        pcm = bytes(data)
        if len(pcm) < self.config.frame_bytes:
            pcm = pcm.ljust(self.config.frame_bytes, b"\x00")  # добиваем тишиной
        return AudioFrame(pcm=pcm, sample_rate=self.config.sample_rate)


class WavFileSource(AudioSource):
    """Чтение кадров из WAV-файла или PCM-байтов (отладка/тесты).

    ``data`` принимает как «голый» PCM s16le, так и WAV-контейнер (auto-detect
    по сигнатуре ``RIFF``). Геометрия WAV сверяется с ``config``.
    """

    name = "wav_file"
    blocking = False

    def __init__(
        self,
        path: str | None = None,
        data: bytes | None = None,
        config: CaptureConfig | None = None,
        loop: bool = False,
    ) -> None:
        super().__init__(config)
        if (path is None) == (data is None):
            raise CaptureError("WavFileSource: нужен ровно один из параметров path или data")
        self.path = path
        self._data = data
        self.loop = loop
        self._pcm: bytes = b""
        self._pos = 0
        self._index = 0

    def is_available(self) -> bool:
        return self.path is not None or self._data is not None

    @classmethod
    def from_bytes(cls, pcm: bytes, config: CaptureConfig | None = None, **kw: Any) -> WavFileSource:
        """Источник из «голого» PCM s16le (без WAV-заголовка)."""
        return cls(data=pcm, config=config, **kw)

    def _load_wav(self, wav: Any) -> bytes:
        """Прочитать PCM из открытого ``wave.Wave_read`` с проверкой геометрии."""
        if wav.getnchannels() != self.config.channels or wav.getsampwidth() != self.config.sample_width:
            raise CaptureError(
                f"WAV не совпадает с конфигом: каналы={wav.getnchannels()}, "
                f"сэмпл={wav.getsampwidth()} байт"
            )
        return wav.readframes(wav.getnframes())

    def open(self) -> None:
        if self._pcm:
            return
        if self._data is not None:
            if self._data[:4] == b"RIFF":  # WAV-контейнер в памяти
                try:
                    with wave.open(io.BytesIO(self._data), "rb") as wav:
                        self._pcm = self._load_wav(wav)
                except CaptureError:
                    raise
                except Exception as exc:  # noqa: BLE001
                    raise CaptureError(f"Некорректный WAV в памяти: {exc}") from exc
            else:  # «голый» PCM s16le
                self._pcm = self._data
            return
        try:
            with wave.open(self.path, "rb") as wav:
                self._pcm = self._load_wav(wav)
        except CaptureError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise CaptureUnavailable(f"Не удалось открыть WAV '{self.path}': {exc}") from exc
        logger.debug("WAV открыт: %s байт PCM", len(self._pcm))

    def close(self) -> None:
        self._pcm = b""
        self._pos = 0

    def read_frame(self) -> AudioFrame:
        if not self._pcm:
            self.open()
        size = self.config.frame_bytes
        if self._pos + size > len(self._pcm):
            if not self.loop:
                raise CaptureEOF(f"Источник '{self.name}' исчерпан")
            self._pos = 0
        pcm = self._pcm[self._pos : self._pos + size]
        self._pos += size
        frame = AudioFrame(pcm=pcm, sample_rate=self.config.sample_rate, index=self._index)
        self._index += 1
        return frame


# ---------------------------------------------------------------------------
# Кольцевой буфер
# ---------------------------------------------------------------------------
class RingBuffer:
    """Кольцевой буфер PCM: хранит последние ``capacity_bytes`` байт."""

    def __init__(self, capacity_bytes: int) -> None:
        if capacity_bytes <= 0:
            raise CaptureError("RingBuffer: ёмкость должна быть > 0")
        self.capacity = capacity_bytes
        self._chunks: deque[bytes] = deque()
        self._size = 0

    def write(self, data: bytes) -> None:
        """Добавить данные, вытесняя самые старые при переполнении."""
        if not data:
            return
        self._chunks.append(data)
        self._size += len(data)
        while self._size > self.capacity and self._chunks:
            self._size -= len(self._chunks.popleft())

    def tail(self, seconds: float, config: CaptureConfig) -> bytes:
        """Последние ``seconds`` секунд аудио целиком (конкатенация кадров)."""
        want = min(config.seconds_to_bytes(seconds), self._size)
        out: list[bytes] = []
        got = 0
        for chunk in reversed(self._chunks):
            if got >= want:
                break
            out.append(chunk)
            got += len(chunk)
        return b"".join(reversed(out))[-want:] if want else b""

    def clear(self) -> None:
        self._chunks.clear()
        self._size = 0

    def __len__(self) -> int:
        return self._size


# ---------------------------------------------------------------------------
# Высокоуровневый захват
# ---------------------------------------------------------------------------
class AudioCapture:
    """
    Обёртка над ``AudioSource``: кадры + запись + кольцевой буфер + async-поток.

    Использование:
        cap = AudioCapture(MicrophoneSource())
        with cap:
            pcm = cap.record(1.0)                 # 1 секунда звука
            pcm = cap.record_until(is_silence, timeout=5.0)
            async for frame in cap.stream():      # поток кадров для STT
                ...
    """

    def __init__(
        self,
        source: AudioSource,
        ring_seconds: float = 5.0,
    ) -> None:
        self.source = source
        self.config = source.config
        self._ring = RingBuffer(self.config.seconds_to_bytes(ring_seconds))
        self._frames_read = 0

    # -- контекст ----------------------------------------------------------
    def open(self) -> None:
        self.source.open()

    def close(self) -> None:
        self.source.close()

    def __enter__(self) -> AudioCapture:
        self.open()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    # -- чтение ------------------------------------------------------------
    def read_frame(self) -> AudioFrame:
        """Прочитать кадр (и положить его в кольцевой буфер)."""
        frame = self.source.read_frame()
        self._ring.write(frame.pcm)
        self._frames_read += 1
        return frame

    def record(self, seconds: float) -> bytes:
        """Записать ровно ``seconds`` секунд PCM (s16le)."""
        if seconds <= 0:
            raise CaptureError("record: длительность должна быть > 0")
        need = self.config.seconds_to_bytes(seconds)
        buf = bytearray()
        while len(buf) < need:
            buf += self.read_frame().pcm
        return bytes(buf[:need])

    def record_until(
        self,
        stop: Callable[[AudioFrame], bool],
        *,
        timeout: float = 10.0,
        max_seconds: float = 30.0,
    ) -> bytes:
        """
        Собирать кадры, пока ``stop(frame)`` не вернёт ``True``
        (например, VAD увидел конец фразы). Возвращает весь собранный PCM.

        ``timeout`` — ждать первое срабатывание не дольше N секунд,
        ``max_seconds`` — общий предел записи (защита от «вечной» речи).
        """
        if timeout <= 0 or max_seconds <= 0:
            raise CaptureError("record_until: timeout и max_seconds должны быть > 0")
        started = time.monotonic()
        buf = bytearray()
        while True:
            frame = self.read_frame()
            buf += frame.pcm
            if stop(frame):
                return bytes(buf)
            waited = time.monotonic() - started
            if waited > timeout:
                raise CaptureError(f"record_until: таймаут {timeout} c — условие не выполнено")
            if self.config.bytes_to_seconds(len(buf)) >= max_seconds:
                raise CaptureError(f"record_until: превышен лимит записи {max_seconds} c")

    def recent(self, seconds: float) -> bytes:
        """Последние ``seconds`` секунд из кольцевого буфера (без чтения)."""
        return self._ring.tail(seconds, self.config)

    # -- асинхронный поток --------------------------------------------------
    async def stream(self, max_frames: int | None = None) -> AsyncIterator[AudioFrame]:
        """
        Асинхронный поток кадров (для пайплайна STT).

        Блокирующее чтение (микрофон) выносится в отдельный поток,
        чтобы не мешать event loop.
        """
        count = 0
        while max_frames is None or count < max_frames:
            if self.source.blocking:
                frame = await asyncio.to_thread(self.read_frame)
            else:
                frame = self.read_frame()
            count += 1
            yield frame

    # -- утилиты ------------------------------------------------------------
    @property
    def frames_read(self) -> int:
        """Сколько кадров прочитано за сессию."""
        return self._frames_read

    def describe(self) -> dict[str, Any]:
        info = self.source.describe()
        info["frames_read"] = self._frames_read
        info["ring_bytes"] = len(self._ring)
        return info


# ---------------------------------------------------------------------------
# Помощники (без внешних зависимостей)
# ---------------------------------------------------------------------------
def pcm_to_wav(pcm: bytes, config: CaptureConfig | None = None) -> bytes:
    """Обернуть PCM s16le в WAV-контейнер (для STT-API и отладки)."""
    cfg = config or CaptureConfig()
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wav:
        wav.setnchannels(cfg.channels)
        wav.setsampwidth(cfg.sample_width)
        wav.setframerate(cfg.sample_rate)
        wav.writeframes(pcm)
    return buf.getvalue()


def wav_to_pcm(data: bytes) -> tuple[bytes, CaptureConfig]:
    """Разобрать WAV-байты → (PCM, CaptureConfig)."""
    try:
        with wave.open(io.BytesIO(data), "rb") as wav:
            cfg = CaptureConfig(
                sample_rate=wav.getframerate(),
                channels=wav.getnchannels(),
                frame_ms=20,
                sample_width=wav.getsampwidth(),
            )
            return wav.readframes(wav.getnframes()), cfg
    except Exception as exc:  # noqa: BLE001
        raise CaptureError(f"Некорректный WAV: {exc}") from exc


def wav_header_size() -> int:
    """Размер WAV-заголовка, который пишет ``pcm_to_wav`` (обычно 44 байта)."""
    return len(pcm_to_wav(b""))
