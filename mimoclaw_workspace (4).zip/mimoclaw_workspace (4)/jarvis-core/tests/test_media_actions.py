"""
Проверка actions/media_actions.py — команды мультимедиа.

Запуск:  python3 tests/test_media_actions.py
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from actions.media_actions import (
    DryRunMediaBackend,
    MediaActions,
    MediaInfo,
    MediaUnavailable,
    MediaUnsupported,
    PlaybackStatus,
    SubprocessMediaBackend,
    _normalize_status,
    _parse_now_playing,
    register_media_actions,
)
from actions.registry import CommandRegistry, RiskLevel


# ---------------------------------------------------------------------------
# Хелперы
# ---------------------------------------------------------------------------
def _raises(exc_type, fn, *args, **kwargs) -> str:
    """Проверяет, что fn бросает exc_type; возвращает текст ошибки."""
    try:
        fn(*args, **kwargs)
    except exc_type as e:
        return str(e)
    raise AssertionError(f"ожидался {exc_type.__name__}, но ошибки не было")


# ---------------------------------------------------------------------------
# Тесты: статусы и метаданные
# ---------------------------------------------------------------------------
def test_normalize_status() -> None:
    assert _normalize_status("Playing") == PlaybackStatus.PLAYING
    assert _normalize_status("paused") == PlaybackStatus.PAUSED
    assert _normalize_status("stop") == PlaybackStatus.STOPPED
    assert _normalize_status("") == PlaybackStatus.UNKNOWN
    assert _normalize_status(None) == PlaybackStatus.UNKNOWN
    assert _normalize_status("garbage") == PlaybackStatus.UNKNOWN


def test_parse_now_playing() -> None:
    info = _parse_now_playing("playing|Daft Punk|Get Lucky")
    assert info is not None
    assert info.status == PlaybackStatus.PLAYING
    assert info.artist == "Daft Punk"
    assert info.title == "Get Lucky"

    # неполные поля не ломают разбор
    partial = _parse_now_playing("paused|Solo")
    assert partial is not None
    assert partial.artist == "Solo"
    assert partial.title == ""

    assert _parse_now_playing("   ") is None
    assert _parse_now_playing("") is None


def test_media_info_describe() -> None:
    info = MediaInfo(status=PlaybackStatus.PLAYING, artist="Muse", title="Starlight")
    assert "играет" in info.describe()
    assert "Muse" in info.describe()
    assert "Starlight" in info.describe()

    empty = MediaInfo(status=PlaybackStatus.STOPPED)
    assert "нет данных" in empty.describe()


# ---------------------------------------------------------------------------
# Тесты: DryRunMediaBackend + MediaActions
# ---------------------------------------------------------------------------
def test_dry_run_control_flow() -> None:
    backend = DryRunMediaBackend()
    svc = MediaActions(backend=backend)

    assert "возобновлено" in svc.play().lower()
    assert backend.calls[-1] == ("play", ())
    assert backend.status == PlaybackStatus.PLAYING

    assert "пауза" in svc.pause().lower()
    assert backend.status == PlaybackStatus.PAUSED

    assert "остановлено" in svc.stop().lower()
    assert backend.status == PlaybackStatus.STOPPED

    assert "следующий" in svc.next().lower()
    assert backend.calls[-1] == ("next_track", ())

    assert "предыдущий" in svc.previous().lower()
    assert backend.calls[-1] == ("previous_track", ())


def test_dry_run_now_playing() -> None:
    backend = DryRunMediaBackend()
    svc = MediaActions(backend=backend)
    backend.info = MediaInfo(status=PlaybackStatus.PLAYING, artist="Muse", title="Starlight")
    assert "Muse" in svc.now_playing()

    backend.info = None
    assert "ничего не воспроизводится" in svc.now_playing().lower()


def test_unavailable_backend() -> None:
    svc = MediaActions(backend=DryRunMediaBackend(available=False))
    _raises(MediaUnavailable, svc.play)
    _raises(MediaUnavailable, svc.pause)
    _raises(MediaUnavailable, svc.stop)
    _raises(MediaUnavailable, svc.next)
    _raises(MediaUnavailable, svc.previous)
    _raises(MediaUnavailable, svc.now_playing)


# ---------------------------------------------------------------------------
# Тесты: SubprocessMediaBackend (подменённый runner)
# ---------------------------------------------------------------------------
class RecordingRunner:
    """Фейковый runner: запоминает argv и возвращает заданный stdout."""

    def __init__(self, output: str = "") -> None:
        self.output = output
        self.calls: list[list[str]] = []

    def __call__(self, argv: list[str]) -> str:
        self.calls.append(list(argv))
        return self.output


def test_subprocess_linux_commands() -> None:
    runner = RecordingRunner(output="playing|Daft Punk|Get Lucky\n")
    backend = SubprocessMediaBackend(runner=runner, platform_name="Linux")

    assert backend.is_available()
    backend.play()
    backend.pause()
    backend.stop()
    backend.next_track()
    backend.previous_track()

    assert runner.calls[0] == ["playerctl", "play"]
    assert runner.calls[1] == ["playerctl", "pause"]
    assert runner.calls[2] == ["playerctl", "stop"]
    assert runner.calls[3] == ["playerctl", "next"]
    assert runner.calls[4] == ["playerctl", "previous"]

    info = backend.now_playing()
    assert info is not None
    assert info.status == PlaybackStatus.PLAYING
    assert runner.calls[5][0] == "playerctl"
    assert runner.calls[5][1] == "metadata"


def test_subprocess_darwin_commands() -> None:
    mac = RecordingRunner(output="playing|Radiohead|Creep")
    backend = SubprocessMediaBackend(runner=mac, platform_name="Darwin")
    backend.play()
    backend.pause()
    backend.stop()
    backend.next_track()
    backend.previous_track()

    assert mac.calls[0] == ["osascript", "-e", 'tell application "Music" to play']
    assert mac.calls[1] == ["osascript", "-e", 'tell application "Music" to pause']
    assert mac.calls[2] == ["osascript", "-e", 'tell application "Music" to stop']
    assert mac.calls[3] == ["osascript", "-e", 'tell application "Music" to next track']
    assert mac.calls[4] == ["osascript", "-e", 'tell application "Music" to previous track']

    info = backend.now_playing()
    assert info is not None
    assert info.artist == "Radiohead"


def test_subprocess_windows_commands() -> None:
    win = RecordingRunner()
    backend = SubprocessMediaBackend(runner=win, platform_name="Windows")
    backend.play()
    backend.next_track()
    backend.previous_track()
    backend.stop()

    # все команды — powershell с keybd_event
    for argv in win.calls:
        assert argv[0] == "powershell"
        assert "keybd_event" in argv[3]
    # play_pause = 0xB3 (179), next = 0xB0 (176), previous = 0xB1 (177), stop = 0xB2 (178)
    assert "179" in win.calls[0][3]
    assert "176" in win.calls[1][3]
    assert "177" in win.calls[2][3]
    assert "178" in win.calls[3][3]

    # now_playing на Windows не поддерживается
    _raises(MediaUnsupported, backend.now_playing)

    unknown = SubprocessMediaBackend(runner=RecordingRunner(), platform_name="Plan9")
    assert not unknown.is_available()
    _raises(MediaUnavailable, MediaActions(backend=unknown).play)


# ---------------------------------------------------------------------------
# Тесты: регистрация команд
# ---------------------------------------------------------------------------
def test_register_media_actions() -> None:
    reg = CommandRegistry()
    names = register_media_actions(reg, MediaActions(backend=DryRunMediaBackend()))

    expected = {
        "media_play",
        "media_pause",
        "media_stop",
        "media_next",
        "media_previous",
        "now_playing",
    }
    assert set(names) == expected
    assert set(reg.names()) == expected

    for name in expected:
        assert reg.get(name).risk == RiskLevel.SAFE
        assert not reg.get(name).requires_confirmation

    tool = reg.get("now_playing").to_tool()
    assert tool.name == "now_playing"
    assert tool.risk_level == RiskLevel.SAFE


def test_commands_run_through_registry() -> None:
    backend = DryRunMediaBackend()
    reg = CommandRegistry()
    register_media_actions(reg, MediaActions(backend=backend))

    async def _run() -> None:
        await reg.get("media_play").run()
        assert backend.status == PlaybackStatus.PLAYING
        await reg.get("media_next").run()
        result = await reg.get("now_playing").run()
        assert isinstance(result, str)

    asyncio.run(_run())
    assert ("play", ()) in backend.calls
    assert ("next_track", ()) in backend.calls
    assert ("now_playing", ()) in backend.calls


# ---------------------------------------------------------------------------
# Запуск
# ---------------------------------------------------------------------------
def main() -> int:
    print("JARVIS CORE — проверка actions/media_actions")
    try:
        test_normalize_status()
        test_parse_now_playing()
        test_media_info_describe()
        test_dry_run_control_flow()
        test_dry_run_now_playing()
        test_unavailable_backend()
        test_subprocess_linux_commands()
        test_subprocess_darwin_commands()
        test_subprocess_windows_commands()
        test_register_media_actions()
        test_commands_run_through_registry()
    except AssertionError as e:
        import traceback

        print(f"\n✗ FAIL: {e}")
        traceback.print_exc()
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модулей прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
