"""
Профиль пользователя JARVIS CORE (ТЗ-5, «вечная память»).

Извлекает из речи/записей памяти устойчивые сведения о пользователе
(имя, город, работа, предпочтения) и поддерживает их в актуальном
состоянии — «досье», которое потом подаётся в контекст LLM, чтобы
ассистент помнил, с кем разговаривает. Работает по принципу
**локально-first**:

- ``HeuristicProfileExtractor`` — локальная эвристическая экстракция на чистом
  Python (регулярные выражения), без зависимостей и без сети — работает
  всегда, это гарантированный fallback;
- ``LLMProfileExtractor`` — «умная» экстракция через любой LLM-клиент
  (``ai.llm_router.LLMRouter`` или совместимый): локальная модель (Ollama)
  или облако, по выбору роутера; ответ — JSON «ключ: значение»;
- ``ProfileExtractorRouter`` — смена движков (локально ↔ облако) и
  fallback-цепочка: если «умный» движок упал, молча переходим к эвристике;
- ``ProfileStore`` + ``InMemoryProfileStore`` / ``JsonProfileStore`` —
  персистентное хранение профиля (в памяти или атомарный JSON-файл);
- ``ProfileBuilder`` — фасад: учиться из текста/записей памяти, объединять
  факты (одиночные ключи заменяются, предпочтения копятся), отдавать
  компактный текст профиля для промпта и сохранять профиль на диск.

Ошибки экстракции (``ProfileError`` / ``ProfileUnavailable``) никогда не
роняют конвейер: роутер при исчерпании цепочки деградирует до эвристики,
а не падает. Приватность: в режиме ``INCOGNITO`` профиль не персистится
на диск (живёт только в текущей сессии).

Использование:
    from memory.profile import ProfileBuilder, default_profile_extractor_router

    builder = ProfileBuilder(
        extractor=default_profile_extractor_router(llm=router),
        store=JsonProfileStore("data/profile.json"),
    )
    await builder.learn_from_text("Меня зовут Иван, я живу в Москве и люблю чай.")
    builder.get("name")            # -> ProfileEntry(key="name", value="Иван", ...)
    print(builder.to_prompt_text())
"""

from __future__ import annotations

import abc
import json
import logging
import os
import re
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Sequence

from memory.store import MemoryKind, MemoryRecord, PrivacyMode

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Константы и валидация
# ---------------------------------------------------------------------------
MAX_INPUT_LEN = 50_000       # максимум символов во входном тексте
MAX_VALUE_LEN = 200          # максимум символов в значении факта
MAX_KEY_LEN = 40             # максимум символов в ключе факта
MAX_ENTRIES = 100            # потолок числа фактов в профиле
MAX_MULTI_VALUES = 10        # сколько значений копится у «множественных» ключей
MAX_LLM_ANSWER_LEN = 8_000   # лимит разбираемого ответа LLM

# Управляющие символы (антиинъекция в промпт/логи)
_CTRL_RE = re.compile(r"[\x00-\x1f\x7f]")

# Ключ факта: строчные буквы/цифры/подчёркивание/дефис (латиница/кириллица)
_KEY_RE = re.compile(r"^[0-9a-zа-яё_\-]{1,%d}$" % MAX_KEY_LEN)

# Одиночные ключи: новое значение заменяет старое (последний факт важнее)
SINGLE_KEYS = frozenset({"name", "city", "job", "timezone", "language"})

# Множественные ключи: значения копятся через "; " (список предпочтений)
MULTI_KEYS = frozenset({"likes", "dislikes", "hobbies"})

# Все известные ключи (остальное — «custom» с валидацией формы)
KNOWN_KEYS = SINGLE_KEYS | MULTI_KEYS


def _now() -> float:
    """Текущее время в секундах (Unix time)."""
    return time.time()


def _normalize(text: str) -> str:
    """Нормализация для сравнения: регистр + ё→е (как в ``memory/store.py``)."""
    return text.lower().replace("ё", "е")


def _clean_input(text: str) -> str:
    """Валидация входного текста: str, непустой, в пределах длины, без мусора."""
    if not isinstance(text, str):
        raise ValueError("text: ожидается str")
    cleaned = text.strip()
    if not cleaned:
        raise ValueError("text: пустое значение")
    if len(cleaned) > MAX_INPUT_LEN:
        raise ValueError(f"text: превышена длина {MAX_INPUT_LEN}")
    if _CTRL_RE.search(cleaned):
        raise ValueError("text: недопустимые управляющие символы")
    return cleaned


def _clean_key(key: Any) -> str:
    """Валидация ключа факта: строгая форма, без управляющих символов."""
    if not isinstance(key, str):
        raise ValueError("key: ожидается str")
    cleaned = key.strip().lower().replace("ё", "е")
    if not cleaned or not _KEY_RE.match(cleaned):
        raise ValueError(f"key: некорректный ключ {key!r}")
    return cleaned


def _clean_value(value: Any) -> str:
    """Валидация значения факта: непустое, без управляющих символов, ≤ MAX_VALUE_LEN."""
    if not isinstance(value, str):
        raise ValueError("value: ожидается str")
    if _CTRL_RE.search(value):
        raise ValueError("value: недопустимые управляющие символы")
    cleaned = re.sub(r"\s+", " ", value).strip()
    if not cleaned:
        raise ValueError("value: пустое значение")
    if len(cleaned) > MAX_VALUE_LEN:
        raise ValueError(f"value: превышена длина {MAX_VALUE_LEN}")
    return cleaned


def _clean_confidence(value: Any) -> float:
    """Уверенность в факте — число в диапазоне [0, 1]."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("confidence: ожидается число")
    conf = float(value)
    if not 0.0 <= conf <= 1.0:
        raise ValueError("confidence: вне диапазона [0, 1]")
    return conf


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class ProfileError(Exception):
    """Базовая ошибки профиля пользователя."""


class ProfileUnavailable(ProfileError):
    """Движок экстракции недоступен или упал — нужен fallback."""


# ---------------------------------------------------------------------------
# Сущность факта
# ---------------------------------------------------------------------------
@dataclass
class ProfileEntry:
    """Один устойчивый факт о пользователе (ключ + значение + доверие)."""

    key: str
    value: str
    confidence: float = 0.5
    source: str = "heuristic"
    updated_at: float = field(default_factory=_now)

    def __post_init__(self) -> None:
        self.key = _clean_key(self.key)
        self.value = _clean_value(self.value)
        self.confidence = _clean_confidence(self.confidence)
        if not isinstance(self.source, str) or not self.source.strip():
            raise ValueError("source: некорректное имя источника")
        if _CTRL_RE.search(self.source):
            raise ValueError("source: недопустимые управляющие символы")
        self.source = self.source.strip()[:MAX_KEY_LEN]
        if self.updated_at < 0:
            raise ValueError("updated_at: не может быть отрицательным")

    def to_dict(self) -> dict[str, Any]:
        """Сериализация в JSON-безопасный словарь."""
        return {
            "key": self.key,
            "value": self.value,
            "confidence": round(self.confidence, 3),
            "source": self.source,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ProfileEntry":
        """Десериализация из словаря (с валидацией через ``__post_init__``)."""
        if not isinstance(data, dict):
            raise ValueError("ProfileEntry: ожидается dict")
        return cls(
            key=data.get("key", ""),
            value=data.get("value", ""),
            confidence=data.get("confidence", 0.5),
            source=data.get("source", "unknown"),
            updated_at=float(data.get("updated_at", _now())),
        )


# ---------------------------------------------------------------------------
# Профиль (сборник фактов)
# ---------------------------------------------------------------------------
class UserProfile:
    """
    Профиль пользователя: словарь фактов с политикой слияния.

    Политика слияния по ключу:
    - одиночные ключи (``SINGLE_KEYS``: имя/город/работа…) — новое значение
      заменяет старое, если доверие не меньше (последний факт важнее);
    - множественные ключи (``MULTI_KEYS``: люблю/не люблю/хобби) — значения
      копятся через ``"; "`` (с дедупликацией по нормализованной форме),
      максимум ``MAX_MULTI_VALUES`` значений;
    - неизвестные ключи — как одиночные.
    """

    def __init__(self, entries: Iterable[ProfileEntry] | None = None) -> None:
        self._entries: dict[str, ProfileEntry] = {}
        for entry in entries or ():
            self.merge(entry)

    # -- доступ ------------------------------------------------------------
    def __len__(self) -> int:
        return len(self._entries)

    def __contains__(self, key: str) -> bool:
        try:
            return _clean_key(key) in self._entries
        except ValueError:
            return False

    def keys(self) -> list[str]:
        """Ключи фактов (в порядке добавления)."""
        return list(self._entries)

    def get(self, key: str) -> ProfileEntry | None:
        """Получить факт по ключу (или ``None``)."""
        return self._entries.get(_clean_key(key))

    def entries(self) -> list[ProfileEntry]:
        """Все факты (в порядке добавления)."""
        return list(self._entries.values())

    # -- слияние -----------------------------------------------------------
    def merge(self, entry: ProfileEntry) -> ProfileEntry:
        """
        Объединить факт с профилем по политике слияния.

        Возвращает итоговый факт по этому ключу.
        """
        if not isinstance(entry, ProfileEntry):
            raise ValueError("entry: ожидается ProfileEntry")
        if len(self._entries) >= MAX_ENTRIES and entry.key not in self._entries:
            raise ProfileError(f"профиль переполнен (максимум {MAX_ENTRIES} фактов)")

        current = self._entries.get(entry.key)
        if current is None:
            self._entries[entry.key] = entry
            return entry

        if entry.key in MULTI_KEYS:
            merged = self._merge_multi(current, entry)
            self._entries[entry.key] = merged
            return merged

        # Одиночный ключ: заменяем, если доверие не меньше текущего
        if entry.confidence >= current.confidence:
            self._entries[entry.key] = entry
            return entry
        return current

    @staticmethod
    def _merge_multi(current: ProfileEntry, new: ProfileEntry) -> ProfileEntry:
        """Слить множественный ключ: копим значения через '; ' с дедупликацией."""
        values = [v.strip() for v in current.value.split(";") if v.strip()]
        seen = {_normalize(v) for v in values}
        for candidate in new.value.split(";"):
            candidate = candidate.strip()
            if candidate and _normalize(candidate) not in seen:
                values.append(candidate)
                seen.add(_normalize(candidate))
        values = values[:MAX_MULTI_VALUES]
        return ProfileEntry(
            key=new.key,
            value="; ".join(values),
            confidence=max(current.confidence, new.confidence),
            source=new.source,
            updated_at=max(current.updated_at, new.updated_at),
        )

    def remove(self, key: str) -> bool:
        """Удалить факт по ключу (``True`` — если был)."""
        return self._entries.pop(_clean_key(key), None) is not None

    def clear(self) -> int:
        """«Забудь профиль» — удалить все факты, вернуть количество."""
        count = len(self._entries)
        self._entries.clear()
        return count

    # -- вывод -------------------------------------------------------------
    def to_prompt_text(self) -> str:
        """Компактный текст профиля для системного промпта LLM."""
        if not self._entries:
            return ""
        labels = {
            "name": "имя",
            "city": "город",
            "job": "работа",
            "timezone": "часовой пояс",
            "language": "язык",
            "likes": "любит",
            "dislikes": "не любит",
            "hobbies": "хобби",
        }
        lines = ["Профиль пользователя:"]
        for entry in self._entries.values():
            label = labels.get(entry.key, entry.key)
            lines.append(f"- {label}: {entry.value}")
        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """Сериализация в JSON-безопасный словарь."""
        return {"entries": [e.to_dict() for e in self._entries.values()]}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "UserProfile":
        """Десериализация из словаря (битые факты пропускаются, не падаем)."""
        if not isinstance(data, dict):
            raise ValueError("UserProfile: ожидается dict")
        profile = cls()
        for raw in data.get("entries", []):
            try:
                profile.merge(ProfileEntry.from_dict(raw))
            except (ValueError, ProfileError) as exc:
                logger.warning("пропущен битый факт профиля: %s", exc)
        return profile


# ---------------------------------------------------------------------------
# Контракт движка
# ---------------------------------------------------------------------------
class ProfileExtractor(abc.ABC):
    """Абстрактный движок извлечения фактов (контракт)."""

    name: str = "base"

    def is_available(self) -> bool:
        """Готов ли движок работать прямо сейчас (без сети/зависимостей?)."""
        return True

    def describe(self) -> dict[str, Any]:
        """Статус для панели."""
        return {"name": self.name, "available": self.is_available()}

    @abc.abstractmethod
    async def extract(self, text: str) -> list[ProfileEntry]:
        """Извлечь из текста факты о пользователе."""


# ---------------------------------------------------------------------------
# Локальная эвристика
# ---------------------------------------------------------------------------
# «меня зовут Иван», «моё имя Иван», «я Иван» (имя — только с заглавной буквы;
# ключевые слова — регистронезависимо, само имя — строго по регистру,
# чтобы не ловить «я знаю» и подобные местоимённые обороты)
_NAME_RE = re.compile(
    r"(?:[Мм]еня\s+зовут|[Мм]о[её]\s+имя)\s+([А-ЯЁA-Z][\w\-а-яё]{1,30})"
    r"|(?:^|(?<=[.\s]))я\s+([А-ЯЁA-Z][а-яё]{2,20})(?=[\s.,!?]|$)"
)
# «живу в Москве», «я из Москвы» (значение сохраняем в форме пользователя —
# без опасных склонений; LLM в промпте и так поймёт «Москве»/«Москвы»)
_CITY_RE = re.compile(
    r"(?:живу\s+в|живу\s+на|я\s+из)\s+([А-ЯЁA-Z][\w\-а-яё]{2,30})"
    r"(?:\s+(?:городе|области))?",
    re.IGNORECASE,
)
# «работаю инженером», «работаю в Яндексе»
_JOB_RE = re.compile(
    r"(?:я\s+)?работаю\s+(?:в|на|как)?\s*([а-яёa-z0-9\-]{2,40})",
    re.IGNORECASE,
)
# Единый шаблон предпочтений: глагол определяет класс (любит / не любит)
_PREF_RE = re.compile(
    r"(?<!не\s)(?:я\s+)?"
    r"(не\s+люблю|терпеть\s+не\s+могу|ненавижу|люблю|обожаю|предпочитаю)"
    r"\s+([^.!?\n]{2,120})",
    re.IGNORECASE,
)
# Граница клаузы «… и обожаю …» — новое предпочтение после союза
_PREF_SPLIT_RE = re.compile(
    r"\s+(?:и|а|также)\s+(?=(?:очень\s+)?(?:не\s+)?"
    r"(?:люблю|обожаю|предпочитаю|ненавижу|терпеть))",
    re.IGNORECASE,
)
# Ведущий глагол в клаузе — для классификации и вырезания из значения
_PREF_VERB_RE = re.compile(
    r"^(?:очень\s+)?(не\s+люблю|терпеть\s+не\s+могу|ненавижу|люблю|обожаю|предпочитаю)\s+",
    re.IGNORECASE,
)
# Негативные глаголы предпочтений (→ ключ dislikes)
_NEGATIVE_PREF_VERBS = frozenset({"не люблю", "терпеть не могу", "ненавижу"})

# Доверие эвристики по ключу (регулярки ошибаются чаще LLM, но зато всегда есть)
_HEURISTIC_CONFIDENCE = {
    "name": 0.9,
    "city": 0.8,
    "job": 0.7,
    "likes": 0.6,
    "dislikes": 0.6,
}


class HeuristicProfileExtractor(ProfileExtractor):
    """
    Локальная эвристическая экстракция фактов (чистый Python, без зависимостей).

    Распознаёт типовые русские фразы: имя, город, работа, предпочтения.
    Не падает никогда: нераспознанный текст → пустой список фактов.
    """

    name = "heuristic"

    async def extract(self, text: str) -> list[ProfileEntry]:
        """Извлечь факты регулярными выражениями (по порядку появления)."""
        text = _clean_input(text)
        found: list[ProfileEntry] = []

        for match in _NAME_RE.finditer(text):
            value = next((g for g in match.groups() if g), "")
            entry = self._entry("name", value) if value else None
            if entry is not None:
                found.append(entry)
                break  # имя одно — берём первое распознанное

        for match in _CITY_RE.finditer(text):
            # Значение сохраняем в форме пользователя (без склонений) —
            # так профиль честнее цитирует и не искажает топонимы
            raw_city = match.group(1).strip()
            entry = self._entry("city", raw_city) if raw_city else None
            if entry is not None:
                found.append(entry)
                break

        for match in _JOB_RE.finditer(text):
            value = match.group(1).strip()
            entry = None
            if value and value.lower() not in {"в", "на", "как"}:
                entry = self._entry("job", value)
            if entry is not None:
                found.append(entry)
                break

        for match in _PREF_RE.finditer(text):
            for key, value in self._expand_preferences(match.group(1), match.group(2)):
                entry = self._entry(key, value)
                if entry is not None:
                    found.append(entry)

        return found

    def _expand_preferences(self, verb: str, clause: str) -> list[tuple[str, str]]:
        """
        Разобрать клаузу предпочтений на пары (ключ, значение).

        «люблю чай и обожаю кофе» → [(likes, «чай»), (likes, «кофе»)]:
        клауза режется по союзам, за которыми стоит новый глагол предпочтений;
        класс (likes/dislikes) определяется по глаголу каждой части.
        """
        verb_norm = re.sub(r"\s+", " ", verb.strip().lower()).replace("ё", "е")
        pairs: list[tuple[str, str]] = []
        for piece in _PREF_SPLIT_RE.split(clause):
            piece = piece.strip()
            if not piece:
                continue
            piece_key: str | None = None
            verb_match = _PREF_VERB_RE.match(piece)
            if verb_match:
                piece_verb = re.sub(
                    r"\s+", " ", verb_match.group(1).strip().lower()
                ).replace("ё", "е")
                piece_key = "dislikes" if piece_verb in _NEGATIVE_PREF_VERBS else "likes"
                piece = piece[verb_match.end():].strip()
            value = self._clean_phrase(piece)
            if value:
                key = piece_key or (
                    "dislikes" if verb_norm in _NEGATIVE_PREF_VERBS else "likes"
                )
                pairs.append((key, value))
        return pairs

    def _entry(self, key: str, value: str) -> ProfileEntry | None:
        """Собрать факт с доверием эвристики (мусорные значения отбрасываем)."""
        try:
            return ProfileEntry(
                key=key,
                value=value,
                confidence=_HEURISTIC_CONFIDENCE.get(key, 0.5),
                source=self.name,
            )
        except ValueError:
            # Мусорное значение (пустое/длинное) — тихо пропускаем
            return None

    @staticmethod
    def _clean_phrase(raw: str | None) -> str:
        """Вычистить захваченную фразу: обрезать по служебным оборотам."""
        if not raw:
            return ""
        phrase = raw.strip()
        # Обороты вида «, который…», « потому что…» — отрезаем хвост
        phrase = re.split(r",\s*(?:котор|потому|чтобы|и\s+это)", phrase, maxsplit=1)[0]
        phrase = phrase.strip(" ,.;:—-")
        if len(phrase) < 2 or len(phrase) > MAX_VALUE_LEN:
            return ""
        return phrase


# ---------------------------------------------------------------------------
# LLM-движок (локально ↔ облако)
# ---------------------------------------------------------------------------
class LLMProfileExtractor(ProfileExtractor):
    """
    «Умная» экстракция фактов через LLM-клиент (``ai.llm_router.LLMRouter``
    или совместимый объект с ``async ask(messages, ...) -> ответ``).

    Клиент может указывать на локальную модель (Ollama) или облако — движку
    всё равно, он лишь формирует промпт и разбирает JSON-ответ. Любой сбой
    клиента или мусорный ответ превращается в ``ProfileUnavailable`` — дальше
    сработает fallback роутера.
    """

    name = "llm"

    def __init__(
        self,
        llm: Any,
        *,
        system_prompt: str | None = None,
        max_tokens: int = 300,
        temperature: float = 0.0,
    ) -> None:
        if llm is None:
            raise ValueError("llm: клиент не задан")
        if isinstance(max_tokens, bool) or not isinstance(max_tokens, int) or max_tokens < 1:
            raise ValueError("max_tokens: ожидается положительный int")
        self._llm = llm
        self._max_tokens = max_tokens
        self._temperature = temperature
        self._system_prompt = system_prompt or (
            "Ты — модуль памяти ассистента JARVIS. Из текста пользователя извлеки "
            "устойчивые факты о нём и верни СТРОГО JSON-объект вида "
            '{"ключ": "значение"} с ключами из списка: name, city, job, '
            "likes, dislikes, hobbies. Если факт не упомянут — не добавляй ключ. "
            "Значения — короткие строки на языке оригинала. Без комментариев."
        )

    def is_available(self) -> bool:
        """Доступен ли у клиента хотя бы один провайдер (если это умеет проверять)."""
        checker = getattr(self._llm, "available_providers", None)
        if callable(checker):
            try:
                return bool(checker())
            except Exception:  # noqa: BLE001 — статус не должен ронять панель
                return False
        return True

    async def extract(self, text: str) -> list[ProfileEntry]:
        """Отправить текст в LLM и разобрать JSON с фактами."""
        text = _clean_input(text)
        try:
            resp = await self._llm.ask(
                [
                    {"role": "system", "content": self._system_prompt},
                    {"role": "user", "content": text},
                ],
                max_tokens=self._max_tokens,
                temperature=self._temperature,
            )
        except Exception as exc:  # noqa: BLE001 — любой сбой LLM → fallback
            raise ProfileUnavailable(f"LLM-экстракция не удалась: {exc}") from exc

        raw = resp if isinstance(resp, str) else getattr(resp, "content", "")
        if not isinstance(raw, str) or not raw.strip():
            raise ProfileUnavailable("LLM вернул пустой ответ")

        return self._parse_answer(raw)

    def _parse_answer(self, raw: str) -> list[ProfileEntry]:
        """Разобрать JSON-ответ LLM в факты (битые поля пропускаются)."""
        if len(raw) > MAX_LLM_ANSWER_LEN:
            raise ProfileUnavailable("ответ LLM слишком длинный")
        cleaned = raw.strip()
        # Убираем возможные ```json … ``` ограждения
        cleaned = re.sub(r"^```[a-zA-Z]*\s*|\s*```$", "", cleaned).strip()
        try:
            data = json.loads(cleaned)
        except json.JSONDecodeError as exc:
            raise ProfileUnavailable(f"LLM вернул не JSON: {exc}") from exc
        if not isinstance(data, dict) or not data:
            raise ProfileUnavailable("LLM вернул не объект «ключ: значение»")

        entries: list[ProfileEntry] = []
        for key, value in data.items():
            if not isinstance(value, str):
                continue  # числа/объекты/массивы — не наш формат, пропускаем
            try:
                entries.append(
                    ProfileEntry(
                        key=str(key),
                        value=value,
                        confidence=0.7,
                        source=self.name,
                    )
                )
            except ValueError as exc:
                logger.warning("LLM-факт пропущен (%s): %s", key, exc)
        if not entries:
            raise ProfileUnavailable("в ответе LLM нет валидных фактов")
        return entries


# ---------------------------------------------------------------------------
# Роутер: смена движков + fallback
# ---------------------------------------------------------------------------
class ProfileExtractorRouter:
    """
    Маршрутизирует извлечение фактов по движкам: смена локально ↔ облако,
    fallback-цепочка.

    ``engine=`` — явный движок (без fallback): если он упал, ошибка уходит
    наружу. Без явного движка цепочка пробует по очереди все зарегистрированные,
    а при полном отказе деградирует до встроенной эвристики — извлечение фактов
    **не должно** ронять конвейер памяти.
    """

    def __init__(
        self,
        engines: Sequence[ProfileExtractor] | None = None,
        *,
        primary: str | None = None,
    ) -> None:
        self._engines: dict[str, ProfileExtractor] = {}
        self._order: list[str] = []
        self._primary = primary
        self._last_resort = HeuristicProfileExtractor()
        for eng in engines or ():
            self.register(eng)

    # -- управление движками ------------------------------------------------
    @property
    def primary(self) -> str | None:
        """Имя основного движка (или None — тогда порядок регистрации)."""
        return self._primary

    def register(self, engine: ProfileExtractor) -> None:
        """Добавить/заменить движок."""
        self._engines[engine.name] = engine
        if engine.name not in self._order:
            self._order.append(engine.name)
        if self._primary is None:
            self._primary = engine.name

    def set_primary(self, name: str) -> None:
        """Сменить основной движок (локально ↔ облако)."""
        if name not in self._engines:
            raise ProfileError(f"неизвестный движок профиля: {name}")
        self._primary = name

    def available(self) -> list[str]:
        """Имена движков, готовых отвечать прямо сейчас."""
        return [n for n in self._order if self._engines[n].is_available()]

    def engine_status(self) -> list[dict[str, Any]]:
        """Статусы всех движков для панели."""
        return [self._engines[n].describe() for n in self._order]

    def _chain(self, explicit: str | None) -> list[ProfileExtractor]:
        """Цепочка движков: явный → основной → остальные (без дублей)."""
        if explicit is not None:
            if explicit not in self._engines:
                raise ProfileError(f"неизвестный движок профиля: {explicit}")
            return [self._engines[explicit]]
        chain: list[ProfileExtractor] = []
        order = ([self._primary] if self._primary else []) + [
            n for n in self._order if n != self._primary
        ]
        for name in order:
            if name in self._engines:
                chain.append(self._engines[name])
        return chain

    async def extract(self, text: str, *, engine: str | None = None) -> list[ProfileEntry]:
        """
        Извлечь факты, пробуя движки по цепочке.

        Явный ``engine=`` — без fallback (его ошибка уходит наружу).
        Иначе — цепочка с гарантированной деградацией до эвристики.
        """
        text = _clean_input(text)
        if engine is not None:
            return await self._chain(engine)[0].extract(text)

        last_exc: Exception | None = None
        for eng in self._chain(None):
            try:
                return await eng.extract(text)
            except Exception as exc:  # noqa: BLE001 — пробуем следующий движок
                last_exc = exc
                logger.debug("движок %s не справился: %s", eng.name, exc)
        try:
            return await self._last_resort.extract(text)
        except Exception as exc:  # noqa: BLE001 — эвристика почти неуязвима
            raise ProfileUnavailable(
                f"все движки экстракции недоступны: {last_exc or exc}"
            ) from (last_exc or exc)


# ---------------------------------------------------------------------------
# Хранилище профиля
# ---------------------------------------------------------------------------
class ProfileStore(abc.ABC):
    """Абстрактное хранилище профиля (контракт)."""

    @abc.abstractmethod
    def load(self) -> UserProfile:
        """Загрузить профиль (или пустой, если ничего нет/файл битый)."""

    @abc.abstractmethod
    def save(self, profile: UserProfile) -> None:
        """Сохранить профиль (атомарно, потокобезопасно)."""

    @abc.abstractmethod
    def clear(self) -> None:
        """«Забудь профиль» — удалить сохранённые данные."""

    def close(self) -> None:
        """Освободить ресурсы (по умолчанию — ничего)."""


class InMemoryProfileStore(ProfileStore):
    """Профиль в памяти (fallback/тесты/INCOGNITO) — не пишет на диск."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._data: dict[str, Any] | None = None

    def load(self) -> UserProfile:
        with self._lock:
            return UserProfile.from_dict(self._data) if self._data else UserProfile()

    def save(self, profile: UserProfile) -> None:
        if not isinstance(profile, UserProfile):
            raise ValueError("profile: ожидается UserProfile")
        with self._lock:
            self._data = profile.to_dict()

    def clear(self) -> None:
        with self._lock:
            self._data = None


class JsonProfileStore(ProfileStore):
    """
    Персистентное хранение профиля в JSON-файле (атомарная запись).

    Битый/нечитаемый файл не роняет загрузку — возвращается пустой профиль
    с предупреждением в лог (профиль не важнее стабильности ассистента).
    """

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._lock = threading.Lock()

    @property
    def path(self) -> Path:
        return self._path

    def load(self) -> UserProfile:
        with self._lock:
            return self._load_unlocked()

    def _load_unlocked(self) -> UserProfile:
        if not self._path.exists():
            return UserProfile()
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning("профиль %s не читается (%s) — начинаем с пустого", self._path, exc)
            return UserProfile()
        try:
            return UserProfile.from_dict(data)
        except (ValueError, TypeError) as exc:
            logger.warning("профиль %s битый (%s) — начинаем с пустого", self._path, exc)
            return UserProfile()

    def save(self, profile: UserProfile) -> None:
        if not isinstance(profile, UserProfile):
            raise ValueError("profile: ожидается UserProfile")
        payload = json.dumps(profile.to_dict(), ensure_ascii=False, indent=2)
        with self._lock:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self._path.with_name(self._path.name + ".tmp")
            tmp.write_text(payload, encoding="utf-8")
            os.replace(tmp, self._path)

    def clear(self) -> None:
        with self._lock:
            try:
                self._path.unlink(missing_ok=True)
            except OSError as exc:
                logger.warning("не удалось удалить профиль %s: %s", self._path, exc)


# ---------------------------------------------------------------------------
# Фасад: обучение профиля
# ---------------------------------------------------------------------------
class ProfileBuilder:
    """
    Фасад поверх роутера и хранилища: «учится» из текста и записей памяти.

    - ``learn_from_text`` — извлечь факты из текста и объединить с профилем;
    - ``learn_from_records`` — то же для записей памяти (``MemoryRecord``);
    - ``save`` / ``load`` — персистентность через ``ProfileStore``;
    - ``to_prompt_text`` — компактное «досье» для системного промпта LLM.

    Приватность: в режиме ``INCOGNITO`` профиль живёт только в памяти
    сессии — ``save()`` ничего не пишет на диск.
    """

    def __init__(
        self,
        *,
        extractor: ProfileExtractor | ProfileExtractorRouter | None = None,
        store: ProfileStore | None = None,
        privacy_mode: PrivacyMode = PrivacyMode.NORMAL,
    ) -> None:
        self._extractor: ProfileExtractorRouter
        if isinstance(extractor, ProfileExtractorRouter):
            self._extractor = extractor
        elif isinstance(extractor, ProfileExtractor):
            self._extractor = ProfileExtractorRouter([extractor])
        elif extractor is None:
            self._extractor = default_profile_extractor_router()
        else:
            raise ValueError("extractor: ожидается ProfileExtractor/ProfileExtractorRouter")
        self._store = store
        self._privacy_mode = privacy_mode
        self._profile = UserProfile()
        if self._store is not None:
            self._profile = self._store.load()

    # -- доступ ------------------------------------------------------------
    @property
    def profile(self) -> UserProfile:
        """Текущий профиль."""
        return self._profile

    def get(self, key: str) -> ProfileEntry | None:
        """Получить факт по ключу."""
        return self._profile.get(key)

    def to_prompt_text(self) -> str:
        """Компактный текст профиля для системного промпта LLM."""
        return self._profile.to_prompt_text()

    def describe(self) -> dict[str, Any]:
        """Статус для панели."""
        return {
            "entries": len(self._profile),
            "privacy": self._privacy_mode.value,
            "engines": self._extractor.engine_status(),
        }

    # -- обучение ----------------------------------------------------------
    async def learn_from_text(
        self,
        text: str,
        *,
        engine: str | None = None,
        persist: bool = True,
    ) -> list[ProfileEntry]:
        """
        Извлечь факты из текста и объединить с профилем.

        Возвращает список фактов, которые изменились/добавились.
        Ошибка извлечения не роняет вызов (роутер сам деградирует);
        ``persist=True`` — сразу сохранить профиль (если хранилище задано
        и режим приватности это позволяет).
        """
        entries = await self._extractor.extract(text, engine=engine)
        applied: list[ProfileEntry] = []
        for entry in entries:
            try:
                applied.append(self._profile.merge(entry))
            except (ValueError, ProfileError) as exc:
                logger.warning("факт не применён (%s): %s", entry.key, exc)
        if persist and applied:
            self.save()
        return applied

    async def learn_from_records(
        self,
        records: Iterable[MemoryRecord],
        *,
        persist: bool = True,
    ) -> list[ProfileEntry]:
        """Извлечь факты из записей памяти (факты/предпочтения — приоритет)."""
        applied: list[ProfileEntry] = []
        for record in records:
            if not isinstance(record, MemoryRecord):
                raise ValueError("records: ожидается MemoryRecord")
            # Сводки/диалоги шумят — учимся только из фактов и предпочтений
            if record.kind not in (MemoryKind.FACT, MemoryKind.PREFERENCE):
                continue
            applied.extend(await self.learn_from_text(record.content, persist=False))
        if persist and applied:
            self.save()
        return applied

    # -- персистентность ---------------------------------------------------
    def save(self) -> bool:
        """
        Сохранить профиль через хранилище.

        Возвращает ``True``, если сохранение состоялось. Без хранилища или в
        режиме ``INCOGNITO`` — ``False`` (профиль остаётся только в памяти).
        """
        if self._store is None:
            return False
        if self._privacy_mode is PrivacyMode.INCOGNITO:
            logger.debug("INCOGNITO: профиль не персистится на диск")
            return False
        self._store.save(self._profile)
        return True

    def reload(self) -> UserProfile:
        """Перечитать профиль из хранилища (сброс несохранённых изменений)."""
        if self._store is None:
            raise ProfileError("не задано хранилище профиля (store)")
        self._profile = self._store.load()
        return self._profile

    def forget(self) -> int:
        """«Забудь профиль» — удалить все факты (и на диске, если есть хранилище)."""
        count = self._profile.clear()
        if self._store is not None and self._privacy_mode is not PrivacyMode.INCOGNITO:
            self._store.clear()
        return count


# ---------------------------------------------------------------------------
# Фабрика «локально-first»
# ---------------------------------------------------------------------------
def default_profile_extractor_router(llm: Any = None) -> ProfileExtractorRouter:
    """
    Дефолтная цепочка экстракции: эвристика (локально) → опционально LLM.

    Если передан LLM-клиент (локальный Ollama или облако), он становится
    основным движком, а эвристика остаётся гарантированным fallback.
    """
    engines: list[ProfileExtractor] = [HeuristicProfileExtractor()]
    if llm is not None:
        engines.insert(0, LLMProfileExtractor(llm))
    return ProfileExtractorRouter(engines)
