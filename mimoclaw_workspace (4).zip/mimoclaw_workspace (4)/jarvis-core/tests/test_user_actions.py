"""
Проверка actions/user_actions.py — fuzzy-поиск программ, макросы,
пользовательские команды.

Запуск:  python3 tests/test_user_actions.py
"""

from __future__ import annotations

import asyncio
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from actions.registry import CommandRegistry, RiskLevel
from actions.user_actions import (
    Macro,
    MacroError,
    MacroNotFound,
    MacroRunReport,
    MacroRunner,
    MacroStep,
    MemoryMacroStore,
    JsonMacroStore,
    ProgramCatalog,
    ProgramEntry,
    UserActionError,
    UserActions,
    UserCommand,
    UserCommandError,
    UserCommandStore,
    default_program_catalog,
    fuzzy_score,
    normalize_text,
    register_user_actions,
    validate_name,
    validate_trigger,
)


# ---------------------------------------------------------------------------
# Хелперы
# ---------------------------------------------------------------------------
def _raises(exc_type, fn, *args, **kwargs) -> str:
    """Проверяет, что fn бросает exc_type; возвращает текст ошибки."""
    try:
        fn(*args, **kwargs)
    except exc_type as e:
        return str(e)
    raise AssertionError(f"ожидался {exc_type.__name__}, но ошибки не было")


def _async_raises(exc_type, coro) -> str:
    """Проверяет, что async-вызов бросает exc_type; возвращает текст ошибки."""
    async def _wrap():
        await coro

    try:
        asyncio.run(_wrap())
    except exc_type as e:
        return str(e)
    raise AssertionError(f"ожидался {exc_type.__name__}, но ошибки не было")


def _demo_registry() -> tuple[CommandRegistry, list[str]]:
    """Реестр с простыми записывающими командами для макросов."""
    reg = CommandRegistry()
    log: list[str] = []

    def make(name: str):
        def handler(**kwargs):
            log.append(f"{name}:{kwargs}")
            return f"{name}-ok"
        handler.__name__ = f"do_{name}"
        return handler

    from actions.registry import Command

    for name in ("open", "say", "boom", "danger"):
        risk = RiskLevel.SAFE if name in ("open", "say") else (
            RiskLevel.MEDIUM if name == "danger" else RiskLevel.HIGH
        )
        reg.register(Command(
            name=name,
            description=name,
            handler=make(name),
            risk=risk,
            requires_confirmation=risk != RiskLevel.SAFE,
        ))
    reg.register(Command(
        name="forbidden",
        description="запрещено",
        handler=make("forbidden"),
        risk=RiskLevel.FORBIDDEN,
        requires_confirmation=True,
    ))
    return reg, log


# ---------------------------------------------------------------------------
# Тесты: нормализация и fuzzy_score
# ---------------------------------------------------------------------------
def test_normalize_and_fuzzy_score() -> None:
    assert normalize_text("  Ёжик\nГром  ") == "ежик гром"
    assert normalize_text(42) == ""

    assert fuzzy_score("Хром", "хром") == 1.0
    assert fuzzy_score("fire", "firefox") > 0.8          # префикс
    assert fuzzy_score("chrome", "google chrome") > 0.7  # подстрока/токены
    assert fuzzy_score("абракадабра", "firefox") == 0.0  # ничего общего
    assert fuzzy_score("", "firefox") == 0.0
    assert fuzzy_score("нечто", "") == 0.0


# ---------------------------------------------------------------------------
# Тесты: валидация имён/триггеров/параметров
# ---------------------------------------------------------------------------
def test_validators() -> None:
    assert validate_name("  кино-вечер  ") == "кино-вечер"
    for bad in ["", "   ", "-rf", "макрос; rm -rf /", "a" * 65, "$(evil)", None, 7]:
        assert _raises(ValueError, validate_name, bad), f"не поймано: {bad!r}"

    assert validate_trigger("  включи кино ") == "включи кино"
    for bad in ["", "   ", "привет\nмир", "x" * 200, "!!!", None, []]:
        assert _raises(ValueError, validate_trigger, bad), f"не поймано: {bad!r}"

    step = MacroStep.make("open", {"app": "firefox"})
    assert step.command == "open" and step.params == {"app": "firefox"}
    assert _raises(ValueError, MacroStep.make, "Open App", {})       # не snake_case
    assert _raises(ValueError, MacroStep.make, "-evil", {})          # ведущий дефис
    assert _raises(ValueError, MacroStep.make, "open", {"a": object()})  # не-JSON
    assert _raises(ValueError, MacroStep.make, "open", {"x" * 70: 1})    # имя параметра
    assert _raises(ValueError, MacroStep.make, "open", {"s": "x" * 5000})  # размер
    deep = {"a": [{"b": [{"c": 1}]}]}
    assert _raises(ValueError, MacroStep.make, "open", deep)         # вложенность


# ---------------------------------------------------------------------------
# Тесты: каталог программ и fuzzy-поиск
# ---------------------------------------------------------------------------
def test_program_catalog_search() -> None:
    cat = ProgramCatalog([
        ProgramEntry(name="google-chrome", aliases=["хром", "chrome"], description="браузер"),
        ProgramEntry(name="firefox", aliases=["браузер", "файрфокс"]),
        ProgramEntry(name="spotify", aliases=["музыка"]),
    ])

    hits = cat.search("хром")
    assert hits and hits[0].name == "google-chrome", hits
    assert hits[0].score == 1.0

    hits = cat.search("файрфокс")
    assert hits and hits[0].name == "firefox", hits

    hits = cat.search("spotyfi")            # опечатка
    assert hits and hits[0].name == "spotify", hits

    assert cat.search("несуществующее приложение xyz") == []
    assert len(cat.search("chrome", limit=1)) == 1
    assert _raises(ValueError, cat.search, "")
    assert _raises(ValueError, cat.search, "chrome", 0)

    # дубликат имени — перезапись
    cat.add(ProgramEntry(name="spotify", aliases=["музыка"]))
    assert cat.names() == ["firefox", "google-chrome", "spotify"]
    assert _raises(ValueError, cat.add, ProgramEntry(name="-bad"))


def test_default_program_catalog_reuses_aliases() -> None:
    cat = default_program_catalog()
    hits = cat.search("браузер")
    assert hits and hits[0].name == "firefox", hits
    hits = cat.search("хром")
    assert hits and hits[0].name == "google-chrome", hits


# ---------------------------------------------------------------------------
# Тесты: макросы и хранилища
# ---------------------------------------------------------------------------
def test_macro_make_and_dict_roundtrip() -> None:
    macro = Macro.make("утро", [{"command": "open", "params": {"app": "firefox"}}],
                       description="утренний сценарий")
    assert macro.name == "утро" and len(macro.steps) == 1
    assert macro.to_dict()["steps"][0]["command"] == "open"

    again = Macro.from_dict(macro.to_dict())
    assert again.name == macro.name and again.steps[0].params == {"app": "firefox"}

    assert _raises(ValueError, Macro.make, "пустой", [])                       # нет шагов
    assert _raises(ValueError, Macro.make, "много", [{"command": "open"}] * 33)
    assert _raises(ValueError, Macro.make, "-x", [{"command": "open"}])
    assert _raises(ValueError, Macro.make, "имя", [{"params": {}}])            # нет command
    assert _raises(ValueError, Macro.make, "имя", [{"command": "open", "zzz": 1}])


def test_memory_and_json_macro_stores() -> None:
    mem = MemoryMacroStore()
    m1 = Macro.make("один", [{"command": "open"}])
    mem.add(m1)
    assert [m.name for m in mem.list()] == ["один"]
    assert mem.get("один") is not None and mem.get("нет") is None

    msg = _raises(MacroError, mem.add, Macro.make("один", [{"command": "say"}]), False)
    assert "уже существует" in msg
    assert mem.remove("один") is True
    assert mem.remove("один") is False

    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "macros.json"
        store = JsonMacroStore(path)
        store.add(Macro.make("кино", [{"command": "open", "params": {"app": "vlc"}}]))
        store.add(Macro.make("музыка", [{"command": "say", "params": {"text": "hi"}}]))
        assert path.is_file()

        reloaded = JsonMacroStore(path)
        assert sorted(reloaded.list() and [m.name for m in reloaded.list()]) == ["кино", "музыка"]
        assert reloaded.get("кино").steps[0].params == {"app": "vlc"}

        # удаление персистентно
        reloaded.remove("музыка")
        third = JsonMacroStore(path)
        assert third.list() and [m.name for m in third.list()] == ["кино"]

        # битый файл → деградация в пустое хранилище
        path.write_text("{oops", encoding="utf-8")
        broken = JsonMacroStore(path)
        assert broken.list() == []

        # битая запись в валидном JSON пропускается, валидные остаются
        path.write_text(json.dumps([{"bad": 1}, Macro.make("ок", [{"command": "open"}]).to_dict()]),
                        encoding="utf-8")
        mixed = JsonMacroStore(path)
        assert [m.name for m in mixed.list()] == ["ок"]


# ---------------------------------------------------------------------------
# Тесты: исполнение макросов
# ---------------------------------------------------------------------------
def test_macro_runner_success_and_abort() -> None:
    reg, log = _demo_registry()
    runner = MacroRunner(reg)
    macro = Macro.make("сценарий", [
        {"command": "open", "params": {"app": "firefox"}},
        {"command": "say", "params": {"text": "готово"}},
    ])

    report = asyncio.run(runner.run(macro))
    assert report.ok and len(report.steps) == 2
    assert log == ["open:{'app': 'firefox'}", "say:{'text': 'готово'}"]
    assert "выполнен" in report.summary()

    # ошибка шага: отчёт фиксирует, выполнение прервано
    class Boom:
        def __call__(self, **kwargs):
            raise RuntimeError("взрыв")

    reg2, _ = _demo_registry()
    from actions.registry import Command
    reg2.register(Command(name="open", description="", handler=Boom(),
                          risk=RiskLevel.SAFE, requires_confirmation=False))
    macro2 = Macro.make("авария", [{"command": "open"}, {"command": "say"}])
    report2 = asyncio.run(MacroRunner(reg2).run(macro2))
    assert not report2.ok and len(report2.steps) == 1
    assert "взрыв" in report2.steps[0].error
    assert "прерван" in report2.summary()

    # stop_on_error=False → идёт дальше
    report3 = asyncio.run(MacroRunner(reg2, stop_on_error=False).run(macro2))
    assert len(report3.steps) == 2 and report3.steps[1].ok


def test_macro_runner_security_rules() -> None:
    reg, log = _demo_registry()
    runner = MacroRunner(reg)

    msg = _async_raises(MacroError, runner.run(
        Macro.make("x", [{"command": "nope"}])))
    assert "не зарегистрирована" in msg

    msg = _async_raises(MacroError, runner.run(
        Macro.make("x", [{"command": "forbidden"}])))
    assert "запрещена" in msg

    # шаг с подтверждением: без confirmed — отказ, с confirmed — работает
    msg = _async_raises(MacroError, runner.run(
        Macro.make("x", [{"command": "danger"}]), confirmed=False))
    assert "подтверждения" in msg

    report = asyncio.run(runner.run(
        Macro.make("x", [{"command": "danger"}]), confirmed=True))
    assert report.ok and log == ["danger:{}"]

    # async-обработчики поддерживаются
    async def async_handler(**kwargs):
        return "async-ok"

    from actions.registry import Command
    reg.register(Command(name="acmd", description="", handler=async_handler,
                         risk=RiskLevel.SAFE, requires_confirmation=False))
    report = asyncio.run(runner.run(Macro.make("x", [{"command": "acmd"}])))
    assert report.ok and report.steps[0].output == "async-ok"


# ---------------------------------------------------------------------------
# Тесты: пользовательские команды
# ---------------------------------------------------------------------------
def test_user_command_make_and_store() -> None:
    cmd = UserCommand.make("включи кино", reply="Включаю кино")
    assert cmd.trigger == "включи кино" and cmd.macro == ""

    msg = _raises(ValueError, UserCommand.make, "привет")
    assert "ответ-текст или макрос" in msg
    assert _raises(ValueError, UserCommand.make, "привет", reply=42)
    assert _raises(ValueError, UserCommand.make, "привет", macro=7)

    store = UserCommandStore()
    store.add(cmd)
    assert store.get("ВКЛЮЧИ КИНО") is not None         # нормализация регистра
    msg = _raises(UserCommandError, store.add, UserCommand.make("включи кино", reply="x"))
    assert "уже существует" in msg

    store.add(UserCommand.make("включи кино", reply="обновлено"), overwrite=True)
    assert store.get("включи кино").reply == "обновлено"
    assert store.remove("включи кино") is True
    assert store.remove("включи кино") is False
    assert _raises(ValueError, store.get, "")


def test_user_command_match() -> None:
    store = UserCommandStore()
    store.add(UserCommand.make("включи кино", reply="Включаю"))
    store.add(UserCommand.make("выключи свет", reply="Выключаю"))
    store.add(UserCommand.make("спящий режим", reply="ok", enabled=False))

    hit = store.match("ВКЛЮЧИ КИНО")
    assert hit is not None and hit[0].trigger == "включи кино" and hit[1] == 1.0

    hit = store.match("включи кино сейчас")
    assert hit is not None and hit[0].trigger == "включи кино" and hit[1] < 1.0

    assert store.match("сделай кофе") is None
    assert store.match("спящий режим") is None          # выключена


def test_user_command_json_store() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "cmds.json"
        store = UserCommandStore(path)
        store.add(UserCommand.make("погода", reply="Сейчас узнаю"))
        assert path.is_file()

        reloaded = UserCommandStore(path)
        assert [c.trigger for c in reloaded.list()] == ["погода"]

        path.write_text("[]oops", encoding="utf-8")
        assert UserCommandStore(path).list() == []      # деградация


# ---------------------------------------------------------------------------
# Тесты: слой UserActions
# ---------------------------------------------------------------------------
def test_user_actions_service() -> None:
    reg, log = _demo_registry()
    svc = UserActions(
        programs=ProgramCatalog([ProgramEntry(name="firefox", aliases=["браузер"])]),
        registry=reg,
    )

    assert svc.search_programs("браузер")[0].name == "firefox"

    msg = svc.save_macro("утро", [{"command": "open", "params": {"app": "firefox"}}])
    assert "сохранён" in msg and svc.list_macros() == ["утро"]
    assert svc.get_macro("утро").steps[0].command == "open"

    # шаг против реестра: неизвестная и запрещённая команда
    msg = _raises(MacroError, svc.save_macro, "битый", [{"command": "unknown_cmd"}])
    assert "не зарегистрирована" in msg
    msg = _raises(MacroError, svc.save_macro, "запрет", [{"command": "forbidden"}])
    assert "запрещена" in msg

    # выполнение через слой (подтверждение уже получено реестром)
    result = asyncio.run(svc.run_macro("утро"))
    assert "выполнен" in result and log == ["open:{'app': 'firefox'}"]

    assert "удалён" in svc.delete_macro("утро")
    assert _raises(MacroNotFound, svc.delete_macro, "утро")
    assert _raises(MacroNotFound, svc.get_macro, "нет")


def test_user_actions_run_macro_errors() -> None:
    reg, _ = _demo_registry()
    svc = UserActions(registry=reg)
    _raises(MacroNotFound, asyncio.run, svc.run_macro("нет"))
    svc.save_macro("шаг", [{"command": "say"}])
    svc.registry = None
    msg = _async_raises(MacroError, svc.run_macro("шаг"))
    assert "реестр" in msg


def test_user_actions_user_commands() -> None:
    reg, log = _demo_registry()
    svc = UserActions(registry=reg)

    svc.save_macro("свет", [{"command": "say", "params": {"text": "включаю свет"}}])
    msg = svc.add_user_command("включи свет", macro="свет")
    assert "сохранена" in msg and svc.list_user_commands() == ["включи свет"]

    # макрос должен существовать
    msg = _raises(MacroNotFound, svc.add_user_command, "новая фраза", macro="нет_такого")
    assert "не найден" in msg

    hit = svc.match_user_command("включи свет")
    assert hit is not None and hit[0].macro == "свет"

    assert "удалена" in svc.remove_user_command("включи свет")
    assert _raises(UserCommandError, svc.remove_user_command, "включи свет")


# ---------------------------------------------------------------------------
# Тесты: регистрация команд в реестре
# ---------------------------------------------------------------------------
def test_register_user_actions() -> None:
    reg = CommandRegistry()
    svc = UserActions(
        programs=ProgramCatalog([ProgramEntry(name="firefox", aliases=["браузер"])]),
        registry=reg,
    )
    names = register_user_actions(reg, svc)
    assert set(names) == {
        "search_programs", "list_macros", "list_user_commands",
        "save_macro", "delete_macro", "run_macro",
        "add_user_command", "remove_user_command",
    }
    assert svc.registry is reg

    expected_risks = {
        "search_programs": RiskLevel.SAFE,
        "list_macros": RiskLevel.SAFE,
        "list_user_commands": RiskLevel.SAFE,
        "save_macro": RiskLevel.MEDIUM,
        "delete_macro": RiskLevel.MEDIUM,
        "add_user_command": RiskLevel.MEDIUM,
        "remove_user_command": RiskLevel.MEDIUM,
        "run_macro": RiskLevel.HIGH,
    }
    for name, risk in expected_risks.items():
        cmd = reg.get(name)
        assert cmd is not None and cmd.risk == risk, name
        assert cmd.requires_confirmation == (risk != RiskLevel.SAFE), name

    # команды реально выполняются через реестр (function-calling путь)
    async def _run() -> None:
        out = await reg.get("save_macro").run(
            name="утро",
            steps=[{"command": "search_programs", "params": {"query": "браузер"}}],
            description="тест",
        )
        assert "сохранён" in out
        assert await reg.get("list_macros").run() == ["утро"]
        report = await reg.get("run_macro").run(name="утро")
        assert "выполнен" in report
        assert await reg.get("delete_macro").run(name="утро") == "Макрос 'утро' удалён."

    asyncio.run(_run())

    # инструменты для LLM корректно отдают схемы
    tools = {t.name: t for t in reg.enabled_tools()}
    assert "run_macro" in tools and "save_macro" in tools
    assert any(p.name == "steps" for p in tools["save_macro"].params)


# ---------------------------------------------------------------------------
# Запуск
# ---------------------------------------------------------------------------
def main() -> int:
    print("JARVIS CORE — проверка actions/user_actions")
    try:
        test_normalize_and_fuzzy_score()
        test_validators()
        test_program_catalog_search()
        test_default_program_catalog_reuses_aliases()
        test_macro_make_and_dict_roundtrip()
        test_memory_and_json_macro_stores()
        test_macro_runner_success_and_abort()
        test_macro_runner_security_rules()
        test_user_command_make_and_store()
        test_user_command_match()
        test_user_command_json_store()
        test_user_actions_service()
        test_user_actions_run_macro_errors()
        test_user_actions_user_commands()
        test_register_user_actions()
    except AssertionError as e:
        import traceback

        print(f"\n✗ FAIL: {e}")
        traceback.print_exc()
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модулей прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
