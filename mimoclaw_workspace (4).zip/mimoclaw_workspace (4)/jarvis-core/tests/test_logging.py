"""
Проверка модуля config/logging: настройка sink-ов, ротация, деградации.

Запуск:  python3 tests/test_logging.py

Тесты работают в обоих режимах: loguru (если установлен) и stdlib-fallback.
"""

from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config.logging import (
    HAS_LOGURU,
    _coerce_dir,
    _normalize_level,
    _parse_retention_days,
    _parse_size,
    logger,
    setup_logging,
)


# ---------------------------------------------------------------------------
# Утилиты
# ---------------------------------------------------------------------------
def _flush_logger() -> None:
    """Сбрасывает буферы (loguru-очередь / stdlib-хендлеры)."""
    complete = getattr(logger, "complete", None)
    if callable(complete):
        complete()
    for handler in list(getattr(logger, "handlers", [])):
        flush = getattr(handler, "flush", None)
        if callable(flush):
            flush()


def _read_log(tmp: Path) -> str:
    """Читает первый файл лога из папки (имя зависит от бэкенда)."""
    files = sorted(Path(tmp).glob("jarvis*.log"))
    assert files, f"файл лога не создан в {tmp}"
    return files[0].read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Разборы значений конфига
# ---------------------------------------------------------------------------
def test_normalization_and_parsing() -> None:
    assert _normalize_level("debug") == "DEBUG"
    assert _normalize_level(" INFO ") == "INFO"
    assert _normalize_level("VERBOSE") == "INFO"  # мусор → дефолт
    assert _normalize_level(None) == "INFO"
    assert _normalize_level("") == "INFO"

    assert _coerce_dir(None) is None
    assert _coerce_dir("data/logs") == Path("data/logs")
    assert _coerce_dir(42) is None  # не-путь → только консоль

    assert _parse_size("10 MB") == 10 * 1024 * 1024
    assert _parse_size("512 KB") == 512 * 1024
    assert _parse_size("1 GB") == 1024 * 1024 * 1024
    assert _parse_size("10") == 10  # без единицы — байты
    assert _parse_size("10 MB", default=7) == 10 * 1024 * 1024
    assert _parse_size("мусор") == 10 * 1024 * 1024
    assert _parse_size("0 MB") == 10 * 1024 * 1024  # не-положительное → дефолт

    assert _parse_retention_days("30 days") == 30
    assert _parse_retention_days("2 weeks") == 14
    assert _parse_retention_days("7") == 7
    assert _parse_retention_days("мусор") == 30
    assert _parse_retention_days("0 days") == 30


# ---------------------------------------------------------------------------
# Настройка: файл + консоль
# ---------------------------------------------------------------------------
def test_setup_writes_file() -> None:
    with _tmp_logs() as tmp:
        cfg = SimpleNamespace(
            level="INFO", dir=tmp, rotation="10 MB", retention="30 days"
        )
        setup_logging(cfg)
        logger.info("ПРОВЕРКА_ФАЙЛА_123")
        _flush_logger()
        content = _read_log(tmp)
        assert "ПРОВЕРКА_ФАЙЛА_123" in content, f"строка не попала в лог: {content!r}"


def test_level_filter_and_idempotency() -> None:
    with _tmp_logs() as tmp:
        cfg = SimpleNamespace(level="ERROR", dir=tmp, rotation="1 MB", retention="5")
        setup_logging(cfg)
        setup_logging(cfg)  # повторный вызов не должен плодить sink-и
        logger.info("НЕ_ДОЛЖНО_БЫТЬ_В_ФАЙЛЕ")
        logger.error("ОШИБКА_ДОЛЖНА_БЫТЬ_123")
        _flush_logger()
        content = _read_log(tmp)
        assert "ОШИБКА_ДОЛЖНА_БЫТЬ_123" in content
        assert "НЕ_ДОЛЖНО_БЫТЬ_В_ФАЙЛЕ" not in content, "уровень ERROR не отфильтровал INFO"

        if not HAS_LOGURU:
            from logging.handlers import RotatingFileHandler

            file_handlers = [
                h for h in logger.handlers if isinstance(h, RotatingFileHandler)  # type: ignore[attr-defined]
            ]
            assert len(file_handlers) == 1, f"дубли файловых хендлеров: {file_handlers}"


def test_bad_dir_degrades_to_console() -> None:
    with _tmp_logs() as tmp:
        busy = tmp / "занято.log"
        busy.write_text("файл на месте папки", encoding="utf-8")
        cfg = SimpleNamespace(level="INFO", dir=busy, rotation="10 MB", retention="30 days")
        setup_logging(cfg)  # не должно упасть
        logger.warning("ПОСЛЕ_ОШИБКИ_ПАПКИ_456")  # логгер жив
        _flush_logger()
        assert busy.read_text(encoding="utf-8") == "файл на месте папки"  # не перетёрт


def test_console_only_when_no_dir() -> None:
    setup_logging(SimpleNamespace())  # атрибутов нет → дефолты, без папки
    logger.info("ТОЛЬКО_КОНСОЛЬ_789")
    _flush_logger()
    if not HAS_LOGURU:
        from logging.handlers import RotatingFileHandler

        assert not [
            h for h in logger.handlers if isinstance(h, RotatingFileHandler)  # type: ignore[attr-defined]
        ], "без папки файловых хендлеров быть не должно"


# ---------------------------------------------------------------------------
# Утилита для временных папок логов (внутри tests/, как в остальных тестах)
# ---------------------------------------------------------------------------
def _tmp_logs():
    """Временная папка логов как ``Path`` (внутри tests/, как в остальных тестах)."""
    import tempfile
    from contextlib import contextmanager

    @contextmanager
    def _ctx():
        with tempfile.TemporaryDirectory(
            dir=str(Path(__file__).resolve().parent)
        ) as name:
            yield Path(name)

    return _ctx()


# ---------------------------------------------------------------------------
def main() -> int:
    print(f"backend = {'loguru' if HAS_LOGURU else 'stdlib (fallback)'}")
    try:
        test_normalization_and_parsing()
        test_setup_writes_file()
        test_level_filter_and_idempotency()
        test_bad_dir_degrades_to_console()
        test_console_only_when_no_dir()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модуля прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
