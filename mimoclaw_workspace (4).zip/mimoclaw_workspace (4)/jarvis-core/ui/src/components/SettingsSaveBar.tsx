/**
 * Панель сохранения настроек: индикатор режима (ядро/демо),
 * кнопка «Сохранить» и текст уведомления.
 */

import { Badge, Notice } from "./ui/panels";
import { Button } from "./ui/controls";
import { useSettingsStore } from "../stores/settingsStore";

export function SettingsSaveBar() {
  const remote = useSettingsStore((s) => s.remote);
  const saving = useSettingsStore((s) => s.saving);
  const notice = useSettingsStore((s) => s.notice);
  const dirty = useSettingsStore((s) => s.isDirty)();
  const save = useSettingsStore((s) => s.save);
  const reset = useSettingsStore((s) => s.reset);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-3">
        <Badge className={remote ? "border-ok/40 bg-ok/10 text-ok" : "border-warn/40 bg-warn/10 text-warn"}>
          {remote ? "REST настроек активен" : "демо-режим: ядро не отвечает"}
        </Badge>
        {dirty ? (
          <Badge className="border-accent/50 bg-accent/10 text-accent" pulse>
            есть несохранённые изменения
          </Badge>
        ) : null}
        <div className="ml-auto flex gap-2">
          <Button onClick={() => void reset()}>Сбросить</Button>
          <Button variant="primary" onClick={() => void save()} disabled={saving || !dirty}>
            {saving ? "Сохранение…" : "Сохранить"}
          </Button>
        </div>
      </div>
      {notice ? <Notice tone={notice.includes("недоступно") ? "warn" : "info"}>{notice}</Notice> : null}
    </div>
  );
}
