"""
Проверка main.py — точка входа: разбор аргументов, режимы, коды возврата.

Запуск:  python3 tests/test_main.py
"""

from __future__ import annotations

import asyncio
import sys
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import main as entry  # noqa: E402


class FakeActionResult:
    """Фейк результата действия (см. core/orchestrator)."""

    def __init__(self, name: str, ok: bool = True, output: str = "ok", error: str = "") -> None:
        self.name = name
        self.ok = ok
        self.output = output
        self.error = error


class FakeResult:
    """Фейк ответа оркестратора (OrchestratorResult)."""

    def __init__(self, reply: str = "готово", actions=None) -> None:
        self.transcript = "поставь громкость 50"
        self.reply = reply
        self.actions = actions or []
        self.used_provider = "mock"
        self.used_tts = "local"


class FakeOrchestrator:
    """Фейк оркестратора: фиксирует вызов process_text."""

    def __init__(self, result: FakeResult | None = None, exc: Exception | None = None) -> None:
        self.result = result or FakeResult()
        self.exc = exc
        self.calls: list[str] = []

    async def process_text(self, text: str):
        self.calls.append(text)
        if self.exc is not None:
            raise self.exc
        return self.result


def _patch_orchestrator(monkey: dict):
    """Возвращает фейк и подменяет build_orchestrator в модуле main."""
    fake = FakeOrchestrator()
    monkey["build_orchestrator"] = entry.build_orchestrator
    entry.build_orchestrator = lambda cfg, persona, offline: fake
    return fake


def _restore(monkey: dict) -> None:
    for name, fn in monkey.items():
        setattr(entry, name, fn)


def test_text_mode_success(capsys=None):
    """--text: успешный прогон возвращает 0 и печатает ответ."""
    monkey: dict = {}
    fake = _patch_orchestrator(monkey)
    fake.result = FakeResult(reply="Громкость 50%",
                             actions=[FakeActionResult("set_volume"),
                                      FakeActionResult("open_url", ok=False, error="нет сети")])
    try:
        code = entry.main(["--text", "поставь громкость 50"])
        assert code == 0, f"ожидали 0, получили {code}"
        assert fake.calls == ["поставь громкость 50"]
    finally:
        _restore(monkey)


def test_text_mode_llm_error_returns_2():
    """--text: отказ LLM → код 2 (не падение)."""
    monkey: dict = {}
    fake = _patch_orchestrator(monkey)
    fake.exc = RuntimeError("ollama недоступна")
    try:
        code = entry.main(["--text", "привет"])
        assert code == 2, f"ожидали 2, получили {code}"
    finally:
        _restore(monkey)


def test_headless_mode_returns_0():
    """--headless: каркас голосового цикла завершается кодом 0."""
    code = entry.main(["--headless"])
    assert code == 0, f"ожидали 0, получили {code}"


def test_ui_mode_without_uvicorn_returns_1(monkeypatch=None):
    """--ui: без uvicorn/FastAPI деградирует в код 1, а не traceback."""
    import builtins

    real_import = builtins.__import__

    def blocked_import(name, *args, **kwargs):
        if name == "uvicorn" or name.startswith("ui_server"):
            raise ImportError("нет зависимости")
        return real_import(name, *args, **kwargs)

    builtins.__import__ = blocked_import
    try:
        code = entry.main(["--ui"])
        assert code == 1, f"ожидали 1, получили {code}"
    finally:
        builtins.__import__ = real_import


def test_mutually_exclusive_modes():
    """--text/--headless/--ui взаимоисключающие: парный выбор → SystemExit(2)."""
    import contextlib
    import io

    for pair in (["--text", "hi", "--ui"], ["--ui", "--headless"], ["--text", "hi", "--headless"]):
        with contextlib.redirect_stderr(io.StringIO()):
            try:
                entry.main(pair)
            except SystemExit as exc:
                assert exc.code == 2, f"{pair}: ожидали SystemExit(2), получили {exc.code}"
            else:
                raise AssertionError(f"{pair}: ожидали SystemExit(2), но вызов прошёл")


def test_no_mode_defaults_to_headless():
    """Без режимов → фоновый (headless) сценарий, код 0."""
    code = entry.main([])
    assert code == 0, f"ожидали 0, получили {code}"


def test_load_action_modules_is_resilient():
    """_load_action_modules: упавший модуль не роняет загрузку остальных."""
    import importlib

    real_import_module = importlib.import_module
    seen: list[str] = []

    def flaky_import(name, *args, **kwargs):
        seen.append(name)
        if name == "actions.app_actions":
            raise ImportError("битый модуль")
        return real_import_module(name, *args, **kwargs)

    importlib.import_module = flaky_import
    try:
        loaded = entry._load_action_modules()
        assert "actions.app_actions" not in loaded
        assert len(loaded) >= 1, "хотя бы один модуль команд должен загрузиться"
    finally:
        importlib.import_module = real_import_module


def test_build_orchestrator_wiring():
    """build_orchestrator: собирает оркестратор с реестром и персоной."""
    import types as _types

    # LLMRouter.from_config тянет провайдеры — подменяем на лёгкий фейк.
    fake_llm_mod = _types.ModuleType("ai.llm_router")

    class FakeLLMRouter:
        offline_only = False

        @classmethod
        def from_config(cls, cfg):
            return cls()

    fake_llm_mod.LLMRouter = FakeLLMRouter

    import ai.llm_router as real_llm_mod

    sys.modules["ai.llm_router"] = fake_llm_mod
    try:
        cfg = entry.load_settings()
        orch = entry.build_orchestrator(cfg, "friday", offline=True)
        assert orch is not None
        assert orch.persona_key == "friday"
    finally:
        sys.modules["ai.llm_router"] = real_llm_mod


def run_all() -> None:
    tests = [
        test_text_mode_success,
        test_text_mode_llm_error_returns_2,
        test_headless_mode_returns_0,
        test_ui_mode_without_uvicorn_returns_1,
        test_mutually_exclusive_modes,
        test_no_mode_defaults_to_headless,
        test_load_action_modules_is_resilient,
        test_build_orchestrator_wiring,
    ]
    failed = 0
    for t in tests:
        try:
            t()
            print(f"  ✓ {t.__name__}")
        except AssertionError as exc:
            failed += 1
            print(f"  ✗ {t.__name__}: {exc}")
        except Exception as exc:  # noqa: BLE001
            failed += 1
            print(f"  ✗ {t.__name__}: {type(exc).__name__}: {exc}")
    print(f"{len(tests) - failed}/{len(tests)} прошло")
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    run_all()
