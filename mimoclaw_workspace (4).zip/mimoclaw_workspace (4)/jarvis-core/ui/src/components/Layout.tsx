/**
 * Layout — каркас панели: левое меню + верхняя панель + контент раздела.
 */

import { motion } from "framer-motion";
import { useEffect } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { useSocket } from "../hooks/useSocket";
import { applyAccent, useUiStore } from "../stores/uiStore";
import { Sidebar } from "./Sidebar";
import { TopBar } from "./TopBar";

export function Layout() {
  const location = useLocation();
  const persona = useUiStore((s) => s.persona);
  // Поднимаем WS-подключение и держим его живым на всех страницах.
  useSocket();

  useEffect(() => {
    applyAccent(persona);
  }, [persona]);

  return (
    <div className="flex h-full overflow-hidden">
      <Sidebar />
      <div className="flex h-full min-w-0 flex-1 flex-col">
        <TopBar />
        <main className="hud-grid flex-1 overflow-y-auto px-6 py-6">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.32, ease: "easeOut" }}
            className="mx-auto max-w-7xl"
          >
            <Outlet />
          </motion.div>
        </main>
      </div>
    </div>
  );
}
