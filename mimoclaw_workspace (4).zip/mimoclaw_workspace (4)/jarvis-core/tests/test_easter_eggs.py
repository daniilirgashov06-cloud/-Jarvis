"""
Проверка модуля fun/easter_eggs: пасхалки, нормализация, детектор фраз.

Запуск:  python3 tests/test_easter_eggs.py
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fun.easter_eggs import (
    EasterEgg,
    EasterEggDetector,
    choose_response,
    default_eggs,
    normalize_text,
)


# ---------------------------------------------------------------------------
# Хелперы
# ---------------------------------------------------------------------------
def _raises(exc_type, fn, *args, **kwargs) -> str:
    """Проверяет, что fn бросает exc_type; возвращает текст ошибки."""
    try:
        fn(*args, **kwargs)
    except exc_type as e:
        return str(e)
    raise AssertionError(f"ожидался {exc_type.__name__}, но ошибки не было")


# ---------------------------------------------------------------------------
# Тесты: нормализация
# ---------------------------------------------------------------------------
def test_normalize_text() -> None:
    """Нормализация убирает регистр, ё, пунктуацию и лишние пробелы."""
    assert normalize_text("  Спасибо,  Джарвис!!  ") == "спасибо джарвис"
    assert normalize_text("Ёлка") == "елка"
    assert normalize_text("ты... со мной???") == "ты со мной"
    assert normalize_text("") == ""
    assert "строкой" in _raises(ValueError, normalize_text, 42)
    print("  ✓ normalize_text: регистр, ё, пунктуация")


# ---------------------------------------------------------------------------
# Тесты: обязательные пасхалки
# ---------------------------------------------------------------------------
def test_required_eggs_detected() -> None:
    """Обязательные фразы-триггеры распознаются в любом виде."""
    detector = EasterEggDetector()
    cases = {
        "thanks": ["Спасибо, Джарвис!", "спасибо джарвис", "ДЖАРВИС, спасибо тебе"],
        "are_you_with_me": ["ты со мной?", "Ты со мной", "ты тут?"],
        "house_party_protocol": [
            "Активируй протокол разрушитель!",
            "активируй  протокол  разрушитель",
            "запусти протокол разрушитель",
        ],
        "age": ["Сколько тебе лет?", "сколько тебе год", "твой возраст?"],
    }
    for egg_id, phrases in cases.items():
        for phrase in phrases:
            match = detector.detect(phrase)
            assert match is not None, f"фраза не распознана: {phrase!r}"
            assert match.egg.id == egg_id, f"{phrase!r} → {match.egg.id}, ожидался {egg_id}"
            assert match.egg.responses, f"у пасхалки {egg_id} нет ответов"
    print("  ✓ Обязательные пасхалки: благодарность/присутствие/протокол/возраст")


def test_no_false_positives() -> None:
    """Обычные фразы пасхалками не считаются."""
    detector = EasterEggDetector()
    for phrase in ("открой браузер", "какая сегодня погода", "поставь будильник", ""):
        assert detector.detect(phrase) is None, f"ложное срабатывание на {phrase!r}"
        assert detector.respond(phrase) is None
    print("  ✓ Без ложных срабатываний")


# ---------------------------------------------------------------------------
# Тесты: ответы
# ---------------------------------------------------------------------------
def test_responses() -> None:
    """Ответ выбирается из вариантов и детерминирован по seed."""
    detector = EasterEggDetector()
    match = detector.detect("спасибо джарвис")
    assert match is not None
    for seed in range(5):
        answer = match.pick_response(seed=seed)
        assert answer in match.egg.responses, f"ответ не из набора: {answer!r}"
    assert match.pick_response(seed="chat-1") == match.pick_response(seed="chat-1"), (
        "одинаковый seed должен давать одинаковый ответ"
    )
    assert detector.respond("ты со мной", seed=7) in detector.detect("ты со мной").egg.responses

    assert choose_response(("а", "б"), seed=1) in ("а", "б")
    assert "пуст" in _raises(ValueError, choose_response, ())
    print("  ✓ Ответы: варианты и детерминированность")


# ---------------------------------------------------------------------------
# Тесты: конструирование и приоритеты
# ---------------------------------------------------------------------------
def test_egg_construction() -> None:
    """EasterEgg валидирует id/триггеры/ответы и regex."""
    egg = EasterEgg(id="demo", patterns=(r"привет",), responses=("здорово",))
    assert egg.priority == 0 and egg.description == ""

    assert "id" in _raises(ValueError, EasterEgg, "", (r"х",), ("у",))
    assert "триггеров" in _raises(ValueError, EasterEgg, "x", (), ("у",))
    assert "ответа" in _raises(ValueError, EasterEgg, "x", (r"х",), ())
    _raises(re.error, EasterEgg, "x", (r"[битый",), ("у",))
    print("  ✓ EasterEgg: валидация")


def test_custom_eggs_and_priority() -> None:
    """Свой набор, register и приоритет при пересечении триггеров."""
    low = EasterEgg(id="low", patterns=(r"привет",), responses=("низкий",), priority=1)
    high = EasterEgg(id="high", patterns=(r"привет",), responses=("высокий",), priority=5)
    detector = EasterEggDetector([low, high])
    match = detector.detect("ПРИВЕТ!")
    assert match is not None and match.egg.id == "high", "должен побеждать больший приоритет"

    detector.register(EasterEgg(id="bye", patterns=(r"пока",), responses=("до связи",)))
    assert detector.respond("ну пока") == "до связи"
    assert len(detector.eggs) == 3
    print("  ✓ Детектор: свой набор, register, приоритеты")


def test_default_eggs_shape() -> None:
    """Стандартный набор: уникальные id и рабочие regex."""
    eggs = default_eggs()
    ids = [egg.id for egg in eggs]
    assert len(ids) == len(set(ids)), f"дублирующиеся id: {ids}"
    assert {"thanks", "are_you_with_me", "house_party_protocol", "age"} <= set(ids)
    for egg in eggs:
        for pattern in egg.patterns:
            re.compile(pattern), f"битый regex в {egg.id}: {pattern}"
    print("  ✓ default_eggs: состав и regex")


def main() -> int:
    print("Проверка fun/easter_eggs ...")
    try:
        test_normalize_text()
        test_required_eggs_detected()
        test_no_false_positives()
        test_responses()
        test_egg_construction()
        test_custom_eggs_and_priority()
        test_default_eggs_shape()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модуля прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
