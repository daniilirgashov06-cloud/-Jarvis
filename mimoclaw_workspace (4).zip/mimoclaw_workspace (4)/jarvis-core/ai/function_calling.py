"""
Function calling — схемы инструментов для LLM JARVIS CORE.

Описывает инструменты (команды) в едином формате и отдаёт их провайдерам.
Все провайдеры принимают схемы в формате OpenAI ``tools``; провайдеры сами
конвертируют их под свой API (см. ai/providers/*).

Использование:
    tool = Tool.from_command(name="set_volume", description="...", params={...})
    tools_payload = to_openai_tools([tool])
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable

# Типы JSON Schema, которые мы используем
_JSON_TYPES = {"string", "number", "integer", "boolean", "object", "array"}


@dataclass
class ParamSpec:
    """Описание одного параметра инструмента."""

    name: str
    type: str = "string"
    description: str = ""
    required: bool = True
    enum: list[Any] | None = None
    default: Any = None

    def to_schema(self) -> dict[str, Any]:
        schema: dict[str, Any] = {
            "type": self.type if self.type in _JSON_TYPES else "string",
            "description": self.description,
        }
        if self.enum:
            schema["enum"] = self.enum
        return schema


@dataclass
class Tool:
    """Инструмент (команда), доступный LLM через function calling."""

    name: str
    description: str = ""
    params: list[ParamSpec] = field(default_factory=list)
    handler: Callable[..., Any] | None = None
    risk_level: str = "safe"

    def __post_init__(self) -> None:
        self.name = _sanitize_name(self.name)

    @classmethod
    def from_command(
        cls,
        name: str,
        description: str,
        params: dict[str, dict[str, Any]] | None = None,
        handler: Callable[..., Any] | None = None,
        risk_level: str = "safe",
    ) -> "Tool":
        """
        Создаёт инструмент из декларативного описания параметров.

        params: {имя: {"type", "description", "required", "enum", "default"}}
        """
        specs = [
            ParamSpec(
                name=pname,
                type=pdata.get("type", "string"),
                description=pdata.get("description", ""),
                required=pdata.get("required", True),
                enum=pdata.get("enum"),
                default=pdata.get("default"),
            )
            for pname, pdata in (params or {}).items()
        ]
        return cls(
            name=name,
            description=description,
            params=specs,
            handler=handler,
            risk_level=risk_level,
        )

    def parameters_schema(self) -> dict[str, Any]:
        """JSON Schema параметров для function calling."""
        properties = {p.name: p.to_schema() for p in self.params}
        required = [p.name for p in self.params if p.required]
        return {
            "type": "object",
            "properties": properties,
            "required": required,
        }

    def to_openai(self) -> dict[str, Any]:
        """Схема в формате OpenAI tools (базовый формат для всех провайдеров)."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters_schema(),
            },
        }


def to_openai_tools(tools: list[Tool]) -> list[dict[str, Any]]:
    """Конвертирует список инструментов в payload ``tools`` (формат OpenAI)."""
    return [t.to_openai() for t in tools]


def _sanitize_name(name: str) -> str:
    """Имена инструментов: буквы/цифры/подчёркивание, начинаются с буквы."""
    cleaned = re.sub(r"[^a-zA-Z0-9_]", "_", name.strip())
    cleaned = re.sub(r"_+", "_", cleaned).strip("_")  # схлопать и обрезать края
    if not cleaned or not cleaned[0].isalpha():
        cleaned = f"fn_{cleaned}" if cleaned else "fn_tool"
    return cleaned
