"""
Проверка telegram_bot: мост, whitelist, подтверждения, обработчики (без сети).

Запуск:  python3 tests/test_telegram_handlers.py
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import telegram_bot.bot as bot_mod
import telegram_bot.handlers as handlers_mod
from telegram_bot.bot import BotConfig, TelegramBotApp, TelegramConfigError, resolve_token
from telegram_bot.bridge import (
    CALLBACK_APPROVE,
    CALLBACK_CANCEL,
    AccessDenied,
    AccessLevel,
    BridgeFullError,
    ChatWhitelist,
    CommandBridge,
    ConfirmationExpired,
    ConfirmationManager,
    ConfirmationUnknown,
    RiskLevel,
    decode_callback,
    encode_callback,
    requires_confirmation,
)
from telegram_bot.handlers import (
    AIOGRAM_AVAILABLE,
    BotHandlers,
    TelegramDependencyError,
    format_confirmation,
    format_status,
    require_aiogram,
)


# ---------------------------------------------------------------------------
# Хелперы
# ---------------------------------------------------------------------------
def _raises(exc_type, fn, *args, **kwargs) -> str:
    """Проверяет, что fn бросает exc_type; возвращает текст ошибки."""
    try:
        fn(*args, **kwargs)
    except exc_type as e:
        return str(e)
    raise AssertionError(f"ожидался {exc_type.__name__}, но ошибки не было")


class _FakeSecret:
    """Заглушка SecretStr из pydantic (без зависимости от pydantic в тесте)."""

    def __init__(self, value: str) -> None:
        self._value = value

    def get_secret_value(self) -> str:
        return self._value


class _FakeSettings:
    """Заглушка config.settings.Settings с секцией telegram."""

    def __init__(self, token: object = None, chat_id: str | None = "42", level: str = "full") -> None:
        self.telegram = type(
            "TelegramSection",
            (),
            {"token": token, "chat_id": chat_id, "access_level": level, "notify_errors": True},
        )()


def _make_handlers(
    *,
    allowed: tuple[str, ...] = ("42",),
    max_pending: int = 8,
    ttl_s: float = 100.0,
    status: dict | None = None,
    screenshot=None,
) -> BotHandlers:
    """Собрать BotHandlers с тестовыми мостом/подтверждениями/whitelist."""
    clock_box = {"now": 0.0}
    confirmations = ConfirmationManager(ttl_s=ttl_s, clock=lambda: clock_box["now"])
    return BotHandlers(
        bridge=CommandBridge(max_pending=max_pending, clock=lambda: clock_box["now"]),
        confirmations=confirmations,
        whitelist=ChatWhitelist(frozenset(allowed), allow_all=False, default_level=AccessLevel.FULL),
        status_provider=lambda: status or {"overall": "ok", "items": []},
        screenshot_provider=(lambda: screenshot),
    )


# ---------------------------------------------------------------------------
# Тесты: whitelist и уровни доступа
# ---------------------------------------------------------------------------
def test_whitelist() -> None:
    """Whitelist: разрешённые chat_id, нормализация, уровни доступа."""
    wl = ChatWhitelist.from_config("42, -100", extra=["77"])
    assert wl.is_allowed(42) and wl.is_allowed("-100") and wl.is_allowed("77")
    assert not wl.is_allowed("43"), "чужой chat_id должен блокироваться"
    assert not wl.is_allowed("abc"), "некорректный chat_id должен блокироваться"

    assert wl.require("42") == "42"
    assert "whitelist" in _raises(AccessDenied, wl.require, "43")
    assert "некорректный" in _raises(ValueError, wl.require, "привет")

    open_wl = ChatWhitelist(allow_all=True, default_level=AccessLevel.VIEW)
    assert open_wl.is_allowed("любой") is False, "allow_all всё равно валидирует формат chat_id"
    assert open_wl.is_allowed("123")

    assert AccessLevel.VIEW.allows(AccessLevel.VIEW)
    assert not AccessLevel.VIEW.allows(AccessLevel.NOTIFY)
    assert AccessLevel.FULL.allows(AccessLevel.NOTIFY)
    assert "уровень" in _raises(AccessDenied, open_wl.check_access, "123", AccessLevel.FULL)
    print("  ✓ ChatWhitelist: allow/deny, нормализация, уровни")


def test_risk_levels() -> None:
    """Уровни риска: подтверждение нужно для medium/high/forbidden."""
    assert not requires_confirmation(RiskLevel.SAFE)
    assert requires_confirmation(RiskLevel.MEDIUM)
    assert requires_confirmation("high")
    assert requires_confirmation(RiskLevel.FORBIDDEN)
    print("  ✓ RiskLevel: requires_confirmation")


# ---------------------------------------------------------------------------
# Тесты: мост команд
# ---------------------------------------------------------------------------
def test_command_bridge() -> None:
    """Очередь команд: submit → pop, переполнение, валидация."""

    async def scenario() -> None:
        bridge = CommandBridge(max_pending=2)
        req = bridge.submit("42", "open_app", args={"name": "firefox"}, risk=RiskLevel.MEDIUM)
        assert req.chat_id == "42" and req.command == "open_app"
        assert req.request_id.startswith("tg-"), f"id запроса: {req.request_id}"
        assert bridge.qsize() == 1
        assert bridge.describe()["commands"] == ["open_app"]

        bridge.submit("42", "status")
        assert bridge.qsize() == 2
        assert "переполнена" in _raises(BridgeFullError, bridge.submit, "42", "ещё")

        got = await bridge.pop()
        assert got.to_dict()["args"] == {"name": "firefox"}, "аргументы должны сохраняться"
        bridge.done(got)
        assert bridge.qsize() == 1

    asyncio.run(scenario())
    assert "пуст" in _raises(ValueError, CommandBridge().submit, "42", "  ")
    assert "max_pending" in _raises(ValueError, CommandBridge, 0)
    print("  ✓ CommandBridge: очередь, переполнение, сериализация")


# ---------------------------------------------------------------------------
# Тесты: подтверждения
# ---------------------------------------------------------------------------
def test_confirmations() -> None:
    """Подтверждения: TTL, одноразовость, кнопки, просрочка."""
    clock = {"now": 100.0}
    manager = ConfirmationManager(ttl_s=30.0, clock=lambda: clock["now"])
    pending = manager.create("42", "delete_file", args={"path": "/x"}, risk=RiskLevel.HIGH)
    assert pending.risk is RiskLevel.HIGH and pending.chat_id == "42"

    for data in (pending.callback_approve, pending.callback_cancel):
        assert len(data.encode("utf-8")) <= 64, f"callback_data слишком длинный: {data!r}"
    kind, token = decode_callback(pending.callback_approve)
    assert (kind, token) == (CALLBACK_APPROVE, pending.token)
    assert encode_callback(CALLBACK_CANCEL, pending.token) == pending.callback_cancel

    # просрочка
    clock["now"] = 131.0
    assert pending.is_expired(clock["now"]), "подтверждение должно истечь по TTL"
    assert "просрочено" in _raises(ConfirmationExpired, manager.resolve, pending.token, True)
    assert manager.pending() == [], "просроченное подтверждение удаляется"

    # одноразовость
    second = manager.create("42", "reboot")
    got, approved = manager.resolve(second.token, approved=False)
    assert got.action == "reboot" and approved is False
    assert "не найдено" in _raises(ConfirmationUnknown, manager.resolve, second.token, True)

    # purge_expired
    third = manager.create("42", "ping")
    clock["now"] += manager.ttl_s + 1
    assert manager.purge_expired() == 1, "purge_expired должен чистить просроченные"

    assert "ttl_s" in _raises(ValueError, ConfirmationManager, 0)
    assert "пустым" in _raises(ValueError, manager.create, "42", " ")
    assert "callback" in _raises(ValueError, encode_callback, "maybe", "abc")
    assert "callback-данные" in _raises(ValueError, decode_callback, "нет-двоеточия")
    print("  ✓ ConfirmationManager: TTL, кнопки, одноразовость, purge")


# ---------------------------------------------------------------------------
# Тесты: форматтеры
# ---------------------------------------------------------------------------
def test_formatters() -> None:
    """Форматирование статуса и подтверждения (HTML, экранирование)."""
    text = format_status({"overall": "warn", "items": [{"name": "CPU", "value": 71, "unit": "%", "level": "warn"}]})
    assert "Статус системы" in text and "CPU" in text and "71" in text and "WARN" in text

    escaped = format_status({"overall": "ok", "items": [{"name": "<b>x</b>", "value": 1}]})
    assert "&lt;b&gt;x&lt;/b&gt;" in escaped, "значения должны экранироваться для HTML"

    manager = ConfirmationManager(ttl_s=10.0, clock=lambda: 0.0)
    pending = manager.create("42", "shutdown", args={"force": True}, risk=RiskLevel.HIGH, note="осторожно")
    conf_text = format_confirmation(pending)
    assert "shutdown" in conf_text and "force=True" in conf_text and "high" in conf_text
    assert "осторожно" in conf_text and "ПОДТВЕРД" not in conf_text  # кнопки — отдельно
    print("  ✓ Форматтеры: статус и подтверждение")


# ---------------------------------------------------------------------------
# Тесты: обработчики
# ---------------------------------------------------------------------------
def test_handlers_basic() -> None:
    """/start, /status, /screenshot и текст → оркестратор."""
    handlers = _make_handlers(status={"overall": "ok", "items": [{"name": "CPU", "value": 3, "unit": "%"}]})

    reply = handlers.start("42", user_name="Тони")
    assert "JARVIS" in reply.text and "Тони" in reply.text and "full" in reply.text

    assert "Доступ запрещён" not in reply.text
    assert "whitelist" in _raises(AccessDenied, handlers.start, "999"), "чужой chat_id должен получать отказ"

    status_reply = handlers.status("42")
    assert "CPU" in status_reply.text and "3" in status_reply.text

    shot_reply = handlers.screenshot("42")
    assert shot_reply.attachment is None and "недоступен" in shot_reply.text

    with_shot = _make_handlers(screenshot=b"PNGDATA")
    shot = with_shot.screenshot("42")
    assert shot.attachment == b"PNGDATA" and "Скриншот" in shot.attachment_caption

    text_reply = handlers.text("42", "  открой браузер  ")
    assert "принята" in text_reply.text
    assert handlers.bridge.pending()[0].args == {"text": "открой браузер"}
    assert "Пустая" in handlers.text("42", "   ").text
    print("  ✓ BotHandlers: start/status/screenshot/text")


def test_handlers_dangerous_flow() -> None:
    """Опасные действия: кнопки ПОДТВЕРДИТЬ/ОТМЕНА и мост в оркестратор."""
    handlers = _make_handlers()

    reply = handlers.request_action("42", "delete_file", args={"path": "/x"}, risk=RiskLevel.MEDIUM)
    assert reply.buttons, "для опасного действия нужны кнопки"
    texts = [b.text for b in reply.buttons]
    assert any("ПОДТВЕРДИТЬ" in t for t in texts) and any("ОТМЕНА" in t for t in texts)
    assert handlers.bridge.qsize() == 0, "опасное действие не должно выполняться без подтверждения"

    approve_data = reply.buttons[0].callback_data
    done = handlers.handle_callback("42", approve_data)
    assert "подтверждено" in done.text
    assert handlers.bridge.qsize() == 1, "подтверждённое действие уходит в оркестратор"
    queued = handlers.bridge.pending()[0]
    assert queued.command == "delete_file" and queued.args == {"path": "/x"}

    # отмена
    cancel_reply = handlers.request_action("42", "reboot", risk=RiskLevel.HIGH)
    done = handlers.handle_callback("42", cancel_reply.buttons[1].callback_data)
    assert "отменено" in done.text and handlers.bridge.qsize() == 1, "отмена не должна исполнять действие"

    # повторное нажатие
    stale = handlers.handle_callback("42", approve_data)
    assert "неактивно" in stale.text

    # чужой чат
    assert "whitelist" in _raises(AccessDenied, handlers.handle_callback, "777", approve_data)

    # запрещённый уровень риска
    assert "запрещено" in _raises(
        AccessDenied, handlers.request_action, "42", "wipe_disk", risk=RiskLevel.FORBIDDEN
    )
    print("  ✓ Опасные действия: подтверждение/отмена/одноразовость")


# ---------------------------------------------------------------------------
# Тесты: устойчивость к отсутствию aiogram и конфигурация бота
# ---------------------------------------------------------------------------
def test_aiogram_graceful() -> None:
    """Модули импортируются без aiogram; ошибки понятные, без падений."""
    assert isinstance(AIOGRAM_AVAILABLE, bool), "флаг доступности aiogram должен быть bool"
    if AIOGRAM_AVAILABLE:
        assert require_aiogram() is not None
    else:
        message = _raises(TelegramDependencyError, require_aiogram)
        assert "aiogram не установлен" in message, f"непонятное сообщение: {message}"
        assert "pip install" in message
        kb_message = _raises(TelegramDependencyError, handlers_mod.build_inline_keyboard, ())
        assert "aiogram не установлен" in kb_message
    print("  ✓ Зависимость aiogram: мягкая деградация")


def test_bot_config() -> None:
    """Токен из окружения/настроек, без хардкода секретов."""
    env = {"TELEGRAM_BOT_TOKEN": "123456:TEST-TOKEN"}
    assert resolve_token(env=env) == "123456:TEST-TOKEN"

    settings = _FakeSettings(token=_FakeSecret("654321:FROM-SETTINGS"))
    assert resolve_token(env={}, settings=settings) == "654321:FROM-SETTINGS"

    message = _raises(TelegramConfigError, resolve_token, env={})
    assert "TELEGRAM_BOT_TOKEN" in message, f"подсказка про токен обязательна: {message}"
    assert "пуст" in _raises(TelegramConfigError, BotConfig, token="  ")

    config = BotConfig.from_settings(settings, env={})
    assert config.allowed_chats == frozenset({"42"}) and config.access_level is AccessLevel.FULL
    described = config.describe()
    assert described["token_set"] is True
    assert "654321" not in json.dumps(described, ensure_ascii=False), "токен не должен попадать в описание"

    app = TelegramBotApp(config)
    info = app.describe()
    assert info["config"]["allowed_chats"] == ["42"] and "aiogram_available" in info
    json.dumps(info, ensure_ascii=False)  # сериализуемость

    if not AIOGRAM_AVAILABLE:
        started = asyncio.run(app.run())
        assert started is False, "без aiogram run() должен вернуть False, а не падать"
    print("  ✓ BotConfig/TelegramBotApp: токен из env/настроек, describe без секретов")


def test_env_default_source() -> None:
    """resolve_token по умолчанию читает os.environ (без зашитых токенов)."""
    old = os.environ.get("TELEGRAM_BOT_TOKEN")
    os.environ["TELEGRAM_BOT_TOKEN"] = "777:ENV-DEFAULT"
    try:
        assert resolve_token() == "777:ENV-DEFAULT"
    finally:
        if old is None:
            os.environ.pop("TELEGRAM_BOT_TOKEN", None)
        else:
            os.environ["TELEGRAM_BOT_TOKEN"] = old
    print("  ✓ resolve_token: чтение из os.environ")


def main() -> int:
    print("Проверка telegram_bot ...")
    try:
        test_whitelist()
        test_risk_levels()
        test_command_bridge()
        test_confirmations()
        test_formatters()
        test_handlers_basic()
        test_handlers_dangerous_flow()
        test_aiogram_graceful()
        test_bot_config()
        test_env_default_source()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модуля прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
