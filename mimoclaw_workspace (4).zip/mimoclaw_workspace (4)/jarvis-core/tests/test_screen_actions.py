"""
Проверка actions/screen_actions.py.

Запуск:  python3 tests/test_screen_actions.py
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from actions.registry import CommandRegistry, RiskLevel
from actions.screen_actions import (
    DryRunScreenBackend,
    ScreenActions,
    ScreenError,
    ScreenSize,
    ScreenUnavailable,
    SubprocessScreenBackend,
    WindowInfo,
    register_screen_actions,
    validate_screenshot_path,
)


# ---------------------------------------------------------------------------
# Валидация пути скриншота
# ---------------------------------------------------------------------------
def test_validate_path() -> None:
    # допустимые расширения
    p = validate_screenshot_path("/tmp/shot.png")
    assert p.name == "shot.png"
    # расширение по умолчанию при path=None
    auto = validate_screenshot_path(None, output_dir="screenshots")
    assert auto.name.startswith("screenshot_") and auto.suffix == ".png"
    # запрещённые варианты
    for bad in ["", "  ", "-shot.png", "shot.txt", "shot", "sh\x00ot.png", 42]:
        try:
            validate_screenshot_path(bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"путь {bad!r} должен быть отклонён")
    # запрещённые директории (политика безопасности)
    try:
        validate_screenshot_path("/etc/passwd.png", forbidden_paths=["/etc"])
    except ScreenError:
        pass
    else:
        raise AssertionError("запрещённый путь должен блокироваться")
    print("  ✓ validate_path: допустимые/запрещённые пути и расширения")


# ---------------------------------------------------------------------------
# DryRun: сквозной прогон команд
# ---------------------------------------------------------------------------
def test_dry_run_actions() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        backend = DryRunScreenBackend(
            size=ScreenSize(2560, 1440),
            windows=[WindowInfo("0x1", "Терминал", "gnome-terminal"),
                     WindowInfo("0x2", "Браузер", "firefox")],
            active=WindowInfo("0x2", "Браузер", "firefox"),
        )
        svc = ScreenActions(backend=backend, output_dir=str(Path(tmp) / "shots"))

        info = svc.screen_info()
        assert info == {"width": 2560, "height": 1440}

        wins = svc.list_windows()
        assert len(wins) == 2 and wins[0]["title"] == "Терминал"

        act = svc.active_window()
        assert act["title"] == "Браузер"

        # скриншот с явным путём
        target = Path(tmp) / "screen.png"
        shot = svc.take_screenshot(str(target))
        assert shot["path"] == str(target.resolve())
        assert shot["bytes"] > 0 and target.exists()

        # скриншот без пути → в output_dir
        auto = svc.take_screenshot()
        auto_path = Path(auto["path"])
        assert auto_path.parent == (Path(tmp) / "shots").resolve()
        assert auto_path.exists()

        # недоступный backend → контролируемый отказ
        backend.available = False
        try:
            svc.screen_info()
        except ScreenUnavailable:
            pass
        else:
            raise AssertionError("недоступный backend должен давать ScreenUnavailable")
    print("  ✓ dry_run: screen_info/list_windows/active_window/screenshot + fallback")


# ---------------------------------------------------------------------------
# SubprocessScreenBackend: разбор вывода и сборка argv под платформы
# ---------------------------------------------------------------------------
def test_subprocess_linux_parsing() -> None:
    calls: list[list[str]] = []

    def runner(argv: list[str]) -> str:
        calls.append(argv)
        if argv[:2] == ["xrandr", "--current"]:
            return "Screen 0: minimum 320 x 200, current 1920 x 1080, maximum 16384 x 16384"
        if argv == ["wmctrl", "-l"]:
            return ("0x04200003  0 host Терминал\n"
                    "0x04200004  0 host Браузер\n")
        if argv == ["xdotool", "getactivewindow"]:
            return "0x42\n"
        if argv == ["xdotool", "getwindowname", "0x42"]:
            return "Редактор\n"
        return ""

    tools = {"xrandr", "wmctrl", "xdotool", "scrot"}
    backend = SubprocessScreenBackend(
        runner=runner,
        platform_name="Linux",
        which=lambda t: f"/usr/bin/{t}" if t in tools else None,
    )
    assert backend.is_available()
    assert backend.screen_size() == ScreenSize(1920, 1080)

    wins = backend.list_windows()
    assert [w.title for w in wins] == ["Терминал", "Браузер"]
    assert wins[0].id.startswith("0x")

    act = backend.active_window()
    assert act.id == "0x42" and act.title == "Редактор"

    # скриншот через scrot
    with tempfile.TemporaryDirectory() as tmp:
        target = Path(tmp) / "shot.png"

        def shot_runner(argv: list[str]) -> str:
            calls.append(argv)
            target.write_bytes(b"png-data")
            return ""

        backend.runner = shot_runner
        size = backend.screenshot(target)
        assert size == len(b"png-data")
        assert ["scrot", "--overwrite", str(target)] in calls
    print("  ✓ subprocess/linux: xrandr + wmctrl + xdotool + scrot, разбор argv/вывода")


def test_subprocess_platform_fallbacks() -> None:
    # macOS: system_profiler + screencapture + osascript
    calls: list[list[str]] = []

    def mac_runner(argv: list[str]) -> str:
        calls.append(argv)
        if argv[0] == "system_profiler":
            return "Displays:\n  Resolution: 2560 x 1600 Retina\n"
        if argv[0] == "osascript" and "frontmost" in argv[-1]:
            return "Редактор\n"
        return ""

    mac = SubprocessScreenBackend(
        runner=mac_runner,
        platform_name="Darwin",
        which=lambda t: "/usr/bin/" + t,
    )
    assert mac.screen_size() == ScreenSize(2560, 1600)
    assert mac.active_window().title == "Редактор"

    # Windows: PowerShell, размер + активное окно
    def win_runner(argv: list[str]) -> str:
        calls.append(argv)
        script = argv[-1]
        if "PrimaryScreen.Bounds" in script and "CopyFromScreen" not in script:
            return "3840 2160\n"
        if "GetForegroundWindow" in script:
            return "0x1234|Блокнот\n"
        return ""

    win = SubprocessScreenBackend(
        runner=win_runner,
        platform_name="Windows",
        which=lambda t: "/usr/bin/" + t,
    )
    assert win.screen_size() == ScreenSize(3840, 2160)
    assert win.active_window().title == "Блокнот"

    # недоступные утилиты / пустой вывод → контролируемые отказы
    bare = SubprocessScreenBackend(
        runner=lambda argv: "",
        platform_name="Linux",
        which=lambda t: None,
    )
    assert not bare.is_available()
    try:
        bare.screen_size()
    except ScreenUnavailable:
        pass
    else:
        raise AssertionError("без утилит должен быть ScreenUnavailable")

    empty = SubprocessScreenBackend(
        runner=lambda argv: "",
        platform_name="Linux",
        which=lambda t: "/usr/bin/" + t,
    )
    try:
        empty.screen_size()
    except ScreenError:
        pass
    else:
        raise AssertionError("пустой вывод xrandr должен давать ScreenError")
    print("  ✓ subprocess/macOS+Windows: разбор вывода и деградация без утилит")


# ---------------------------------------------------------------------------
# Регистрация команд: имена, риски, подтверждения
# ---------------------------------------------------------------------------
def test_register_commands() -> None:
    reg = CommandRegistry()
    names = register_screen_actions(reg, actions=ScreenActions(backend=DryRunScreenBackend()))
    assert set(names) == {"screen_info", "list_windows", "active_window", "take_screenshot"}

    for safe in ("screen_info", "list_windows", "active_window"):
        cmd = reg.get(safe)
        assert cmd is not None
        assert cmd.risk == RiskLevel.SAFE and cmd.requires_confirmation is False
    shot = reg.get("take_screenshot")
    assert shot is not None
    assert shot.risk == RiskLevel.MEDIUM and shot.requires_confirmation is True
    # схема для LLM: у take_screenshot необязательный параметр path
    tool = shot.to_tool()
    assert tool.name == "take_screenshot"
    assert [p.name for p in tool.params] == ["path"] and tool.params[0].required is False
    print("  ✓ register: 4 команды, уровни риска/подтверждения и схема для LLM верны")


def main() -> int:
    print("JARVIS CORE — проверка screen_actions")
    try:
        test_validate_path()
        test_dry_run_actions()
        test_subprocess_linux_parsing()
        test_subprocess_platform_fallbacks()
        test_register_commands()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки screen_actions прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
