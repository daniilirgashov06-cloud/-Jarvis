"""
Проверка vision/screen_awareness.py (Screen Awareness: маскировка парольных
полей, секреты в тексте, политика приватности для облака).

Запуск:  python3 tests/test_screen_awareness.py
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from vision.capture import CaptureRegion, ScreenFrame
from vision.ocr import OCRBox, OCRImage, OCRResult
from vision.screen_awareness import (
    MAX_BLUR_PIXELS,
    MaskStyle,
    PrivacyBlocked,
    PrivacyPolicy,
    ScreenAwarenessError,
    ScreenGuard,
    SensitiveFieldDetector,
    SensitiveKind,
    SensitiveRegion,
    TextSecret,
    default_privacy_policy,
    find_text_secrets,
    mask_image,
    redact_text,
)


# ---------------------------------------------------------------------------
# Вспомогательные построители
# ---------------------------------------------------------------------------
def gradient_image(width: int = 20, height: int = 20, mode: str = "L") -> OCRImage:
    """Растр с градиентом (значение зависит от x+y) — размытие его меняет."""
    channels = 1 if mode == "L" else 3
    data = bytearray()
    for y in range(height):
        for x in range(width):
            v = (x * 7 + y * 11) % 256
            data.extend([v] * channels)
    return OCRImage(width, height, bytes(data), mode)


def box(text: str, x: int, y: int, w: int = 30, h: int = 12) -> OCRBox:
    return OCRBox(text=text, x=x, y=y, width=w, height=h, confidence=90.0)


def outside_pixels(image: OCRImage, regions: list[SensitiveRegion]) -> bytes:
    """Склеивает байты пикселей вне регионов (для проверки «остальное не тронуто»)."""
    touched: set[int] = set()
    ch = image.channels
    for reg in regions:
        for y in range(reg.y, reg.bottom):
            for x in range(reg.x, reg.right):
                for c in range(ch):
                    touched.add((y * image.width + x) * ch + c)
    return bytes(b for i, b in enumerate(image.data) if i not in touched)


# ---------------------------------------------------------------------------
# 1. SensitiveRegion / PrivacyPolicy: валидация
# ---------------------------------------------------------------------------
def test_region_and_policy_validation() -> None:
    reg = SensitiveRegion(1, 2, 3, 4, "password", "пароль")
    assert reg.kind is SensitiveKind.PASSWORD
    assert reg.area == 12 and reg.right == 4 and reg.bottom == 6
    assert reg.overlaps(SensitiveRegion(3, 5, 10, 10))
    assert not reg.overlaps(SensitiveRegion(10, 10, 2, 2))

    from_text = SensitiveRegion.from_box(box("•••", 5, 6, 2, 2), kind="secret", label="•••")
    assert from_text.kind is SensitiveKind.SECRET and from_text.x == 5

    clipped = SensitiveRegion(6, 6, 8, 8).clipped(10, 10)
    assert clipped == SensitiveRegion(6, 6, 4, 4)
    assert SensitiveRegion(20, 20, 5, 5).clipped(10, 10) is None

    for kwargs in [
        {"x": -1, "y": 0, "width": 1, "height": 1},
        {"x": 0, "y": 0, "width": 0, "height": 1},
        {"x": 0, "y": 0, "width": 1, "height": 1, "kind": "нет такой"},
        {"x": 0, "y": 0, "width": 1, "height": 1, "label": "a\nb"},
        {"x": True, "y": 0, "width": 1, "height": 1},
    ]:
        try:
            SensitiveRegion(**kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError(f"ожидали ValueError для {kwargs}")

    policy = PrivacyPolicy(mask_kinds=frozenset({"password", "card"}), style="blur")
    assert policy.mask_kinds == frozenset({SensitiveKind.PASSWORD, SensitiveKind.CARD})
    assert policy.style is MaskStyle.BLUR and policy.allow_cloud is False
    assert default_privacy_policy().style is MaskStyle.BLACK

    for kwargs in [
        {"mask_kinds": frozenset()},
        {"style": "нет такой"},
        {"blur_radius": 0},
        {"pixelate_block": 1},
        {"max_regions": 0},
        {"allow_cloud": "yes"},
    ]:
        try:
            PrivacyPolicy(**kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError(f"ожидали ValueError для {kwargs}")


# ---------------------------------------------------------------------------
# 2. mask_image: BLACK / BLUR / PIXELATE
# ---------------------------------------------------------------------------
def test_mask_image_styles() -> None:
    img = gradient_image()
    reg = SensitiveRegion(5, 5, 6, 6)
    before_outside = outside_pixels(img, [reg])

    black = mask_image(img, [reg], style=MaskStyle.BLACK)
    assert (black.width, black.height, black.mode) == (img.width, img.height, img.mode)
    assert black.data[6 * 20 + 6] == 0 and black.data[10 * 20 + 10] == 0
    assert outside_pixels(black, [reg]) == before_outside

    blurred = mask_image(img, [reg], style="blur", blur_radius=2)
    region_bytes = bytes(
        blurred.data[y * 20 + x] for y in range(5, 11) for x in range(5, 11)
    )
    orig_bytes = bytes(img.data[y * 20 + x] for y in range(5, 11) for x in range(5, 11))
    assert region_bytes != orig_bytes, "размытие должно менять регион"
    assert outside_pixels(blurred, [reg]) == before_outside

    pix = mask_image(img, [reg], style=MaskStyle.PIXELATE, pixelate_block=3)
    assert pix.data[5 * 20 + 5] == pix.data[5 * 20 + 6] == pix.data[6 * 20 + 5]
    assert outside_pixels(pix, [reg]) == before_outside

    # RGB-растр и регион за границей
    rgb = gradient_image(8, 8, mode="RGB")
    same = mask_image(rgb, [SensitiveRegion(100, 100, 4, 4)])
    assert same is rgb
    assert mask_image(rgb, []) is rgb

    # огромный регион при BLUR деградирует в чёрную заливку (предохранитель)
    import vision.screen_awareness as sa

    assert MAX_BLUR_PIXELS >= 1
    big = OCRImage(4, 4, bytes([7]) * 16, "L")
    old_limit = sa.MAX_BLUR_PIXELS
    sa.MAX_BLUR_PIXELS = 4
    try:
        filled = mask_image(big, [SensitiveRegion(0, 0, 4, 4)], style=MaskStyle.BLUR)
    finally:
        sa.MAX_BLUR_PIXELS = old_limit
    assert filled.data == bytes(16)

    for kwargs in [{"style": "нет"}, {"blur_radius": 99}, {"pixelate_block": 1}]:
        try:
            mask_image(img, [reg], **kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError(f"ожидали ValueError для {kwargs}")


# ---------------------------------------------------------------------------
# 3. Секреты в тексте: find_text_secrets / redact_text
# ---------------------------------------------------------------------------
def test_text_secrets_and_redaction() -> None:
    text = (
        "Пиши на john.doe+x@site.io, карта 4111 1111 1111 1111, "
        "тел +7 916 123-45-67, пароль: qwerty123 и token=abcdef0123."
    )
    secrets = find_text_secrets(text)
    kinds = [s.kind for s in secrets]
    assert SensitiveKind.EMAIL in kinds and SensitiveKind.CARD in kinds
    assert SensitiveKind.PHONE in kinds and SensitiveKind.PASSWORD in kinds
    assert SensitiveKind.SECRET in kinds
    assert all(text[s.start : s.end] for s in secrets)

    redacted = redact_text(text)
    assert "john.doe+x@site.io" not in redacted and "[EMAIL]" in redacted
    assert "4111 1111 1111 1111" not in redacted and "[КАРТА]" in redacted
    assert "916 123-45-67" not in redacted and "[ТЕЛЕФОН]" in redacted
    assert "qwerty123" not in redacted and "[ПАРОЛЬ]" in redacted
    assert "abcdef0123" not in redacted and "[СЕКРЕТ]" in redacted

    # карта с неверной контрольной суммой Луна не маскируется как карта
    bad_card = "код 4111 1111 1111 1112"
    assert not any(s.kind is SensitiveKind.CARD for s in find_text_secrets(bad_card))

    assert redact_text("обычный текст без секретов") == "обычный текст без секретов"
    assert find_text_secrets("") == ()

    # пересечения: «пароль: значение» важнее вложенного email-подобного хвоста
    seq = find_text_secrets("password: a@b.co")
    assert seq[0].kind in (SensitiveKind.PASSWORD, SensitiveKind.SECRET)

    try:
        find_text_secrets(123)  # type: ignore[arg-type]
    except ValueError:
        pass
    else:
        raise AssertionError("ожидали ValueError для не-str")
    try:
        TextSecret(SensitiveKind.EMAIL, 5, 5)
    except ValueError:
        pass
    else:
        raise AssertionError("ожидали ValueError для пустого спана")


# ---------------------------------------------------------------------------
# 4. SensitiveFieldDetector: парольные поля по OCR
# ---------------------------------------------------------------------------
def test_sensitive_field_detector() -> None:
    result = OCRResult(
        text="Пароль: qwerty123 •••• CVV 123",
        boxes=(
            box("Пароль:", 10, 10, 40, 12),
            box("qwerty123", 60, 10, 60, 12),
            box("••••", 150, 10, 30, 12),
            box("CVV", 10, 40, 25, 12),
            box("123", 45, 40, 20, 12),
        ),
    )
    detector = SensitiveFieldDetector(max_gap=15, expand_right=0)
    regions = detector.detect(result)

    kinds_by_label = {(r.label, r.x): r.kind for r in regions}
    assert ("Пароль:", 10) in kinds_by_label
    assert kinds_by_label[("Пароль:", 10)] is SensitiveKind.PASSWORD
    # значение справа от подписи тоже замаскировано
    value_regions = [r for r in regions if r.x == 60]
    assert value_regions and value_regions[0].kind is SensitiveKind.PASSWORD
    # «••••» — SECRET
    assert any(r.x == 150 and r.kind is SensitiveKind.SECRET for r in regions)
    # CVV → CARD + значение
    assert any(r.x == 10 and r.y == 40 and r.kind is SensitiveKind.CARD for r in regions)
    assert any(r.x == 45 and r.kind is SensitiveKind.CARD for r in regions)

    # expand_right расширяет регион подписи
    wide = SensitiveFieldDetector(max_gap=0, expand_right=50).detect(result)
    label_region = next(r for r in wide if r.x == 10 and r.y == 10)
    assert label_region.width == 40 + 50

    # без подписей и «звёздочек» регионов нет
    clean = OCRResult(text="Просто текст", boxes=(box("Просто", 0, 0), box("текст", 60, 0)))
    assert SensitiveFieldDetector().detect(clean) == ()

    for kwargs in [{"max_gap": -1}, {"expand_right": -2}, {"max_regions": 0}]:
        try:
            SensitiveFieldDetector(**kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError(f"ожидали ValueError для {kwargs}")
    try:
        detector.detect("не результат")  # type: ignore[arg-type]
    except ValueError:
        pass
    else:
        raise AssertionError("ожидали ValueError для не-OCRResult")


# ---------------------------------------------------------------------------
# 5. ScreenGuard: protect_* и гейт облака
# ---------------------------------------------------------------------------
def test_screen_guard() -> None:
    img = gradient_image(30, 20)
    result = OCRResult(
        text="Пароль: secret1",
        boxes=(box("Пароль:", 2, 2, 30, 10), box("secret1", 40, 2, 30, 10)),
    )

    guard = ScreenGuard()
    protected, regions = guard.protect_image(img, result=result)
    assert regions and protected.data != img.data
    assert guard.protect_text("пароль: abc123") == "пароль: [ПАРОЛЬ]"
    assert guard.describe()["allow_cloud"] is False

    # облако запрещено → блокировка при найденных секретах
    try:
        guard.prepare_for_cloud(img, result=result)
    except PrivacyBlocked as exc:
        assert isinstance(exc, ScreenAwarenessError)
    else:
        raise AssertionError("ожидали PrivacyBlocked")
    try:
        guard.prepare_text_for_cloud("мой пароль: abc123")
    except PrivacyBlocked:
        pass
    else:
        raise AssertionError("ожидали PrivacyBlocked для текста")

    # облако разрешено осознанно → уходит только маскированная версия
    cloud_guard = ScreenGuard(PrivacyPolicy(allow_cloud=True))
    safe, applied = cloud_guard.prepare_for_cloud(img, result=result)
    assert applied and safe.data != img.data
    assert cloud_guard.prepare_text_for_cloud("пароль: abc123") == "пароль: [ПАРОЛЬ]"

    # секретов нет → растр без изменений
    clean = OCRResult(text="Привет", boxes=(box("Привет", 0, 0),))
    same, none_regions = cloud_guard.prepare_for_cloud(img, result=clean)
    assert same is img and none_regions == ()

    # extra_regions маскируются; отключённые mask_kinds не маскируются
    manual = SensitiveRegion(0, 0, 5, 5, SensitiveKind.CUSTOM, "окно")
    strict = ScreenGuard(PrivacyPolicy(mask_kinds=frozenset({SensitiveKind.PASSWORD})))
    masked, applied = strict.protect_image(img, extra_regions=[manual])
    assert applied == () and masked is img
    loose, applied = guard.protect_image(img, extra_regions=[manual])
    assert applied == (manual,) and loose.data != img.data

    # protect_frame: метаданные сохраняются, пиксели региона замаскированы
    frame = ScreenFrame(
        width=10,
        height=6,
        pixels=bytes(range(180)),
        region=CaptureRegion(0, 0, 10, 6),
        backend="test",
    )
    safe_frame, frame_regions = guard.protect_frame(
        frame, extra_regions=[SensitiveRegion(2, 1, 3, 2)]
    )
    assert frame_regions and safe_frame.region == frame.region
    assert safe_frame.width == 10 and len(safe_frame.pixels) == 180
    assert safe_frame.pixel(2, 1) == (0, 0, 0)
    assert safe_frame.pixel(9, 5) == frame.pixel(9, 5)

    try:
        guard.protect_text(42)  # type: ignore[arg-type]
    except ValueError:
        pass
    else:
        raise AssertionError("ожидали ValueError для не-str")


# ---------------------------------------------------------------------------
def main() -> int:
    print("JARVIS CORE — проверка vision/screen_awareness")
    try:
        test_region_and_policy_validation()
        test_mask_image_styles()
        test_text_secrets_and_redaction()
        test_sensitive_field_detector()
        test_screen_guard()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки vision/screen_awareness прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
