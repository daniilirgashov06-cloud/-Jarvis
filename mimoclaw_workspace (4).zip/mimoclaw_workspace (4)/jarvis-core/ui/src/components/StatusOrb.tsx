/**
 * StatusOrb — крупный индикатор состояния пайплайна:
 * «Ожидание / Слушаю / Думаю / Говорю» с неоновой пульсацией.
 */

import { motion } from "framer-motion";
import type { PipelineState } from "../types/api";

interface StateMeta {
  label: string;
  hint: string;
  className: string;
}

const META: Record<string, StateMeta> = {
  idle: { label: "ОЖИДАНИЕ", hint: "Система в режиме ожидания", className: "text-muted" },
  listening: { label: "СЛУШАЮ", hint: "Микрофон активен, идёт распознавание", className: "text-accent" },
  thinking: { label: "ДУМАЮ", hint: "Модель обрабатывает запрос", className: "text-warn" },
  speaking: { label: "ГОВОРЮ", hint: "Идёт синтез и воспроизведение речи", className: "text-ok" },
};

export function StatusOrb({ state }: { state: PipelineState }) {
  const meta = META[state] ?? {
    label: String(state).toUpperCase(),
    hint: "Неизвестное состояние пайплайна",
    className: "text-accent",
  };
  const active = state !== "idle";

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative h-44 w-44">
        {/* внешние кольца */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
          className="absolute inset-0 rounded-full border border-dashed border-accent/25"
        />
        <motion.div
          animate={{ rotate: -360 }}
          transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
          className="absolute inset-3 rounded-full border border-accent/20"
          style={{ borderTopColor: "rgb(var(--accent-rgb))" }}
        />
        {/* пульс */}
        <motion.div
          animate={active ? { scale: [1, 1.18, 1], opacity: [0.55, 0.15, 0.55] } : { scale: 1, opacity: 0.25 }}
          transition={{ duration: state === "speaking" ? 1.1 : 2.2, repeat: Infinity, ease: "easeInOut" }}
          className="absolute inset-6 rounded-full"
          style={{ background: "radial-gradient(circle, rgb(var(--accent-rgb) / 0.5), transparent 70%)" }}
        />
        {/* ядро */}
        <div
          className="absolute inset-10 flex items-center justify-center rounded-full border border-accent/60 bg-panel-2"
          style={{ boxShadow: active ? "0 0 46px -8px rgb(var(--accent-rgb) / 0.8)" : undefined }}
        >
          <motion.span
            animate={{ opacity: active ? [1, 0.45, 1] : 0.7 }}
            transition={{ duration: 1.4, repeat: Infinity, ease: "easeInOut" }}
            className="font-display text-3xl font-bold text-accent"
          >
            {state === "listening" ? "◉" : state === "thinking" ? "✦" : state === "speaking" ? "▶" : "◌"}
          </motion.span>
        </div>
      </div>

      <div className="text-center">
        <motion.h2
          key={meta.label}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className={`font-display text-xl font-bold uppercase tracking-[0.32em] ${meta.className}`}
        >
          {meta.label}
          <span className="blink ml-1 text-accent">_</span>
        </motion.h2>
        <p className="mt-1 text-xs text-muted">{meta.hint}</p>
      </div>
    </div>
  );
}
