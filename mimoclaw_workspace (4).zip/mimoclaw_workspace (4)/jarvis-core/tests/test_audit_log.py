"""
Проверка модуля core/audit_log: запись, маскирование секретов, запросы,
ротация, деградация в память, потокобезопасность.

Запуск:  python3 tests/test_audit_log.py
"""

from __future__ import annotations

import json
import sys
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.audit_log import REDACTED, AuditEvent, AuditLog, redact


# ---------------------------------------------------------------------------
# Утилиты
# ---------------------------------------------------------------------------
def _make(tmp: Path, **kwargs) -> AuditLog:
    return AuditLog(tmp / "audit.jsonl", **kwargs)


# ---------------------------------------------------------------------------
# Событие и маскирование
# ---------------------------------------------------------------------------
def test_event_validation_and_masking() -> None:
    # Недопустимое решение
    try:
        AuditEvent(action="x", decision="whatever")
    except ValueError:
        pass
    else:
        raise AssertionError("ожидался ValueError для недопустимого decision")

    # Чувствительные ключи маскируются, обычные — нет
    event = AuditEvent(
        action="send_mail",
        decision="executed",
        params={"to": "a@b.c", "password": "qwerty", "nested": {"api_key": "sk-123"}},
    )
    assert event.params["to"] == "a@b.c"
    assert event.params["password"] == REDACTED
    assert event.params["nested"]["api_key"] == REDACTED
    assert json.loads(event.to_json())["action"] == "send_mail"


def test_redact_helpers() -> None:
    data = {"Token": "abc", "list": [{"secret": "s"}, 5], "n": None, "obj": object()}
    out = redact(data)
    assert out["Token"] == REDACTED
    assert out["list"][0]["secret"] == REDACTED
    assert out["list"][1] == 5
    assert out["n"] is None
    assert isinstance(out["obj"], str)


# ---------------------------------------------------------------------------
# Запись и файл
# ---------------------------------------------------------------------------
def test_record_writes_jsonl(tmp_path: Path) -> None:
    audit = _make(tmp_path)
    event = audit.record_command(
        "shutdown", decision="confirmed", risk="high", actor="llm", params={"delay": 10}
    )
    assert event.decision == "confirmed"
    assert audit.total == 1 and not audit.degraded

    rows = audit.read_file()
    assert len(rows) == 1
    assert rows[0]["action"] == "shutdown"
    assert rows[0]["risk"] == "high"
    assert rows[0]["actor"] == "llm"

    # Пустое имя действия — ошибка ввода, файл не трогаем
    try:
        audit.record("  ", decision="executed")
    except ValueError:
        pass
    else:
        raise AssertionError("ожидался ValueError для пустого action")
    assert len(audit.read_file()) == 1


def test_query_filters(tmp_path: Path) -> None:
    audit = _make(tmp_path)
    audit.record("a", decision="executed", risk="safe")
    audit.record("b", decision="denied", risk="high", actor="llm")
    audit.record("b", decision="executed", risk="high", actor="llm")

    assert len(audit.query()) == 3
    assert len(audit.query(action="b")) == 2
    assert [e.decision for e in audit.query(decision="denied")] == ["denied"]
    assert len(audit.query(risk="high", actor="llm")) == 2
    assert len(audit.query(action="a", risk="high")) == 0
    assert len(audit.query(since=audit.recent(1)[0].ts + 1)) == 0
    # recent возвращает события от старых к новым
    assert [e.action for e in audit.recent(2)] == ["b", "b"]


def test_export_and_clear(tmp_path: Path) -> None:
    audit = _make(tmp_path)
    audit.record("x", decision="executed")
    audit.record("y", decision="failed", detail="boom")

    target = tmp_path / "export" / "out.jsonl"
    assert audit.export(target) == 2
    lines = target.read_text(encoding="utf-8").strip().splitlines()
    assert json.loads(lines[1])["detail"] == "boom"

    audit.clear()
    assert audit.total == 0 and audit.recent(10) == []
    assert audit.read_file() == []


# ---------------------------------------------------------------------------
# Ротация
# ---------------------------------------------------------------------------
def test_rotation(tmp_path: Path) -> None:
    audit = AuditLog(tmp_path / "audit.jsonl", max_bytes=1024, keep=2)
    for i in range(60):
        audit.record(f"cmd_{i}", decision="executed", detail="x" * 40)

    main = tmp_path / "audit.jsonl"
    bak1 = tmp_path / "audit.jsonl.1"
    bak2 = tmp_path / "audit.jsonl.2"
    bak3 = tmp_path / "audit.jsonl.3"
    assert main.exists() and bak1.exists() and bak2.exists()
    assert not bak3.exists(), "при keep=2 третьего бэкапа быть не должно"
    assert main.stat().st_size <= 1024 + 200  # не раздувается бесконечно

    # keep=0 — файл обнуляется, бэкапов нет
    audit0 = AuditLog(tmp_path / "audit0.jsonl", max_bytes=1024, keep=0)
    for i in range(30):
        audit0.record(f"c{i}", decision="executed", detail="y" * 40)
    assert not (tmp_path / "audit0.jsonl.1").exists()


# ---------------------------------------------------------------------------
# Деградация
# ---------------------------------------------------------------------------
def test_degraded_when_path_is_directory(tmp_path: Path) -> None:
    bad = tmp_path / "dir.jsonl"
    bad.mkdir()
    audit = AuditLog(bad)
    event = audit.record("x", decision="executed")
    assert audit.degraded, "файл-папка должна дать деградацию в память"
    assert event in audit.recent(10)
    assert audit.read_file() == []


def test_memory_only_mode() -> None:
    audit = AuditLog(None)
    audit.record("x", decision="auto", risk="medium")
    assert audit.path is None and not audit.degraded
    assert audit.query(risk="medium")[0].action == "x"
    assert audit.read_file() == []


# ---------------------------------------------------------------------------
# Потокобезопасность
# ---------------------------------------------------------------------------
def test_concurrent_records(tmp_path: Path) -> None:
    audit = _make(tmp_path)

    def worker(n: int) -> None:
        for i in range(20):
            audit.record(f"t{n}_{i}", decision="executed")

    threads = [threading.Thread(target=worker, args=(n,)) for n in range(5)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert audit.total == 100
    assert len(audit.read_file()) == 100
    assert len(audit.recent(200)) == 100


if __name__ == "__main__":
    import tempfile
    import traceback

    tests = [(k, v) for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    base = Path(".openclaw/tmp")
    base.mkdir(parents=True, exist_ok=True)
    for name, fn in tests:
        try:
            if fn.__code__.co_argcount == 0:
                fn()
            else:
                fn(Path(tempfile.mkdtemp(dir=base)))
            print(f"  ok  {name}")
        except Exception:
            failed += 1
            print(f"FAIL  {name}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
