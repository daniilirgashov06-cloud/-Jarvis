"""
Проверка модуля audio/vad: конфиг кадров, движки (energy / webrtcvad),
роутер с fallback, конечный автомат сегментации речи.

Запуск:  python3 tests/test_vad.py
"""

from __future__ import annotations

import math
import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from audio.vad import (
    EnergyVAD,
    SileroVAD,
    VADEngine,
    VADError,
    VADEvent,
    VADRouter,
    VADResult,
    VADUnavailable,
    VoiceActivityDetector,
    WebRTCVAD,
    create_default_router,
    VADConfig,
)


# ---------------------------------------------------------------------------
# Хелперы синтеза PCM (s16le, 16 кГц, моно)
# ---------------------------------------------------------------------------
def silence(frames: int = 1, config: VADConfig | None = None) -> bytes:
    cfg = config or VADConfig()
    return b"\x00\x00" * cfg.frame_samples * frames


def tone(frames: int = 1, amplitude: float = 0.5, freq: float = 440.0,
         config: VADConfig | None = None) -> bytes:
    cfg = config or VADConfig()
    out = bytearray()
    for _ in range(frames):
        for i in range(cfg.frame_samples):
            sample = amplitude * 32767.0 * math.sin(2.0 * math.pi * freq * i / cfg.sample_rate)
            out += struct.pack("<h", int(sample))
    return bytes(out)


class FakeEngine(VADEngine):
    """Движок-заглушка: заданный сценарий вердиктов либо отказ."""

    name = "fake"

    def __init__(self, available: bool = True, fail: bool = False) -> None:
        self.available = available
        self.fail = fail
        self.calls = 0

    def is_available(self) -> bool:
        return self.available

    def detect(self, pcm: bytes, *, sample_rate: int = 16000) -> VADResult:
        self.calls += 1
        if self.fail:
            raise VADUnavailable("fake: отказ")
        is_speech = any(pcm)  # ненулевые сэмплы = «речь»
        return VADResult(is_speech=is_speech, score=1.0 if is_speech else 0.0, engine=self.name)


# ---------------------------------------------------------------------------
def test_vad_config_geometry() -> None:
    cfg = VADConfig()
    assert cfg.frame_samples == 320, f"frame_samples={cfg.frame_samples}"
    assert cfg.frame_bytes == 640, f"frame_bytes={cfg.frame_bytes}"
    assert cfg.ms_to_frames(200) == 10, "min_speech_ms=200 → 10 кадров"
    assert cfg.ms_to_frames(0) == 1, "0 мс → минимум 1 кадр"
    cfg30 = VADConfig(frame_ms=30)
    assert cfg30.frame_samples == 480, f"frame_samples@30ms={cfg30.frame_samples}"
    print("  ✓ config: геометрия кадров и перевод мс → кадры")


def test_energy_vad_silence_and_tone() -> None:
    vad = EnergyVAD(threshold=0.5, adapt=False, noise_floor_db=-50.0)
    assert vad.is_available(), "EnergyVAD должен быть доступен всегда"
    res_sil = vad.detect(silence(1))
    assert not res_sil.is_speech, f"тишина распознана как речь: {res_sil}"
    assert res_sil.score == 0.0, f"score тишины={res_sil.score}"
    res_tone = vad.detect(tone(1, amplitude=0.5))
    assert res_tone.is_speech, f"громкий тон не распознан: {res_tone}"
    assert res_tone.score >= 0.5, f"score тона={res_tone.score}"
    try:
        vad.detect(b"")
    except VADError:
        pass
    else:
        assert False, "пустой PCM должен давать VADError"
    print("  ✓ energy: тишина vs тон, ошибка на пустом PCM")


def test_energy_vad_adaptive_floor() -> None:
    vad = EnergyVAD(threshold=0.5, adapt=True, noise_floor_db=-50.0)
    for _ in range(20):
        vad.detect(silence(1))
    assert vad.noise_floor_db <= -50.0, f"пол шума не опустился: {vad.noise_floor_db}"
    for _ in range(50):
        vad.detect(tone(1, amplitude=0.05))
    assert vad.noise_floor_db <= -20.0, f"пол шума улетел в потолок: {vad.noise_floor_db}"
    print("  ✓ energy: адаптация шумового пола ограничена [-90, -20] дБ")


def test_webrtcvad_availability_contract() -> None:
    vad = WebRTCVAD()
    if not vad.is_available():
        try:
            vad.detect(tone(1))
        except VADUnavailable:
            pass
        else:
            assert False, "без webrtcvad detect() обязан бросать VADUnavailable"
        print("  ✓ webrtcvad: не установлен → VADUnavailable (контракт fallback)")
        return
    res = vad.detect(tone(3))
    assert isinstance(res, VADResult), f"не VADResult: {res}"
    print("  ✓ webrtcvad: установлен → детекция работает")


def test_silero_availability_contract() -> None:
    vad = SileroVAD()
    if not vad.is_available():
        try:
            vad.detect(tone(1))
        except VADUnavailable:
            pass
        else:
            assert False, "без torch detect() обязан бросать VADUnavailable"
    print("  ✓ silero: контракт недоступности проверен")


def test_router_fallback_and_switch() -> None:
    fake_fail = FakeEngine(fail=True)
    energy = EnergyVAD(threshold=0.5, adapt=False)
    router = VADRouter(
        engines={"fake": fake_fail, "energy": energy},
        primary="fake",
        fallback_chain=["fake", "energy"],
    )
    res = router.detect(silence(1))
    assert res.engine == "energy", f"fallback не сработал: {res}"
    assert fake_fail.calls == 1, "fake должен был попробоваться первым"

    router.set_primary("energy")
    assert router.primary == "energy", "set_primary не переключил"
    res = router.detect(tone(1))
    assert res.engine == "energy", f"primary не energy: {res}"
    assert "energy" in router.available(), "energy должен быть в available()"

    try:
        router.set_primary("nope")
    except VADError:
        pass
    else:
        assert False, "неизвестный движок должен давать VADError"

    dead = VADRouter(engines={"x": FakeEngine(available=False)}, primary="x")
    try:
        dead.detect(silence(1))
    except VADError:
        pass
    else:
        assert False, "без рабочих движков — VADError"
    print("  ✓ router: fallback, смена primary, недоступные движки")


def test_router_forced_engine() -> None:
    fake = FakeEngine()
    energy = EnergyVAD(threshold=0.5, adapt=False)
    router = VADRouter(engines={"fake": fake, "energy": energy}, primary="energy")
    res = router.detect(tone(1), engine="fake")
    assert res.engine == "fake", f"явный движок не использован: {res}"
    print("  ✓ router: явный выбор движка (engine=...)")


def test_segmentation_start_end_and_preroll() -> None:
    cfg = VADConfig(min_speech_ms=60, min_silence_ms=60, preroll_ms=40)  # 3/3/2 кадра
    fake = FakeEngine()
    det = VoiceActivityDetector(
        router=VADRouter(engines={"fake": fake}, primary="fake"), config=cfg
    )

    # 2 кадра тишины (pre-roll) → 4 кадра «речи» → 4 кадра тишины
    stream = silence(2, cfg) + tone(4, config=cfg) + silence(4, cfg)
    events = det.feed(stream)

    starts = [e for e in events if e.is_start]
    ends = [e for e in events if e.is_end]
    assert len(starts) == 1, f"starts={len(starts)}"
    assert len(ends) == 1, f"ends={len(ends)}"
    assert ends[0].pcm, "speech_end без PCM фразы"
    # Фраза = pre-roll (2) + речь (4) + хвост тишины (3) = 9 кадров
    frames = len(ends[0].pcm) // cfg.frame_bytes
    assert frames == 9, f"фраза = {frames} кадров, ждали 9 (2+4+3)"
    assert not det.in_speech, "автомат не вернулся в тишину"
    print("  ✓ segmentation: start/end, pre-roll и хвост тишины во фрагменте")


def test_segmentation_requires_min_speech() -> None:
    cfg = VADConfig(min_speech_ms=100, min_silence_ms=60)  # 5 кадров до подтверждения
    det = VoiceActivityDetector(
        router=VADRouter(engines={"fake": FakeEngine()}, primary="fake"), config=cfg
    )
    # Короткий «всплеск» — 2 кадра речи, не должен подтвердиться
    events = det.feed(tone(2, config=cfg) + silence(3, cfg))
    assert events == [], f"ложное срабатывание: {events}"
    assert not det.in_speech, "короткий всплеск не должен открывать фразу"
    print("  ✓ segmentation: короткий всплеск игнорируется (min_speech_ms)")


def test_segmentation_second_utterance_and_flush() -> None:
    cfg = VADConfig(min_speech_ms=20, min_silence_ms=20, preroll_ms=20)  # 1/1/1 кадр
    det = VoiceActivityDetector(
        router=VADRouter(engines={"fake": FakeEngine()}, primary="fake"), config=cfg
    )
    stream = tone(3, config=cfg) + silence(2, cfg) + tone(3, config=cfg) + silence(2, cfg)
    events = det.feed(stream)
    starts = [e for e in events if e.is_start]
    ends = [e for e in events if e.is_end]
    assert len(starts) == 2, f"starts={len(starts)}"
    assert len(ends) == 2, f"ends={len(ends)}"

    # Незавершённая фраза + flush
    det.feed(tone(3, config=cfg))
    assert det.in_speech, "фраза должна быть открыта"
    assert det.current_pcm, "current_pcm пуст при открытой фразе"
    tail = det.flush()
    assert len(tail) == 1 and tail[0].is_end, f"flush: {tail}"
    assert tail[0].pcm, "flush без PCM"
    assert det.flush() == [], "повторный flush должен быть пустым"
    print("  ✓ segmentation: две фразы подряд + flush незавершённой")


def test_segmentation_max_speech_guard() -> None:
    cfg = VADConfig(min_speech_ms=20, min_silence_ms=20, max_speech_ms=100)  # 5 кадров
    det = VoiceActivityDetector(
        router=VADRouter(engines={"fake": FakeEngine()}, primary="fake"), config=cfg
    )
    events = det.feed(tone(20, config=cfg))  # 20 кадров без тишины
    ends = [e for e in events if e.is_end]
    assert ends, "max_speech_ms не закрыл залипшую речь"
    assert not det.in_speech, "автомат не сброшен после max_speech"
    print("  ✓ segmentation: предохранитель max_speech_ms")


def test_default_router_chain() -> None:
    router = create_default_router()
    assert router.primary == "webrtcvad", f"primary={router.primary}"
    assert "energy" in router.available(), "energy обязан быть доступен"
    # Даже без webrtcvad/silero запрос должен пройти через fallback на energy
    res = router.detect(tone(2))
    assert res.engine in ("webrtcvad", "silero", "energy"), f"engine={res.engine}"
    assert router.detect(silence(2)).score == 0.0, "тишина через роутер ≠ 0"
    print("  ✓ default router: цепочка webrtcvad → silero → energy работает")


def test_vad_result_score_clamped() -> None:
    r = VADResult(is_speech=True, score=1.7, engine="x")
    assert r.score == 1.0, f"score не зажат: {r.score}"
    r2 = VADResult(is_speech=False, score=-0.2, engine="x")
    assert r2.score == 0.0, f"score не зажат: {r2.score}"
    e = VADEvent(kind="speech_start", score=0.9)
    assert e.is_start and not e.is_end, "геттеры VADEvent"
    print("  ✓ VADResult: score зажимается в [0..1], геттеры VADEvent")


# ---------------------------------------------------------------------------
def main() -> int:
    print("JARVIS CORE — проверка audio/vad")
    try:
        test_vad_config_geometry()
        test_energy_vad_silence_and_tone()
        test_energy_vad_adaptive_floor()
        test_webrtcvad_availability_contract()
        test_silero_availability_contract()
        test_router_fallback_and_switch()
        test_router_forced_engine()
        test_segmentation_start_end_and_preroll()
        test_segmentation_requires_min_speech()
        test_segmentation_second_utterance_and_flush()
        test_segmentation_max_speech_guard()
        test_default_router_chain()
        test_vad_result_score_clamped()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модуля прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
