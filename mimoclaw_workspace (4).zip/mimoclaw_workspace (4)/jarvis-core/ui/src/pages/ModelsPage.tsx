/**
 * Модели — LLM-провайдеры, роутинг и лимиты.
 */

import { useEffect } from "react";
import { Card, PageHeader } from "../components/ui/panels";
import { SettingsSaveBar } from "../components/SettingsSaveBar";
import { Chip, FieldRow, SelectField, Slider, TextField, Toggle } from "../components/ui/controls";
import type { LLMProviderConfig, Settings } from "../types/settings";
import { useSettingsStore } from "../stores/settingsStore";

const PROVIDERS: Array<keyof Pick<Settings["ai"], "ollama" | "openai" | "anthropic" | "gemini">> = [
  "ollama",
  "openai",
  "anthropic",
  "gemini",
];

const PROVIDER_LABEL: Record<string, string> = {
  ollama: "Ollama (локально)",
  openai: "OpenAI",
  anthropic: "Anthropic",
  gemini: "Google Gemini",
};

export function ModelsPage() {
  const ai = useSettingsStore((s) => s.data.ai);
  const loaded = useSettingsStore((s) => s.loaded);
  const patch = useSettingsStore((s) => s.patch);

  useEffect(() => {
    if (!loaded) void useSettingsStore.getState().load();
  }, [loaded]);

  const toggleFallback = (name: string) => {
    const chain = ai.fallback_chain.includes(name)
      ? ai.fallback_chain.filter((p) => p !== name)
      : [...ai.fallback_chain, name];
    patch("ai", { fallback_chain: chain });
  };

  const patchProvider = (name: keyof Settings["ai"], values: Partial<LLMProviderConfig>) => {
    const current = ai[name] as LLMProviderConfig;
    patch("ai", { [name]: { ...current, ...values } } as Partial<Settings["ai"]>);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Модели"
        subtitle="Провайдеры LLM, цепочка автопереключения и бюджет запросов."
        actions={
          <Chip accent>
            <span className="uppercase tracking-wider">ключи API — из .env</span>
          </Chip>
        }
      />

      <Card title="Роутинг" subtitle="Основной провайдер и запасные варианты">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <SelectField
            label="Основной провайдер"
            value={ai.primary}
            onChange={(e) => patch("ai", { primary: e.target.value })}
            options={PROVIDERS.map((p) => ({ value: p, label: PROVIDER_LABEL[p] ?? p }))}
          />
          <div>
            <p className="text-sm text-text">Цепочка fallback</p>
            <p className="text-xs text-muted">При отказе провайдера запрос уходит дальше по цепочке</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {PROVIDERS.map((p) => (
                <Chip
                  key={p}
                  accent={ai.fallback_chain.includes(p)}
                  onRemove={undefined}
                >
                  <button type="button" onClick={() => toggleFallback(p)}>
                    {PROVIDER_LABEL[p] ?? p}
                  </button>
                </Chip>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
          <TextField
            label="Лимит токенов в день"
            type="number"
            min={0}
            value={String(ai.daily_token_limit)}
            onChange={(e) => patch("ai", { daily_token_limit: Number(e.target.value) })}
            hint="0 — без ограничения"
          />
          <TextField
            label="Лимит расходов в день, $"
            type="number"
            min={0}
            step={0.5}
            value={String(ai.daily_spend_limit_usd)}
            onChange={(e) => patch("ai", { daily_spend_limit_usd: Number(e.target.value) })}
            hint="Для облачных провайдеров"
          />
        </div>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {PROVIDERS.map((name, i) => {
          const provider = ai[name] as LLMProviderConfig;
          return (
            <Card
              key={name}
              title={PROVIDER_LABEL[name] ?? name}
              subtitle={provider.enabled ? "активен" : "отключён"}
              delay={i * 0.05}
              right={
                <Toggle
                  checked={provider.enabled}
                  onChange={(v) => patchProvider(name, { enabled: v })}
                  label={`Включить ${name}`}
                />
              }
            >
              <div className="space-y-3">
                <TextField
                  label="Модель"
                  value={provider.model}
                  placeholder="имя модели"
                  onChange={(e) => patchProvider(name, { model: e.target.value })}
                />
                <TextField
                  label="Base URL"
                  value={provider.base_url ?? ""}
                  placeholder="оставьте пустым для облака"
                  onChange={(e) => patchProvider(name, { base_url: e.target.value || null })}
                />
                <Slider
                  label="Температура"
                  min={0}
                  max={2}
                  value={provider.temperature}
                  onChange={(v) => patchProvider(name, { temperature: v })}
                  format={(v) => v.toFixed(2)}
                  hint="Выше — креативнее, ниже — точнее"
                />
                <TextField
                  label="Максимум токенов"
                  type="number"
                  min={1}
                  value={String(provider.max_tokens)}
                  onChange={(e) => patchProvider(name, { max_tokens: Number(e.target.value) })}
                />
              </div>
            </Card>
          );
        })}
      </div>

      <SettingsSaveBar />
    </div>
  );
}
