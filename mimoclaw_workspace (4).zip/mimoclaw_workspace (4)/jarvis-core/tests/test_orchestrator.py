"""
Проверка core/orchestrator.py — сквозной пайплайн на моках.

Запуск:  python3 tests/test_orchestrator.py
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from actions.registry import CommandRegistry, RiskLevel, command, registry
from ai.function_calling import to_openai_tools
from ai.llm_router import LLMRouter
from ai.providers.base import BaseLLMProvider, LLMMessage, LLMResponse, ToolCall, Usage
from core.orchestrator import Orchestrator
from speech.tts_engine import SpeechAudio, TTSRouter, VoicePreset


class ScriptedLLM(BaseLLMProvider):
    """Мок-LLM: отдаёт заранее заданную последовательность ответов."""

    name = "mock"
    def __init__(self, responses: list[LLMResponse]) -> None:
        self.responses = responses
        self.calls = 0

    def is_available(self) -> bool:
        return True

    async def complete(self, messages, tools=None, *, temperature=0.7, max_tokens=2048):
        resp = self.responses[min(self.calls, len(self.responses) - 1)]
        self.calls += 1
        resp.provider = self.name  # как настоящий провайдер — проставляем своё имя
        return resp


class EchoTTS:
    name = "echo"
    def is_available(self) -> bool:
        return True
    async def synthesize(self, text, *, preset=None) -> SpeechAudio:
        return SpeechAudio(pcm=text.encode(), engine=self.name)


# Реальная команда для теста function calling
@command(name="set_volume", description="Установить громкость",
         params={"level": {"type": "number", "description": "0..100"}},
         risk=RiskLevel.SAFE)
def set_volume(level: float) -> str:
    return f"громкость {int(level)}%"


@command(name="forbidden_thing", description="Запрещено", risk=RiskLevel.FORBIDDEN)
def forbidden_thing() -> str:
    return "не должно выполниться"


def _llm_router_with(scripted: ScriptedLLM) -> LLMRouter:
    return LLMRouter(providers={"mock": scripted}, primary="mock", fallback_chain=["mock"])


async def test_pipeline_with_tool_call() -> None:
    """LLM зовёт set_volume -> действие -> LLM формулирует финальный ответ."""
    responses = [
        LLMResponse(content="", tool_calls=[ToolCall(id="c1", name="set_volume", arguments={"level": 50})]),
        LLMResponse(content="Готово, сэр. Громкость 50%."),
    ]
    scripted = ScriptedLLM(responses)
    orch = Orchestrator(
        llm=_llm_router_with(scripted),
        tts=TTSRouter(engines={"echo": EchoTTS()}, primary="echo"),
        registry=registry,
        speak=True,
    )
    result = await orch.process_text("поставь громкость 50")
    assert result.reply == "Готово, сэр. Громкость 50%."
    assert len(result.actions) == 1
    assert result.actions[0].name == "set_volume" and result.actions[0].ok is True
    assert "50" in str(result.actions[0].output)
    assert result.used_provider == "mock"
    assert result.audio == "Готово, сэр. Громкость 50%.".encode() and result.used_tts == "echo"
    print("  ✓ orchestrator: tool call -> действие -> финальный ответ -> TTS")


async def test_pipeline_plain_text() -> None:
    """Без действий — просто текстовый ответ."""
    scripted = ScriptedLLM([LLMResponse(content="Привет, сэр.")])
    orch = Orchestrator(llm=_llm_router_with(scripted), speak=False, registry=registry)
    result = await orch.process_text("привет")
    assert result.reply == "Привет, сэр." and result.actions == []
    print("  ✓ orchestrator: простой текстовый ответ без действий")


async def test_pipeline_forbidden_command() -> None:
    """FORBIDDEN-команда не выполняется, ошибка возвращается LLM."""
    responses = [
        LLMResponse(content="", tool_calls=[ToolCall(id="c1", name="forbidden_thing", arguments={})]),
        LLMResponse(content="Не могу выполнить это, сэр."),
    ]
    scripted = ScriptedLLM(responses)
    orch = Orchestrator(llm=_llm_router_with(scripted), speak=False, registry=registry)
    result = await orch.process_text("сделай запрещённое")
    assert len(result.actions) == 1 and result.actions[0].ok is False
    assert "запрещена" in result.actions[0].error
    print("  ✓ orchestrator: FORBIDDEN-команда блокируется, ошибка уходит в LLM")


async def test_pipeline_unknown_action() -> None:
    """Вызов несуществующей команды не роняет пайплайн."""
    responses = [
        LLMResponse(content="", tool_calls=[ToolCall(id="c1", name="nope", arguments={})]),
        LLMResponse(content="Такой команды нет."),
    ]
    scripted = ScriptedLLM(responses)
    orch = Orchestrator(llm=_llm_router_with(scripted), speak=False, registry=registry)
    result = await orch.process_text("вызови nope")
    assert result.actions[0].ok is False and "неизвестная" in result.actions[0].error
    print("  ✓ orchestrator: неизвестная команда обрабатывается мягко")


def test_registry_tools_feed_llm() -> None:
    tools = to_openai_tools(registry.enabled_tools())
    names = {t["function"]["name"] for t in tools}
    assert "set_volume" in names and "forbidden_thing" in names
    print("  ✓ orchestrator: реестр отдаёт схемы tools для LLM")


async def _run_async() -> None:
    await test_pipeline_with_tool_call()
    await test_pipeline_plain_text()
    await test_pipeline_forbidden_command()
    await test_pipeline_unknown_action()


def main() -> int:
    print("JARVIS CORE — проверка оркестратора")
    try:
        test_registry_tools_feed_llm()
        asyncio.run(_run_async())
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки оркестратора прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
