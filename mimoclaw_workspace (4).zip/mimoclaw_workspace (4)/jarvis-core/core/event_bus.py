"""
Внутренняя шина событий (pub/sub) JARVIS CORE.

Модули общаются через шину, чтобы добавлять плагины без правки ядра.
Поддерживает синхронные и асинхронные подписчиков, отложенную доставку
и «жёсткие» события (ошибки), которые нельзя терять.

Использование:
    bus = EventBus()
    bus.subscribe("stt.transcript", on_transcript)
    await bus.publish("stt.transcript", {"text": "привет"})
"""

from __future__ import annotations

import asyncio
import fnmatch
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

# Обработчик события: принимает имя + payload.
Subscriber = Callable[[str, dict[str, Any]], Any]


@dataclass
class Subscription:
    """Одна подписка на событие."""

    pattern: str
    callback: Subscriber
    once: bool = False


class EventBus:
    """
    Асинхронная шина событий с поддержкой wildcard-паттернов.

    - ``subscribe("stt.*", handler)`` — сработает на любой топик, начинающийся с stt.
    - ``publish`` дожидается корутин-обработчиков, но не падает, если обработчик
      синхронный или бросил исключение (ошибка логируется, событие не теряется).
    """

    def __init__(self) -> None:
        self._subs: dict[str, list[Subscription]] = defaultdict(list)
        self._lock = asyncio.Lock()
        self._history: list[tuple[str, dict[str, Any]]] = []

    def subscribe(
        self,
        pattern: str,
        callback: Subscriber,
        *,
        once: bool = False,
    ) -> Callable[[], None]:
        """
        Подписаться на событие/паттерн. Возвращает функцию отписки.

        pattern: точное имя ("stt.transcript") или wildcard ("stt.*", "*").
        """
        sub = Subscription(pattern=pattern, callback=callback, once=once)
        self._subs[pattern].append(sub)

        def _unsubscribe() -> None:
            try:
                self._subs[pattern].remove(sub)
            except (KeyError, ValueError):
                pass

        return _unsubscribe

    def unsubscribe(self, pattern: str, callback: Subscriber) -> None:
        """Отписаться от события по паттерну и обработчику."""
        for sub in list(self._subs.get(pattern, [])):
            if sub.callback is callback:
                self._subs[pattern].remove(sub)

    async def publish(
        self,
        topic: str,
        payload: dict[str, Any] | None = None,
    ) -> int:
        """
        Опубликовать событие. Возвращает число вызванных обработчиков.

        Ошибки в обработчиках логируются и не прерывают доставку остальным.
        """
        payload = payload or {}
        self._history.append((topic, payload))
        if len(self._history) > 1000:
            self._history = self._history[-500:]

        matched: list[Subscription] = []
        for pattern, subs in self._subs.items():
            if fnmatch.fnmatch(topic, pattern):
                matched.extend(subs)

        called = 0
        for sub in matched:
            if sub.once:
                self._subs[sub.pattern].remove(sub)
            try:
                result = sub.callback(topic, payload)
                if asyncio.iscoroutine(result):
                    await result  # type: ignore[misc]
                called += 1
            except Exception:  # noqa: BLE001 — обработчик не должен ронять шину
                logger.exception("Обработчик '%s' упал на событии '%s'", sub.pattern, topic)
        return called

    def publish_sync(self, topic: str, payload: dict[str, Any] | None = None) -> None:
        """
        Синхронная публикация для не-async контекстов (например, из GUI-потока).
        Запускает асинхронную доставу в текущем цикле событий, если он есть.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            asyncio.run(self.publish(topic, payload))
            return
        loop.create_task(self.publish(topic, payload))

    def topics(self) -> list[str]:
        """Список всех известных топиков подписки."""
        return list(self._subs.keys())


# Глобальная шина приложения (единая точка доступа)
bus = EventBus()
