"""
Проверка actions/system_actions.py — системные команды.

Запуск:  python3 tests/test_system_actions.py
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from actions.registry import CommandRegistry, RiskLevel
from actions.system_actions import (
    DryRunBackend,
    SubprocessBackend,
    SystemActions,
    SystemUnavailable,
    register_system_actions,
)


# ---------------------------------------------------------------------------
# Хелперы
# ---------------------------------------------------------------------------
def _raises(exc_type, fn, *args, **kwargs) -> str:
    """Проверяет, что fn бросает exc_type; возвращает текст ошибки."""
    try:
        fn(*args, **kwargs)
    except exc_type as e:
        return str(e)
    raise AssertionError(f"ожидался {exc_type.__name__}, но ошибки не было")


# ---------------------------------------------------------------------------
# Тесты: DryRunBackend + валидация
# ---------------------------------------------------------------------------
def test_dry_run_volume_and_mute() -> None:
    svc = SystemActions(backend=DryRunBackend(volume=30))
    assert svc.get_volume() == 30
    assert "45%" in svc.set_volume(45.4), "дробное значение должно округляться"
    assert svc.backend.volume == 45
    assert svc.backend.calls[-1] == ("set_volume", (45,))
    assert "выключен" in svc.set_mute(True)
    assert svc.backend.muted is True

    msg = _raises(ValueError, svc.set_volume, 150)
    assert "0..100" in msg
    _raises(ValueError, svc.set_volume, -1)
    _raises(ValueError, svc.set_volume, True)  # bool — не число
    _raises(ValueError, svc.set_mute, "yes")


def test_dry_run_power_and_url() -> None:
    backend = DryRunBackend()
    svc = SystemActions(backend=backend)

    assert "заблокирован" in svc.lock_screen().lower()
    assert "Выключение" in svc.shutdown(30)
    assert "Перезагрузка" in svc.restart(0)
    assert "усып" in svc.sleep().lower()

    assert backend.calls[:4] == [
        ("lock", ()),
        ("shutdown", (30,)),
        ("restart", (0,)),
        ("sleep", ()),
    ]

    assert "ya.ru" in svc.open_url("https://ya.ru/path")
    assert backend.calls[-1] == ("open_url", ("https://ya.ru/path",))

    _raises(ValueError, svc.open_url, "ftp://host/file")
    _raises(ValueError, svc.open_url, "file:///etc/passwd")
    _raises(ValueError, svc.open_url, "")
    _raises(ValueError, svc.shutdown, -5)
    _raises(ValueError, svc.restart, 2.5)


def test_unavailable_backend() -> None:
    svc = SystemActions(backend=DryRunBackend(available=False))
    _raises(SystemUnavailable, svc.system_info)
    _raises(SystemUnavailable, svc.set_volume, 10)
    _raises(SystemUnavailable, svc.lock_screen)


# ---------------------------------------------------------------------------
# Тесты: SubprocessBackend (подменённый runner)
# ---------------------------------------------------------------------------
class RecordingRunner:
    """Фейковый runner: запоминает argv и возвращает заданный stdout."""

    def __init__(self, output: str = "") -> None:
        self.output = output
        self.calls: list[list[str]] = []

    def __call__(self, argv: list[str]) -> str:
        self.calls.append(list(argv))
        return self.output


def test_subprocess_linux_commands() -> None:
    runner = RecordingRunner(output="Front Left: Playback 42 [42%]")
    backend = SubprocessBackend(runner=runner, platform_name="Linux")

    assert backend.is_available()
    assert backend.get_volume() == 42
    backend.set_volume(77)
    backend.set_mute(True)
    backend.lock()
    backend.shutdown(120)
    backend.restart(0)
    backend.open_url("https://example.com")

    assert runner.calls[0][:2] == ["amixer", "get"]
    assert runner.calls[1] == ["amixer", "set", "Master", "77%"]
    assert runner.calls[2] == ["amixer", "set", "Master", "mute"]
    assert runner.calls[3] == ["loginctl", "lock-session"] or runner.calls[3][0] == "xdg-screensaver"
    assert runner.calls[4][:3] == ["shutdown", "-h", "+2"]
    assert runner.calls[5][:3] == ["shutdown", "-r", "+0"]
    assert runner.calls[6] in (["xdg-open", "https://example.com"], ["sensible-browser", "https://example.com"])


def test_subprocess_darwin_commands_and_parse_errors() -> None:
    runner = RecordingRunner(output="55")
    backend = SubprocessBackend(runner=runner, platform_name="Darwin")

    assert backend.get_volume() == 55
    backend.set_volume(10)
    backend.set_mute(False)
    backend.lock()
    assert runner.calls[1] == ["osascript", "-e", "set volume output volume 10"]
    assert runner.calls[2] == ["osascript", "-e", "set volume output muted false"]
    assert runner.calls[3] == ["pmset", "displaysleepnow"]

    bad = SubprocessBackend(runner=RecordingRunner(output="тишина"), platform_name="Darwin")
    _raises(Exception, bad.get_volume)

    unknown = SubprocessBackend(runner=RecordingRunner(), platform_name="Plan9")
    assert not unknown.is_available()
    _raises(SystemUnavailable, SystemActions(backend=unknown).system_info)


# ---------------------------------------------------------------------------
# Тесты: регистрация команд
# ---------------------------------------------------------------------------
def test_register_system_actions() -> None:
    reg = CommandRegistry()
    names = register_system_actions(reg, SystemActions(backend=DryRunBackend()))

    expected = {
        "system_info", "get_volume", "set_volume", "set_mute",
        "open_url", "lock_screen", "sleep_system",
        "shutdown_system", "restart_system",
    }
    assert set(names) == expected
    assert set(reg.names()) == expected

    # Уровни риска и подтверждения
    assert reg.get("system_info").risk == RiskLevel.SAFE
    assert not reg.get("system_info").requires_confirmation
    assert reg.get("open_url").risk == RiskLevel.MEDIUM
    assert reg.get("open_url").requires_confirmation
    assert reg.get("shutdown_system").risk == RiskLevel.HIGH
    assert reg.get("shutdown_system").requires_confirmation
    assert reg.get("restart_system").risk == RiskLevel.HIGH

    # Схемы для function calling
    tools = reg.enabled_tools()
    assert len(tools) == len(expected)
    volume_tool = reg.get("set_volume").to_tool()
    assert volume_tool.params[0].name == "level"
    assert volume_tool.params[0].type == "number"
    shutdown_tool = reg.get("shutdown_system").to_tool()
    assert shutdown_tool.params[0].required is False


def test_commands_run_through_registry() -> None:
    backend = DryRunBackend(volume=20)
    reg = CommandRegistry()
    register_system_actions(reg, SystemActions(backend=backend))

    async def _run() -> None:
        cmd = reg.get("set_volume")
        result = await cmd.run(level=64)
        assert "64%" in result
        assert backend.volume == 64
        info = await reg.get("system_info").run()
        assert info["platform"] == "dry-run"

    asyncio.run(_run())
    assert ("set_volume", (64,)) in backend.calls
    assert ("system_info", ()) in backend.calls


# ---------------------------------------------------------------------------
# Запуск
# ---------------------------------------------------------------------------
def main() -> int:
    print("JARVIS CORE — проверка actions/system_actions")
    try:
        test_dry_run_volume_and_mute()
        test_dry_run_power_and_url()
        test_unavailable_backend()
        test_subprocess_linux_commands()
        test_subprocess_darwin_commands_and_parse_errors()
        test_register_system_actions()
        test_commands_run_through_registry()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модулей прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
