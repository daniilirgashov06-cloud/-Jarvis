"""
Детектор слова активации (wake-word) JARVIS CORE.

Единый контракт ``WakeWordEngine`` + диспетчер ``WakeWordRouter`` с **живой
сменой** движков и fallback (по образцу ``audio/vad.VADRouter``). Движки:

  * ``OpenWakeWordEngine``     — openwakeword (нейросеть, локально,
    предобученная модель ``hey_jarvis`` подходит под «Джарвис»);
  * ``TemplateWakeWordEngine`` — чистый Python: DTW-сопоставление огибающей
    PCM с эталонными шаблонами. Мало точен, но работает без зависимостей —
    эталонный fallback и отладка.

Wake-word работает **только локально** (on-device): детектор слушает микрофон
постоянно, поэтому локально ↔ облако здесь уместно лишь для последующего
распознавания команды (см. ``speech/stt_engine``). Непрерывно стримить звук
в облако ради триггера — и задержка, и дыра в приватности.

Поверх движков — ``WakeWordDetector``: кадры PCM → события ``WakeWordEvent``
с окном звука (можно сразу скармливать STT) и защитой от повторных
срабатываний (cooldown).
"""

from __future__ import annotations

import abc
import logging
import math
from array import array
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Sequence

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class WakeWordError(Exception):
    """Ошибка детекции слова активации."""


class WakeWordUnavailable(WakeWordError):
    """Движок недоступен (нет библиотеки/модели/шаблонов) — можно fallback."""


# ---------------------------------------------------------------------------
# Утилиты
# ---------------------------------------------------------------------------
def normalize_word(word: str) -> str:
    """Нормализовать слово активации: нижний регистр, без лишних пробелов."""
    return word.strip().lower()


# ---------------------------------------------------------------------------
# Конфигурация и результат
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class WakeWordConfig:
    """Параметры wake-word. Дефолты — под «Джарвис/Пятницу» из ТЗ."""

    sample_rate: int = 16000
    frame_ms: int = 20
    #: Слова активации (нормализуются к нижнему регистру).
    words: tuple[str, ...] = ("джарвис", "jarvis", "пятница", "friday")
    #: Порог уверенности (0..1), см. ``config/settings.WakeWordConfig.confidence``.
    threshold: float = 0.5
    #: «Тихий период» после срабатывания — защита от двойных триггеров.
    cooldown_ms: int = 1500
    #: Размер окна аудио, которое анализирует движок (и отдаёт в событии).
    window_ms: int = 1800

    def __post_init__(self) -> None:
        # Слова храним кортежем нормализованных строк — конфиг неизменяем.
        object.__setattr__(
            self, "words", tuple(normalize_word(w) for w in self.words if w.strip())
        )

    @property
    def frame_samples(self) -> int:
        """Число сэмплов на кадр (20 мс @ 16 кГц = 320)."""
        return self.sample_rate * self.frame_ms // 1000

    @property
    def frame_bytes(self) -> int:
        """Размер кадра PCM s16le в байтах (320 × 2 = 640)."""
        return self.frame_samples * 2

    @property
    def window_samples(self) -> int:
        """Число сэмплов в окне анализа."""
        return self.sample_rate * self.window_ms // 1000

    @property
    def window_bytes(self) -> int:
        """Размер окна анализа PCM s16le в байтах."""
        return self.window_samples * 2

    def ms_to_frames(self, ms: int) -> int:
        """Перевести миллисекунды в целое число кадров (минимум 1)."""
        return max(1, round(ms / self.frame_ms))


@dataclass(frozen=True)
class WakeWordResult:
    """Вердикт движка: сработало ли слово активации и с какой уверенностью."""

    detected: bool
    word: str = ""
    score: float = 0.0
    engine: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "word", normalize_word(self.word))
        # Единая шкала уверенности [0..1] для всех движков.
        if not 0.0 <= self.score <= 1.0:
            object.__setattr__(self, "score", min(1.0, max(0.0, float(self.score))))


# ---------------------------------------------------------------------------
# Контракт движка
# ---------------------------------------------------------------------------
class WakeWordEngine(abc.ABC):
    """Контракт движка wake-word: вердикт по куску PCM s16le.

    Движок сам держит нужное внутреннее окно/состояние между вызовами
    ``detect`` — снаружи можно скармливать кадры любого размера.
    """

    name: str = "base"

    @abc.abstractmethod
    def is_available(self) -> bool:
        """Движок можно использовать в этой среде?"""

    @abc.abstractmethod
    def detect(self, pcm: bytes, *, sample_rate: int = 16000) -> WakeWordResult:
        """Определить, прозвучало ли слово активации в куске PCM."""

    def reset(self) -> None:
        """Сбросить внутренний буфер/состояние (шаблоны и модели сохраняются)."""

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "available": self.is_available()}


# ---------------------------------------------------------------------------
# Движки
# ---------------------------------------------------------------------------
class OpenWakeWordEngine(WakeWordEngine):
    """Wake-word на openwakeword (нейросеть, локально, без облака).

    По умолчанию слова «джарвис/jarvis» сопоставлены предобученной модели
    ``hey_jarvis``. Для пользовательских слов («пятница» и др.) нужен свой
    ``.onnx``-файл: передайте его через ``model_paths={"пятница": "/путь/м.onnx"}``.
    """

    name = "openwakeword"

    #: Предобученные модели openwakeword для известных слов активации.
    PRETRAINED: dict[str, str] = {
        "джарвис": "hey_jarvis",
        "jarvis": "hey_jarvis",
    }

    def __init__(
        self,
        words: Sequence[str] | None = None,
        threshold: float = 0.5,
        config: WakeWordConfig | None = None,
        model_paths: dict[str, str] | None = None,
    ) -> None:
        self.config = config or WakeWordConfig()
        self.threshold = threshold
        wanted = [normalize_word(w) for w in (words if words is not None else self.config.words)]
        paths = {normalize_word(k): v for k, v in (model_paths or {}).items()}
        # слово активации → идентификатор/путь модели openwakeword
        self._models: dict[str, str] = {}
        for word in wanted:
            if word in paths:
                self._models[word] = paths[word]
            elif word in self.PRETRAINED:
                self._models[word] = self.PRETRAINED[word]
            else:
                logger.debug("openwakeword: для слова '%s' нет модели (нужен model_paths)", word)
        self._model: Any = None

    def is_available(self) -> bool:
        if not self._models:
            return False
        try:
            import openwakeword  # noqa: F401

            return True
        except ImportError:
            return False

    def _load(self) -> Any:
        """Ленивая загрузка моделей (тяжёлые, грузим при первом вызове)."""
        if self._model is not None:
            return self._model
        try:
            from openwakeword import Model
        except ImportError as exc:  # pragma: no cover
            raise WakeWordUnavailable("openwakeword не установлен") from exc
        model_names = sorted(set(self._models.values()))
        try:
            self._model = Model(wakeword_models=model_names, inference_framework="onnx")
        except Exception as exc:  # noqa: BLE001 — разные версии API/битые пути
            raise WakeWordUnavailable(f"openwakeword: не удалось загрузить модели: {exc}") from exc
        return self._model

    @staticmethod
    def _match_key(score_key: str, model_id: str) -> bool:
        """Совпал ли ключ из predict() с идентификатором модели (имя/путь)."""
        stem = model_id.replace("\\", "/").rsplit("/", 1)[-1].rsplit(".", 1)[0]
        return score_key == model_id or score_key == stem or stem in score_key

    def detect(self, pcm: bytes, *, sample_rate: int = 16000) -> WakeWordResult:
        if not self._models:
            raise WakeWordUnavailable("openwakeword: не заданы слова с доступными моделями")
        if not self.is_available():
            raise WakeWordUnavailable("openwakeword не установлен")
        if len(pcm) < 2:
            raise WakeWordError("Слишком маленький кусок PCM")
        try:
            import numpy as np
        except ImportError as exc:  # pragma: no cover
            raise WakeWordUnavailable("нужен numpy") from exc

        model = self._load()
        audio = np.frombuffer(pcm, dtype=np.int16).astype(np.float32) / 32768.0
        try:
            scores = model.predict(audio)
        except Exception as exc:  # noqa: BLE001
            raise WakeWordError(f"openwakeword: ошибка инференса: {exc}") from exc

        best_word, best_score = "", 0.0
        for word, model_id in self._models.items():
            for key, value in (scores or {}).items():
                if self._match_key(str(key), model_id):
                    score = float(value)
                    if score > best_score:
                        best_word, best_score = word, score
                    break
        return WakeWordResult(
            detected=best_score >= self.threshold,
            word=best_word,
            score=best_score,
            engine=self.name,
        )


class TemplateWakeWordEngine(WakeWordEngine):
    """Wake-word на шаблонах огибающей (чистый Python, без зависимостей).

    Работает всегда после ``add_template`` — эталонный fallback, когда
    openwakeword не установлен. Идея: RMS-огибающая PCM нормируется по пику;
    шаблон скользит по окну и сравнивается с DTW **в полосе** (ограниченное
    выравнивание времени) — амплитудо-инвариантно и терпимо к темпу, но без
    патологического «замирания» пути (поэтому половина слова не срабатывает).
    Точность, разумеется, ниже нейросети: это запасной вариант, а не основной
    сценарий.
    """

    name = "template"

    def __init__(
        self,
        threshold: float = 0.5,
        config: WakeWordConfig | None = None,
        hop_ms: int = 20,
    ) -> None:
        self.threshold = threshold
        self.config = config or WakeWordConfig()
        self.hop_ms = hop_ms
        self._templates: dict[str, list[list[float]]] = {}
        self._buf: deque[bytes] = deque()
        self._buf_samples = 0

    # -- шаблоны ----------------------------------------------------------
    def add_template(self, word: str, pcm: bytes, *, sample_rate: int = 16000) -> None:
        """Добавить эталонный фрагмент PCM для слова активации.

        Слово можно записывать несколькими голосами/темпами — усреднение не
        нужно, DTW сравнит со всеми шаблонами и возьмёт лучший.
        """
        env = self._envelope(pcm, sample_rate, self.hop_ms)
        if len(env) < 3:
            raise WakeWordError("Шаблон слишком короткий (нужно минимум 3 окна огибающей)")
        self._templates.setdefault(normalize_word(word), []).append(env)

    def words(self) -> list[str]:
        """Слова, для которых есть хотя бы один шаблон."""
        return sorted(self._templates)

    def is_available(self) -> bool:
        return bool(self._templates)

    def reset(self) -> None:
        self._buf.clear()
        self._buf_samples = 0

    # -- огибающая и DTW ---------------------------------------------------
    @staticmethod
    def _envelope(pcm: bytes, sample_rate: int, hop_ms: int) -> list[float]:
        """RMS-огибающая PCM s16le: одно значение на хоп, нормировка по пику."""
        hop = max(1, sample_rate * hop_ms // 1000)
        samples = array("h")
        samples.frombytes(pcm[: len(pcm) - (len(pcm) % 2)])
        rms: list[float] = []
        for off in range(0, len(samples), hop):
            chunk = samples[off : off + hop]
            if not chunk:
                break
            mean_sq = sum(s * s for s in chunk) / len(chunk)
            rms.append(math.sqrt(mean_sq) / 32768.0)
        if not rms:
            return []
        peak = max(rms)
        if peak <= 0.0:
            return [0.0] * len(rms)
        env = [min(1.0, v / peak) for v in rms]
        if len(env) < 3:
            return env
        # Лёгкое сглаживание [0.25, 0.5, 0.25] — устойчивость к мелким скачкам.
        smoothed = [env[0]]
        for i in range(1, len(env) - 1):
            smoothed.append(0.25 * env[i - 1] + 0.5 * env[i] + 0.25 * env[i + 1])
        smoothed.append(env[-1])
        return smoothed

    @staticmethod
    def _dtw(a: Sequence[float], b: Sequence[float], band: int | None = None) -> float:
        """Средняя разница огибающих вдоль оптимального пути DTW (0..1).

        ``band`` — ширина полосы вокруг диагонали (Сакоэ-Чиба): ограничивает
        выравнивание времени, чтобы DTW не «замораживал» один кусок сигнала
        на весь шаблон (иначе половина слова матчится как целое).
        """
        n, m = len(a), len(b)
        if n == 0 or m == 0:
            return 1.0
        if band is None:
            band = max(n, m)
        inf = float("inf")
        cost_prev = [inf] * (m + 1)
        len_prev = [0] * (m + 1)
        cost_prev[0] = 0.0
        for i in range(1, n + 1):
            cost_cur = [inf] * (m + 1)
            len_cur = [0] * (m + 1)
            center = i * m / n
            j_lo = max(1, int(center - band))
            j_hi = min(m, int(center + band)) + 1
            ai = a[i - 1]
            for j in range(j_lo, j_hi):
                step_cost = abs(ai - b[j - 1])
                diag, up, left = cost_prev[j - 1], cost_prev[j], cost_cur[j - 1]
                best = min(diag, up, left)
                if best == inf:
                    continue
                if best == diag:
                    best_len = len_prev[j - 1]
                elif best == left:
                    best_len = len_cur[j - 1]
                else:
                    best_len = len_prev[j]
                cost_cur[j] = step_cost + best
                len_cur[j] = best_len + 1
            cost_prev, len_prev = cost_cur, len_cur
        if cost_prev[m] == inf:
            return 1.0
        return cost_prev[m] / max(1, len_prev[m])

    @classmethod
    def _match(cls, env: Sequence[float], tpl: Sequence[float]) -> float:
        """Лучшая оценка совпадения шаблона с любой позицией окна (0..1).

        Шаблон скользит по огибающей; сравнение — DTW в полосе ±20% длины,
        оценка ``1 − 3·dist``: полное совпадение → 1, заметная разница → 0.
        """
        length = len(tpl)
        if length == 0 or len(env) < length:
            return 0.0
        band = max(2, length // 5)
        best = 0.0
        for off in range(0, len(env) - length + 1):
            window = env[off : off + length]
            # Дешёвый предфильтр: заведомо чужое окно не гоняем через DTW.
            rough = sum(abs(x - y) for x, y in zip(window, tpl)) / length
            if rough > 0.8:
                continue
            score = max(0.0, 1.0 - 3.0 * cls._dtw(window, tpl, band=band))
            if score > best:
                best = score
        return best

    # -- вердикт ------------------------------------------------------------
    def detect(self, pcm: bytes, *, sample_rate: int = 16000) -> WakeWordResult:
        if not self._templates:
            raise WakeWordUnavailable("template: нет ни одного шаблона (add_template)")
        if len(pcm) < 2:
            raise WakeWordError("Слишком маленький кусок PCM")

        # Копим скользящее окно последних window_bytes PCM.
        self._buf.append(pcm)
        self._buf_samples += len(pcm) // 2
        max_samples = self.config.window_samples
        while self._buf_samples > max_samples and len(self._buf) > 1:
            dropped = self._buf.popleft()
            self._buf_samples -= len(dropped) // 2

        env = self._envelope(b"".join(self._buf), sample_rate, self.hop_ms)
        if len(env) < 3:
            return WakeWordResult(detected=False, score=0.0, engine=self.name)

        best_word, best_score = "", 0.0
        for word, templates in self._templates.items():
            if self.config.words and word not in self.config.words:
                continue  # слово не входит в список активации
            for tpl in templates:
                score = self._match(env, tpl)
                if score > best_score:
                    best_word, best_score = word, score
        return WakeWordResult(
            detected=best_score >= self.threshold,
            word=best_word,
            score=best_score,
            engine=self.name,
        )


# ---------------------------------------------------------------------------
# Диспетчер движков
# ---------------------------------------------------------------------------
class WakeWordRouter:
    """Диспетчер wake-word: смена движков + fallback (по образцу VADRouter)."""

    def __init__(
        self,
        engines: dict[str, WakeWordEngine] | None = None,
        primary: str = "openwakeword",
        fallback_chain: list[str] | None = None,
    ) -> None:
        self._engines = engines or {}
        self._primary = primary
        self._fallback_chain = fallback_chain or [primary]

    @property
    def primary(self) -> str:
        return self._primary

    def set_primary(self, name: str) -> None:
        if name not in self._engines:
            raise WakeWordError(f"Неизвестный wake-word движок: {name}")
        self._primary = name
        self._fallback_chain = [name] + [e for e in self._fallback_chain if e != name]
        logger.info("Wake-word движок переключён на '%s'", name)

    def available(self) -> list[str]:
        return [n for n, e in self._engines.items() if e.is_available()]

    def _chain(self, explicit: str | None) -> list[str]:
        if explicit:
            return [explicit]
        order = self._fallback_chain or list(self._engines.keys())
        chain = [self._primary] + [n for n in order if n != self._primary]
        chain += [n for n in self._engines if n not in chain]
        return chain

    def detect(
        self,
        pcm: bytes,
        *,
        sample_rate: int = 16000,
        engine: str | None = None,
    ) -> WakeWordResult:
        """Вердикт с fallback: несработавший движок пропускаем дальше по цепочке."""
        last_err: Exception | None = None
        for name in self._chain(engine):
            eng = self._engines.get(name)
            if eng is None or not eng.is_available():
                last_err = WakeWordUnavailable(f"{name}: недоступен")
                continue
            try:
                return eng.detect(pcm, sample_rate=sample_rate)
            except (WakeWordUnavailable, WakeWordError) as exc:
                last_err = exc
                continue
        raise WakeWordError(
            f"Ни один wake-word движок не справился. Последняя ошибка: {last_err}"
        )

    def reset(self) -> None:
        for eng in self._engines.values():
            eng.reset()


def create_default_router(config: WakeWordConfig | None = None) -> WakeWordRouter:
    """Стандартный комплект: openwakeword → template (всё локально)."""
    cfg = config or WakeWordConfig()
    return WakeWordRouter(
        engines={
            "openwakeword": OpenWakeWordEngine(threshold=cfg.threshold, config=cfg),
            "template": TemplateWakeWordEngine(threshold=cfg.threshold, config=cfg),
        },
        primary="openwakeword",
        fallback_chain=["openwakeword", "template"],
    )


# ---------------------------------------------------------------------------
# Детектор слова активации (состояние поверх движка)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class WakeWordEvent:
    """Событие активации: слово прозвучало, JARVIS «проснулся»."""

    kind: str = "wakeword"
    word: str = ""
    score: float = 0.0
    #: Кусок PCM окна активации (можно сразу передавать в STT).
    pcm: bytes = b""

    def __post_init__(self) -> None:
        object.__setattr__(self, "word", normalize_word(self.word))


@dataclass
class _Window:
    """Скользящее окно последних кадров (для PCM в событии)."""

    frames: deque[bytes] = field(default_factory=deque)

    @property
    def pcm(self) -> bytes:
        return b"".join(self.frames)


class WakeWordDetector:
    """Кадры PCM → события ``WakeWordEvent`` с cooldown против повторов.

    Правила (настраиваются через ``WakeWordConfig``):
      * каждый кадр уходит в движок (цепочку fallback);
      * срабатывание — когда ``score >= threshold``;
      * после срабатывания движки сбрасываются (активация «съедается» —
        то же аудио не может сработать повторно) и на ``cooldown_ms``
        включается «тихий период» без походов в движки;
      * в событии отдаётся окно PCM длиной до ``window_ms`` — готовый
        фрагмент для STT (команда после «Джарвис»).
    """

    def __init__(
        self,
        router: WakeWordRouter | None = None,
        config: WakeWordConfig | None = None,
        engine: str | None = None,
    ) -> None:
        self.config = config or WakeWordConfig()
        self.router = router or create_default_router(self.config)
        self.engine = engine  # None = цепочка fallback
        self.reset()

    # -- состояние ---------------------------------------------------------
    @property
    def in_cooldown(self) -> bool:
        """Идёт «тихий период» после срабатывания?"""
        return self._cooldown_frames > 0

    @property
    def recent_pcm(self) -> bytes:
        """PCM текущего окна прослушивания."""
        return self._window.pcm

    def reset(self) -> None:
        """Сбросить детектор (новая сессия прослушивания)."""
        window_frames = max(1, self.config.window_bytes // self.config.frame_bytes)
        self._window = _Window(frames=deque(maxlen=window_frames))
        self._cooldown_frames = 0

    # -- основной вход -----------------------------------------------------
    def feed(self, pcm: bytes) -> list[WakeWordEvent]:
        """Скормить кусок PCM (любого размера). Вернуть события активации.

        Хвост короче одного кадра отбрасывается — движки работают покадрово.
        """
        frame_bytes = self.config.frame_bytes
        events: list[WakeWordEvent] = []
        for off in range(0, len(pcm) - frame_bytes + 1, frame_bytes):
            events.extend(self._feed_frame(pcm[off : off + frame_bytes]))
        return events

    def flush(self) -> list[WakeWordEvent]:
        """Закрыть сессию прослушивания (конец потока) и сбросить буферы."""
        self.reset()
        self.router.reset()
        return []

    # -- внутренняя логика -------------------------------------------------
    def _feed_frame(self, frame: bytes) -> list[WakeWordEvent]:
        self._window.frames.append(frame)
        if self._cooldown_frames > 0:
            self._cooldown_frames -= 1
            return []
        result = self.router.detect(frame, sample_rate=self.config.sample_rate, engine=self.engine)
        if not result.detected or result.score < self.config.threshold:
            return []
        self._cooldown_frames = self.config.ms_to_frames(self.config.cooldown_ms)
        self.router.reset()  # активация «съедена»: старое аудио не сработает снова
        logger.info("Wake-word: '%s' (score=%.2f, %s)", result.word, result.score, result.engine)
        return [
            WakeWordEvent(
                kind="wakeword",
                word=result.word,
                score=result.score,
                pcm=self._window.pcm,
            )
        ]
