/**
 * Fun — характер, пасхалки и режимы настроения ассистента.
 */

import { motion } from "framer-motion";
import { useEffect } from "react";
import { Card, PageHeader } from "../components/ui/panels";
import { SettingsSaveBar } from "../components/SettingsSaveBar";
import { FieldRow, SelectField, Toggle } from "../components/ui/controls";
import { clsx } from "../lib/format";
import { useSettingsStore } from "../stores/settingsStore";

const MODES: Array<{ id: string; label: string; hint: string; icon: string }> = [
  { id: "normal", label: "Обычный", hint: "Спокойный, с лёгким юмором", icon: "◉" },
  { id: "stealth", label: "Стелс", hint: "Минимум звука и уведомлений", icon: "◒" },
  { id: "focus", label: "Фокус", hint: "Только по делу, без отвлечений", icon: "✦" },
  { id: "party", label: "Вечеринка", hint: "Громко, ярко, с эффектами", icon: "♫" },
  { id: "alarm", label: "Тревога", hint: "Максимальная громкость и внимание", icon: "⚠" },
];

export function FunPage() {
  const fun = useSettingsStore((s) => s.data.fun);
  const loaded = useSettingsStore((s) => s.loaded);
  const patch = useSettingsStore((s) => s.patch);

  useEffect(() => {
    if (!loaded) void useSettingsStore.getState().load();
  }, [loaded]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Fun"
        subtitle="Пасхалки, эмоциональный тон и режимы настроения — характер JARVIS/FRIDAY."
      />

      <Card title="Режим настроения">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
          {MODES.map((mode, i) => (
            <motion.button
              key={mode.id}
              type="button"
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.96 }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              onClick={() => patch("fun", { mode: mode.id })}
              className={clsx(
                "rounded-xl border p-4 text-left transition-colors",
                fun.mode === mode.id
                  ? "border-accent/70 bg-accent/10 shadow-neon"
                  : "border-line bg-panel-2/50 hover:border-line-bright",
              )}
            >
              <div className="text-xl text-accent">{mode.icon}</div>
              <p className="mt-2 hud-title text-xs text-text">{mode.label}</p>
              <p className="mt-1 text-[11px] text-muted">{mode.hint}</p>
            </motion.button>
          ))}
        </div>
      </Card>

      <Card title="Характер" delay={0.05}>
        <FieldRow
          label="Пасхалки"
          hint="Скрытые шутки и реакции на необычные фразы"
          control={<Toggle checked={fun.easter_eggs} onChange={(v) => patch("fun", { easter_eggs: v })} />}
        />
        <FieldRow
          label="Приветствия"
          hint="Ассистент здоровается при активации"
          control={<Toggle checked={fun.greetings} onChange={(v) => patch("fun", { greetings: v })} />}
        />
        <FieldRow
          label="Эмоциональный тон"
          hint="Интонация голоса подстраивается под контекст"
          control={<Toggle checked={fun.emotional_tone} onChange={(v) => patch("fun", { emotional_tone: v })} />}
        />
        <div className="mt-3 max-w-sm">
          <SelectField
            label="Текущий режим"
            value={fun.mode}
            onChange={(e) => patch("fun", { mode: e.target.value })}
            options={MODES.map((m) => ({ value: m.id, label: m.label }))}
            hint="Дублирует карточки выше"
          />
        </div>
      </Card>

      <SettingsSaveBar />
    </div>
  );
}
