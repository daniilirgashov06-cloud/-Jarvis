"""
Движки распознавания речи (STT) JARVIS CORE.

Единый контракт ``STTEngine`` + диспетчер ``STRouter`` с **живой сменой**
локально ↔ облако и fallback (как в LLMRouter). Локально — faster-whisper
(без интернета); облако — OpenAI Whisper API / Deepgram.

Аудио подаётся как PCM bytes (16 кГц, моно, s16le).
"""

from __future__ import annotations

import abc
import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class Transcript:
    """Результат распознавания."""

    text: str
    language: str = "ru"
    confidence: float = 1.0
    engine: str = ""


class STTError(Exception):
    """Ошибка распознавания."""


class STTUnavailable(STTError):
    """Движок недоступен (нет модели/ключа) — можно fallback."""


class STTEngine(abc.ABC):
    """Контракт движка STT."""

    name: str = "base"

    @abc.abstractmethod
    def is_available(self) -> bool: ...

    @abc.abstractmethod
    async def transcribe(
        self,
        pcm: bytes,
        *,
        sample_rate: int = 16000,
        language: str = "auto",
    ) -> Transcript: ...

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "available": self.is_available()}


class FasterWhisperSTT(STTEngine):
    """Локальное распознавание через faster-whisper (без интернета)."""

    name = "faster_whisper"

    def __init__(self, model: str = "large-v3", device: str = "auto") -> None:
        self.model = model
        self.device = device
        self._whisper: Any = None

    def is_available(self) -> bool:
        try:
            import faster_whisper  # noqa: F401

            return True
        except ImportError:
            return False

    async def transcribe(self, pcm, *, sample_rate=16000, language="auto") -> Transcript:
        if not self.is_available():
            raise STTUnavailable("faster-whisper не установлен")
        # Ленивая загрузка модели (тяжёлая)
        if self._whisper is None:
            from faster_whisper import WhisperModel

            self._whisper = WhisperModel(self.model, device=self.device)
        import numpy as np

        audio = np.frombuffer(pcm, dtype=np.int16).astype(np.float32) / 32768.0
        lang = None if language == "auto" else language
        segments, info = self._whisper.transcribe(audio, language=lang)
        text = " ".join(s.text.strip() for s in segments).strip()
        return Transcript(
            text=text,
            language=getattr(info, "language", language),
            engine=self.name,
        )


class OpenAISTT(STTEngine):
    """Облачное распознавание через OpenAI Whisper API."""

    name = "openai"

    def __init__(self, api_key: str | None = None, model: str = "whisper-1") -> None:
        self.api_key = api_key
        self.model = model

    def is_available(self) -> bool:
        return bool(self.api_key)

    async def transcribe(self, pcm, *, sample_rate=16000, language="auto") -> Transcript:
        if not self.api_key:
            raise STTUnavailable("OpenAI STT: не задан API-ключ")
        try:
            import httpx
        except ImportError as exc:  # pragma: no cover
            raise STTUnavailable("httpx не установлен") from exc

        files = {"file": ("audio.wav", _to_wav(pcm, sample_rate), "audio/wav")}
        data = {"model": self.model}
        if language != "auto":
            data["language"] = language
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                resp = await client.post(
                    "https://api.openai.com/v1/audio/transcriptions",
                    headers={"Authorization": f"Bearer {self.api_key}"},
                    data=data,
                    files=files,
                )
        except Exception as exc:  # noqa: BLE001
            raise STTUnavailable(f"OpenAI STT недоступен: {exc}") from exc
        if resp.status_code != 200:
            raise STTError(f"OpenAI STT HTTP {resp.status_code}: {resp.text[:200]}")
        return Transcript(text=resp.json().get("text", ""), engine=self.name)


def _to_wav(pcm: bytes, sample_rate: int) -> bytes:
    """Оборачивает PCM s16le в WAV-контейнер (для облачных API)."""
    import io
    import struct

    buf = io.BytesIO()
    n = len(pcm)
    buf.write(b"RIFF")
    buf.write(struct.pack("<I", 36 + n))
    buf.write(b"WAVEfmt ")
    buf.write(struct.pack("<IHHIIHH", 16, 1, 1, sample_rate, sample_rate * 2, 2, 16))
    buf.write(b"data")
    buf.write(struct.pack("<I", n))
    buf.write(pcm)
    return buf.getvalue()


class STRouter:
    """Диспетчер STT: смена движков + fallback."""

    def __init__(
        self,
        engines: dict[str, STTEngine] | None = None,
        primary: str = "faster_whisper",
        fallback_chain: list[str] | None = None,
    ) -> None:
        self._engines = engines or {}
        self._primary = primary
        self._fallback_chain = fallback_chain or [primary]

    @property
    def primary(self) -> str:
        return self._primary

    def set_primary(self, name: str) -> None:
        if name not in self._engines:
            raise STTError(f"Неизвестный STT-движок: {name}")
        self._primary = name
        self._fallback_chain = [name] + [e for e in self._fallback_chain if e != name]
        logger.info("STT-движок переключён на '%s'", name)

    def available(self) -> list[str]:
        return [n for n, e in self._engines.items() if e.is_available()]

    def _chain(self, explicit: str | None) -> list[str]:
        if explicit:
            return [explicit]
        order = self._fallback_chain or list(self._engines.keys())
        chain = [self._primary] + [n for n in order if n != self._primary]
        chain += [n for n in self._engines if n not in chain]  # все зарегистрированные
        return chain

    async def transcribe(
        self,
        pcm: bytes,
        *,
        sample_rate: int = 16000,
        language: str = "auto",
        engine: str | None = None,
    ) -> Transcript:
        last_err: Exception | None = None
        for name in self._chain(engine):
            eng = self._engines.get(name)
            if eng is None or not eng.is_available():
                last_err = STTUnavailable(f"{name}: недоступен")
                continue
            try:
                return await eng.transcribe(pcm, sample_rate=sample_rate, language=language)
            except STTUnavailable as exc:
                last_err = exc
                continue
            except STTError as exc:
                last_err = exc
                continue
        raise STTError(f"Ни один STT-движок не справился. Последняя ошибка: {last_err}")
