"""
Проверка actions/file_actions.py.

Запуск:  python3 tests/test_file_actions.py
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from actions.file_actions import FileActions, FileError, register_file_actions
from actions.registry import CommandRegistry, RiskLevel


def test_file_ops_roundtrip() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        fa = FileActions(forbidden_paths=[], trash=False)

        # создать папку + файл
        fa.create_folder(str(root / "docs"))
        (root / "docs" / "a.txt").write_text("привет", encoding="utf-8")

        # list_dir
        assert fa.list_dir(str(root / "docs")) == ["a.txt"]
        # read_file
        assert fa.read_file(str(root / "docs" / "a.txt")) == "привет"
        # file_info
        info = fa.file_info(str(root / "docs" / "a.txt"))
        assert info["name"] == "a.txt" and info["is_dir"] is False and info["size"] > 0
        # find_files
        assert any(p.endswith("a.txt") for p in fa.find_files(str(root), "*.txt"))
        # rename
        fa.rename(str(root / "docs" / "a.txt"), "b.txt")
        assert (root / "docs" / "b.txt").exists()
        # copy
        fa.copy(str(root / "docs" / "b.txt"), str(root / "copy.txt"))
        assert (root / "copy.txt").read_text(encoding="utf-8") == "привет"
        # move
        fa.move(str(root / "copy.txt"), str(root / "docs" / "moved.txt"))
        assert (root / "docs" / "moved.txt").exists() and not (root / "copy.txt").exists()
        # delete (trash=False -> физически)
        fa.delete(str(root / "docs" / "moved.txt"))
        assert not (root / "docs" / "moved.txt").exists()
    print("  ✓ file_ops: создать/прочитать/переименовать/копировать/переместить/удалить")


def test_forbidden_paths_blocked() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        forbidden = tmp
        fa = FileActions(forbidden_paths=[forbidden], trash=False)
        try:
            fa.list_dir(forbidden)
            assert False, "ожидали блокировку запрещённого пути"
        except FileError as e:
            assert "запрещён" in str(e)
    print("  ✓ file_ops: запрещённые пути блокируются политикой безопасности")


def test_missing_paths_error() -> None:
    fa = FileActions(forbidden_paths=[], trash=False)
    try:
        fa.read_file("/definitely/not/exists.txt")
        assert False
    except FileError:
        pass
    print("  ✓ file_ops: несуществующие пути -> корректная ошибка")


def test_register_commands() -> None:
    reg = CommandRegistry()
    names = register_file_actions(reg)
    assert "delete_file" in names and "read_file" in names
    delete_cmd = reg.get("delete_file")
    assert delete_cmd.risk == RiskLevel.HIGH and delete_cmd.requires_confirmation is True
    read_cmd = reg.get("read_file")
    assert read_cmd.risk == RiskLevel.SAFE and read_cmd.requires_confirmation is False
    print("  ✓ file_ops: регистрация команд + уровни риска/подтверждения верны")


def main() -> int:
    print("JARVIS CORE — проверка file_actions")
    try:
        test_file_ops_roundtrip()
        test_forbidden_paths_blocked()
        test_missing_paths_error()
        test_register_commands()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки file_actions прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
