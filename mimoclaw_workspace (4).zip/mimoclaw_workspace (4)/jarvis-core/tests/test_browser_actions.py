"""
Проверка actions/browser_actions.py.

Запуск:  python3 tests/test_browser_actions.py
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from actions.browser_actions import (
    ALLOWED_SCHEMES,
    DEFAULT_ENGINE,
    KNOWN_BROWSERS,
    SEARCH_ENGINES,
    BrowserActions,
    BrowserError,
    BrowserUnavailable,
    DryRunBrowserBackend,
    SubprocessBrowserBackend,
    build_search_url,
    normalize_url,
    register_browser_actions,
    validate_browser_name,
    validate_url,
)
from actions.registry import CommandRegistry, RiskLevel


# ---------------------------------------------------------------------------
# Валидация URL
# ---------------------------------------------------------------------------
def test_validate_url() -> None:
    assert ALLOWED_SCHEMES == {"http", "https"}
    good = [
        "https://example.com",
        "http://localhost:8080/x?y=1#frag",
        "https://пример.рф/путь",
        "https://user:pass@host.example/a",
        "HTTPS://Example.com/A",
    ]
    for url in good:
        assert validate_url(url) == url.strip()

    bad = [
        42,
        None,
        "",
        "   ",
        "https://exa mple.com",          # пробел
        "https://a\x00b.com",            # управляющий символ
        "-https://example.com",          # ведущий дефис → инъекция опций
        "javascript:alert(1)",           # XSS
        "data:text/html,<script>x</script>",
        "file:///etc/passwd",            # локальные файлы
        "about:blank",
        "ftp://example.com",             # схема вне allow-list
        "https://",                      # нет хоста
        "https:///path",                 # нет хоста
        "http://<bad>/",                 # недопустимые символы в хосте
        "https://example.com/" + "a" * 3000,  # длиннее лимита
    ]
    for url in bad:
        try:
            validate_url(url)
        except ValueError:
            pass
        else:
            raise AssertionError(f"URL {url!r} должен быть отклонён")
    print("  ✓ validate_url: допустимые http/https и отклонение опасных схем/мусора")


# ---------------------------------------------------------------------------
# Нормализация и поисковые URL
# ---------------------------------------------------------------------------
def test_normalize_url() -> None:
    assert normalize_url("example.com/path") == "https://example.com/path"
    assert normalize_url("  http://a.b/c  ") == "http://a.b/c"
    assert normalize_url("HTTPS://Example.com") == "HTTPS://Example.com"
    for bad in ["", "пример ру", "домашняя страница", 42, "javascript:alert(1)"]:
        try:
            normalize_url(bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"строка {bad!r} должна быть отклонена")
    print("  ✓ normalize_url: добавление https:// и отклонение свободного текста")


def test_search_url() -> None:
    url = build_search_url("погода москва", "duckduckgo")
    assert url == "https://duckduckgo.com/?q=" + "%D0%BF%D0%BE%D0%B3%D0%BE%D0%B4%D0%B0+%D0%BC%D0%BE%D1%81%D0%BA%D0%B2%D0%B0"
    assert build_search_url("jarvis", "Yandex") == (
        "https://yandex.ru/search/?text=jarvis"
    )
    assert build_search_url("jarvis") == SEARCH_ENGINES[DEFAULT_ENGINE].format("jarvis")
    for bad_query in ["", "   ", "x" * 501, "tab\tseparated", 7]:
        try:
            build_search_url(bad_query)
        except ValueError:
            pass
        else:
            raise AssertionError(f"запрос {bad_query!r} должен быть отклонён")
    for bad_engine in ["evil", "duckduckgo; rm -rf /", ""]:
        try:
            build_search_url("ok", bad_engine)
        except ValueError:
            pass
        else:
            raise AssertionError(f"движок {bad_engine!r} должен быть отклонён")
    print("  ✓ build_search_url: кодирование запроса, allow-list движков, лимиты")


# ---------------------------------------------------------------------------
# DryRun: сквозной прогон команд
# ---------------------------------------------------------------------------
def test_dry_run_actions() -> None:
    backend = DryRunBrowserBackend(
        default="firefox",
        installed=["firefox", "chrome"],
        running=["firefox"],
    )
    svc = BrowserActions(backend=backend)

    status = svc.browser_status()
    assert status["default"] == "firefox"
    assert {b["key"] for b in status["browsers"]} == {"firefox", "chrome"}
    assert [b["running"] for b in status["browsers"] if b["key"] == "firefox"] == [True]

    opened = svc.open_url("example.com", new_window=True)
    assert opened["url"] == "https://example.com"
    assert opened["browser"] is None and opened["new_window"] is True
    assert backend.calls[-1] == ("open_url", ("https://example.com", None, True))

    found = svc.open_search("как настроить джарвис", engine="google")
    assert found["engine"] == "google"
    assert found["url"].startswith("https://www.google.com/search?q=")
    assert "%D0%BA%D0%B0%D0%BA" in found["url"]

    # закрытие: явный браузер и браузер по умолчанию
    assert svc.close_browser("firefox") == {"browser": "firefox", "closed": 1}
    assert svc.close_browser() == {"browser": "firefox", "closed": 0}

    # некорректные аргументы → ValueError / BrowserError
    for bad_url in ["javascript:alert(1)", "file:///etc/passwd", "-x", "", 5]:
        try:
            svc.open_url(bad_url)
        except ValueError:
            pass
        else:
            raise AssertionError(f"URL {bad_url!r} должен быть отклонён")
    try:
        svc.open_url("https://ok.example", browser="netscape")
    except ValueError:
        pass
    else:
        raise AssertionError("неизвестный браузер должен быть отклонён")
    try:
        svc.open_url("https://ok.example", new_window="yes")  # type: ignore[arg-type]
    except ValueError:
        pass
    else:
        raise AssertionError("не-bool new_window должен быть отклонён")

    # без браузера по умолчанию close_browser требует явного имени
    backend.default = None
    try:
        svc.close_browser()
    except BrowserError:
        pass
    else:
        raise AssertionError("без дефолтного браузера нужен явный browser")

    # недоступный backend → контролируемый отказ
    backend.available = False
    try:
        svc.browser_status()
    except BrowserUnavailable:
        pass
    else:
        raise AssertionError("недоступный backend должен давать BrowserUnavailable")
    print("  ✓ dry_run: status/open_url/open_search/close_browser + отказы")


# ---------------------------------------------------------------------------
# SubprocessBrowserBackend: Linux (argv, pgrep/pkill, xdg-settings)
# ---------------------------------------------------------------------------
def test_subprocess_linux() -> None:
    calls: list[list[str]] = []

    def runner(argv: list[str]) -> str:
        calls.append(argv)
        if argv == ["xdg-settings", "get", "default-web-browser"]:
            return "google-chrome.desktop\n"
        if argv[0] == "pgrep":
            return "123\n456\n" if argv[-1] == "firefox" else ""
        return ""

    backend = SubprocessBrowserBackend(
        runner=runner,
        platform_name="Linux",
        which=lambda t: "/usr/bin/" + t,
    )
    assert backend.is_available()

    # дефолтный браузер средствами ОС
    assert backend.open_url("https://a.example") == "xdg-open https://a.example"
    # явный браузер + новое окно
    assert backend.open_url("https://a.example", "firefox", True) == (
        "firefox --new-window https://a.example"
    )
    assert calls[-1] == ["firefox", "--new-window", "https://a.example"]

    # закрытие: pgrep считает, pkill шлёт мягкий сигнал
    assert backend.close("firefox") == 2
    assert calls[-2][0] == "pgrep" and calls[-1] == ["pkill", "-x", "firefox"]
    assert backend.close("chrome") == 0  # процессов нет

    # сводка: chrome по умолчанию (google-chrome.desktop), firefox запущен
    report = backend.detect()
    assert report.default == "chrome"
    keys = {b.key: b for b in report.browsers}
    assert keys["chrome"].is_default and not keys["chrome"].running
    assert keys["firefox"].running and keys["firefox"].installed
    assert "safari" not in keys  # на Linux не бывает

    # нет утилит → контролируемые отказы
    bare = SubprocessBrowserBackend(
        runner=lambda argv: "", platform_name="Linux", which=lambda t: None
    )
    assert not bare.is_available()
    try:
        bare.open_url("https://a.example")
    except BrowserUnavailable:
        pass
    else:
        raise AssertionError("без xdg-open должен быть BrowserUnavailable")

    def raising_runner(argv: list[str]) -> str:
        raise BrowserError("нет дисплея")

    broken = SubprocessBrowserBackend(
        runner=raising_runner, platform_name="Linux", which=lambda t: "/bin/" + t
    )
    assert broken.close("firefox") == 0
    assert broken.detect().default is None  # xdg-settings недоступен → best-effort
    print("  ✓ subprocess/linux: argv, pgrep/pkill, xdg-settings и деградация")


# ---------------------------------------------------------------------------
# SubprocessBrowserBackend: macOS и Windows
# ---------------------------------------------------------------------------
def test_subprocess_platforms() -> None:
    calls: list[list[str]] = []

    def mac_runner(argv: list[str]) -> str:
        calls.append(argv)
        if argv[0] == "osascript":
            return "true\n" if "Safari" in argv[-1] else "false\n"
        if argv[0] == "pgrep":
            return "99\n" if argv[-1] == "Safari" else ""
        return ""

    mac = SubprocessBrowserBackend(
        runner=mac_runner, platform_name="Darwin", which=lambda t: "/usr/bin/" + t
    )
    mac.open_url("https://a.example")
    assert calls[-1] == ["open", "https://a.example"]
    mac.open_url("https://a.example", "safari", True)
    assert calls[-1] == ["open", "-na", "Safari", "https://a.example"]
    mac.open_url("https://a.example", "firefox")
    assert calls[-1] == ["open", "-a", "Firefox", "https://a.example"]
    assert mac.close("safari") == 1
    assert calls[-2][0] == "pgrep" and calls[-1] == ["pkill", "-x", "Safari"]
    report = mac.detect()
    keys = {b.key: b for b in report.browsers}
    assert set(keys) == {"safari"} and keys["safari"].running

    def win_runner(argv: list[str]) -> str:
        calls.append(argv)
        ps = argv[-1]
        if "ProgId" in ps:
            return "ChromeHTML\n"
        if "tasklist" in ps:
            return "chrome.exe   1234 Console\n"
        return ""

    win = SubprocessBrowserBackend(
        runner=win_runner,
        platform_name="Windows",
        which=lambda t: "C:/" + t if t in ("powershell", "chrome.exe") else None,
    )
    win.open_url("https://a.example")
    assert calls[-1] == [
        "powershell", "-NoProfile", "-Command", "Start-Process 'https://a.example'",
    ]
    # экранирование одинарной кавычки в PowerShell + новое окно
    win.open_url("https://a.example/a'b", "chrome", True)
    assert calls[-1][-1] == (
        "Start-Process -FilePath 'chrome.exe' "
        "-ArgumentList '--new-window','https://a.example/a''b'"
    )
    assert win.close("chrome") == 1
    assert "taskkill /IM 'chrome.exe'" in calls[-1][-1]
    assert win.detect().default == "chrome"
    assert {b.key for b in win.detect().browsers} == {"chrome"}

    # macOS без браузера, которого нет в системе → пустая сводка
    def mac_none(argv: list[str]) -> str:
        if argv[0] == "osascript":
            return "false\n"
        return ""

    mac_bare = SubprocessBrowserBackend(
        runner=mac_none, platform_name="Darwin", which=lambda t: "/usr/bin/" + t
    )
    assert mac_bare.detect().browsers == ()
    # windows без powershell → недоступен
    win_bare = SubprocessBrowserBackend(
        runner=win_runner, platform_name="Windows", which=lambda t: None
    )
    assert not win_bare.is_available()
    print("  ✓ subprocess/macOS+Windows: argv, экранирование, сводка и деградация")


# ---------------------------------------------------------------------------
# Валидация имени браузера (allow-list)
# ---------------------------------------------------------------------------
def test_validate_browser_name() -> None:
    assert validate_browser_name("Chrome ") == "chrome"
    assert validate_browser_name("FIREFOX") == "firefox"
    for bad in ["netscape", "firefox; rm -rf /", "../../bin/sh", "-x", "", 3, "fire fox"]:
        try:
            validate_browser_name(bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"имя {bad!r} должно быть отклонено")
    assert set(KNOWN_BROWSERS) >= {"firefox", "chrome", "safari"}
    print("  ✓ validate_browser_name: allow-list известных браузеров")


# ---------------------------------------------------------------------------
# Регистрация команд: имена, риски, подтверждения
# ---------------------------------------------------------------------------
def test_register_commands() -> None:
    reg = CommandRegistry()
    names = register_browser_actions(
        reg, actions=BrowserActions(backend=DryRunBrowserBackend())
    )
    assert set(names) == {"browser_status", "open_url", "open_search", "close_browser"}

    status = reg.get("browser_status")
    assert status is not None
    assert status.risk == RiskLevel.SAFE and status.requires_confirmation is False
    for name in ("open_url", "open_search", "close_browser"):
        cmd = reg.get(name)
        assert cmd is not None
        assert cmd.risk == RiskLevel.MEDIUM and cmd.requires_confirmation is True

    open_tool = reg.get("open_url").to_tool()
    assert [p.name for p in open_tool.params] == ["url", "browser", "new_window"]
    assert open_tool.params[0].required is True
    assert open_tool.params[2].required is False and open_tool.params[2].default is False
    assert set(open_tool.params[1].enum or []) == set(KNOWN_BROWSERS)

    search_tool = reg.get("open_search").to_tool()
    assert [p.name for p in search_tool.params] == ["query", "engine", "browser"]
    assert set(search_tool.params[1].enum or []) == set(SEARCH_ENGINES)

    close_tool = reg.get("close_browser").to_tool()
    assert [p.name for p in close_tool.params] == ["browser"]
    assert close_tool.params[0].required is False
    print("  ✓ register: 4 команды, риски/подтверждения и схемы для LLM верны")


def main() -> int:
    print("JARVIS CORE — проверка browser_actions")
    try:
        test_validate_url()
        test_normalize_url()
        test_search_url()
        test_dry_run_actions()
        test_subprocess_linux()
        test_subprocess_platforms()
        test_validate_browser_name()
        test_register_commands()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки browser_actions прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
