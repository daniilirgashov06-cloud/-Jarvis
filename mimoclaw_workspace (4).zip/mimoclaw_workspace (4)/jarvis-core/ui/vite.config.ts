import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Панель JARVIS CORE.
// dev-сервер проксирует REST/WS на ядро (FastAPI+WS, 127.0.0.1:8765).
// Прод-сборка (dist/) можно отдавать прямо из FastAPI или любого статики.
const CORE = process.env.JARVIS_CORE_URL ?? "http://127.0.0.1:8765";

export default defineConfig({
  plugins: [react()],
  base: "./",
  server: {
    port: 5173,
    proxy: {
      "/api": { target: CORE, changeOrigin: true },
      "/ws": { target: CORE, ws: true, changeOrigin: true },
    },
  },
  build: {
    outDir: "dist",
    sourcemap: false,
    chunkSizeWarningLimit: 900,
  },
});
