"""
Проверка модуля fun/boot_sequence: «диагностика костюма», тайминги, прогресс.

Запуск:  python3 tests/test_boot_sequence.py
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fun.boot_sequence import (
    BootLine,
    BootSequence,
    minimal_boot,
    suit_diagnostic,
    typed_text,
)


# ---------------------------------------------------------------------------
# Хелперы
# ---------------------------------------------------------------------------
def _raises(exc_type, fn, *args, **kwargs) -> str:
    """Проверяет, что fn бросает exc_type; возвращает текст ошибки."""
    try:
        fn(*args, **kwargs)
    except exc_type as e:
        return str(e)
    raise AssertionError(f"ожидался {exc_type.__name__}, но ошибки не было")


# ---------------------------------------------------------------------------
# Тесты: валидация строк
# ---------------------------------------------------------------------------
def test_boot_line_validation() -> None:
    """BootLine валидирует текст, тайминги и тип строки."""
    line = BootLine("ПРОВЕРКА СИСТЕМ", delay_ms=100, duration_ms=500, kind="check")
    assert line.text == "ПРОВЕРКА СИСТЕМ" and line.duration_ms == 500

    assert "пустым" in _raises(ValueError, BootLine, "   ")
    assert "delay_ms" in _raises(ValueError, BootLine, "текст", delay_ms=-1)
    assert "duration_ms" in _raises(ValueError, BootLine, "текст", duration_ms=0)
    assert "kind" in _raises(ValueError, BootLine, "текст", kind="шум")
    print("  ✓ BootLine: валидация")


# ---------------------------------------------------------------------------
# Тесты: таймлайн и прогресс
# ---------------------------------------------------------------------------
def _tiny_sequence() -> BootSequence:
    """Компактная последовательность для проверки таймингов."""
    return BootSequence(
        name="tiny",
        lines=[
            BootLine("А", delay_ms=100, duration_ms=400),  # 100..500
            BootLine("Б", delay_ms=100, duration_ms=400),  # 500+100=600..1000
            BootLine("В", delay_ms=0, duration_ms=200),    # 1000..1200
        ],
    )


def test_timeline_and_total() -> None:
    """Таймлайн учитывает паузы; total_ms — конец последней строки."""
    seq = _tiny_sequence()
    assert seq.timeline() == [(100, 500), (600, 1000), (1000, 1200)], f"таймлайн: {seq.timeline()}"
    assert seq.total_ms == 1200, f"total_ms: {seq.total_ms}"

    empty = BootSequence(name="empty")
    assert empty.total_ms == 0 and empty.progress_at(50) == 1.0, "пустая последовательность сразу готова"
    print("  ✓ BootSequence: таймлайн и total_ms")


def test_progress() -> None:
    """Прогресс монотонен, ограничен 0..1 и доходит до 1."""
    seq = _tiny_sequence()
    assert seq.progress_at(0) == 0.0, "до старта прогресс нулевой"
    assert seq.progress_at(-100) == 0.0, "отрицательное время → 0"
    assert seq.progress_at(10_000) == 1.0, "после конца прогресс полный"

    prev = 0.0
    for t in range(0, 1300, 25):
        p = seq.progress_at(t)
        assert 0.0 <= p <= 1.0, f"прогресс вне диапазона при t={t}: {p}"
        assert p >= prev - 1e-9, f"прогресс ушёл назад при t={t}: {p} < {prev}"
        prev = p
    assert prev == 1.0, f"к концу прогресс должен быть 1: {prev}"
    assert seq.progress_at(500) == 1 / 3, "завершена ровно одна строка из трёх"
    print("  ✓ BootSequence: прогресс")


def test_active_index_and_frames() -> None:
    """Активная строка, кадры, «печать» текста."""
    seq = _tiny_sequence()
    assert seq.active_index_at(0) == -1, "в начальной паузе активной строки нет"
    assert seq.active_index_at(300) == 0, "300 мс — первая строка"
    assert seq.active_index_at(550) == 1, "550 мс — пауза перед второй строкой"
    assert seq.active_index_at(5000) == 3, "после конца индекс = len(lines)"

    frame = seq.frame_at(300)
    assert frame.line_index == 0 and frame.line is not None
    assert frame.text.startswith("А"), f"текст кадра: {frame.text!r}"
    assert not frame.complete and frame.done_count == 0

    final = seq.frame_at(1200)
    assert final.complete and final.done_count == 3 and final.progress == 1.0
    assert final.text == "", "после завершения текста нет"

    assert typed_text("СИСТЕМА", 0.5) == "СИСТ", "печать по буквам (ceil)"
    assert typed_text("СИСТЕМА", 0.0) == "" and typed_text("СИСТЕМА", 1.0) == "СИСТЕМА"
    assert typed_text("СИСТЕМА", float("nan")) == ""

    frames = list(seq.frames(tick_ms=100))
    assert frames[-1].complete, "последний кадр должен быть завершающим"
    assert [f.t_ms for f in frames] == sorted(f.t_ms for f in frames), "кадры идут по времени"
    assert "tick_ms" in _raises(ValueError, lambda: list(seq.frames(0)))
    print("  ✓ BootSequence: кадры и печать текста")


def test_presets() -> None:
    """Пресеты запуска непустые и самодостаточные."""
    for factory in (suit_diagnostic, minimal_boot):
        seq = factory()
        assert seq.lines, f"{factory.__name__}: нет строк"
        assert seq.total_ms > 0, f"{factory.__name__}: нулевая длительность"
        assert 0.0 < seq.progress_at(seq.total_ms / 2) < 1.0, f"{factory.__name__}: прогресс посередине"
        data = seq.to_dict()
        assert data["name"] == seq.name and len(data["lines"]) == len(seq.lines)

    full = suit_diagnostic()
    assert "РЕАКТОР" in " ".join(line.text for line in full.lines), "диагностика должна проверять реактор"
    assert full.total_ms > minimal_boot().total_ms, "полная диагностика длиннее короткой"
    print("  ✓ Пресеты: suit_diagnostic и minimal_boot")


def test_sequence_validation() -> None:
    """BootSequence валидирует имя."""
    assert "имя" in _raises(ValueError, BootSequence, "  ")
    print("  ✓ BootSequence: валидация имени")


def main() -> int:
    print("Проверка fun/boot_sequence ...")
    try:
        test_boot_line_validation()
        test_timeline_and_total()
        test_progress()
        test_active_index_and_frames()
        test_presets()
        test_sequence_validation()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модуля прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
