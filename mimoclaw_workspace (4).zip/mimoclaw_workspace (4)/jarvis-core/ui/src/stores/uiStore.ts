/**
 * Стор интерфейса: персона (JARVIS/FRIDAY), боковое меню, HUD-акцент.
 */

import { create } from "zustand";

export type Persona = "jarvis" | "friday";

export const PERSONA_ACCENT: Record<Persona, { hex: string; rgb: string }> = {
  jarvis: { hex: "#00E5FF", rgb: "0 229 255" },
  friday: { hex: "#FF3B30", rgb: "255 59 48" },
};

interface UiState {
  persona: Persona;
  sidebarCollapsed: boolean;
  setPersona: (persona: Persona) => void;
  toggleSidebar: () => void;
}

export const useUiStore = create<UiState>((set) => ({
  persona: "jarvis",
  sidebarCollapsed: false,

  setPersona: (persona) => {
    applyAccent(persona);
    set({ persona });
  },

  toggleSidebar: () => set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
}));

/** Применить акцент персоны к CSS-переменным (циан/красный). */
export function applyAccent(persona: Persona): void {
  const accent = PERSONA_ACCENT[persona];
  const root = document.documentElement;
  root.style.setProperty("--accent", accent.hex);
  root.style.setProperty("--accent-rgb", accent.rgb);
}
