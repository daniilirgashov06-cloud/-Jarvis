"""
Сборщик контекста для LLM (Context Builder) JARVIS CORE.

Собирает системную часть промпта: идентичность персоны, дату/время,
состояние ПК, последние сообщения и релевантные воспоминания (RAG).
Базовая версия (Этап 1) — без экрана; расширяется на Этапе 4-5.

Всё детерминированно и тестируемо: источник системной информации
и памяти подключается как зависимость (можно подставить мок).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Protocol

from ai.personas import Persona, get_persona


class SystemInfoSource(Protocol):
    """Источник состояния ПК (реализуется в actions/system_actions)."""

    def snapshot(self) -> dict[str, Any]: ...


class MemorySearch(Protocol):
    """Поиск по памяти (реализуется в memory/vector_store)."""

    def search(self, query: str, top_k: int) -> list[str]: ...


@dataclass
class ContextBuilder:
    """
    Собирает контекст для ``LLMRouter.ask``.

    Обязательные части: персона + дата/время. Опционально: состояние ПК,
    последние сообщения, воспоминания, описание экрана.
    """

    persona_key: str = "jarvis"
    context_messages: int = 20
    rag_top_k: int = 8
    system_info: SystemInfoSource | None = None
    memory: MemorySearch | None = None
    screen_describer: Callable[[], str] | None = None

    def _now_str(self) -> str:
        return datetime.now().strftime("%Y-%m-%d %H:%M, %A")

    def build_system_context(self) -> dict[str, Any]:
        """Словарь контекста для Persona.system_prompt."""
        ctx: dict[str, Any] = {"datetime": self._now_str()}
        if self.system_info is not None:
            try:
                ctx["system_status"] = self.system_info.snapshot()
            except Exception:  # noqa: BLE001 — состояние ПК не должно ронять сборку
                ctx["system_status"] = "недоступно"
        return ctx

    def build_messages(
        self,
        persona: Persona | None = None,
        history: list[dict[str, Any]] | None = None,
        user_text: str = "",
    ) -> list[dict[str, Any]]:
        """
        Собирает список сообщений в формате role/content для LLM.

        Порядок: system (персона+контекст) -> история -> (опц.) воспоминания -> user.
        """
        persona = persona or get_persona(self.persona_key)
        sys_ctx = self.build_system_context()

        system_prompt = persona.system_prompt(sys_ctx)

        # RAG-воспоминания по текущему запросу
        if self.memory is not None and user_text:
            try:
                memories = self.memory.search(user_text, self.rag_top_k)
                if memories:
                    system_prompt += "\n\nРелевантные воспоминания:\n" + "\n".join(
                        f"- {m}" for m in memories
                    )
            except Exception:  # noqa: BLE001
                pass

        messages: list[dict[str, Any]] = [{"role": "system", "content": system_prompt}]

        for msg in (history or [])[-self.context_messages :]:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if content:
                messages.append({"role": role, "content": content})

        if user_text:
            messages.append({"role": "user", "content": user_text})
        return messages
