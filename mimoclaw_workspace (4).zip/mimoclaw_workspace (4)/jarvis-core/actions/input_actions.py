"""
Команды ввода JARVIS CORE (ТЗ-6, каталог input).

Команды уровня «ввод»: набор текста в активное окно, горячие клавиши,
управление курсором мыши (перемещение, клики, прокрутка). Каждая команда
имеет уровень риска (``RiskLevel``) и регистрируется в ``CommandRegistry``,
откуда она попадает в схемы function calling для LLM.

Архитектура (в стиле ``actions/app_actions.py``):

- ``InputBackend`` — контракт «исполнитель» операций ввода;
- ``SubprocessInputBackend`` — локальная реализация через subprocess
  (Linux: xdotool/ydotool, macOS: osascript + cliclick,
  Windows: PowerShell + SendKeys/user32), команды строятся под платформу;
- ``DryRunInputBackend`` — безопасный fallback/отладка: ничего не вводит,
  только записывает операции (используется и в тестах).

«Локально ↔ облако» здесь неприменимо: весь ввод выполняется локально.
При недоступности исполнителя команда падает контролируемо
(``InputUnavailable``) без побочных эффектов.

Безопасность: текст и имена клавиш проходят строгую валидацию
(длина, управляющие символы, ведущие дефисы → антиинъекция опций в argv),
горячие клавиши разбираются парсером ``parse_hotkey`` с алиасами
(«ввод»/«пробел»/«esc»…). Ввод текста и «горячие» клавиши считаются
операциями уровня MEDIUM (требуют подтверждения): они могут нажать
кнопки в чужих диалогах.

Использование:
    from actions.registry import CommandRegistry
    from actions.input_actions import InputActions, register_input_actions

    registry = CommandRegistry()
    register_input_actions(registry)         # или со своим backend
"""

from __future__ import annotations

import abc
import logging
import platform
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Any, Callable

from actions.registry import REQUIRES_CONFIRMATION, Command, CommandRegistry, RiskLevel
from ai.function_calling import ParamSpec

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class InputError(Exception):
    """Ошибка команды ввода."""


class InputUnavailable(InputError):
    """Исполнитель недоступен (нет утилиты/прав) — можно fallback."""


# ---------------------------------------------------------------------------
# Валидация текста
# ---------------------------------------------------------------------------
#: Максимальная длина набираемого текста
MAX_TEXT_LEN = 2000
#: Максимальное число клавиш в комбинации
MAX_HOTKEY_LEN = 5


def validate_text(text: Any) -> str:
    """
    Проверяет набираемый текст и возвращает его без изменений.

    Запрещены: не-строки, пустой текст, текст длиннее ``MAX_TEXT_LEN``,
    управляющие символы (для них есть горячие клавиши) и ведущий дефис
    (инъекция опций в argv утилит ввода).
    """
    if not isinstance(text, str):
        raise ValueError(f"текст должен быть строкой, получено: {text!r}")
    if not text:
        raise ValueError("текст не может быть пустым")
    if len(text) > MAX_TEXT_LEN:
        raise ValueError(
            f"текст слишком длинный: {len(text)} > {MAX_TEXT_LEN} символов"
        )
    if text.startswith("-"):
        raise ValueError(
            "текст не должен начинаться с '-' (инъекция опций в argv); "
            "используйте пробел в начале или команду горячих клавиш"
        )
    bad = [ch for ch in text if ord(ch) < 32]
    if bad:
        raise ValueError(
            f"текст содержит управляющие символы: {bad!r} "
            "(используйте команду горячих клавиш)"
        )
    return text


# ---------------------------------------------------------------------------
# Клавиши: канонические имена и алиасы
# ---------------------------------------------------------------------------
#: Модификаторы
MODIFIERS: frozenset[str] = frozenset({"ctrl", "alt", "shift", "meta"})

#: Базовые (немодификаторные) клавиши
_BASE_KEYS: frozenset[str] = frozenset(
    {
        "enter", "esc", "tab", "space", "backspace", "delete", "insert",
        "home", "end", "page_up", "page_down",
        "up", "down", "left", "right",
    }
) | frozenset(chr(ord("a") + i) for i in range(26)) | frozenset(
    str(i) for i in range(10)
) | frozenset(f"f{i}" for i in range(1, 13))

#: Канонические имена клавиш (включая модификаторы)
ALLOWED_KEYS: frozenset[str] = _BASE_KEYS | MODIFIERS

#: алиас (lowercase) → каноническое имя клавиши
DEFAULT_KEY_ALIASES: dict[str, str] = {
    # модификаторы
    "control": "ctrl", "ctrl": "ctrl", "контрол": "ctrl", "контроль": "ctrl",
    "alt": "alt", "option": "alt", "альт": "alt", "опция": "alt",
    "shift": "shift", "шифт": "shift",
    "meta": "meta", "win": "meta", "super": "meta", "cmd": "meta",
    "command": "meta", "гвинь": "meta", "мак": "meta",
    # системные
    "enter": "enter", "return": "enter", "ввод": "enter", "энтер": "enter",
    "esc": "esc", "escape": "esc", "эскейп": "esc", "эск": "esc",
    "tab": "tab", "таб": "tab",
    "space": "space", "пробел": "space",
    "backspace": "backspace", "бекспейс": "backspace", "забой": "backspace",
    "delete": "delete", "del": "delete", "удалить": "delete", "дел": "delete",
    "insert": "insert", "ins": "insert", "вставить": "insert",
    "home": "home", "хом": "home", "начало": "home",
    "end": "end", "конец": "end",
    "page_up": "page_up", "pageup": "page_up", "pgup": "page_up",
    "страница вверх": "page_up",
    "page_down": "page_down", "pagedown": "page_down", "pgdn": "page_down",
    "страница вниз": "page_down",
    # стрелки
    "up": "up", "вверх": "up", "стрелка вверх": "up",
    "down": "down", "вниз": "down", "стрелка вниз": "down",
    "left": "left", "влево": "left", "стрелка влево": "left",
    "right": "right", "вправо": "right", "стрелка вправо": "right",
}


def normalize_key(key: Any) -> str:
    """
    Нормализует имя клавиши (включая алиасы и регистр) в каноническое.

    Одиночные буквы/цифры/F1..F12 приводятся к нижнему регистру;
    неизвестные имена отклоняются с перечислением допустимых групп.
    """
    if not isinstance(key, str):
        raise ValueError(f"имя клавиши должно быть строкой, получено: {key!r}")
    cleaned = key.strip().lower()
    if not cleaned:
        raise ValueError("имя клавиши не может быть пустым")
    if cleaned in DEFAULT_KEY_ALIASES:
        return DEFAULT_KEY_ALIASES[cleaned]
    if cleaned in ALLOWED_KEYS:
        return cleaned
    raise ValueError(
        f"неизвестная клавиша: {key!r} (алиасы: 'ввод', 'пробел', 'esc'…; "
        "буквы, цифры, F1..F12, модификаторы ctrl/alt/shift/meta)"
    )


def parse_hotkey(hotkey: Any) -> tuple[str, ...]:
    """
    Разбирает комбинацию клавиш («ctrl+alt+t», «enter») в кортеж канонических
    имён: модификаторы в порядке ctrl → alt → shift → meta, затем основная
    клавиша.

    Правила: 1..``MAX_HOTKEY_LEN`` клавиш, без дублей, ровно одна основная
    (немодификаторная) клавиша.
    """
    if not isinstance(hotkey, str):
        raise ValueError(f"комбинация должна быть строкой, получено: {hotkey!r}")
    parts = [p for p in (s.strip() for s in hotkey.split("+")) if p]
    if not parts:
        raise ValueError("комбинация клавиш не может быть пустой")
    if len(parts) > MAX_HOTKEY_LEN:
        raise ValueError(
            f"слишком длинная комбинация: {len(parts)} > {MAX_HOTKEY_LEN} клавиш"
        )
    keys = [normalize_key(p) for p in parts]
    if len(set(keys)) != len(keys):
        raise ValueError(f"повторяющиеся клавиши в комбинации: {hotkey!r}")
    mains = [k for k in keys if k not in MODIFIERS]
    if len(mains) != 1:
        raise ValueError(
            f"комбинация должна содержать ровно одну основную клавишу: {hotkey!r}"
        )
    mods = [m for m in ("ctrl", "alt", "shift", "meta") if m in keys]
    return tuple(mods + mains)


def validate_coords(x: Any, y: Any) -> tuple[int, int]:
    """Проверяет координаты курсора: целые числа в диапазоне 0..10000."""
    out: list[int] = []
    for name, value in (("x", x), ("y", y)):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f"координата {name} должна быть числом: {value!r}")
        if isinstance(value, float) and not value.is_integer():
            raise ValueError(f"координата {name} должна быть целой: {value!r}")
        ivalue = int(value)
        if not 0 <= ivalue <= 10000:
            raise ValueError(f"координата {name} вне диапазона 0..10000: {ivalue}")
        out.append(ivalue)
    return out[0], out[1]


#: допустимые кнопки мыши
MOUSE_BUTTONS: dict[str, str] = {"left": "left", "middle": "middle", "right": "right"}


def validate_click(button: Any, count: Any) -> tuple[str, int]:
    """Проверяет кнопку мыши (left/middle/right) и число кликов (1..3)."""
    if not isinstance(button, str) or button.strip().lower() not in MOUSE_BUTTONS:
        raise ValueError(
            f"кнопка мыши должна быть left/middle/right: {button!r}"
        )
    if isinstance(count, bool) or not isinstance(count, int):
        raise ValueError(f"число кликов должно быть целым: {count!r}")
    if not 1 <= count <= 3:
        raise ValueError(f"число кликов вне диапазона 1..3: {count}")
    return MOUSE_BUTTONS[button.strip().lower()], count


def validate_scroll(dx: Any, dy: Any) -> tuple[int, int]:
    """Проверяет смещение прокрутки: целые числа в -100..100, не оба нулевые."""
    out: list[int] = []
    for name, value in (("dx", dx), ("dy", dy)):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f"смещение {name} должно быть числом: {value!r}")
        if isinstance(value, float) and not value.is_integer():
            raise ValueError(f"смещение {name} должно быть целым: {value!r}")
        ivalue = int(value)
        if not -100 <= ivalue <= 100:
            raise ValueError(f"смещение {name} вне диапазона -100..100: {ivalue}")
        out.append(ivalue)
    if out[0] == 0 and out[1] == 0:
        raise ValueError("смещение прокрутки не может быть нулевым (dx=dy=0)")
    return out[0], out[1]


# ---------------------------------------------------------------------------
# Экранирование для внешних утилит
# ---------------------------------------------------------------------------
def _osa_quote(text: str) -> str:
    """Экранирует строку для AppleScript-литерала в двойных кавычках."""
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


#: символ → escape-последовательность SendKeys (Windows)
_SENDKEYS_SPECIAL: dict[str, str] = {
    "{": "{{}", "}": "{}}", "+": "{+}", "^": "{^}",
    "%": "{%}", "~": "{~}", "(": "{(}", ")": "{)}",
}


def _sendkeys_escape(text: str) -> str:
    """Экранирует текст для ``SendKeys`` (Windows): спецсимволы +^%~(){}."""
    return "".join(_SENDKEYS_SPECIAL.get(ch, ch) for ch in text)


def _ps_sq(text: str) -> str:
    """Экранирует строку для PowerShell-литерала в одинарных кавычках."""
    return "'" + text.replace("'", "''") + "'"


# ---------------------------------------------------------------------------
# Синтаксис клавиш под платформы
# ---------------------------------------------------------------------------
#: каноническое имя → имя клавиши xdotool (Linux)
_XDOTOOL_KEYS: dict[str, str] = {
    "enter": "Return", "esc": "Escape", "tab": "Tab", "space": "space",
    "backspace": "BackSpace", "delete": "Delete", "insert": "Insert",
    "home": "Home", "end": "End", "page_up": "Prior", "page_down": "Next",
    "up": "Up", "down": "Down", "left": "Left", "right": "Right",
    "ctrl": "ctrl", "alt": "alt", "shift": "shift", "meta": "super",
}

#: каноническое имя → код клавиши macOS (key code в System Events)
_MAC_KEY_CODES: dict[str, int] = {
    "enter": 36, "esc": 53, "tab": 48, "space": 49,
    "backspace": 51, "delete": 117, "insert": 114,
    "home": 115, "end": 119, "page_up": 116, "page_down": 121,
    "left": 123, "right": 124, "down": 125, "up": 126,
    "f1": 122, "f2": 120, "f3": 99, "f4": 118, "f5": 96, "f6": 97,
    "f7": 98, "f8": 100, "f9": 101, "f10": 109, "f11": 103, "f12": 111,
}

#: каноническое имя → модификатор AppleScript
_MAC_MODIFIERS: dict[str, str] = {
    "ctrl": "control down", "alt": "option down",
    "shift": "shift down", "meta": "command down",
}

#: каноническое имя → токен SendKeys (Windows)
_SENDKEYS_KEYS: dict[str, str] = {
    "enter": "{ENTER}", "esc": "{ESC}", "tab": "{TAB}", "space": "{SPACE}",
    "backspace": "{BS}", "delete": "{DEL}", "insert": "{INSERT}",
    "home": "{HOME}", "end": "{END}", "page_up": "{PGUP}", "page_down": "{PGDN}",
    "up": "{UP}", "down": "{DOWN}", "left": "{LEFT}", "right": "{RIGHT}",
}

#: флаги кнопок мыши user32 (Windows): (down, up)
_WIN_MOUSE_EVENTS: dict[str, tuple[int, int]] = {
    "left": (0x0002, 0x0004),
    "right": (0x0008, 0x0010),
    "middle": (0x0020, 0x0040),
}


def _xdotool_hotkey(keys: tuple[str, ...]) -> str:
    """Собирает комбинацию в синтаксис xdotool («ctrl+alt+t»)."""
    return "+".join(_XDOTOOL_KEYS.get(k, k) for k in keys)


def _mac_hotkey_script(keys: tuple[str, ...]) -> str:
    """Собирает AppleScript нажатия комбинации (System Events)."""
    mods = [_MAC_MODIFIERS[k] for k in keys if k in _MAC_MODIFIERS]
    main = keys[-1]
    using = f" using {{{', '.join(mods)}}}" if mods else ""
    if len(main) == 1:  # буква/цифра
        return f"keystroke {_osa_quote(main)}{using}"
    if main in _MAC_KEY_CODES:
        return f"key code {_MAC_KEY_CODES[main]}{using}"
    raise InputError(f"клавиша '{main}' не поддерживается на macOS")


def _sendkeys_hotkey(keys: tuple[str, ...]) -> str:
    """Собирает комбинацию в синтаксис SendKeys (Windows): «^%t»."""
    if "meta" in keys:
        raise InputError("клавиша Win не поддерживается SendKeys (Windows)")
    mods = "".join(
        {"ctrl": "^", "alt": "%", "shift": "+"}[k] for k in keys if k in MODIFIERS
    )
    main = keys[-1]
    if len(main) == 1:
        return mods + _sendkeys_escape(main)
    if main in _SENDKEYS_KEYS:
        return mods + _SENDKEYS_KEYS[main]
    if main.startswith("f") and main[1:].isdigit():
        return mods + "{F" + main[1:] + "}"
    raise InputError(f"клавиша '{main}' не поддерживается SendKeys (Windows)")


# ---------------------------------------------------------------------------
# Контракт исполнителя
# ---------------------------------------------------------------------------
class InputBackend(abc.ABC):
    """Контракт исполнителя операций ввода."""

    name: str = "base"

    @abc.abstractmethod
    def is_available(self) -> bool: ...

    @abc.abstractmethod
    def type_text(self, text: str, delay_ms: int) -> None: ...

    @abc.abstractmethod
    def press_hotkey(self, keys: tuple[str, ...]) -> None: ...

    @abc.abstractmethod
    def mouse_move(self, x: int, y: int) -> None: ...

    @abc.abstractmethod
    def mouse_click(self, button: str, count: int) -> None: ...

    @abc.abstractmethod
    def mouse_scroll(self, dx: int, dy: int) -> None: ...

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "available": self.is_available()}


# ---------------------------------------------------------------------------
# Реальный исполнитель (subprocess)
# ---------------------------------------------------------------------------
#: Тип «запуск argv -> stdout» (подменяется в тестах)
Runner = Callable[[list[str]], str]

#: Максимальная задержка между символами при наборе текста, мс
MAX_TYPE_DELAY_MS = 500


def _default_runner(argv: list[str]) -> str:
    """Выполняет argv и возвращает stdout; ошибки оборачивает в InputError."""
    try:
        proc = subprocess.run(  # noqa: S603 — argv формируем сами, shell=False
            argv,
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
    except FileNotFoundError as e:
        raise InputUnavailable(f"утилита не найдена: {argv[0]}") from e
    except subprocess.TimeoutExpired as e:
        raise InputError(f"таймаут команды: {' '.join(argv)}") from e
    if proc.returncode != 0:
        raise InputError(
            f"команда завершилась с кодом {proc.returncode}: {' '.join(argv)}"
            f" ({proc.stderr.strip()[:200]})"
        )
    return proc.stdout


@dataclass
class SubprocessInputBackend(InputBackend):
    """
    Локальный исполнитель: строит и выполняет команды ввода под текущую ОС.

    runner подменяется в тестах; platform_name позволяет сымитировать
    другую платформу (linux / darwin / windows), which — сымитировать
    наличие утилит (xdotool / ydotool / cliclick).
    """

    name: str = "subprocess"
    runner: Runner = field(default=_default_runner)
    platform_name: str = field(default_factory=platform.system)
    which: Callable[[str], str | None] = field(default=shutil.which)

    def _plat(self) -> str:
        return self.platform_name.lower()

    def _tool(self, *candidates: str) -> str:
        """Возвращает первую доступную утилиту или бросает InputUnavailable."""
        for tool in candidates:
            if self.which(tool):
                return tool
        raise InputUnavailable(
            f"нет утилиты ввода из списка: {', '.join(candidates)}"
        )

    def is_available(self) -> bool:
        plat = self._plat()
        if plat == "linux":
            return bool(self.which("xdotool") or self.which("ydotool"))
        if plat == "darwin":
            return bool(self.which("osascript"))
        if plat == "windows":
            return bool(self.which("powershell") or self.which("pwsh"))
        return False

    # -- текст ---------------------------------------------------------------
    def type_text(self, text: str, delay_ms: int) -> None:
        plat = self._plat()
        if plat == "darwin":
            if delay_ms:
                # посимвольный набор с задержкой (System Events)
                script = (
                    "tell application \"System Events\"\n"
                    f"repeat with ch in characters of {_osa_quote(text)}\n"
                    "keystroke (ch as text)\n"
                    f"delay {delay_ms / 1000:.3f}\n"
                    "end repeat\nend tell"
                )
            else:
                script = (
                    'tell application "System Events" to '
                    f"keystroke {_osa_quote(text)}"
                )
            self.runner(["osascript", "-e", script])
        elif plat == "windows":
            # SendKeys не умеет задержку между символами — набираем целиком
            ps = self._win_assembly_script(
                "System.Windows.Forms",
                ["[System.Windows.Forms.SendKeys]::SendWait("
                 f"{_ps_sq(_sendkeys_escape(text))})"],
            )
            self.runner([self._ps_exe(), "-NoProfile", "-Command", ps])
        else:
            # xdotool/ydotool не различают "--" как конец опций — текст
            # проходит валидацию (без ведущих '-'), поэтому передаётся как есть
            tool = self._tool("xdotool", "ydotool")
            if tool == "xdotool":
                argv = ["xdotool", "type", "--clearmodifiers"]
                if delay_ms:
                    argv += ["--delay", str(delay_ms)]
                self.runner(argv + [text])
            else:
                self.runner(["ydotool", "type", text])

    # -- горячие клавиши -------------------------------------------------------
    def press_hotkey(self, keys: tuple[str, ...]) -> None:
        plat = self._plat()
        if plat == "darwin":
            self.runner(["osascript", "-e", _mac_hotkey_script(keys)])
        elif plat == "windows":
            ps = self._win_assembly_script(
                "System.Windows.Forms",
                ["[System.Windows.Forms.SendKeys]::SendWait("
                 f"{_ps_sq(_sendkeys_hotkey(keys))})"],
            )
            self.runner([self._ps_exe(), "-NoProfile", "-Command", ps])
        else:
            tool = self._tool("xdotool", "ydotool")
            if tool == "xdotool":
                self.runner(["xdotool", "key", "--clearmodifiers",
                             _xdotool_hotkey(keys)])
            else:
                raise InputUnavailable(
                    "горячие клавиши через ydotool не поддерживаются "
                    "нужен xdotool"
                )

    # -- мышь ----------------------------------------------------------------
    def mouse_move(self, x: int, y: int) -> None:
        plat = self._plat()
        if plat == "darwin":
            self.runner(["cliclick", f"m:{x},{y}"])
        elif plat == "windows":
            self.runner([self._ps_exe(), "-NoProfile", "-Command",
                         self._win_user32_script([f"[J.U]::SetCursorPos({x}, {y})"])])
        else:
            self.runner([self._tool("xdotool"), "mousemove", str(x), str(y)])

    def mouse_click(self, button: str, count: int) -> None:
        plat = self._plat()
        if plat == "darwin":
            if button != "left":
                raise InputUnavailable(
                    f"кнопка '{button}' не поддерживается cliclick (macOS)"
                )
            for _ in range(count):
                self.runner(["cliclick", "c:."])
        elif plat == "windows":
            down, up = _WIN_MOUSE_EVENTS[button]
            stmts = [
                f"[J.U]::mouse_event({down}, 0, 0, 0, 0); "
                f"[J.U]::mouse_event({up}, 0, 0, 0, 0)"
                for _ in range(count)
            ]
            self.runner([self._ps_exe(), "-NoProfile", "-Command",
                         self._win_user32_script(stmts)])
        else:
            codes = {"left": "1", "middle": "2", "right": "3"}
            self.runner([self._tool("xdotool"), "click", "--repeat", str(count),
                         codes[button]])

    def mouse_scroll(self, dx: int, dy: int) -> None:
        plat = self._plat()
        if plat == "darwin":
            raise InputUnavailable("прокрутка мыши на macOS не поддерживается")
        if plat == "windows":
            stmts: list[str] = []
            if dy:
                stmts.append(f"[J.U]::mouse_event(0x0800, 0, 0, {dy * 120}, 0)")
            if dx:
                stmts.append(f"[J.U]::mouse_event(0x1000, 0, 0, {dx * 120}, 0)")
            self.runner([self._ps_exe(), "-NoProfile", "-Command",
                         self._win_user32_script(stmts)])
            return
        # Linux: 4=вверх, 5=вниз, 6=влево, 7=вправо
        tool = self._tool("xdotool")
        if dy:
            code = "4" if dy > 0 else "5"
            self.runner([tool, "click", "--repeat", str(abs(dy)), code])
        if dx:
            code = "7" if dx > 0 else "6"
            self.runner([tool, "click", "--repeat", str(abs(dx)), code])

    # -- помощники -------------------------------------------------------------
    def _ps_exe(self) -> str:
        return "pwsh" if self.which("pwsh") else "powershell"

    @staticmethod
    def _win_assembly_script(assembly: str, statements: list[str]) -> str:
        """Собирает PowerShell-скрипт: загрузка .NET-сборки + операции."""
        return f"Add-Type -AssemblyName {assembly}; " + "; ".join(statements)

    @staticmethod
    def _win_user32_script(statements: list[str]) -> str:
        """Собирает PowerShell-скрипт с P/Invoke user32 для операций мыши."""
        header = (
            "Add-Type -Namespace J -Name U -MemberDefinition "
            "'[DllImport(\"user32.dll\")] public static extern bool "
            "SetCursorPos(int X,int Y); "
            "[DllImport(\"user32.dll\")] public static extern void "
            "mouse_event(uint f,uint x,uint y,uint d,uint e);'"
        )
        return header + "; " + "; ".join(statements)


# ---------------------------------------------------------------------------
# Безопасный исполнитель (fallback / отладка / тесты)
# ---------------------------------------------------------------------------
@dataclass
class DryRunInputBackend(InputBackend):
    """
    Ничего не вводит: записывает операции в ``calls``. Используется в тестах
    и как fallback при недоступности системных утилит ввода.
    """

    name: str = "dry-run"
    available: bool = True
    calls: list[tuple[str, tuple[Any, ...]]] = field(default_factory=list)

    def is_available(self) -> bool:
        return self.available

    def type_text(self, text: str, delay_ms: int) -> None:
        self.calls.append(("type_text", (text, delay_ms)))

    def press_hotkey(self, keys: tuple[str, ...]) -> None:
        self.calls.append(("press_hotkey", (keys,)))

    def mouse_move(self, x: int, y: int) -> None:
        self.calls.append(("mouse_move", (x, y)))

    def mouse_click(self, button: str, count: int) -> None:
        self.calls.append(("mouse_click", (button, count)))

    def mouse_scroll(self, dx: int, dy: int) -> None:
        self.calls.append(("mouse_scroll", (dx, dy)))


# ---------------------------------------------------------------------------
# Служба команд ввода
# ---------------------------------------------------------------------------
@dataclass
class InputActions:
    """
    Служба команд ввода: строгая валидация входа + нормализация клавиш + backend.

    При недоступности backend операции падают контролируемо
    (``InputUnavailable``), без побочных эффектов.
    """

    backend: InputBackend = field(default_factory=SubprocessInputBackend)

    def _require_backend(self) -> InputBackend:
        if not self.backend.is_available():
            raise InputUnavailable(
                f"исполнитель '{self.backend.name}' недоступен"
            )
        return self.backend

    # -- команды ------------------------------------------------------------
    def type_text(self, text: str, delay_ms: int = 12) -> str:
        """Набрать текст в активном окне (после подтверждения)."""
        clean = validate_text(text)
        if isinstance(delay_ms, bool) or not isinstance(delay_ms, int):
            raise ValueError(f"задержка должна быть целым числом мс: {delay_ms!r}")
        if not 0 <= delay_ms <= MAX_TYPE_DELAY_MS:
            raise ValueError(
                f"задержка вне диапазона 0..{MAX_TYPE_DELAY_MS} мс: {delay_ms}"
            )
        self._require_backend().type_text(clean, delay_ms)
        logger.info("Введено %d символов", len(clean))
        return f"Ввожу текст ({len(clean)} символов)."

    def press_hotkey(self, hotkey: str) -> str:
        """Нажать комбинацию клавиш в активном окне (после подтверждения)."""
        keys = parse_hotkey(hotkey)
        self._require_backend().press_hotkey(keys)
        logger.info("Нажата комбинация: %s", "+".join(keys))
        return f"Нажимаю {'+'.join(keys)}."

    def mouse_move(self, x: int, y: int) -> str:
        """Переместить курсор мыши в точку (x, y)."""
        cx, cy = validate_coords(x, y)
        self._require_backend().mouse_move(cx, cy)
        return f"Курсор перемещён в ({cx}, {cy})."

    def mouse_click(self, button: str = "left", count: int = 1) -> str:
        """Кликнуть кнопкой мыши в текущей позиции курсора."""
        btn, n = validate_click(button, count)
        self._require_backend().mouse_click(btn, n)
        logger.info("Клик мышью: %s x%d", btn, n)
        plural = {1: "Клик", 2: "Двойной клик", 3: "Тройной клик"}.get(
            n, f"{n} клика"
        )
        return f"{plural} кнопкой '{btn}'."

    def mouse_scroll(self, dx: int = 0, dy: int = 0) -> str:
        """Прокрутить колесо мыши: dy>0 — вверх, dx>0 — вправо."""
        sdx, sdy = validate_scroll(dx, dy)
        self._require_backend().mouse_scroll(sdx, sdy)
        return f"Прокрутка: dx={sdx}, dy={sdy}."


# ---------------------------------------------------------------------------
# Регистрация команд в реестре
# ---------------------------------------------------------------------------
def _spec(name: str, type_: str, description: str, **kw: Any) -> ParamSpec:
    return ParamSpec(
        name=name,
        type=type_,
        description=description,
        required=kw.get("required", True),
        enum=kw.get("enum"),
        default=kw.get("default"),
    )


def register_input_actions(
    registry: CommandRegistry,
    actions: InputActions | None = None,
) -> list[str]:
    """
    Регистрирует команды ввода в ``registry`` (возвращает их имена).

    Уровни риска (ТЗ-6.7):
      - SAFE:   mouse_move, mouse_scroll
      - MEDIUM: type_text, press_hotkey, mouse_click (требуют подтверждения:
                могут нажать кнопки в активном окне/диалоге)
    """
    svc = actions or InputActions()

    defs: list[tuple[str, str, list[ParamSpec], str, Callable[..., Any]]] = [
        (
            "mouse_move",
            "Переместить курсор мыши в точку (x, y)",
            [
                _spec("x", "number", "координата X (0..10000)"),
                _spec("y", "number", "координата Y (0..10000)"),
            ],
            RiskLevel.SAFE,
            svc.mouse_move,
        ),
        (
            "mouse_scroll",
            "Прокрутить колесо мыши (dy>0 — вверх, dx>0 — вправо)",
            [
                _spec("dx", "number", "горизонтальное смещение (-100..100)",
                      required=False, default=0),
                _spec("dy", "number", "вертикальное смещение (-100..100)",
                      required=False, default=0),
            ],
            RiskLevel.SAFE,
            svc.mouse_scroll,
        ),
        (
            "type_text",
            "Набрать текст в активном окне (после подтверждения)",
            [
                _spec("text", "string", "текст для набора (до 2000 символов)"),
                _spec("delay_ms", "number", "задержка между символами, мс",
                      required=False, default=12),
            ],
            RiskLevel.MEDIUM,
            svc.type_text,
        ),
        (
            "press_hotkey",
            "Нажать комбинацию клавиш, например ctrl+alt+t (после подтверждения)",
            [_spec("hotkey", "string", "комбинация: ctrl+alt+t, enter, f5…")],
            RiskLevel.MEDIUM,
            svc.press_hotkey,
        ),
        (
            "mouse_click",
            "Кликнуть кнопкой мыши в текущей позиции курсора",
            [
                _spec("button", "string", "кнопка мыши",
                      required=False, enum=["left", "middle", "right"],
                      default="left"),
                _spec("count", "number", "число кликов (1..3)",
                      required=False, default=1),
            ],
            RiskLevel.MEDIUM,
            svc.mouse_click,
        ),
    ]

    names: list[str] = []
    for name, description, params, risk, handler in defs:
        registry.register(
            Command(
                name=name,
                description=description,
                params=params,
                handler=handler,
                risk=risk,
                requires_confirmation=REQUIRES_CONFIRMATION.get(risk, False),
            )
        )
        names.append(name)
    logger.debug("Зарегистрированы команды ввода: %s", ", ".join(names))
    return names
