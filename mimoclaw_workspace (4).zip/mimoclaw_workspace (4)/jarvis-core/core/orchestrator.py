"""
Оркестратор JARVIS CORE — главный цикл пайплайна.

Реализует связку:  речь -> STT -> ContextBuilder -> LLM (function calling)
-> действие (actions) -> ответ -> TTS.

Работает с любым аудио/движками через инжектируемые зависимости, поэтому
логика полностью тестируется на моках (без микрофона и сети).
Реальное «микрофон -> динамики» подключается в audio/* и main.py.

Использование:
    orch = Orchestrator(llm=..., tts=..., registry=..., context=...)
    result = await orch.process_text("поставь громкость 50")
    print(result.reply)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from actions.registry import CommandRegistry
from ai.context_builder import ContextBuilder
from ai.function_calling import to_openai_tools
from ai.llm_router import LLMRouter
from ai.personas import Persona, get_persona
from ai.providers.base import LLMMessage, LLMResponse
from speech.stt_engine import STRouter, Transcript
from speech.tts_engine import TTSRouter, VoicePreset

logger = logging.getLogger(__name__)

# Максимум раундов function calling за один запрос (защита от зацикливания)
MAX_TOOL_ROUNDS = 5


@dataclass
class ActionResult:
    """Результат выполнения одной команды."""

    name: str
    ok: bool
    output: Any = None
    error: str | None = None


@dataclass
class PipelineResult:
    """Итог обработки одной реплики."""

    transcript: str = ""
    reply: str = ""
    actions: list[ActionResult] = field(default_factory=list)
    used_provider: str = ""
    used_stt: str = ""
    used_tts: str = ""
    audio: bytes | None = None  # PCM озвученного ответа (если TTS включён)


class Orchestrator:
    """Связывает STT/LLM/TTS и реестр команд в единый конвейер."""

    def __init__(
        self,
        llm: LLMRouter,
        tts: TTSRouter | None = None,
        stt: STRouter | None = None,
        registry: CommandRegistry | None = None,
        context: ContextBuilder | None = None,
        persona_key: str = "jarvis",
        voice_preset: VoicePreset | None = None,
        speak: bool = True,
    ) -> None:
        self.llm = llm
        self.tts = tts
        self.stt = stt
        self.registry = registry or CommandRegistry()
        self.context = context or ContextBuilder(persona_key=persona_key)
        self.persona_key = persona_key
        self.voice_preset = voice_preset
        self.speak = speak

    # -- публичный API -------------------------------------------------------
    async def process_text(
        self,
        user_text: str,
        history: list[dict[str, Any]] | None = None,
    ) -> PipelineResult:
        """Обработать текстовую реплику (без аудио)."""
        persona = get_persona(self.persona_key)
        messages = self._to_llm_messages(
            self.context.build_messages(persona=persona, history=history, user_text=user_text)
        )
        tools = to_openai_tools(self.registry.enabled_tools()) or None

        result = PipelineResult(transcript=user_text)
        final_text = ""
        for _round in range(MAX_TOOL_ROUNDS):
            resp = await self.llm.ask(messages, tools=tools)
            result.used_provider = resp.provider

            if not resp.has_tool_calls:
                final_text = resp.content
                break

            # Есть вызовы инструментов — выполняем и кормим результаты обратно
            messages.append(LLMMessage.assistant(resp.content, resp.tool_calls))
            for call in resp.tool_calls:
                action_result = await self._run_action(call.name, call.arguments)
                result.actions.append(action_result)
                messages.append(
                    LLMMessage(
                        role="tool",
                        name=call.name,
                        tool_call_id=call.id,
                        content=str(action_result.output if action_result.ok else action_result.error),
                    )
                )
        else:
            # Не вышли из цикла tool calls — просим финальный текстовый ответ
            resp = await self.llm.ask(messages, tools=None)
            final_text = resp.content

        result.reply = final_text

        # Озвучка ответа
        if self.speak and self.tts is not None and final_text:
            try:
                audio = await self.tts.synthesize(final_text, preset=self.voice_preset)
                result.audio = audio.pcm
                result.used_tts = audio.engine
            except Exception:  # noqa: BLE001 — озвучка не должна ронять пайплайн
                logger.warning("TTS недоступен, ответ только текстом", exc_info=True)
        return result

    async def process_audio(
        self,
        pcm: bytes,
        *,
        sample_rate: int = 16000,
        language: str = "auto",
        history: list[dict[str, Any]] | None = None,
    ) -> PipelineResult:
        """Обработать голос: STT -> process_text."""
        if self.stt is None:
            raise RuntimeError("STT-роутер не подключён")
        transcript: Transcript = await self.stt.transcribe(
            pcm, sample_rate=sample_rate, language=language
        )
        result = await self.process_text(transcript.text, history=history)
        result.used_stt = transcript.engine
        return result

    # -- внутренние ----------------------------------------------------------
    async def _run_action(self, name: str, args: dict[str, Any]) -> ActionResult:
        """Выполнить команду из реестра с учётом подтверждения (упрощённо)."""
        cmd = self.registry.get(name)
        if cmd is None:
            return ActionResult(name=name, ok=False, error=f"неизвестная команда: {name}")
        if not cmd.enabled:
            return ActionResult(name=name, ok=False, error=f"команда отключена: {name}")
        if cmd.risk == "forbidden":
            return ActionResult(name=name, ok=False, error=f"команда запрещена: {name}")
        try:
            output = await cmd.run(**args)
            logger.info("Команда '%s' выполнена: %s", name, args)
            return ActionResult(name=name, ok=True, output=output)
        except Exception as exc:  # noqa: BLE001 — ошибка действия не роняет пайплайн
            logger.exception("Команда '%s' упала", name)
            return ActionResult(name=name, ok=False, error=str(exc))

    @staticmethod
    def _to_llm_messages(raw: list[dict[str, Any]]) -> list[LLMMessage]:
        """Конвертирует role/content словари в LLMMessage."""
        out: list[LLMMessage] = []
        for m in raw:
            out.append(LLMMessage(role=m.get("role", "user"), content=m.get("content", "")))
        return out
