/**
 * JARVIS CORE — панель управления.
 *
 * Левое меню + роутинг разделов. Живое подключение к ядру (WS) поднимается
 * в Layout и держится на всех страницах.
 */

import { Route, Routes } from "react-router-dom";
import { Layout } from "./components/Layout";
import { Card, EmptyState } from "./components/ui/panels";
import { CommandsPage } from "./pages/CommandsPage";
import { DashboardPage } from "./pages/DashboardPage";
import { DiagnosticsPage } from "./pages/DiagnosticsPage";
import { FunPage } from "./pages/FunPage";
import { MemoryPage } from "./pages/MemoryPage";
import { ModelsPage } from "./pages/ModelsPage";
import { SecurityPage } from "./pages/SecurityPage";
import { SettingsPage } from "./pages/SettingsPage";
import { TelegramPage } from "./pages/TelegramPage";
import { VisionPage } from "./pages/VisionPage";
import { VoicePage } from "./pages/VoicePage";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<DashboardPage />} />
        <Route path="voice" element={<VoicePage />} />
        <Route path="commands" element={<CommandsPage />} />
        <Route path="models" element={<ModelsPage />} />
        <Route path="vision" element={<VisionPage />} />
        <Route path="memory" element={<MemoryPage />} />
        <Route path="telegram" element={<TelegramPage />} />
        <Route path="security" element={<SecurityPage />} />
        <Route path="fun" element={<FunPage />} />
        <Route path="diagnostics" element={<DiagnosticsPage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route
          path="*"
          element={
            <Card title="Раздел не найден">
              <EmptyState icon="⌁" title="404 — такого раздела нет" hint="Выберите пункт в левом меню" />
            </Card>
          }
        />
      </Route>
    </Routes>
  );
}
