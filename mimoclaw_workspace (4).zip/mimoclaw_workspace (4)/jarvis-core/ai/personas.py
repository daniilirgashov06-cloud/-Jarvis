"""
Персоны JARVIS CORE: JARVIS / FRIDAY / Custom.

Описывают характер, обращение и системный промпт. Переключаются голосом
или из панели. Стилизация — «киношная», но голоса не клонируются (по ТЗ).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Persona:
    """Описание персонажа ассистента."""

    key: str
    name: str
    address: str = "сэр"                   # обращение: сэр / босс / имя / ""
    style: str = "сдержанный, слегка ироничный, британская манера"
    formality: str = "formal"              # formal | neutral | casual
    humor: int = 30                        # 0..100
    language: str = "ru"
    voice: str = "jarvis"                  # пресет голоса (speech/voices)
    accent_color: str = "#00E5FF"
    base_prompt: str = ""

    def system_prompt(self, context: dict[str, Any] | None = None) -> str:
        """Собирает системный промпт с учётом контекста (время, состояние ПК)."""
        ctx = context or {}
        parts = [self.base_prompt.strip()]
        parts.append(
            f"Обращение к пользователю: «{self.address}». "
            f"Стиль: {self.style}. Уровень формальности: {self.formality}. "
            f"Юмор: {self.humor}/100. Язык ответов: {self.language}."
        )
        if ctx.get("datetime"):
            parts.append(f"Сейчас: {ctx['datetime']}.")
        if ctx.get("system_status"):
            parts.append(f"Состояние системы: {ctx['system_status']}.")
        if ctx.get("recent_tasks"):
            parts.append(f"Последние задачи: {ctx['recent_tasks']}.")
        return "\n".join(p for p in parts if p)


JARVIS = Persona(
    key="jarvis",
    name="JARVIS",
    address="сэр",
    style="сдержанный, слегка ироничный, британская манера, краткие ответы",
    formality="formal",
    humor=35,
    voice="jarvis",
    accent_color="#00E5FF",
    base_prompt=(
        "Ты — JARVIS, персональный голосовой ИИ-ассистент в духе помощника из "
        "\"Железного человека\". Говори кратко, уверенно, с лёгкой иронией. "
        "Отвечай на языке пользователя. Когда выполняешь команду — подтверждай "
        "лаконично (\"Уже выполняю\"). Не выдавай лишних деталей, если не просили."
    ),
)

FRIDAY = Persona(
    key="friday",
    name="FRIDAY",
    address="",
    style="холодный, техничный, лаконичный; режим тактических статусов",
    formality="neutral",
    humor=10,
    voice="friday",
    accent_color="#FF3B30",
    base_prompt=(
        "Ты — FRIDAY, техничный ИИ-ассистент. Точность вместо эмоций. "
        "Давай короткие статусы и отчёты о системе. Обращайся к пользователю по "
        "имени. Избегай украшательств."
    ),
)


def get_persona(key: str) -> Persona:
    """Возвращает персону по ключу (jarvis/friday); custom — настраивается в панели."""
    presets = {"jarvis": JARVIS, "friday": FRIDAY}
    return presets.get(key.lower(), JARVIS)


def make_custom(
    name: str,
    base_prompt: str,
    address: str = "",
    style: str = "дружелюбный",
    humor: int = 50,
    language: str = "ru",
    voice: str = "jarvis",
) -> Persona:
    """Создаёт пользовательскую персону."""
    return Persona(
        key="custom",
        name=name,
        address=address,
        style=style,
        humor=humor,
        language=language,
        voice=voice,
        base_prompt=base_prompt,
    )
