"""
Команды экрана JARVIS CORE (ТЗ-6, каталог screen).

Команды уровня «экран»: размер экрана, список окон, активное окно,
скриншот в файл. Каждая команда имеет уровень риска (``RiskLevel``)
и регистрируется в ``CommandRegistry``, откуда она попадает в схемы
function calling для LLM.

Архитектура (в стиле ``actions/input_actions.py`` / ``actions/file_actions.py``):

- ``ScreenBackend`` — контракт «исполнитель» операций над экраном;
- ``SubprocessScreenBackend`` — локальная реализация через subprocess
  (Linux: xrandr/xdpyinfo + scrot/import/grim + wmctrl/xdotool,
  macOS: system_profiler + screencapture + osascript,
  Windows: PowerShell + System.Windows.Forms/System.Drawing/user32);
- ``DryRunScreenBackend`` — безопасный fallback/отладка: не трогает экран,
  пишет «скриншот»-заглушку и записывает вызовы (используется и в тестах).

«Локально ↔ облако» здесь неприменимо: всё выполняется локально.
При недоступности исполнителя команда падает контролируемо
(``ScreenUnavailable``) без побочных эффектов.

Приватность: скриншот — снимок всего экрана, поэтому команда
``take_screenshot`` уровня MEDIUM (требует подтверждения), файл пишется
только по явному пути/в разрешённую папку, запрещённые пути
(``SecurityConfig.forbidden_paths``) блокируются.

Использование:
    from actions.registry import CommandRegistry
    from actions.screen_actions import ScreenActions, register_screen_actions

    registry = CommandRegistry()
    register_screen_actions(registry)        # или со своим backend
"""

from __future__ import annotations

import abc
import logging
import platform
import re
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from actions.registry import REQUIRES_CONFIRMATION, Command, CommandRegistry, RiskLevel
from ai.function_calling import ParamSpec

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class ScreenError(Exception):
    """Ошибка команды экрана."""


class ScreenUnavailable(ScreenError):
    """Исполнитель недоступен (нет утилиты/дисплея/прав) — можно fallback."""


# ---------------------------------------------------------------------------
# Валидация
# ---------------------------------------------------------------------------
#: Допустимые расширения файлов скриншотов
SCREENSHOT_EXTS: frozenset[str] = frozenset({".png", ".jpg", ".jpeg", ".bmp"})

#: Максимальное число возвращаемых окон
MAX_WINDOWS = 200


def validate_screenshot_path(
    path: Any,
    output_dir: str | Path | None = None,
    forbidden_paths: list[str] | None = None,
) -> Path:
    """
    Проверяет путь сохранения скриншота и возвращает абсолютный ``Path``.

    Правила:
      - путь — непустая строка без управляющих символов и ведущего '-'
        (антиинъекция опций в argv утилит скриншотов);
      - расширение из ``SCREENSHOT_EXTS``;
      - родительская папка создаётся при необходимости;
      - путь не попадает в ``forbidden_paths`` (политика безопасности);
      - при ``path=None`` файл создаётся в ``output_dir`` с именем
        ``screenshot_<epoch>.png``.
    """
    if path is None:
        base = Path(output_dir or "screenshots").expanduser()
        target = base / f"screenshot_{int(time.time())}.png"
    else:
        if not isinstance(path, str):
            raise ValueError(f"путь должен быть строкой, получено: {path!r}")
        if not path.strip():
            raise ValueError("путь не может быть пустым")
        if any(ord(ch) < 32 for ch in path):
            raise ValueError("путь содержит управляющие символы")
        if path.startswith("-"):
            raise ValueError(
                "путь не должен начинаться с '-' (инъекция опций в argv)"
            )
        target = Path(path).expanduser()
        if target.suffix.lower() not in SCREENSHOT_EXTS:
            raise ValueError(
                f"неподдерживаемое расширение скриншота: {target.suffix!r} "
                f"(допустимы: {', '.join(sorted(SCREENSHOT_EXTS))})"
            )

    resolved = target.resolve()
    for bad in forbidden_paths or []:
        if bad and str(resolved).startswith(str(Path(bad).expanduser().resolve())):
            raise ScreenError(f"Путь запрещён политикой безопасности: {resolved}")
    return resolved


# ---------------------------------------------------------------------------
# Данные
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ScreenSize:
    """Размер экрана в пикселях."""

    width: int
    height: int

    def describe(self) -> dict[str, int]:
        return {"width": self.width, "height": self.height}


@dataclass(frozen=True)
class WindowInfo:
    """Окно на экране."""

    id: str
    title: str
    app: str | None = None

    def describe(self) -> dict[str, Any]:
        return {"id": self.id, "title": self.title, "app": self.app}


# ---------------------------------------------------------------------------
# Контракт исполнителя
# ---------------------------------------------------------------------------
class ScreenBackend(abc.ABC):
    """Контракт исполнителя операций над экраном."""

    name: str = "base"

    @abc.abstractmethod
    def is_available(self) -> bool: ...

    @abc.abstractmethod
    def screen_size(self) -> ScreenSize: ...

    @abc.abstractmethod
    def screenshot(self, path: Path) -> int:
        """Сделать скриншот всего экрана в ``path``; вернуть размер файла, байт."""

    @abc.abstractmethod
    def list_windows(self) -> list[WindowInfo]: ...

    @abc.abstractmethod
    def active_window(self) -> WindowInfo: ...

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "available": self.is_available()}


# ---------------------------------------------------------------------------
# Реальный исполнитель (subprocess)
# ---------------------------------------------------------------------------
#: Тип «запуск argv -> stdout» (подменяется в тестах)
Runner = Callable[[list[str]], str]


def _default_runner(argv: list[str]) -> str:
    """Выполняет argv и возвращает stdout; ошибки оборачивает в ScreenError."""
    try:
        proc = subprocess.run(  # noqa: S603 — argv формируем сами, shell=False
            argv,
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
    except FileNotFoundError as e:
        raise ScreenUnavailable(f"утилита не найдена: {argv[0]}") from e
    except subprocess.TimeoutExpired as e:
        raise ScreenError(f"таймаут команды: {' '.join(argv)}") from e
    if proc.returncode != 0:
        raise ScreenError(
            f"команда завершилась с кодом {proc.returncode}: {' '.join(argv)}"
            f" ({proc.stderr.strip()[:200]})"
        )
    return proc.stdout


#: «current 1920 x 1080» (xrandr) и «1920x1080 pixels» (xdpyinfo)
_RE_XRANDR = re.compile(r"current\s+(\d+)\s*x\s+(\d+)")
_RE_XDXY = re.compile(r"dimensions:\s+(\d+)x(\d+)\s+pixels")
#: «Resolution: 2560 x 1600» (system_profiler, macOS)
_RE_MAC_RES = re.compile(r"Resolution:\s+(\d+)\s*x\s+(\d+)")
#: строка wmctrl: «0x04200003  0 host Заголовок окна»
_RE_WMCTRL = re.compile(r"^(0x[0-9a-fA-F]+)\s+(-?\d+)\s+\S+\s*(.*)$")


@dataclass
class SubprocessScreenBackend(ScreenBackend):
    """
    Локальный исполнитель: строит и выполняет команды под текущую ОС.

    runner подменяется в тестах; platform_name позволяет сымитировать
    другую платформу (linux / darwin / windows), which — сымитировать
    наличие утилит (scrot / grim / wmctrl / xdotool / screencapture).
    """

    name: str = "subprocess"
    runner: Runner = field(default=_default_runner)
    platform_name: str = field(default_factory=platform.system)
    which: Callable[[str], str | None] = field(default=shutil.which)

    def _plat(self) -> str:
        return self.platform_name.lower()

    def _tool(self, *candidates: str) -> str:
        """Возвращает первую доступную утилиту или бросает ScreenUnavailable."""
        for tool in candidates:
            if self.which(tool):
                return tool
        raise ScreenUnavailable(
            f"нет утилиты из списка: {', '.join(candidates)}"
        )

    def is_available(self) -> bool:
        plat = self._plat()
        if plat == "linux":
            return bool(self.which("xrandr") or self.which("xdpyinfo"))
        if plat == "darwin":
            return bool(self.which("system_profiler"))
        if plat == "windows":
            return bool(self.which("powershell") or self.which("pwsh"))
        return False

    # -- размер экрана -------------------------------------------------------
    def screen_size(self) -> ScreenSize:
        plat = self._plat()
        if plat == "darwin":
            out = self.runner(["system_profiler", "SPDisplaysDataType"])
            m = _RE_MAC_RES.search(out)
            if not m:
                raise ScreenError("не удалось определить разрешение экрана (macOS)")
            return ScreenSize(int(m.group(1)), int(m.group(2)))
        if plat == "windows":
            ps = (
                "Add-Type -AssemblyName System.Windows.Forms; "
                "$b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds; "
                "Write-Output \"$($b.Width) $($b.Height)\""
            )
            out = self.runner([self._ps_exe(), "-NoProfile", "-Command", ps])
            parts = out.split()
            if len(parts) < 2 or not parts[0].isdigit() or not parts[1].isdigit():
                raise ScreenError(f"не удалось разобрать размер экрана: {out!r}")
            return ScreenSize(int(parts[0]), int(parts[1]))
        # Linux: xrandr, при отказе — xdpyinfo
        if self.which("xrandr"):
            out = self.runner(["xrandr", "--current"])
            m = _RE_XRANDR.search(out)
            if m:
                return ScreenSize(int(m.group(1)), int(m.group(2)))
        tool = self._tool("xdpyinfo", "xrandr")
        out = self.runner(
            ["xdpyinfo"] if tool == "xdpyinfo" else ["xrandr", "--current"]
        )
        m = _RE_XDXY.search(out)
        if not m:
            raise ScreenError("не удалось определить разрешение экрана (Linux)")
        return ScreenSize(int(m.group(1)), int(m.group(2)))

    # -- скриншот -------------------------------------------------------------
    def screenshot(self, path: Path) -> int:
        plat = self._plat()
        target = str(path)
        if plat == "darwin":
            self.runner(["screencapture", "-x", target])
        elif plat == "windows":
            ps = (
                "Add-Type -AssemblyName System.Windows.Forms; "
                "Add-Type -AssemblyName System.Drawing; "
                "$b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds; "
                "$bmp = New-Object System.Drawing.Bitmap $b.Width, $b.Height; "
                "$g = [System.Drawing.Graphics]::FromImage($bmp); "
                "$g.CopyFromScreen($b.Location, [System.Drawing.Point]::Empty, $b.Size); "
                f"$bmp.Save({_ps_sq(target)}); $g.Dispose(); $bmp.Dispose()"
            )
            self.runner([self._ps_exe(), "-NoProfile", "-Command", ps])
        else:
            # Wayland → grim, иначе scrot / import (ImageMagick)
            if self.which("grim"):
                self.runner(["grim", target])
            else:
                tool = self._tool("scrot", "import")
                if tool == "scrot":
                    self.runner(["scrot", "--overwrite", target])
                else:
                    self.runner(["import", "-window", "root", target])
        try:
            return path.stat().st_size
        except OSError as e:
            raise ScreenError(f"скриншот не создан: {path}") from e

    # -- окна -----------------------------------------------------------------
    def list_windows(self) -> list[WindowInfo]:
        plat = self._plat()
        if plat == "darwin":
            script = (
                'tell application "System Events"\n'
                "set out to \"\"\n"
                "repeat with p in (every process whose background only is false)\n"
                "repeat with w in windows of p\n"
                "set out to out & (name of p) & \"\\t\" & (name of w) & linefeed\n"
                "end repeat\nend repeat\nreturn out\nend tell"
            )
            out = self.runner(["osascript", "-e", script])
            windows: list[WindowInfo] = []
            for i, line in enumerate(out.splitlines()):
                if "\t" in line:
                    app, title = line.split("\t", 1)
                else:
                    app, title = None, line
                if title.strip():
                    windows.append(WindowInfo(str(i), title.strip(), app.strip() or None))
            return windows[:MAX_WINDOWS]
        if plat == "windows":
            ps = (
                "Get-Process | Where-Object {$_.MainWindowTitle} | "
                "ForEach-Object { Write-Output ($_.Id.ToString() + '|' + "
                "$_.MainWindowTitle) }"
            )
            out = self.runner([self._ps_exe(), "-NoProfile", "-Command", ps])
            windows = []
            for line in out.splitlines():
                if "|" in line:
                    wid, title = line.split("|", 1)
                    if title.strip():
                        windows.append(WindowInfo(wid.strip(), title.strip()))
            return windows[:MAX_WINDOWS]
        # Linux: wmctrl проще, xdotool — запасной вариант
        if self.which("wmctrl"):
            out = self.runner(["wmctrl", "-l"])
            windows = []
            for line in out.splitlines():
                m = _RE_WMCTRL.match(line)
                if m and m.group(3).strip():
                    windows.append(WindowInfo(m.group(1), m.group(3).strip()))
            return windows[:MAX_WINDOWS]
        tool = self._tool("xdotool")
        out = self.runner([tool, "search", "--onlyvisible", "--name", "."])
        windows = []
        for wid in out.split():
            try:
                title = self.runner([tool, "getwindowname", wid]).strip()
            except ScreenError:
                continue
            if title:
                windows.append(WindowInfo(wid, title))
        return windows[:MAX_WINDOWS]

    def active_window(self) -> WindowInfo:
        plat = self._plat()
        if plat == "darwin":
            script = (
                'tell application "System Events" to get name of first window '
                "of (first process whose frontmost is true)"
            )
            title = self.runner(["osascript", "-e", script]).strip()
            if not title:
                raise ScreenError("нет активного окна (macOS)")
            return WindowInfo("active", title)
        if plat == "windows":
            ps = (
                "Add-Type -Namespace J -Name W -MemberDefinition "
                "'[DllImport(\"user32.dll\")] public static extern IntPtr "
                "GetForegroundWindow(); "
                "[DllImport(\"user32.dll\")] public static extern int "
                "GetWindowText(IntPtr h, System.Text.StringBuilder t, int c);'; "
                "$h = [J.W]::GetForegroundWindow(); "
                "$sb = New-Object System.Text.StringBuilder 512; "
                "[J.W]::GetWindowText($h, $sb, $sb.Capacity) | Out-Null; "
                "Write-Output ($h.ToString() + '|' + $sb.ToString())"
            )
            out = self.runner([self._ps_exe(), "-NoProfile", "-Command", ps])
            wid, _, title = out.strip().partition("|")
            if not title.strip():
                raise ScreenError("нет активного окна (Windows)")
            return WindowInfo(wid.strip() or "active", title.strip())
        tool = self._tool("xdotool")
        wid = self.runner([tool, "getactivewindow"]).strip()
        title = self.runner([tool, "getwindowname", wid]).strip()
        if not title:
            raise ScreenError("нет активного окна (Linux)")
        return WindowInfo(wid or "active", title)

    # -- помощники -------------------------------------------------------------
    def _ps_exe(self) -> str:
        return "pwsh" if self.which("pwsh") else "powershell"


def _ps_sq(text: str) -> str:
    """Экранирует строку для PowerShell-литерала в одинарных кавычках."""
    return "'" + text.replace("'", "''") + "'"


# ---------------------------------------------------------------------------
# Безопасный исполнитель (fallback / отладка / тесты)
# ---------------------------------------------------------------------------
@dataclass
class DryRunScreenBackend(ScreenBackend):
    """
    Не трогает экран: пишет файл-заглушку скриншота и записывает вызовы
    в ``calls``. Используется в тестах и как fallback при недоступности
    системных утилит (без дисплея, без прав, в контейнере).
    """

    name: str = "dry-run"
    available: bool = True
    size: ScreenSize = field(default_factory=lambda: ScreenSize(1920, 1080))
    windows: list[WindowInfo] = field(default_factory=list)
    active: WindowInfo | None = None
    shot_bytes: bytes = b"\x89PNG\r\n\x1a\n" + b"jarvis-dry-run"
    calls: list[tuple[str, tuple[Any, ...]]] = field(default_factory=list)

    def is_available(self) -> bool:
        return self.available

    def screen_size(self) -> ScreenSize:
        self.calls.append(("screen_size", ()))
        return self.size

    def screenshot(self, path: Path) -> int:
        self.calls.append(("screenshot", (str(path),)))
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(self.shot_bytes)
        return len(self.shot_bytes)

    def list_windows(self) -> list[WindowInfo]:
        self.calls.append(("list_windows", ()))
        return list(self.windows)

    def active_window(self) -> WindowInfo:
        self.calls.append(("active_window", ()))
        if self.active is None:
            raise ScreenUnavailable("в dry-run нет активного окна")
        return self.active


# ---------------------------------------------------------------------------
# Служба команд экрана
# ---------------------------------------------------------------------------
@dataclass
class ScreenActions:
    """
    Служба команд экрана: валидация путей/параметров + backend.

    При недоступности backend операции падают контролируемо
    (``ScreenUnavailable``), без побочных эффектов.
    """

    backend: ScreenBackend = field(default_factory=SubprocessScreenBackend)
    output_dir: str = "screenshots"
    forbidden_paths: list[str] = field(default_factory=list)

    def _require_backend(self) -> ScreenBackend:
        if not self.backend.is_available():
            raise ScreenUnavailable(
                f"исполнитель '{self.backend.name}' недоступен"
            )
        return self.backend

    # -- команды (SAFE) -------------------------------------------------------
    def screen_info(self) -> dict[str, Any]:
        """Размер экрана в пикселях."""
        size = self._require_backend().screen_size()
        return size.describe()

    def list_windows(self) -> list[dict[str, Any]]:
        """Список видимых окон (id, заголовок, приложение)."""
        windows = self._require_backend().list_windows()
        return [w.describe() for w in windows]

    def active_window(self) -> dict[str, Any]:
        """Информация об активном (фокусном) окне."""
        window = self._require_backend().active_window()
        return window.describe()

    # -- команда (MEDIUM: снимок экрана — данные приватности) -----------------
    def take_screenshot(self, path: str | None = None) -> dict[str, Any]:
        """
        Сделать скриншот всего экрана в PNG/JPG (после подтверждения).

        Без ``path`` файл создаётся в ``output_dir`` с именем по времени.
        """
        target = validate_screenshot_path(
            path, output_dir=self.output_dir, forbidden_paths=self.forbidden_paths
        )
        size = self._require_backend().screenshot(target)
        logger.info("Скриншот сохранён: %s (%d байт)", target, size)
        return {"path": str(target), "bytes": size}


# ---------------------------------------------------------------------------
# Регистрация команд в реестре
# ---------------------------------------------------------------------------
def _spec(name: str, type_: str, description: str, **kw: Any) -> ParamSpec:
    return ParamSpec(
        name=name,
        type=type_,
        description=description,
        required=kw.get("required", True),
        enum=kw.get("enum"),
        default=kw.get("default"),
    )


def register_screen_actions(
    registry: CommandRegistry,
    actions: ScreenActions | None = None,
) -> list[str]:
    """
    Регистрирует команды экрана в ``registry`` (возвращает их имена).

    Уровни риска (ТЗ-6.7):
      - SAFE:   screen_info, list_windows, active_window (только чтение)
      - MEDIUM: take_screenshot (требует подтверждения: снимок экрана
                может содержать приватные данные)
    """
    svc = actions or ScreenActions()

    defs: list[tuple[str, str, list[ParamSpec], str, Callable[..., Any]]] = [
        (
            "screen_info",
            "Размер экрана в пикселях (ширина и высота)",
            [],
            RiskLevel.SAFE,
            svc.screen_info,
        ),
        (
            "list_windows",
            "Список видимых окон: id, заголовок, приложение",
            [],
            RiskLevel.SAFE,
            svc.list_windows,
        ),
        (
            "active_window",
            "Информация об активном (фокусном) окне",
            [],
            RiskLevel.SAFE,
            svc.active_window,
        ),
        (
            "take_screenshot",
            "Сделать скриншот всего экрана в файл (после подтверждения)",
            [
                _spec(
                    "path",
                    "string",
                    "путь к файлу .png/.jpg (по умолчанию — в папке скриншотов)",
                    required=False,
                ),
            ],
            RiskLevel.MEDIUM,
            svc.take_screenshot,
        ),
    ]

    names: list[str] = []
    for name, description, params, risk, handler in defs:
        registry.register(
            Command(
                name=name,
                description=description,
                params=params,
                handler=handler,
                risk=risk,
                requires_confirmation=REQUIRES_CONFIRMATION.get(risk, False),
            )
        )
        names.append(name)
    logger.debug("Зарегистрированы команды экрана: %s", ", ".join(names))
    return names
