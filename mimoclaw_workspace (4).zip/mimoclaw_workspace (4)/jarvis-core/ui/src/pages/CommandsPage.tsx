/**
 * Команды и доступы — реестр действий ассистента:
 * поиск, включение/выключение, уровни риска и политика подтверждений.
 */

import { motion } from "framer-motion";
import { useEffect, useMemo, useState } from "react";
import { Badge, Card, Notice, PageHeader } from "../components/ui/panels";
import { Button, Chip, FieldRow, SelectField, Toggle } from "../components/ui/controls";
import { clsx } from "../lib/format";
import { selectFiltered, useCommandsStore, type RiskFilter } from "../stores/commandsStore";
import { useSettingsStore } from "../stores/settingsStore";
import { RISK_META } from "../types/commands";
import type { CommandInfo } from "../types/commands";

const FILTERS: Array<{ id: RiskFilter; label: string }> = [
  { id: "all", label: "Все" },
  { id: "safe", label: "Безопасные" },
  { id: "medium", label: "Средние" },
  { id: "high", label: "Высокие" },
  { id: "forbidden", label: "Запрещённые" },
];

export function CommandsPage() {
  const items = useCommandsStore((s) => s.items);
  const loaded = useCommandsStore((s) => s.loaded);
  const remote = useCommandsStore((s) => s.remote);
  const query = useCommandsStore((s) => s.query);
  const riskFilter = useCommandsStore((s) => s.riskFilter);
  const setQuery = useCommandsStore((s) => s.setQuery);
  const setRiskFilter = useCommandsStore((s) => s.setRiskFilter);
  const toggle = useCommandsStore((s) => s.toggle);

  const settings = useSettingsStore((s) => s.data);
  const patch = useSettingsStore((s) => s.patch);
  const save = useSettingsStore((s) => s.save);
  const isDirty = useSettingsStore((s) => s.isDirty);

  const [debounced, setDebounced] = useState(query);

  useEffect(() => {
    if (!loaded) void useCommandsStore.getState().load();
  }, [loaded]);

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(query), 180);
    return () => clearTimeout(timer);
  }, [query]);

  const filtered = useMemo(
    () => selectFiltered(items, debounced, riskFilter),
    [items, debounced, riskFilter],
  );

  const stats = useMemo(() => {
    const byRisk: Record<string, number> = { safe: 0, medium: 0, high: 0, forbidden: 0 };
    let enabled = 0;
    for (const c of items) {
      byRisk[c.risk] = (byRisk[c.risk] ?? 0) + 1;
      if (c.enabled) enabled += 1;
    }
    return { total: items.length, enabled, byRisk };
  }, [items]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Команды и доступы"
        subtitle="Что ассистент может делать без спроса, что требует подтверждения, а что запрещено."
        actions={
          <Badge className={remote ? "border-ok/40 bg-ok/10 text-ok" : "border-warn/40 bg-warn/10 text-warn"}>
            {remote ? "реестр ядра" : "демо-каталог"}
          </Badge>
        }
      />

      {/* --- статистика рисков -------------------------------------------- */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
        <StatTile label="ВСЕГО" value={stats.total} className="border-line-bright text-text" />
        <StatTile label="ВКЛЮЧЕНО" value={stats.enabled} className="border-ok/40 text-ok" />
        <StatTile label="БЕЗОПАСНЫХ" value={stats.byRisk.safe ?? 0} className="border-ok/30 text-ok" />
        <StatTile label="СРЕДНИХ / ВЫСОКИХ" value={(stats.byRisk.medium ?? 0) + (stats.byRisk.high ?? 0)} className="border-warn/40 text-warn" />
        <StatTile label="ЗАПРЕЩЁННЫХ" value={stats.byRisk.forbidden ?? 0} className="border-danger/50 text-danger" />
      </div>

      {/* --- фильтры ------------------------------------------------------ */}
      <Card title="Реестр команд" subtitle="Поиск и фильтрация по уровню риска">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[240px] flex-1">
            <input
              className="hud-input pl-9"
              placeholder="Поиск по имени, описанию, параметрам…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted">⌕</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {FILTERS.map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setRiskFilter(f.id)}
                className={clsx(
                  "rounded-full border px-3.5 py-1.5 text-xs transition-colors",
                  riskFilter === f.id
                    ? "border-accent/70 bg-accent/10 text-accent"
                    : "border-line text-muted hover:border-line-bright hover:text-text",
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
          <span className="text-xs text-muted">найдено: {filtered.length}</span>
        </div>

        {items.length === 0 && loaded ? (
          <Notice tone="warn">Реестр пуст — ядро не вернуло ни одной команды.</Notice>
        ) : null}

        {/* --- список ------------------------------------------------------ */}
        <div className="mt-4 grid grid-cols-1 gap-3 xl:grid-cols-2">
          {filtered.map((command, i) => (
            <CommandRow key={command.name} command={command} index={i} onToggle={() => toggle(command.name)} />
          ))}
        </div>
      </Card>

      {/* --- политика доступа ---------------------------------------------- */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card title="Политика подтверждений" subtitle="Правила безопасности для действий">
          <FieldRow
            label="Подтверждение для среднего риска"
            hint="Оператор должен одобрить действие"
            control={
              <Toggle
                checked={settings.security.require_confirmation_medium}
                onChange={(v) => patch("security", { require_confirmation_medium: v })}
              />
            }
          />
          <FieldRow
            label="PIN для высокого риска"
            hint="Запрос PIN-кода перед выполнением"
            control={<Toggle checked={settings.security.pin_for_high} onChange={(v) => patch("security", { pin_for_high: v })} />}
          />
          <FieldRow
            label="Журнал аудита"
            hint="Все действия пишутся в audit-лог"
            control={<Toggle checked={settings.security.audit_log} onChange={(v) => patch("security", { audit_log: v })} />}
          />
          <FieldRow
            label="Скрипты в песочнице"
            hint="Разрешить Python/PowerShell-скрипты"
            control={
              <Toggle
                checked={settings.security.allow_shell_scripts}
                onChange={(v) => patch("security", { allow_shell_scripts: v })}
              />
            }
          />
          <div className="mt-4 flex justify-end">
            <Button variant="primary" onClick={() => void save()} disabled={!isDirty()}>
              Сохранить политику
            </Button>
          </div>
        </Card>

        <Card title="Уровни риска" subtitle="Как понимать маркировку команд" delay={0.05}>
          <ul className="space-y-2.5">
            {Object.entries(RISK_META).map(([key, meta]) => (
              <li key={key} className="flex items-start gap-3">
                <Badge className={clsx("shrink-0", meta.className)}>{meta.label}</Badge>
                <div>
                  <p className="text-sm text-text">
                    <code className="text-accent">{key}</code> — {meta.hint}
                  </p>
                </div>
              </li>
            ))}
          </ul>

          <div className="mt-5">
            <SelectField
              label="Доступ Telegram-бота"
              value={settings.telegram.access_level}
              onChange={(e) => patch("telegram", { access_level: e.target.value })}
              options={[
                { value: "full", label: "Полный" },
                { value: "view", label: "Только просмотр" },
                { value: "notify", label: "Только уведомления" },
              ]}
              hint="Уровень действий, доступных из мессенджера"
            />
          </div>

          <div className="mt-4 space-y-2">
            <p className="text-sm text-text">
              Защищённых путей: <span className="text-accent">{settings.security.whitelist_paths.length}</span>
            </p>
            <p className="text-sm text-text">
              Запрещённых путей: <span className="text-danger">{settings.security.forbidden_paths.length}</span>
            </p>
            <div className="flex flex-wrap gap-1.5">
              {settings.security.forbidden_paths.slice(0, 4).map((path) => (
                <Chip key={path}>{path}</Chip>
              ))}
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------- подкомпоненты */

function CommandRow({ command, index, onToggle }: { command: CommandInfo; index: number; onToggle: () => void }) {
  const meta = RISK_META[command.risk] ?? RISK_META.safe;
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, delay: Math.min(index * 0.015, 0.3) }}
      className={clsx(
        "rounded-xl border bg-panel-2/50 p-4 transition-colors",
        command.enabled ? "border-line hover:border-accent/40" : "border-line/60 opacity-60",
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <code className="text-sm text-accent">{command.name}</code>
            <Badge className={meta.className}>{meta.label}</Badge>
            {command.requires_confirmation ? (
              <Badge className="border-line-bright bg-panel text-muted">подтверждение</Badge>
            ) : null}
            {command.source === "demo" ? (
              <Badge className="border-line-bright bg-panel text-muted">демо</Badge>
            ) : null}
          </div>
          <p className="mt-1.5 text-sm text-text/90">{command.description}</p>
          {command.params.length > 0 ? (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {command.params.map((p) => (
                <Chip key={p.name}>
                  <span className="text-accent">{p.name}</span>
                  <span className="text-muted">: {p.type}</span>
                </Chip>
              ))}
            </div>
          ) : null}
        </div>
        <Toggle checked={command.enabled} onChange={onToggle} label={`Включить ${command.name}`} />
      </div>
    </motion.div>
  );
}

function StatTile({ label, value, className }: { label: string; value: number; className: string }) {
  return (
    <div className={clsx("rounded-xl border bg-panel/70 px-4 py-3", className)}>
      <p className="font-display text-xl tabular-nums">{value}</p>
      <p className="mt-0.5 text-[10px] tracking-[0.22em] text-muted">{label}</p>
    </div>
  );
}
