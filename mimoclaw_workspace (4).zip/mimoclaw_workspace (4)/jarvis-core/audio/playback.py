"""
Воспроизведение аудио (речь и SFX) JARVIS CORE.

Контракт ``AudioSink`` + готовые приёмники:
  * ``SoundDeviceSink`` — реальный звуковой вывод через sounddevice
    (16 кГц, моно, s16le — те же параметры, что и захват в audio/capture);
  * ``WavFileSink``    — запись «звука» в WAV-файлы (отладка, без динамика);
  * ``NullSink``       — тихий fallback: ничего не играет, но пишет историю
    (тесты, headless-режим, отсутствие звуковой карты).

``PlaybackRouter`` — диспетчер с живой сменой приёмника и fallback
(динамика ↔ файл ↔ тишина). Ничего не уходит в облако: воспроизведение
всегда локальное.

``AudioPlayer`` — высокоуровневый плеер с очередью и приоритетами:
речь ассистента важнее фоновых SFX, ``stop()`` обрывает всё, ``drain()``
дожидается конца очереди. Громкость применяется к PCM перед выдачей.

SFX — простые процедурные тоны (``ToneGenerator`` + ``builtin_sfx``):
сигналы активации / подтверждения / ошибки / отмены. Богатые звуки
(сэмплы, эффекты) — в fun/sfx.py поверх этого модуля.
"""

from __future__ import annotations

import abc
import asyncio
import logging
import math
import sys
import wave
from array import array
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Iterable

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class PlaybackError(Exception):
    """Ошибка воспроизведения."""


class PlaybackUnavailable(PlaybackError):
    """Приёмник недоступен (нет устройства/библиотеки) — можно fallback."""


# ---------------------------------------------------------------------------
# Конфигурация и клип
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class PlaybackConfig:
    """Параметры воспроизведения. Дефолты согласованы с audio/capture."""

    sample_rate: int = 16000
    channels: int = 1
    sample_width: int = 2  # байт на сэмпл (s16le)
    block_ms: int = 20
    volume: float = 1.0  # базовая громкость, 0.0..1.0
    queue_size: int = 32  # максимум клипов в очереди

    def duration_seconds(self, pcm: bytes) -> float:
        """Длительность PCM-куска в секундах."""
        denom = self.sample_rate * self.channels * self.sample_width
        return len(pcm) / denom if denom else 0.0


@dataclass(frozen=True)
class PlaybackClip:
    """Один фрагмент звука: речь ассистента или SFX."""

    pcm: bytes
    sample_rate: int = 16000
    channels: int = 1
    sample_width: int = 2
    kind: str = "speech"  # "speech" | "sfx"
    name: str = ""  # например "activate", "tts:jarvis"
    priority: int = 0  # выше → играет раньше в очереди
    volume: float = 1.0  # множитель поверх базовой громкости

    @property
    def duration(self) -> float:
        """Длительность клипа в секундах."""
        denom = self.sample_rate * self.channels * self.sample_width
        return len(self.pcm) / denom if denom else 0.0


# ---------------------------------------------------------------------------
# Работа с PCM (чистый Python, без numpy)
# ---------------------------------------------------------------------------
def apply_volume(pcm: bytes, volume: float, sample_width: int = 2) -> bytes:
    """
    Масштабирует громкость s16le-PCM.

    ``volume`` ограничивается диапазоном 0.0..2.0 (усиление до ×2 допустимо,
    клиппинг отсекается). Другие форматы возвращаются без изменений.
    """
    if sample_width != 2 or not pcm:
        return pcm
    vol = max(0.0, min(2.0, float(volume)))
    if vol == 1.0:
        return pcm
    samples = array("h")
    samples.frombytes(pcm)
    if sys.byteorder == "big":  # pragma: no cover — платформо-зависимо
        samples.byteswap()
    scaled = array("h")
    for s in samples:
        v = int(s * vol)
        scaled.append(max(-32768, min(32767, v)))
    if sys.byteorder == "big":  # pragma: no cover
        scaled.byteswap()
    return scaled.tobytes()


class ToneGenerator:
    """Процедурные тоны для SFX (s16le, моно). Без внешних зависимостей."""

    @staticmethod
    def sine(
        freq_hz: float,
        duration_s: float = 0.15,
        *,
        amplitude: float = 0.5,
        sample_rate: int = 16000,
        fade_ms: int = 8,
    ) -> bytes:
        """Синус с плавным огибанием (fade-in/out), чтобы не щёлкало."""
        n = max(0, int(duration_s * sample_rate))
        amp = max(0.0, min(1.0, amplitude)) * 32767
        fade = max(1, int(fade_ms * sample_rate / 1000))
        out = array("h")
        for i in range(n):
            env = 1.0
            if i < fade:
                env = i / fade
            elif i >= n - fade:
                env = max(0.0, (n - i) / fade)
            out.append(int(amp * env * math.sin(2 * math.pi * freq_hz * i / sample_rate)))
        if sys.byteorder == "big":  # pragma: no cover
            out.byteswap()
        return out.tobytes()

    @classmethod
    def sequence(
        cls,
        tones: Iterable[tuple[float, float]],
        *,
        amplitude: float = 0.5,
        sample_rate: int = 16000,
        gap_s: float = 0.03,
    ) -> bytes:
        """Последовательность тонов ``(freq_hz, duration_s)`` с паузами."""
        parts: list[bytes] = []
        gap = b"\x00\x00" * int(gap_s * sample_rate)
        for freq, dur in tones:
            parts.append(
                cls.sine(freq, dur, amplitude=amplitude, sample_rate=sample_rate)
            )
            parts.append(gap)
        return b"".join(parts)


class SfxKind(str, Enum):
    """Встроенные сигналы (см. ТЗ: активация/подтверждение)."""

    ACTIVATE = "activate"  # «я слушаю»
    CONFIRM = "confirm"  # команда принята
    ERROR = "error"  # что-то пошло не так
    CANCEL = "cancel"  # действие отменено


def builtin_sfx(kind: SfxKind | str, *, sample_rate: int = 16000) -> PlaybackClip:
    """Готовый SFX-клип по типу (процедурные тоны, без файлов)."""
    try:
        kind = SfxKind(kind)
    except ValueError as e:
        raise PlaybackError(f"неизвестный SFX: {kind!r}") from e

    if kind is SfxKind.ACTIVATE:
        pcm = ToneGenerator.sequence([(660.0, 0.09), (880.0, 0.12)], sample_rate=sample_rate)
    elif kind is SfxKind.CONFIRM:
        pcm = ToneGenerator.sine(880.0, 0.12, sample_rate=sample_rate)
    elif kind is SfxKind.ERROR:
        pcm = ToneGenerator.sequence([(220.0, 0.12), (180.0, 0.18)], sample_rate=sample_rate)
    else:  # CANCEL
        pcm = ToneGenerator.sine(330.0, 0.18, sample_rate=sample_rate)
    return PlaybackClip(
        pcm=pcm,
        sample_rate=sample_rate,
        kind="sfx",
        name=kind.value,
        priority=-1,  # речь всегда важнее SFX
    )


# ---------------------------------------------------------------------------
# Контракт приёмника
# ---------------------------------------------------------------------------
class AudioSink(abc.ABC):
    """Контракт вывода звука. Все приёмники — локальные."""

    name: str = "base"

    @abc.abstractmethod
    def is_available(self) -> bool: ...

    @abc.abstractmethod
    async def play(self, clip: PlaybackClip) -> None:
        """Сыграть клип целиком (ждать окончания)."""

    def stop(self) -> None:
        """Немедленно оборвать текущее воспроизведение."""

    def close(self) -> None:
        """Освободить ресурсы устройства/файлов."""

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "available": self.is_available()}


class SoundDeviceSink(AudioSink):
    """
    Реальный вывод через ``sounddevice`` (локальные колонки/наушники).

    Библиотека и устройство подхватываются лениво: если их нет —
    ``is_available()`` вернёт False, и роутер уйдёт в fallback.
    """

    name = "sounddevice"

    def __init__(self, config: PlaybackConfig | None = None, device: int | str | None = None) -> None:
        self.config = config or PlaybackConfig()
        self.device = device
        self._stream: Any = None

    def is_available(self) -> bool:
        try:
            import sounddevice  # noqa: F401
        except Exception:  # noqa: BLE001 — импорт может падать по-разному
            return False
        return True

    async def play(self, clip: PlaybackClip) -> None:
        if not self.is_available():
            raise PlaybackUnavailable("sounddevice не установлен")
        import numpy as np
        import sounddevice as sd

        data = np.frombuffer(clip.pcm, dtype="<i2").astype("float32") / 32768.0
        if clip.channels > 1:
            data = data.reshape(-1, clip.channels)
        # Базовая громкость (config.volume) уже учтена в PCM плеером;
        # здесь остаётся индивидуальный множитель клипа.
        if clip.volume != 1.0:
            data = data * clip.volume
        try:
            # sd.play блокирует поток — выносим в executor, чтобы не мешать asyncio
            await asyncio.get_running_loop().run_in_executor(
                None, lambda: sd.play(data, samplerate=clip.sample_rate, device=self.device)
            )
            await asyncio.get_running_loop().run_in_executor(None, sd.wait)
        except Exception as e:  # noqa: BLE001
            raise PlaybackUnavailable(f"вывод звука не удался: {e}") from e

    def stop(self) -> None:
        try:
            import sounddevice as sd

            sd.stop()
        except Exception:  # noqa: BLE001 — остановка не должна падать
            logger.debug("stop: sounddevice недоступен")

    def close(self) -> None:
        self.stop()


class WavFileSink(AudioSink):
    """
    Отладочный приёмник: пишет каждый клип в WAV-файл.

    Удобно для headless-разработки и тестов: слышимость не нужна,
    достаточно проверить, что PCM ушёл в файл.
    """

    name = "wav_file"

    def __init__(self, out_dir: str | Path, prefix: str = "clip") -> None:
        self.out_dir = Path(out_dir)
        self.prefix = prefix
        self.written: list[Path] = []
        self._counter = 0

    def is_available(self) -> bool:
        try:
            self.out_dir.mkdir(parents=True, exist_ok=True)
            return True
        except OSError:
            return False

    async def play(self, clip: PlaybackClip) -> None:
        if not self.is_available():
            raise PlaybackUnavailable(f"не могу писать в {self.out_dir}")
        self._counter += 1
        path = self.out_dir / f"{self.prefix}_{self._counter:04d}_{clip.name or clip.kind}.wav"
        with wave.open(str(path), "wb") as w:
            w.setnchannels(clip.channels)
            w.setsampwidth(clip.sample_width)
            w.setframerate(clip.sample_rate)
            w.writeframes(clip.pcm)
        self.written.append(path)
        logger.debug("WavFileSink: записан %s", path)


class NullSink(AudioSink):
    """
    Тихий приёмник: ничего не выводит, но фиксирует клипы.

    Используется в тестах, headless-режиме и как последний fallback,
    когда звукового вывода нет вообще.
    """

    name = "null"

    def __init__(self) -> None:
        self.played: list[PlaybackClip] = []
        self.stopped = 0

    def is_available(self) -> bool:
        return True

    async def play(self, clip: PlaybackClip) -> None:
        self.played.append(clip)

    def stop(self) -> None:
        self.stopped += 1


# ---------------------------------------------------------------------------
# Роутер приёмников
# ---------------------------------------------------------------------------
class PlaybackRouter:
    """
    Диспетчер воспроизведения: смена приёмника + fallback.

    Если основной приёмник недоступен (``PlaybackUnavailable``) — клип
    уходит запасному; цепочка перебирается по порядку ``order``.
    """

    def __init__(
        self,
        sinks: dict[str, AudioSink],
        primary: str,
        order: list[str] | None = None,
    ) -> None:
        if primary not in sinks:
            raise PlaybackError(f"неизвестный приёмник: {primary!r}")
        self.sinks = dict(sinks)
        self.primary = primary
        self.order = order or list(self.sinks)
        self.last_sink: str | None = None  # кто реально сыграл
        self.fallbacks_used = 0

    def set_primary(self, name: str) -> None:
        """Живая смена приёмника (например, динамика ↔ файл)."""
        if name not in self.sinks:
            raise PlaybackError(f"неизвестный приёмник: {name!r}")
        self.primary = name
        logger.info("PlaybackRouter: основной приёмник → %s", name)

    def add(self, sink: AudioSink) -> None:
        """Зарегистрировать/заменить приёмник."""
        self.sinks[sink.name] = sink

    async def play(self, clip: PlaybackClip) -> str:
        """
        Сыграть клип, вернув имя приёмника, который его обработал.

        Перебор: сначала основной, затем остальные из ``order``.
        """
        chain = [self.primary] + [n for n in self.order if n != self.primary]
        errors: list[str] = []
        for name in chain:
            sink = self.sinks.get(name)
            if sink is None or not sink.is_available():
                errors.append(f"{name}: недоступен")
                continue
            try:
                await sink.play(clip)
            except PlaybackUnavailable as e:
                errors.append(f"{name}: {e}")
                continue
            self.last_sink = name
            if name != self.primary:
                self.fallbacks_used += 1
            return name
        raise PlaybackUnavailable(
            "ни один приёмник не воспроизвёл звук: " + "; ".join(errors)
        )

    def stop(self) -> None:
        for sink in self.sinks.values():
            sink.stop()

    def close(self) -> None:
        for sink in self.sinks.values():
            sink.close()

    def describe(self) -> dict[str, Any]:
        return {
            "primary": self.primary,
            "order": list(self.order),
            "last_sink": self.last_sink,
            "fallbacks_used": self.fallbacks_used,
            "sinks": {n: s.describe() for n, s in self.sinks.items()},
        }


# ---------------------------------------------------------------------------
# Высокоуровневый плеер
# ---------------------------------------------------------------------------
@dataclass(order=True)
class _QueueItem:
    """Элемент очереди: сортировка по убыванию приоритета (и FIFO внутри)."""

    neg_priority: int
    seq: int
    clip: PlaybackClip = field(compare=False)
    done: asyncio.Event = field(compare=False, default_factory=asyncio.Event)


class AudioPlayer:
    """
    Плеер с очередью и приоритетами.

    * ``speak()``   — речь ассистента (приоритет 0, можно выше);
    * ``play_sfx()``— сигналы (приоритет −1, не мешают речи);
    * ``stop()``    — обрывает вывод и очищает очередь;
    * ``drain()``   — дождаться, пока всё в очереди сыграет.

    Очередь ограничена ``PlaybackConfig.queue_size``: переполнение —
    ``PlaybackError`` (лучше ошибка, чем тихая потеря команды).
    """

    def __init__(
        self,
        router: PlaybackRouter,
        config: PlaybackConfig | None = None,
    ) -> None:
        self.router = router
        self.config = config or PlaybackConfig()
        self._queue: asyncio.PriorityQueue[_QueueItem] = asyncio.PriorityQueue(
            maxsize=self.config.queue_size
        )
        self._seq = 0
        self._worker: asyncio.Task[None] | None = None

    # -- жизненный цикл ----------------------------------------------------
    def _ensure_worker(self) -> None:
        if self._worker is None or self._worker.done():
            self._worker = asyncio.get_running_loop().create_task(
                self._work(), name="audio-player"
            )

    async def _work(self) -> None:
        while True:
            item = await self._queue.get()
            try:
                await self.router.play(item.clip)
            except PlaybackError as e:
                logger.warning("AudioPlayer: %s (клип %r)", e, item.clip.name)
            finally:
                item.done.set()
                self._queue.task_done()

    async def close(self) -> None:
        """Остановить плеер и освободить приёмники."""
        self.stop()
        if self._worker is not None:
            self._worker.cancel()
            try:
                await self._worker
            except asyncio.CancelledError:  # pragma: no cover — штатная отмена
                pass
            self._worker = None
        self.router.close()

    # -- воспроизведение ---------------------------------------------------
    async def play(
        self,
        clip: PlaybackClip,
        *,
        wait: bool = False,
    ) -> None:
        """Поставить клип в очередь (и опционально дождаться его конца)."""
        self._ensure_worker()
        self._seq += 1
        item = _QueueItem(neg_priority=-clip.priority, seq=self._seq, clip=clip)
        try:
            self._queue.put_nowait(item)
        except asyncio.QueueFull as e:
            raise PlaybackError("очередь воспроизведения переполнена") from e
        if wait:
            await item.done.wait()

    async def speak(
        self,
        pcm: bytes,
        *,
        name: str = "",
        priority: int = 0,
        volume: float = 1.0,
        wait: bool = False,
    ) -> None:
        """Сыграть речь ассистента (PCM s16le @ конфиг плеера)."""
        clip = PlaybackClip(
            pcm=apply_volume(pcm, self.config.volume * volume, self.config.sample_width),
            sample_rate=self.config.sample_rate,
            channels=self.config.channels,
            sample_width=self.config.sample_width,
            kind="speech",
            name=name or "speech",
            priority=priority,
        )
        await self.play(clip, wait=wait)

    async def play_sfx(
        self,
        kind: SfxKind | str | PlaybackClip,
        *,
        volume: float = 1.0,
        wait: bool = False,
    ) -> None:
        """Сыграть SFX: встроенный сигнал или готовый клип."""
        clip = kind if isinstance(kind, PlaybackClip) else builtin_sfx(
            kind, sample_rate=self.config.sample_rate
        )
        if volume != 1.0:
            clip = PlaybackClip(
                pcm=apply_volume(clip.pcm, self.config.volume * volume, clip.sample_width),
                sample_rate=clip.sample_rate,
                channels=clip.channels,
                sample_width=clip.sample_width,
                kind=clip.kind,
                name=clip.name,
                priority=clip.priority,
            )
        await self.play(clip, wait=wait)

    # -- управление --------------------------------------------------------
    def stop(self) -> None:
        """Оборвать вывод и выбросить всё, что накопилось в очереди."""
        self.router.stop()
        while True:
            try:
                self._queue.get_nowait()
            except asyncio.QueueEmpty:
                break
            else:
                self._queue.task_done()

    async def drain(self) -> None:
        """Дождаться, пока очередь будет полностью разобрана."""
        await self._queue.join()

    @property
    def queued(self) -> int:
        """Сколько клипов ждут воспроизведения."""
        return self._queue.qsize()
