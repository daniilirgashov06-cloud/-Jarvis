"""
Проверка memory/vector_store.py — добавление/поиск/ранжирование, upsert,
валидация, мягкий fallback (без chromadb), потокобезопасность.

Тяжёлые зависимости (chromadb/sentence-transformers) не нужны: fallback-путь
проверяется через подмену ``sys.modules`` (работает и там, где chromadb ставили).

Запуск:  python3 tests/test_vector_store.py
Или:     pytest tests/test_vector_store.py -q
"""

from __future__ import annotations

import contextlib
import sys
import threading
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from memory.vector_store import (
    DEFAULT_TOP_K,
    MAX_TEXT_LEN,
    MAX_TOP_K,
    ChromaVectorStore,
    InMemoryVectorStore,
    VectorStore,
    VectorStoreUnavailable,
    default_vector_store,
)


# ---------------------------------------------------------------------------
# Утилиты: подмена chromadb в sys.modules
# ---------------------------------------------------------------------------
@contextlib.contextmanager
def _without_chromadb():
    """Скрыть chromadb (импорт падает) — эмуляция «зависимость не установлена»."""
    sentinel = object()
    old = sys.modules.get("chromadb", sentinel)
    sys.modules["chromadb"] = None  # None в sys.modules -> ImportError при импорте
    try:
        yield
    finally:
        if old is sentinel:
            sys.modules.pop("chromadb", None)
        else:
            sys.modules["chromadb"] = old


@contextlib.contextmanager
def _broken_chromadb():
    """Подсунуть «сломанный» chromadb: импорт проходит, движок падает."""
    sentinel = object()
    old = sys.modules.get("chromadb", sentinel)

    def _boom(*_a, **_kw):
        raise RuntimeError("движок ChromaDB сломан")

    sys.modules["chromadb"] = types.SimpleNamespace(Client=_boom, PersistentClient=_boom)
    try:
        yield
    finally:
        if old is sentinel:
            sys.modules.pop("chromadb", None)
        else:
            sys.modules["chromadb"] = old


# ---------------------------------------------------------------------------
# Базовое добавление/поиск
# ---------------------------------------------------------------------------
def test_add_search_count() -> None:
    store = InMemoryVectorStore()
    store.add("m1", "пользователь любит чай без сахара", {"kind": "fact"})
    store.add("m2", "вчера была встреча с командой проекта")
    store.add("m3", "кот спит на диване")
    assert store.count() == 3

    hits = store.search("что любит пользователь?")
    assert isinstance(hits, list) and all(isinstance(h, str) for h in hits)
    assert "пользователь любит чай без сахара" in hits, hits
    assert "кот спит на диване" not in hits, "нерелевантное не должно всплывать"
    print("  ✓ vector_store: add/search/count работают, релевантность на месте")


def test_search_ranking() -> None:
    store = InMemoryVectorStore()
    store.add("d1", "кот спит на диване")
    store.add("d2", "собака бегает в парке")
    store.add("d3", "кот гуляет во дворе")
    hits = store.search("кот спит")
    assert hits[0] == "кот спит на диване", f"совпадение по обоим словам — первое: {hits}"
    assert hits[1] == "кот гуляет во дворе", f"частичное совпадение — второе: {hits}"
    assert "собака бегает в парке" not in hits, "без общих слов — мимо"
    print("  ✓ vector_store: ранжирование TF-IDF корректно (полное > частичное)")


def test_top_k_limits() -> None:
    store = InMemoryVectorStore()
    for i in range(12):
        store.add(f"m{i}", f"памятка номер {i} про память")
    assert store.search("память", top_k=5) and len(store.search("память", top_k=5)) == 5
    assert store.search("память", top_k=0) == []
    assert store.search("память", top_k=-3) == []
    clamped = store.search("память", top_k=10_000)
    assert len(clamped) == 12, f"top_k зажимается до числа записей: {len(clamped)}"
    assert DEFAULT_TOP_K == 8 and MAX_TOP_K >= 8, "дефолт top-8 по ТЗ"
    print("  ✓ vector_store: top_k ограничивается корректно (0/-/max)")


def test_empty_and_unknown_query() -> None:
    store = InMemoryVectorStore()
    store.add("m1", "кот спит на диване")
    assert store.search("") == []
    assert store.search("   ") == []
    assert store.search("квантовая телепортация") == [], "нет слов из корпуса — пусто, но не ошибка"
    print("  ✓ vector_store: пустой/неизвестный запрос даёт [], не падает")


def test_upsert_by_id() -> None:
    store = InMemoryVectorStore()
    store.add("x", "абракадабра уникальный текст")
    store.add("x", "другой текст про погоду")
    assert store.count() == 1, "повторный id — замена, не дубль"
    assert store.search("абракадабра") == [], "старый текст вычищен вместе со скорами"
    assert store.search("погоду") == ["другой текст про погоду"]
    print("  ✓ vector_store: upsert по id заменяет запись и чистит индекс")


def test_delete_and_clear() -> None:
    store = InMemoryVectorStore()
    store.add("m1", "чай без сахара")
    store.add("m2", "кофе с молоком")
    assert store.delete("m1") is True
    assert store.delete("m1") is False, "повторное удаление — False"
    assert store.delete("нет-такого") is False
    assert store.count() == 1
    assert store.search("чай") == []
    assert store.clear() == 1
    assert store.count() == 0 and store.search("кофе") == []
    print("  ✓ vector_store: delete/clear работают и возвращают факты")


def test_auto_id_and_metadata() -> None:
    store = InMemoryVectorStore()
    new_id = store.add("", "запись без явного id", {"kind": "note", "importance": 0.7, "on": True, "skip": None})
    assert new_id, "пустой id генерируется автоматически"
    assert store.count() == 1
    assert store.search("запись") == ["запись без явного id"]
    print("  ✓ vector_store: автогенерация id и метаданные-примитивы работают")


def test_normalization_yo_and_case() -> None:
    store = InMemoryVectorStore()
    store.add("m1", "Пользователь ЕЩЁ любит чай")
    assert store.search("еще ЧАЙ"), "регистр и ё↔е нормализуются"
    print("  ✓ vector_store: нормализация регистра и ё↔е работает")


# ---------------------------------------------------------------------------
# Валидация (антиинъекция и защита от мусора)
# ---------------------------------------------------------------------------
def test_validation_errors() -> None:
    store = InMemoryVectorStore()
    for bad_id, bad_text in [
        ("ok", ""),
        ("ok", "   "),
        ("ok", "текст\nс переводом строки"),
        ("ok", "х" * (MAX_TEXT_LEN + 1)),
        ("ok", 123),
        ("х" * 200, "текст"),
        ("id\nс мусором", "текст"),
        (123, "текст"),
    ]:
        try:
            store.add(bad_id, bad_text)
        except ValueError:
            pass
        else:
            raise AssertionError(f"ожидался ValueError для add({bad_id!r}, {bad_text!r})")
    assert store.count() == 0, "невалидные записи не попадают в индекс"
    print("  ✓ vector_store: валидация id/text отсекает мусор (ValueError)")


def test_metadata_validation() -> None:
    store = InMemoryVectorStore()
    for bad_meta in [
        {"k": [1, 2]},                    # список не поддержан
        {"k": {"nested": 1}},             # вложенный словарь
        {"k": object()},                  # произвольный объект
        {1: "value"},                     # не-str ключ
        {"a\nb": 1},                      # управляющие символы в ключе
        {"k": "va\nlue"},                 # управляющие символы в значении
        {f"k{i}": i for i in range(33)},  # больше MAX_METADATA_KEYS
    ]:
        try:
            store.add("m", "текст", bad_meta)
        except ValueError:
            pass
        else:
            raise AssertionError(f"ожидался ValueError для metadata={bad_meta!r}")
    print("  ✓ vector_store: метаданные валидируются (плоские примитивы only)")


def test_top_k_validation() -> None:
    store = InMemoryVectorStore()
    store.add("m1", "текст про память")
    for bad in ("5", 2.5, True, None):
        try:
            store.search("память", top_k=bad)  # type: ignore[arg-type]
        except ValueError:
            pass
        else:
            raise AssertionError(f"ожидался ValueError для top_k={bad!r}")
    print("  ✓ vector_store: некорректный top_k отклоняется (ValueError)")


# ---------------------------------------------------------------------------
# Мягкий fallback (главное по ТЗ: не падать без зависимостей)
# ---------------------------------------------------------------------------
def test_fallback_without_chromadb() -> None:
    with _without_chromadb():
        store = default_vector_store()
    assert isinstance(store, InMemoryVectorStore), f"fallback на TF-IDF: {type(store).__name__}"
    assert store.degraded is True, "аварийный fallback помечается degraded=True"
    store.add("m1", "чай без сахара")
    assert store.search("чай") == ["чай без сахара"], "fallback реально работает"
    status = store.describe()
    assert status["backend"] == "memory" and status["degraded"] is True
    print("  ✓ vector_store: без chromadb — мягкий fallback на TF-IDF (degraded=True)")


def test_fallback_on_broken_engine() -> None:
    with _broken_chromadb():
        store = default_vector_store()
    assert isinstance(store, InMemoryVectorStore), "сломанный движок Chroma -> fallback"
    assert store.degraded is True
    store.add("m1", "кофе с молоком")
    assert store.search("кофе") == ["кофе с молоком"]
    print("  ✓ vector_store: сломанный движок Chroma — тоже деградация без падения")


def test_chroma_unavailable_typed_error() -> None:
    with _without_chromadb():
        try:
            ChromaVectorStore()
        except VectorStoreUnavailable as exc:
            assert "chromadb" in str(exc).lower(), exc
        else:
            raise AssertionError("ожидался VectorStoreUnavailable без chromadb")
    with _broken_chromadb():
        try:
            ChromaVectorStore()
        except VectorStoreUnavailable:
            pass
        else:
            raise AssertionError("ожидался VectorStoreUnavailable для сломанного движка")
    print("  ✓ vector_store: ChromaVectorStore сообщает о недоступности типизированно")


def test_explicit_memory_choice_not_degraded() -> None:
    store = default_vector_store(prefer_chroma=False)
    assert isinstance(store, InMemoryVectorStore)
    assert store.degraded is False, "осознанный выбор in-memory — не деградация"
    print("  ✓ vector_store: prefer_chroma=False даёт in-memory без флага degraded")


# ---------------------------------------------------------------------------
# Потокобезопасность
# ---------------------------------------------------------------------------
def test_thread_safety() -> None:
    store = InMemoryVectorStore()
    n = 25

    def worker(base: int) -> None:
        for i in range(n):
            store.add(f"t{base}-{i}", f"запись {base} номер {i} про память")

    threads = [threading.Thread(target=worker, args=(k,)) for k in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert store.count() == 4 * n
    hits = store.search("память", top_k=MAX_TOP_K)
    assert len(hits) == MAX_TOP_K
    print("  ✓ vector_store: параллельные add/search безопасны (100 записей)")


if __name__ == "__main__":
    import traceback

    tests = [(k, v) for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    print("JARVIS CORE — проверка векторного хранилища памяти")
    for name, fn in tests:
        try:
            fn()
            print(f"  ok  {name}")
        except Exception:
            failed += 1
            print(f"FAIL  {name}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
