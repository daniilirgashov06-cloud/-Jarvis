"""
Мост «Telegram ↔ оркестратор» JARVIS CORE.

Чистая логика без aiogram и сети: whitelist chat_id, уровни доступа,
очередь команд в оркестратор и подтверждение опасных действий
(«ПОДТВЕРДИТЬ» / «ОТМЕНА»). Модуль тестируется без Telegram — ``handlers.py``
и ``bot.py`` лишь оборачивают его в aiogram 3.

Понятия:

- ``AccessLevel``            — права чата: view < notify < full;
- ``ChatWhitelist``          — whitelist chat_id (или «разрешить всё»);
- ``CommandRequest``         — команда из Telegram, ожидающая исполнения;
- ``CommandBridge``          — асинхронная очередь команд → оркестратор;
- ``PendingConfirmation``    — ожидающее подтверждения опасное действие;
- ``ConfirmationManager``    — выдача/погашение подтверждений с TTL;
- ``encode_callback`` / ``decode_callback`` — короткие callback-данные
  для инлайн-кнопок (лимит Telegram — 64 байта).

Безопасность:
  - чат вне whitelist получает отказ (``AccessDenied``) на любой команде;
  - команды с уровнем риска medium/high требуют подтверждения
    (``requires_confirmation``), forbidden — запрещены вовсе;
  - токен подтверждения одноразовый и короткий (12 символов), срок жизни
    ограничен ``ttl_s`` — просроченное подтверждение не сработает.

Использование::

    bridge = CommandBridge()
    confirmations = ConfirmationManager(ttl_s=120)
    whitelist = ChatWhitelist.from_config("12345", extra=["67890"])
"""

from __future__ import annotations

import asyncio
import itertools
import re
import secrets
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Iterable, Mapping

__all__ = [
    "AccessLevel",
    "ChatWhitelist",
    "RiskLevel",
    "requires_confirmation",
    "CommandRequest",
    "CommandBridge",
    "PendingConfirmation",
    "ConfirmationManager",
    "encode_callback",
    "decode_callback",
    "TelegramBridgeError",
    "AccessDenied",
    "BridgeFullError",
    "ConfirmationError",
    "ConfirmationUnknown",
    "ConfirmationExpired",
]


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class TelegramBridgeError(Exception):
    """Базовая ошибка моста Telegram ↔ оркестратор."""


class AccessDenied(TelegramBridgeError):
    """Чат отсутствует в whitelist или не хватает уровня доступа."""


class BridgeFullError(TelegramBridgeError):
    """Очередь команд переполнена — команды слишком много."""


class ConfirmationError(TelegramBridgeError):
    """Ошибка подтверждения опасного действия."""


class ConfirmationUnknown(ConfirmationError):
    """Токен подтверждения не найден (не выдавался или уже погашен)."""


class ConfirmationExpired(ConfirmationError):
    """Подтверждение просрочено — действие нужно запросить заново."""


# ---------------------------------------------------------------------------
# Уровни доступа и риска
# ---------------------------------------------------------------------------
class AccessLevel(str, Enum):
    """Права чата в Telegram-боте (совместимо с config.settings.TelegramConfig)."""

    VIEW = "view"        # только чтение: статус, скриншот
    NOTIFY = "notify"    # чтение + отправка команд «безопасных»
    FULL = "full"        # полный доступ (опасные действия — с подтверждением)

    @property
    def rank(self) -> int:
        """Порядковый номер уровня (для сравнения)."""
        return {"view": 0, "notify": 1, "full": 2}[self.value]

    def allows(self, required: "AccessLevel | str") -> bool:
        """Хватает ли этого уровня для действия с уровнем ``required``."""
        req = AccessLevel(required) if not isinstance(required, AccessLevel) else required
        return self.rank >= req.rank


class RiskLevel(str, Enum):
    """Уровень риска команды (совместимо с actions.registry.RiskLevel)."""

    SAFE = "safe"
    MEDIUM = "medium"
    HIGH = "high"
    FORBIDDEN = "forbidden"


#: какие уровни риска требуют подтверждения (как в actions.registry)
REQUIRES_CONFIRMATION: dict[RiskLevel, bool] = {
    RiskLevel.SAFE: False,
    RiskLevel.MEDIUM: True,
    RiskLevel.HIGH: True,
    RiskLevel.FORBIDDEN: True,
}


def requires_confirmation(risk: "RiskLevel | str") -> bool:
    """Нужно ли подтверждение для команды с данным уровнем риска."""
    level = RiskLevel(risk) if not isinstance(risk, RiskLevel) else risk
    return REQUIRES_CONFIRMATION[level]


# ---------------------------------------------------------------------------
# Whitelist chat_id
# ---------------------------------------------------------------------------
#: chat_id в Telegram — целое число (может быть отрицательным для групп)
_CHAT_ID_RE = re.compile(r"^-?\d{1,20}$")


def _normalize_chat_id(chat_id: Any) -> str:
    """Нормализует chat_id к строке цифр; иначе — ValueError."""
    text = str(chat_id).strip()
    if not _CHAT_ID_RE.match(text):
        raise ValueError(f"некорректный chat_id: {chat_id!r}")
    return text


@dataclass(frozen=True)
class ChatWhitelist:
    """
    Whitelist chat_id: разрешённые чаты и уровень доступа по умолчанию.

    Пустой whitelist без ``allow_all`` означает «никому нельзя» —
    безопасное умолчание. ``from_config`` разбирает строку вида
    ``"123, -456"`` (как ``telegram.chat_id`` в настройках).
    """

    allowed: frozenset[str] = frozenset()
    allow_all: bool = False
    default_level: AccessLevel = AccessLevel.FULL

    @classmethod
    def from_config(
        cls,
        chat_id: str | int | None = None,
        extra: Iterable[str | int] = (),
        *,
        allow_all: bool = False,
        default_level: AccessLevel | str = AccessLevel.FULL,
    ) -> "ChatWhitelist":
        """Собрать whitelist из настроек (основной chat_id + доп. списком)."""
        ids: set[str] = set()
        if chat_id is not None:
            for part in str(chat_id).split(","):
                part = part.strip()
                if part:
                    ids.add(_normalize_chat_id(part))
        for item in extra:
            ids.add(_normalize_chat_id(item))
        level = AccessLevel(default_level) if not isinstance(default_level, AccessLevel) else default_level
        return cls(allowed=frozenset(ids), allow_all=allow_all, default_level=level)

    def is_allowed(self, chat_id: Any) -> bool:
        """Разрешён ли чат (входит в whitelist или открыт доступ всем).

        Формат chat_id проверяется всегда — даже при ``allow_all``.
        """
        try:
            normalized = _normalize_chat_id(chat_id)
        except ValueError:
            return False
        return self.allow_all or normalized in self.allowed

    def require(self, chat_id: Any) -> str:
        """Вернуть нормализованный chat_id или бросить ``AccessDenied``."""
        normalized = _normalize_chat_id(chat_id)
        if not self.is_allowed(normalized):
            raise AccessDenied(f"chat_id {normalized} отсутствует в whitelist")
        return normalized

    def check_access(self, chat_id: Any, required: AccessLevel | str) -> str:
        """Проверить чат и уровень доступа; вернуть chat_id или бросить ошибку."""
        normalized = self.require(chat_id)
        if not self.default_level.allows(required):
            raise AccessDenied(
                f"уровень доступа {self.default_level.value!r} ниже требуемого {AccessLevel(required).value!r}"
            )
        return normalized


# ---------------------------------------------------------------------------
# Команды в оркестратор
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class CommandRequest:
    """Команда из Telegram, поставленная в очередь к оркестратору."""

    request_id: str
    chat_id: str
    command: str
    args: Mapping[str, Any] = field(default_factory=dict)
    risk: RiskLevel = RiskLevel.SAFE
    created_at: float = 0.0
    source: str = "telegram"

    def to_dict(self) -> dict[str, Any]:
        """Сериализуемое представление (для логов/аудита)."""
        return {
            "request_id": self.request_id,
            "chat_id": self.chat_id,
            "command": self.command,
            "args": dict(self.args),
            "risk": self.risk.value,
            "created_at": self.created_at,
            "source": self.source,
        }


class CommandBridge:
    """
    Асинхронная очередь команд Telegram → оркестратор.

    ``submit`` кладёт команду (с защитой от переполнения), оркестратор
    забирает её через ``await pop()``. Очередь ограничена ``max_pending`` —
    флуд из чата не забьёт память ядра.
    """

    def __init__(self, max_pending: int = 32, *, clock: Callable[[], float] = time.monotonic) -> None:
        if max_pending < 1:
            raise ValueError(f"max_pending должен быть >= 1, получено: {max_pending!r}")
        self._max_pending = max_pending
        self._clock = clock
        self._queue: asyncio.Queue[CommandRequest] = asyncio.Queue(maxsize=max_pending)
        self._counter = itertools.count(1)

    @property
    def max_pending(self) -> int:
        """Максимум команд в очереди."""
        return self._max_pending

    def qsize(self) -> int:
        """Сколько команд сейчас ждут исполнения."""
        return self._queue.qsize()

    def submit(
        self,
        chat_id: str,
        command: str,
        args: Mapping[str, Any] | None = None,
        risk: RiskLevel | str = RiskLevel.SAFE,
    ) -> CommandRequest:
        """
        Поставить команду в очередь; вернуть сформированный запрос.

        Бросает ``BridgeFullError``, если очередь переполнена, и
        ``ValueError`` при пустой команде.
        """
        name = str(command).strip()
        if not name:
            raise ValueError("имя команды не может быть пустым")
        level = RiskLevel(risk) if not isinstance(risk, RiskLevel) else risk
        request = CommandRequest(
            request_id=f"tg-{next(self._counter)}",
            chat_id=_normalize_chat_id(chat_id),
            command=name,
            args=dict(args or {}),
            risk=level,
            created_at=self._clock(),
        )
        try:
            self._queue.put_nowait(request)
        except asyncio.QueueFull as exc:
            raise BridgeFullError(
                f"очередь команд переполнена (максимум {self._max_pending})"
            ) from exc
        return request

    async def pop(self) -> CommandRequest:
        """Дождаться следующей команды из очереди (для оркестратора)."""
        return await self._queue.get()

    def pending(self) -> list[CommandRequest]:
        """Список команд, ожидающих исполнения (не извлекая их)."""
        return list(self._queue._queue)  # noqa: SLF001 — read-only просмотр

    def done(self, request: CommandRequest) -> None:
        """Отметить команду исполненной (для asyncio.Queue.task_done)."""
        self._queue.task_done()

    def describe(self) -> dict[str, Any]:
        """Краткое описание моста (для /status и диагностики)."""
        return {
            "pending": self.qsize(),
            "max_pending": self._max_pending,
            "commands": [req.command for req in self.pending()],
        }


# ---------------------------------------------------------------------------
# Подтверждения опасных действий
# ---------------------------------------------------------------------------
#: длина токена подтверждения (символы URL-safe)
_TOKEN_LENGTH = 12
#: префиксы callback-данных инлайн-кнопок
CALLBACK_APPROVE = "yes"
CALLBACK_CANCEL = "no"
_TOKEN_RE = re.compile(r"^[A-Za-z0-9_-]{1,32}$")


def encode_callback(kind: str, token: str) -> str:
    """
    Callback-данные инлайн-кнопки: ``«yes:<token>»`` / ``«no:<token>»``.

    Формат короткий, чтобы уложиться в лимит Telegram на callback_data
    (64 байта). ``kind`` — только ``yes``/``no``.
    """
    if kind not in (CALLBACK_APPROVE, CALLBACK_CANCEL):
        raise ValueError(f"недопустимый тип callback: {kind!r}")
    if not _TOKEN_RE.match(token):
        raise ValueError(f"некорректный токен подтверждения: {token!r}")
    return f"{kind}:{token}"


def decode_callback(data: str) -> tuple[str, str]:
    """
    Разобрать callback-данные кнопки → ``(kind, token)``.

    Бросает ``ValueError`` для пустых/битых данных.
    """
    if not isinstance(data, str) or ":" not in data:
        raise ValueError(f"некорректные callback-данные: {data!r}")
    kind, token = data.split(":", 1)
    if kind not in (CALLBACK_APPROVE, CALLBACK_CANCEL):
        raise ValueError(f"недопустимый тип callback: {kind!r}")
    if not _TOKEN_RE.match(token):
        raise ValueError(f"некорректный токен подтверждения: {token!r}")
    return kind, token


@dataclass(frozen=True)
class PendingConfirmation:
    """
    Опасное действие, ожидающее подтверждения в Telegram.

    ``token`` — одноразовый идентификатор кнопки; ``callback_approve`` /
    ``callback_cancel`` — готовые callback-данные для инлайн-кнопок.
    """

    token: str
    chat_id: str
    action: str
    args: Mapping[str, Any] = field(default_factory=dict)
    risk: RiskLevel = RiskLevel.MEDIUM
    created_at: float = 0.0
    ttl_s: float = 120.0
    note: str = ""

    @property
    def callback_approve(self) -> str:
        """Callback-данные кнопки «ПОДТВЕРДИТЬ»."""
        return encode_callback(CALLBACK_APPROVE, self.token)

    @property
    def callback_cancel(self) -> str:
        """Callback-данные кнопки «ОТМЕНА»."""
        return encode_callback(CALLBACK_CANCEL, self.token)

    def expires_at(self) -> float:
        """Момент истечения срока действия подтверждения."""
        return self.created_at + self.ttl_s

    def is_expired(self, now: float | None = None) -> bool:
        """Истекло ли время подтверждения."""
        moment = self.created_at if now is None else float(now)
        return moment >= self.expires_at()

    def to_dict(self) -> dict[str, Any]:
        """Сериализуемое представление (для логов/аудита)."""
        return {
            "token": self.token,
            "chat_id": self.chat_id,
            "action": self.action,
            "args": dict(self.args),
            "risk": self.risk.value,
            "created_at": self.created_at,
            "ttl_s": self.ttl_s,
            "note": self.note,
        }


class ConfirmationManager:
    """
    Менеджер подтверждений: выдаёт, погашает и чистит просроченные.

    Подтверждение одноразовое: после ``resolve`` токен исчезает, повторное
    нажатие кнопки даёт ``ConfirmationUnknown``. Просроченные чистятся
    явно через ``purge_expired`` (или лениво при ``resolve``).
    """

    def __init__(
        self,
        ttl_s: float = 120.0,
        *,
        clock: Callable[[], float] = time.monotonic,
        token_factory: Callable[[], str] | None = None,
    ) -> None:
        if ttl_s <= 0:
            raise ValueError(f"ttl_s должен быть > 0, получено: {ttl_s!r}")
        self._ttl_s = float(ttl_s)
        self._clock = clock
        self._token_factory = token_factory or (lambda: secrets.token_urlsafe(_TOKEN_LENGTH)[:_TOKEN_LENGTH])
        self._pending: dict[str, PendingConfirmation] = {}

    @property
    def ttl_s(self) -> float:
        """Время жизни подтверждения, секунды."""
        return self._ttl_s

    def create(
        self,
        chat_id: str,
        action: str,
        args: Mapping[str, Any] | None = None,
        risk: RiskLevel | str = RiskLevel.MEDIUM,
        note: str = "",
    ) -> PendingConfirmation:
        """
        Создать подтверждение для опасного действия и вернуть его.

        Кнопки «ПОДТВЕРДИТЬ»/«ОТМЕНА» берутся из ``callback_approve`` /
        ``callback_cancel``.
        """
        name = str(action).strip()
        if not name:
            raise ValueError("имя действия не может быть пустым")
        level = RiskLevel(risk) if not isinstance(risk, RiskLevel) else risk
        token = self._token_factory()
        if not _TOKEN_RE.match(token):
            raise ValueError(f"фабрика токенов вернула некорректный токен: {token!r}")
        if token in self._pending:
            raise ConfirmationError(f"токен подтверждения уже занят: {token!r}")
        pending = PendingConfirmation(
            token=token,
            chat_id=_normalize_chat_id(chat_id),
            action=name,
            args=dict(args or {}),
            risk=level,
            created_at=self._clock(),
            ttl_s=self._ttl_s,
            note=note,
        )
        self._pending[token] = pending
        return pending

    def get(self, token: str) -> PendingConfirmation:
        """Найти подтверждение по токену (или ``ConfirmationUnknown``)."""
        pending = self._pending.get(token)
        if pending is None:
            raise ConfirmationUnknown(f"подтверждение {token!r} не найдено")
        return pending

    def resolve(self, token: str, approved: bool) -> tuple[PendingConfirmation, bool]:
        """
        Погасить подтверждение: вернуть ``(pending, approved)``.

        Бросает ``ConfirmationUnknown`` для неизвестного/погашенного токена
        и ``ConfirmationExpired`` для просроченного (просроченный при этом
        удаляется).
        """
        pending = self.get(token)
        if pending.is_expired(self._clock()):
            self._pending.pop(token, None)
            raise ConfirmationExpired(f"подтверждение {token!r} просрочено")
        self._pending.pop(token, None)
        return pending, bool(approved)

    def purge_expired(self) -> int:
        """Удалить просроченные подтверждения; вернуть их количество."""
        now = self._clock()
        expired = [token for token, pending in self._pending.items() if pending.is_expired(now)]
        for token in expired:
            del self._pending[token]
        return len(expired)

    def pending(self) -> list[PendingConfirmation]:
        """Список активных (не погашенных) подтверждений."""
        return list(self._pending.values())

    def describe(self) -> dict[str, Any]:
        """Краткое описание менеджера (для /status и диагностики)."""
        return {
            "pending": len(self._pending),
            "ttl_s": self._ttl_s,
            "actions": [p.action for p in self._pending.values()],
        }
