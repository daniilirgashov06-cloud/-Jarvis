"""
Команды браузера JARVIS CORE (ТЗ-6, каталог browser).

Команды уровня «браузер»: статус (какие браузеры стоят/запущены, какой
по умолчанию), открытие URL, поиск в интернете, закрытие браузера.
Каждая команда имеет уровень риска (``RiskLevel``) и регистрируется
в ``CommandRegistry``, откуда попадает в схемы function calling для LLM.

Архитектура (в стиле ``actions/screen_actions.py`` / ``actions/input_actions.py``):

- ``BrowserBackend`` — контракт «исполнитель» операций над браузером;
- ``SubprocessBrowserBackend`` — локальная реализация через subprocess
  (Linux: xdg-open/xdg-settings + CLI браузеров + pgrep/pkill,
  macOS: open + osascript + pgrep/pkill,
  Windows: PowerShell Start-Process + taskkill);
- ``DryRunBrowserBackend`` — безопасный fallback/отладка: не запускает
  ничего, пишет вызовы в журнал (используется и в тестах).

«Локально ↔ облако» здесь неприменимо: всё выполняется локально
(поисковый запрос лишь превращается в URL — сеть уже на стороне браузера).
При недоступности исполнителя команда падает контролируемо
(``BrowserUnavailable``) без побочных эффектов.

Безопасность (ТЗ-6.7):
  - URL принимается только со схемами ``http``/``https`` — ``javascript:``,
    ``data:``, ``file:`` и пр. отклоняются (анти-XSS/чтение локальных файлов);
  - все аргументы проходят строгую валидацию (длина, управляющие символы,
    ведущий '-' → антиинъекция опций в argv) и передаются в subprocess
    списком без shell=True;
  - закрытие браузера — только по allow-list имен процессов (``pkill -x`` /
    ``taskkill /IM`` без /F — мягкий сигнал, не SIGKILL);
  - открытие/закрытие браузера и поиск — MEDIUM (требуют подтверждения),
    статус — SAFE (только чтение).

Использование:
    from actions.registry import CommandRegistry
    from actions.browser_actions import BrowserActions, register_browser_actions

    registry = CommandRegistry()
    register_browser_actions(registry)       # или со своим backend
"""

from __future__ import annotations

import abc
import logging
import platform
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Any, Callable
from urllib.parse import quote_plus, urlsplit

from actions.registry import REQUIRES_CONFIRMATION, Command, CommandRegistry, RiskLevel
from ai.function_calling import ParamSpec

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class BrowserError(Exception):
    """Ошибка команды браузера."""


class BrowserUnavailable(BrowserError):
    """Исполнитель недоступен (нет утилиты/браузера/прав) — можно fallback."""


# ---------------------------------------------------------------------------
# Константы и данные
# ---------------------------------------------------------------------------
#: Единственные допустимые схемы URL (анти-XSS, анти-чтение локальных файлов)
ALLOWED_SCHEMES: frozenset[str] = frozenset({"http", "https"})

#: Максимальная длина URL
MAX_URL_LENGTH = 2048

#: Максимальная длина поискового запроса
MAX_QUERY_LENGTH = 500

#: Поисковые системы: ключ → шаблон URL с ``{}`` вместо закодированного запроса
SEARCH_ENGINES: dict[str, str] = {
    "duckduckgo": "https://duckduckgo.com/?q={}",
    "google": "https://www.google.com/search?q={}",
    "yandex": "https://yandex.ru/search/?text={}",
    "wikipedia": "https://ru.wikipedia.org/w/index.php?search={}",
}

#: Поисковая система по умолчанию (приватность + без трекинга)
DEFAULT_ENGINE = "duckduckgo"

#: Имя браузера (ключ) — короткий токен без спецсимволов (антиинъекция)
_BROWSER_KEY_RE = re.compile(r"^[a-z0-9._-]+$")

#: Допустимые символы в хосте URL (буквы любых алфавитов — IDN допустим)
_HOST_RE = re.compile(r"^[\w.\-~%:\[\]]+$", re.UNICODE)

#: Схема в начале строки: ``https://``, ``mailto:`` и т.п.
_SCHEME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9+.\-]*:")


@dataclass(frozen=True)
class BrowserSpec:
    """Описание известного браузера под разные ОС."""

    key: str
    display: str
    #: точное имя процесса (для pgrep -x / pkill -x / taskkill /IM)
    process: str
    #: бинарь в PATH (Linux)
    linux: str | None = None
    #: имя приложения (macOS: open -a / osascript)
    darwin: str | None = None
    #: имя .exe (Windows)
    windows: str | None = None
    #: id .desktop-файлов (Linux, для определения браузера по умолчанию)
    desktop_ids: tuple[str, ...] = ()
    #: фрагменты ProgId (Windows, для определения браузера по умолчанию)
    prog_ids: tuple[str, ...] = ()


#: Известные браузеры (allow-list: посторонние имена не проходят валидацию)
KNOWN_BROWSERS: dict[str, BrowserSpec] = {
    spec.key: spec
    for spec in (
        BrowserSpec(
            key="firefox",
            display="Mozilla Firefox",
            process="firefox",
            linux="firefox",
            darwin="Firefox",
            windows="firefox.exe",
            desktop_ids=("firefox.desktop", "org.mozilla.firefox.desktop"),
            prog_ids=("firefox",),
        ),
        BrowserSpec(
            key="chrome",
            display="Google Chrome",
            process="chrome",
            linux="google-chrome",
            darwin="Google Chrome",
            windows="chrome.exe",
            desktop_ids=("google-chrome.desktop", "google-chrome-beta.desktop"),
            prog_ids=("chromehtml", "chrome"),
        ),
        BrowserSpec(
            key="chromium",
            display="Chromium",
            process="chromium",
            linux="chromium",
            darwin="Chromium",
            windows="chromium.exe",
            desktop_ids=("chromium.desktop", "chromium-browser.desktop"),
            prog_ids=("chromium",),
        ),
        BrowserSpec(
            key="brave",
            display="Brave",
            process="brave",
            linux="brave-browser",
            darwin="Brave Browser",
            windows="brave.exe",
            desktop_ids=("brave-browser.desktop", "com.brave.Browser.desktop"),
            prog_ids=("brave",),
        ),
        BrowserSpec(
            key="edge",
            display="Microsoft Edge",
            process="microsoft-edge",
            linux="microsoft-edge",
            darwin="Microsoft Edge",
            windows="msedge.exe",
            desktop_ids=("microsoft-edge.desktop",),
            prog_ids=("msedge",),
        ),
        BrowserSpec(
            key="opera",
            display="Opera",
            process="opera",
            linux="opera",
            darwin="Opera",
            windows="opera.exe",
            desktop_ids=("opera.desktop", "com.opera.Opera.desktop"),
            prog_ids=("opera",),
        ),
        BrowserSpec(
            key="vivaldi",
            display="Vivaldi",
            process="vivaldi",
            linux="vivaldi",
            darwin="Vivaldi",
            windows="vivaldi.exe",
            desktop_ids=("vivaldi-stable.desktop",),
            prog_ids=("vivaldi",),
        ),
        BrowserSpec(
            key="safari",
            display="Safari",
            process="Safari",
            darwin="Safari",
            desktop_ids=(),
            prog_ids=(),
        ),
    )
}


@dataclass(frozen=True)
class BrowserInfo:
    """Информация об установленном/запущенном браузере."""

    key: str
    display: str
    installed: bool = False
    running: bool = False
    is_default: bool = False

    def describe(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "display": self.display,
            "installed": self.installed,
            "running": self.running,
            "is_default": self.is_default,
        }


@dataclass(frozen=True)
class BrowserReport:
    """Сводка по браузерам: что установлено/запущено и какой по умолчанию."""

    default: str | None = None
    browsers: tuple[BrowserInfo, ...] = ()

    def describe(self) -> dict[str, Any]:
        return {
            "default": self.default,
            "browsers": [b.describe() for b in self.browsers],
        }


# ---------------------------------------------------------------------------
# Валидация
# ---------------------------------------------------------------------------
def validate_url(url: Any) -> str:
    """
    Проверяет URL и возвращает его в исходном виде (без пробелов по краям).

    Правила:
      - строка непустая, длиной до ``MAX_URL_LENGTH``, без управляющих
        символов и пробелов (пробелы должны быть закодированы);
      - не начинается с '-' (антиинъекция опций в argv утилит);
      - схема только из ``ALLOWED_SCHEMES`` (``javascript:`` / ``data:`` /
        ``file:`` и прочие опасные схемы отклоняются);
      - есть хост из допустимых символов (IDN допустим).
    """
    if not isinstance(url, str):
        raise ValueError(f"URL должен быть строкой, получено: {url!r}")
    text = url.strip()
    if not text:
        raise ValueError("URL не может быть пустым")
    if len(text) > MAX_URL_LENGTH:
        raise ValueError(f"URL длиннее {MAX_URL_LENGTH} символов")
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in text):
        raise ValueError("URL содержит управляющие символы")
    if any(ch.isspace() for ch in text):
        raise ValueError("URL содержит пробелы (закодируйте их, например %20)")
    if text.startswith("-"):
        raise ValueError("URL не должен начинаться с '-' (инъекция опций в argv)")
    if not _SCHEME_RE.match(text):
        raise ValueError(
            "у URL нет схемы (ожидается http:// или https://); "
            "похожее на запрос — используйте open_search"
        )

    parts = urlsplit(text)
    scheme = parts.scheme.lower()
    if scheme not in ALLOWED_SCHEMES:
        raise ValueError(
            f"недопустимая схема URL: {scheme!r} (разрешены: "
            f"{', '.join(sorted(ALLOWED_SCHEMES))})"
        )
    host = parts.hostname
    if not host:
        raise ValueError(f"у URL нет хоста: {text!r}")
    if not _HOST_RE.match(host):
        raise ValueError(f"хост содержит недопустимые символы: {host!r}")
    return text


def normalize_url(text: Any) -> str:
    """
    Приводит введённую строку к валидному URL.

    - ``example.com/path`` → ``https://example.com/path`` (схема добавляется);
    - строка со схемой проходит обычную проверку ``validate_url``;
    - свободный текст с пробелами отклоняется с подсказкой про ``open_search``.
    """
    if not isinstance(text, str):
        raise ValueError(f"URL должен быть строкой, получено: {text!r}")
    raw = text.strip()
    if not raw:
        raise ValueError("URL не может быть пустым")
    if raw.startswith("-"):
        raise ValueError("URL не должен начинаться с '-' (инъекция опций в argv)")
    if _SCHEME_RE.match(raw):
        return validate_url(raw)
    if any(ch.isspace() for ch in raw):
        raise ValueError(
            "не похоже на URL (есть пробелы) — для поиска используйте open_search"
        )
    return validate_url("https://" + raw)


def build_search_url(query: Any, engine: str | None = None) -> str:
    """
    Строит URL поиска: ``query`` кодируется и подставляется в шаблон ``engine``.

    ``engine`` — ключ из ``SEARCH_ENGINES`` (по умолчанию ``DEFAULT_ENGINE``).
    """
    if not isinstance(query, str):
        raise ValueError(f"запрос должен быть строкой, получено: {query!r}")
    text = query.strip()
    if not text:
        raise ValueError("поисковый запрос не может быть пустым")
    if len(text) > MAX_QUERY_LENGTH:
        raise ValueError(f"запрос длиннее {MAX_QUERY_LENGTH} символов")
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in text):
        raise ValueError("запрос содержит управляющие символы")

    if engine is None:
        key = DEFAULT_ENGINE
    else:
        key = engine.strip().lower()
        if key not in SEARCH_ENGINES:
            raise ValueError(
                f"неизвестная поисковая система: {engine!r} (допустимы: "
                f"{', '.join(sorted(SEARCH_ENGINES))})"
            )
    return SEARCH_ENGINES[key].format(quote_plus(text))


def validate_browser_name(name: Any) -> str:
    """
    Проверяет имя браузера и возвращает его ключ (``firefox``, ``chrome`` …).

    Имя должно быть токеном из ``KNOWN_BROWSERS`` — посторонние строки
    отклоняются (антиинъекция в argv утилит закрытия/запуска).
    """
    if not isinstance(name, str):
        raise ValueError(f"имя браузера должно быть строкой, получено: {name!r}")
    key = name.strip().lower()
    if not key:
        raise ValueError("имя браузера не может быть пустым")
    if not _BROWSER_KEY_RE.match(key):
        raise ValueError(f"недопустимое имя браузера: {name!r}")
    if key not in KNOWN_BROWSERS:
        raise ValueError(
            f"неизвестный браузер: {name!r} (допустимы: "
            f"{', '.join(sorted(KNOWN_BROWSERS))})"
        )
    return key


# ---------------------------------------------------------------------------
# Контракт исполнителя
# ---------------------------------------------------------------------------
class BrowserBackend(abc.ABC):
    """Контракт исполнителя операций над браузером."""

    name: str = "base"

    @abc.abstractmethod
    def is_available(self) -> bool: ...

    @abc.abstractmethod
    def detect(self) -> BrowserReport:
        """Какие известные браузеры установлены/запущены и какой по умолчанию."""

    @abc.abstractmethod
    def open_url(self, url: str, browser: str | None = None,
                 new_window: bool = False) -> str:
        """Открыть ``url``; вернуть описание выполненной команды."""

    @abc.abstractmethod
    def close(self, browser: str) -> int:
        """Мягко закрыть браузер ``browser``; вернуть число закрытых процессов."""

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "available": self.is_available()}


# ---------------------------------------------------------------------------
# Реальный исполнитель (subprocess)
# ---------------------------------------------------------------------------
#: Тип «запуск argv -> stdout» (подменяется в тестах)
Runner = Callable[[list[str]], str]


def _default_runner(argv: list[str]) -> str:
    """Выполняет argv и возвращает stdout; ошибки оборачивает в BrowserError."""
    try:
        proc = subprocess.run(  # noqa: S603 — argv формируем сами, shell=False
            argv,
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
    except FileNotFoundError as e:
        raise BrowserUnavailable(f"утилита не найдена: {argv[0]}") from e
    except subprocess.TimeoutExpired as e:
        raise BrowserError(f"таймаут команды: {' '.join(argv)}") from e
    if proc.returncode != 0:
        raise BrowserError(
            f"команда завершилась с кодом {proc.returncode}: {' '.join(argv)}"
            f" ({proc.stderr.strip()[:200]})"
        )
    return proc.stdout


@dataclass
class SubprocessBrowserBackend(BrowserBackend):
    """
    Локальный исполнитель: строит и выполняет команды под текущую ОС.

    runner подменяется в тестах; platform_name позволяет сымитировать
    другую платформу (linux / darwin / windows), which — сымитировать
    наличие утилит (xdg-open / pgrep / браузеры / powershell).
    """

    name: str = "subprocess"
    runner: Runner = field(default=_default_runner)
    platform_name: str = field(default_factory=platform.system)
    which: Callable[[str], str | None] = field(default=shutil.which)

    def _plat(self) -> str:
        return self.platform_name.lower()

    def _spec(self, browser: str | None) -> BrowserSpec | None:
        """Спецификация браузера (None — открывать средствами ОС по умолчанию)."""
        if browser is None:
            return None
        key = validate_browser_name(browser)
        return KNOWN_BROWSERS[key]

    def _plat_bin(self, spec: BrowserSpec) -> str:
        """Имя бинарника/приложения браузера под текущую ОС."""
        plat = self._plat()
        name = {
            "linux": spec.linux,
            "darwin": spec.darwin,
            "windows": spec.windows,
        }.get(plat)
        if not name:
            raise BrowserUnavailable(f"браузер '{spec.key}' не поддерживается на {plat}")
        return name

    def is_available(self) -> bool:
        plat = self._plat()
        if plat == "linux":
            return bool(self.which("xdg-open")) or any(
                self.which(spec.linux or "") for spec in KNOWN_BROWSERS.values()
            )
        if plat == "darwin":
            return bool(self.which("open"))
        if plat == "windows":
            return bool(self.which("powershell") or self.which("pwsh"))
        return False

    # -- открытие URL ----------------------------------------------------------
    def open_url(self, url: str, browser: str | None = None,
                 new_window: bool = False) -> str:
        spec = self._spec(browser)
        plat = self._plat()
        if plat == "darwin":
            return self._open_darwin(url, spec, new_window)
        if plat == "windows":
            return self._open_windows(url, spec, new_window)
        return self._open_linux(url, spec, new_window)

    def _open_linux(self, url: str, spec: BrowserSpec | None,
                    new_window: bool) -> str:
        if spec is None:
            if not self.which("xdg-open"):
                raise BrowserUnavailable("нет утилиты xdg-open")
            argv = ["xdg-open", url]
            self.runner(argv)
            return " ".join(argv)
        exe = self._plat_bin(spec)
        if not self.which(exe):
            raise BrowserUnavailable(f"браузер не найден в PATH: {exe}")
        argv = [exe] + (["--new-window"] if new_window else []) + [url]
        self.runner(argv)
        return " ".join(argv)

    def _open_darwin(self, url: str, spec: BrowserSpec | None,
                     new_window: bool) -> str:
        if not self.which("open"):
            raise BrowserUnavailable("нет утилиты open")
        if spec is None:
            argv = ["open"] + (["-n"] if new_window else []) + [url]
        else:
            app = self._plat_bin(spec)
            # -n: новый экземпляр (на macOS так открывается отдельное окно)
            argv = ["open", "-na" if new_window else "-a", app, url]
        self.runner(argv)
        return " ".join(argv)

    def _open_windows(self, url: str, spec: BrowserSpec | None,
                      new_window: bool) -> str:
        exe = self._ps_exe()
        if spec is None:
            ps = f"Start-Process {_ps_sq(url)}"
        else:
            bin_name = self._plat_bin(spec)
            args = (["--new-window"] if new_window else []) + [url]
            joined = ",".join(_ps_sq(a) for a in args)
            ps = f"Start-Process -FilePath {_ps_sq(bin_name)} -ArgumentList {joined}"
        self.runner([exe, "-NoProfile", "-Command", ps])
        return ps

    # -- закрытие ---------------------------------------------------------------
    def close(self, browser: str) -> int:
        spec = self._spec(browser)
        if spec is None:  # защита от прямого вызова с None в обход сигнатуры
            raise BrowserError("не указан браузер для закрытия")
        plat = self._plat()
        if plat == "windows":
            exe = self._plat_bin(spec)
            try:
                self.runner([self._ps_exe(), "-NoProfile", "-Command",
                             f"taskkill /IM {_ps_sq(exe)}"])
            except BrowserError:
                return 0  # процессов не было — не ошибка
            return 1
        # Linux/macOS: мягкий SIGTERM по точному имени процесса (allow-list)
        proc = spec.process
        try:
            out = self.runner(["pgrep", "-x", proc])
        except (BrowserError, BrowserUnavailable):
            return 0
        pids = [p for p in out.split() if p]
        if not pids:
            return 0
        self.runner(["pkill", "-x", proc])
        return len(pids)

    # -- сводка -----------------------------------------------------------------
    def detect(self) -> BrowserReport:
        default = self._detect_default()
        infos: list[BrowserInfo] = []
        for spec in KNOWN_BROWSERS.values():
            try:
                installed = self._is_installed(spec)
                running = self._is_running(spec) if installed else False
            except BrowserError:
                installed, running = False, False
            if not installed:
                continue
            infos.append(
                BrowserInfo(
                    key=spec.key,
                    display=spec.display,
                    installed=True,
                    running=running,
                    is_default=(spec.key == default),
                )
            )
        return BrowserReport(default=default, browsers=tuple(infos))

    def _is_installed(self, spec: BrowserSpec) -> bool:
        plat = self._plat()
        if plat == "darwin":
            app = spec.darwin
            if not app:
                return False
            out = self.runner(["osascript", "-e", f'exists application "{app}"'])
            return out.strip().lower() == "true"
        name = spec.linux if plat != "windows" else spec.windows
        return bool(name and self.which(name))

    def _is_running(self, spec: BrowserSpec) -> bool:
        plat = self._plat()
        try:
            if plat == "windows":
                exe = self._plat_bin(spec)
                out = self.runner([self._ps_exe(), "-NoProfile", "-Command",
                                   f"tasklist /FI {_ps_sq('IMAGENAME eq ' + exe)}"])
                return exe.lower() in out.lower()
            out = self.runner(["pgrep", "-x", spec.process])
            return bool(out.split())
        except (BrowserError, BrowserUnavailable):
            return False

    def _detect_default(self) -> str | None:
        """Определение браузера по умолчанию (best-effort, без исключений)."""
        plat = self._plat()
        try:
            if plat == "linux":
                if not self.which("xdg-settings"):
                    return None
                out = self.runner(["xdg-settings", "get", "default-web-browser"])
                return _key_from_desktop_id(out.strip())
            if plat == "windows":
                ps = (
                    "(Get-ItemProperty "
                    "'HKCU:\\Software\\Microsoft\\Windows\\Shell\\Associations\\"
                    "UrlAssociations\\https\\UserChoice').ProgId"
                )
                out = self.runner([self._ps_exe(), "-NoProfile", "-Command", ps])
                return _key_from_prog_id(out.strip())
        except (BrowserError, BrowserUnavailable):
            return None
        # macOS: системный дефолт надёжно не вытащить без лишних зависимостей
        return None

    def _ps_exe(self) -> str:
        return "pwsh" if self.which("pwsh") else "powershell"


def _ps_sq(text: str) -> str:
    """Экранирует строку для PowerShell-литерала в одинарных кавычках."""
    return "'" + text.replace("'", "''") + "'"


def _key_from_desktop_id(desktop_id: str) -> str | None:
    """``firefox.desktop`` → ``firefox``; ``google-chrome.desktop`` → ``chrome``."""
    value = desktop_id.strip().lower()
    if not value:
        return None
    for spec in KNOWN_BROWSERS.values():
        if value in spec.desktop_ids:
            return spec.key
    stem = value.removesuffix(".desktop")
    for spec in KNOWN_BROWSERS.values():
        if stem == spec.key or stem == (spec.linux or ""):
            return spec.key
    return None


def _key_from_prog_id(prog_id: str) -> str | None:
    """``ChromeHTML`` / ``FirefoxURL-…`` / ``MSEdgeHTM`` → ключ браузера."""
    value = prog_id.strip().lower()
    if not value:
        return None
    for spec in KNOWN_BROWSERS.values():
        if any(fragment and fragment in value for fragment in spec.prog_ids):
            return spec.key
    return None


# ---------------------------------------------------------------------------
# Безопасный исполнитель (fallback / отладка / тесты)
# ---------------------------------------------------------------------------
@dataclass
class DryRunBrowserBackend(BrowserBackend):
    """
    Ничего не запускает: записывает вызовы в ``calls`` и отдаёт
    предзаполненную сводку. Используется в тестах и как fallback
    при недоступности браузеров/утилит (headless-контейнер).
    """

    name: str = "dry-run"
    available: bool = True
    default: str | None = "firefox"
    installed: list[str] = field(default_factory=lambda: ["firefox"])
    running: list[str] = field(default_factory=list)
    closed_count: int = 1
    calls: list[tuple[str, tuple[Any, ...]]] = field(default_factory=list)

    def is_available(self) -> bool:
        return self.available

    def detect(self) -> BrowserReport:
        self.calls.append(("detect", ()))
        infos = tuple(
            BrowserInfo(
                key=key,
                display=KNOWN_BROWSERS[key].display,
                installed=True,
                running=key in self.running,
                is_default=(key == self.default),
            )
            for key in self.installed
            if key in KNOWN_BROWSERS
        )
        return BrowserReport(default=self.default, browsers=infos)

    def open_url(self, url: str, browser: str | None = None,
                 new_window: bool = False) -> str:
        self.calls.append(("open_url", (url, browser, new_window)))
        target = browser or self.default or "default"
        return f"dry-run: open {url} ({target})"

    def close(self, browser: str) -> int:
        self.calls.append(("close", (browser,)))
        if browser in self.running:
            self.running.remove(browser)
            return self.closed_count
        return 0


# ---------------------------------------------------------------------------
# Служба команд браузера
# ---------------------------------------------------------------------------
@dataclass
class BrowserActions:
    """
    Служба команд браузера: валидация URL/имён/запросов + backend.

    При недоступности backend операции падают контролируемо
    (``BrowserUnavailable``), без побочных эффектов.
    """

    backend: BrowserBackend = field(default_factory=SubprocessBrowserBackend)
    default_engine: str = DEFAULT_ENGINE

    def _require_backend(self) -> BrowserBackend:
        if not self.backend.is_available():
            raise BrowserUnavailable(
                f"исполнитель '{self.backend.name}' недоступен"
            )
        return self.backend

    # -- команда (SAFE) --------------------------------------------------------
    def browser_status(self) -> dict[str, Any]:
        """Какие браузеры установлены/запущены и какой по умолчанию."""
        report = self._require_backend().detect()
        return report.describe()

    # -- команды (MEDIUM: запуск/навигация/закрытие) ---------------------------
    def open_url(self, url: Any, browser: str | None = None,
                 new_window: bool = False) -> dict[str, Any]:
        """
        Открыть URL в браузере (после подтверждения).

        ``browser`` — ключ из известных (firefox/chrome/…), без него —
        браузер по умолчанию. ``new_window=True`` — в новом окне.
        """
        if not isinstance(new_window, bool):
            raise ValueError(f"new_window должен быть bool, получено: {new_window!r}")
        target = normalize_url(url)
        key = validate_browser_name(browser) if browser is not None else None
        cmd = self._require_backend().open_url(target, key, new_window)
        logger.info("Открыт URL: %s (%s)", target, key or "по умолчанию")
        return {
            "url": target,
            "browser": key,
            "new_window": new_window,
            "command": cmd,
        }

    def open_search(self, query: Any, engine: str | None = None,
                    browser: str | None = None) -> dict[str, Any]:
        """
        Найти в интернете: строит URL поиска и открывает его в браузере
        (после подтверждения). ``engine`` — duckduckgo/google/yandex/wikipedia.
        """
        chosen = (engine or self.default_engine).strip().lower()
        search_url = build_search_url(query, chosen)
        key = validate_browser_name(browser) if browser is not None else None
        cmd = self._require_backend().open_url(search_url, key, False)
        logger.info("Поиск '%s' через %s", query, chosen)
        return {
            "query": str(query).strip(),
            "engine": chosen,
            "url": search_url,
            "browser": key,
            "command": cmd,
        }

    def close_browser(self, browser: str | None = None) -> dict[str, Any]:
        """
        Мягко закрыть браузер (после подтверждения).

        Без аргумента закрывается браузер по умолчанию; закрытие идёт
        обычным сигналом завершения (не SIGKILL) — данные не теряются.
        """
        if browser is None:
            default = self._require_backend().detect().default
            if default is None:
                raise BrowserError(
                    "не удалось определить браузер по умолчанию — укажите browser"
                )
            key = validate_browser_name(default)
        else:
            key = validate_browser_name(browser)
        closed = self._require_backend().close(key)
        logger.info("Закрыт браузер %s (процессов: %d)", key, closed)
        return {"browser": key, "closed": closed}


# ---------------------------------------------------------------------------
# Регистрация команд в реестре
# ---------------------------------------------------------------------------
def _spec(name: str, type_: str, description: str, **kw: Any) -> ParamSpec:
    return ParamSpec(
        name=name,
        type=type_,
        description=description,
        required=kw.get("required", True),
        enum=kw.get("enum"),
        default=kw.get("default"),
    )


def register_browser_actions(
    registry: CommandRegistry,
    actions: BrowserActions | None = None,
) -> list[str]:
    """
    Регистрирует команды браузера в ``registry`` (возвращает их имена).

    Уровни риска (ТЗ-6.7):
      - SAFE:   browser_status (только чтение)
      - MEDIUM: open_url, open_search, close_browser (навигация и запуск
                браузера — требуют подтверждения)
    """
    svc = actions or BrowserActions()

    defs: list[tuple[str, str, list[ParamSpec], str, Callable[..., Any]]] = [
        (
            "browser_status",
            "Какие браузеры установлены и запущены, какой по умолчанию",
            [],
            RiskLevel.SAFE,
            svc.browser_status,
        ),
        (
            "open_url",
            "Открыть URL в браузере (http/https; после подтверждения)",
            [
                _spec("url", "string", "адрес: https://example.com или example.com"),
                _spec(
                    "browser",
                    "string",
                    "браузер: firefox/chrome/chromium/brave/edge/opera/vivaldi/safari",
                    required=False,
                    enum=sorted(KNOWN_BROWSERS),
                ),
                _spec(
                    "new_window",
                    "boolean",
                    "открыть в новом окне (по умолчанию — вкладка)",
                    required=False,
                    default=False,
                ),
            ],
            RiskLevel.MEDIUM,
            svc.open_url,
        ),
        (
            "open_search",
            "Найти в интернете и открыть результаты в браузере (после подтверждения)",
            [
                _spec("query", "string", "поисковый запрос"),
                _spec(
                    "engine",
                    "string",
                    "поисковая система",
                    required=False,
                    enum=sorted(SEARCH_ENGINES),
                    default=DEFAULT_ENGINE,
                ),
                _spec(
                    "browser",
                    "string",
                    "браузер (по умолчанию — системный)",
                    required=False,
                    enum=sorted(KNOWN_BROWSERS),
                ),
            ],
            RiskLevel.MEDIUM,
            svc.open_search,
        ),
        (
            "close_browser",
            "Закрыть браузер (после подтверждения)",
            [
                _spec(
                    "browser",
                    "string",
                    "какой браузер закрыть (по умолчанию — системный)",
                    required=False,
                    enum=sorted(KNOWN_BROWSERS),
                ),
            ],
            RiskLevel.MEDIUM,
            svc.close_browser,
        ),
    ]

    names: list[str] = []
    for name, description, params, risk, handler in defs:
        registry.register(
            Command(
                name=name,
                description=description,
                params=params,
                handler=handler,
                risk=risk,
                requires_confirmation=REQUIRES_CONFIRMATION.get(risk, False),
            )
        )
        names.append(name)
    logger.debug("Зарегистрированы команды браузера: %s", ", ".join(names))
    return names
