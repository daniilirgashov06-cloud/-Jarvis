"""
Команды продуктивности JARVIS CORE (ТЗ-6, каталог productivity).

Заметки, таймеры/напоминания и буфер обмена. Каждая команда имеет уровень
риска (``RiskLevel``) и регистрируется в ``CommandRegistry``, откуда она
попадает в схемы function calling для LLM.

Архитектура (в стиле ``actions/media_actions.py`` и ``actions/app_actions.py``):

- ``ProductivityBackend`` — контракт «исполнитель»: заметки, таймеры, буфер;
- ``MemoryProductivityBackend`` — локальное хранилище в памяти (потокобезопасно):
  используется по умолчанию, в тестах и как fallback;
- ``LocalProductivityBackend`` — «настоящая» локальная реализация: заметки и
  таймеры в JSON-файле, буфер обмена через системные утилиты
  (Linux ``xclip``/``xsel``, macOS ``pbcopy``/``pbpaste``, Windows ``clip``/
  PowerShell); при недоступности утилиты буфер деградирует в память;
- ``Note`` / ``TimerInfo`` — нормализованные сущности с описанием для голоса.

«Локально ↔ облако» здесь неприменимо: данные продуктивности осознанно
хранятся только локально (приватность). При недоступности backend команда
падает контролируемо (``ProductivityUnavailable``) без побочных эффектов.

Использование:
    from actions.registry import CommandRegistry
    from actions.productivity_actions import (
        ProductivityActions, register_productivity_actions,
    )

    registry = CommandRegistry()
    register_productivity_actions(registry)     # или со своим backend
"""

from __future__ import annotations

import abc
import json
import logging
import platform
import re
import subprocess
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from actions.registry import REQUIRES_CONFIRMATION, Command, CommandRegistry, RiskLevel
from ai.function_calling import ParamSpec

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class ProductivityError(Exception):
    """Ошибка команды продуктивности."""


class ProductivityUnavailable(ProductivityError):
    """Исполнитель недоступен (нет прав/файла/утилиты) — можно fallback."""


class ProductivityInvalidInput(ProductivityError):
    """Некорректные данные команды (пустой текст, чужой id и т.п.)."""


# ---------------------------------------------------------------------------
# Ограничения ввода (защита от мусора и инъекций)
# ---------------------------------------------------------------------------
MAX_TEXT_LENGTH = 2000          # заметка / текст в буфер
MAX_NAME_LENGTH = 64            # имя таймера
MAX_NOTES = 500                 # предохранитель от раздувания хранилища
MAX_TIMERS = 50
MIN_TIMER_SEC = 1
MAX_TIMER_SEC = 86400           # сутки

#: имя таймера: буквы/цифры/пробел/дефис/подчёркивание (антиинъекция в JSON/CLI)
_NAME_RE = re.compile(r"^[\w \-]+$", re.UNICODE)


def _validate_text(text: str) -> str:
    """Проверяет и нормализует текст заметки/буфера."""
    if not isinstance(text, str) or not text.strip():
        raise ProductivityInvalidInput("текст не может быть пустым")
    cleaned = text.strip()
    if len(cleaned) > MAX_TEXT_LENGTH:
        raise ProductivityInvalidInput(
            f"текст слишком длинный ({len(cleaned)} > {MAX_TEXT_LENGTH})"
        )
    return cleaned


def _validate_name(name: str | None) -> str | None:
    """Проверяет имя таймера (опционально)."""
    if name is None:
        return None
    cleaned = name.strip()
    if not cleaned:
        return None
    if len(cleaned) > MAX_NAME_LENGTH:
        raise ProductivityInvalidInput(f"имя слишком длинное (максимум {MAX_NAME_LENGTH})")
    if not _NAME_RE.match(cleaned):
        raise ProductivityInvalidInput("имя содержит недопустимые символы")
    return cleaned


def _validate_duration(duration_sec: float) -> float:
    """Проверяет длительность таймера в секундах."""
    try:
        value = float(duration_sec)
    except (TypeError, ValueError) as exc:
        raise ProductivityInvalidInput("длительность должна быть числом") from exc
    if not (MIN_TIMER_SEC <= value <= MAX_TIMER_SEC):
        raise ProductivityInvalidInput(
            f"длительность вне диапазона {MIN_TIMER_SEC}..{MAX_TIMER_SEC} сек"
        )
    return value


# ---------------------------------------------------------------------------
# Сущности
# ---------------------------------------------------------------------------
@dataclass
class Note:
    """Заметка."""

    id: str
    text: str
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "text": self.text, "created_at": self.created_at}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Note":
        return cls(
            id=str(data["id"]),
            text=str(data["text"]),
            created_at=float(data.get("created_at", time.time())),
        )

    def describe(self) -> str:
        """Строка для голосового ответа/списка."""
        moment = time.strftime("%H:%M", time.localtime(self.created_at))
        return f"{self.id[:6]} [{moment}] {self.text}"


@dataclass
class TimerInfo:
    """Таймер (напоминание) с дедлайном."""

    id: str
    name: str | None
    duration_sec: float
    created_at: float = field(default_factory=time.time)

    @property
    def due_at(self) -> float:
        """Момент срабатывания (epoch)."""
        return self.created_at + self.duration_sec

    @property
    def remaining_sec(self) -> float:
        """Сколько секунд осталось (отрицательно, если уже сработал)."""
        return self.due_at - time.time()

    def is_due(self, now: float | None = None) -> bool:
        """Сработал ли таймер."""
        return (now if now is not None else time.time()) >= self.due_at

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "duration_sec": self.duration_sec,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TimerInfo":
        return cls(
            id=str(data["id"]),
            name=data.get("name"),
            duration_sec=float(data["duration_sec"]),
            created_at=float(data.get("created_at", time.time())),
        )

    def describe(self) -> str:
        """Строка для голосового ответа/списка."""
        label = f"«{self.name}» " if self.name else ""
        left = max(0.0, self.remaining_sec)
        return f"{label}{self.id[:6]} — осталось {_format_seconds(left)}"


def _format_seconds(seconds: float) -> str:
    """Человекочитаемая длительность: '90 сек' → '1 мин 30 сек'."""
    total = int(round(seconds))
    if total < 60:
        return f"{total} сек"
    minutes, sec = divmod(total, 60)
    if minutes < 60:
        return f"{minutes} мин {sec} сек"
    hours, minutes = divmod(minutes, 60)
    return f"{hours} ч {minutes} мин"


# ---------------------------------------------------------------------------
# Контракт исполнителя
# ---------------------------------------------------------------------------
class ProductivityBackend(abc.ABC):
    """Абстрактный исполнитель операций продуктивности."""

    name: str = "abstract"

    def is_available(self) -> bool:
        """Готов ли backend принимать команды."""
        return True

    # -- заметки -----------------------------------------------------------
    @abc.abstractmethod
    def add_note(self, text: str) -> Note:
        """Создать заметку, вернуть сохранённую сущность."""

    @abc.abstractmethod
    def list_notes(self) -> list[Note]:
        """Все заметки (по убыванию свежести)."""

    @abc.abstractmethod
    def remove_note(self, note_id: str) -> Note:
        """Удалить заметку по id (полный или префикс); вернуть удалённую."""

    @abc.abstractmethod
    def clear_notes(self) -> int:
        """Удалить все заметки, вернуть количество."""

    # -- таймеры -----------------------------------------------------------
    @abc.abstractmethod
    def set_timer(self, duration_sec: float, name: str | None = None) -> TimerInfo:
        """Поставить таймер, вернуть его описание."""

    @abc.abstractmethod
    def list_timers(self, include_due: bool = False) -> list[TimerInfo]:
        """Активные таймеры (по умолчанию без сработавших)."""

    @abc.abstractmethod
    def cancel_timer(self, timer_id: str) -> TimerInfo:
        """Отменить таймер по id (полный или префикс); вернуть отменённый."""

    def due_timers(self) -> list[TimerInfo]:
        """Сработавшие таймеры (для опроса оркестратором)."""
        return [t for t in self.list_timers(include_due=True) if t.is_due()]

    # -- буфер обмена ------------------------------------------------------
    @abc.abstractmethod
    def clipboard_copy(self, text: str) -> None:
        """Положить текст в буфер обмена."""

    @abc.abstractmethod
    def clipboard_paste(self) -> str:
        """Прочитать текст из буфера обмена ('' если пусто)."""


# ---------------------------------------------------------------------------
# Локальное хранилище в памяти (default + fallback + тесты)
# ---------------------------------------------------------------------------
class MemoryProductivityBackend(ProductivityBackend):
    """Потокобезопасное хранилище заметок/таймеров и буфера в памяти."""

    name = "memory"

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._notes: dict[str, Note] = {}
        self._timers: dict[str, TimerInfo] = {}
        self._clipboard: str = ""

    # -- заметки -----------------------------------------------------------
    def add_note(self, text: str) -> Note:
        note = Note(id=uuid.uuid4().hex, text=text)
        with self._lock:
            if len(self._notes) >= MAX_NOTES:
                raise ProductivityUnavailable(f"слишком много заметок (максимум {MAX_NOTES})")
            self._notes[note.id] = note
        return note

    def list_notes(self) -> list[Note]:
        with self._lock:
            return sorted(self._notes.values(), key=lambda n: n.created_at, reverse=True)

    def _find_note_locked(self, note_id: str) -> Note:
        """Поиск заметки по полному id или уникальному префиксу (под лок)."""
        if note_id in self._notes:
            return self._notes[note_id]
        matches = [n for n in self._notes.values() if n.id.startswith(note_id)]
        if not matches:
            raise ProductivityInvalidInput(f"заметка '{note_id}' не найдена")
        if len(matches) > 1:
            raise ProductivityInvalidInput(f"префикс '{note_id}' неоднозначен")
        return matches[0]

    def remove_note(self, note_id: str) -> Note:
        with self._lock:
            note = self._find_note_locked(note_id)
            del self._notes[note.id]
        return note

    def clear_notes(self) -> int:
        with self._lock:
            count = len(self._notes)
            self._notes.clear()
        return count

    # -- таймеры -----------------------------------------------------------
    def set_timer(self, duration_sec: float, name: str | None = None) -> TimerInfo:
        timer = TimerInfo(id=uuid.uuid4().hex, name=name, duration_sec=duration_sec)
        with self._lock:
            if len(self._timers) >= MAX_TIMERS:
                raise ProductivityUnavailable(f"слишком много таймеров (максимум {MAX_TIMERS})")
            self._timers[timer.id] = timer
        return timer

    def list_timers(self, include_due: bool = False) -> list[TimerInfo]:
        with self._lock:
            timers = list(self._timers.values())
        if not include_due:
            timers = [t for t in timers if not t.is_due()]
        return sorted(timers, key=lambda t: t.due_at)

    def _find_timer_locked(self, timer_id: str) -> TimerInfo:
        if timer_id in self._timers:
            return self._timers[timer_id]
        matches = [t for t in self._timers.values() if t.id.startswith(timer_id)]
        if not matches:
            raise ProductivityInvalidInput(f"таймер '{timer_id}' не найден")
        if len(matches) > 1:
            raise ProductivityInvalidInput(f"префикс '{timer_id}' неоднозначен")
        return matches[0]

    def cancel_timer(self, timer_id: str) -> TimerInfo:
        with self._lock:
            timer = self._find_timer_locked(timer_id)
            del self._timers[timer.id]
        return timer

    # -- буфер обмена ------------------------------------------------------
    def clipboard_copy(self, text: str) -> None:
        with self._lock:
            self._clipboard = text

    def clipboard_paste(self) -> str:
        with self._lock:
            return self._clipboard


# ---------------------------------------------------------------------------
# Системный буфер обмена (subprocess по платформе)
# ---------------------------------------------------------------------------
def _run_quiet(cmd: list[str], input_text: str | None = None) -> str | None:
    """Запускает утилиту без shell; возвращает stdout или None при сбое."""
    try:
        proc = subprocess.run(
            cmd,
            input=input_text,
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        logger.debug("Буфер обмена: %s недоступна: %s", cmd[0], exc)
        return None
    if proc.returncode != 0:
        logger.debug("Буфер обмена: %s код %s", cmd[0], proc.returncode)
        return None
    return proc.stdout


def _system_clipboard_copy(text: str) -> bool:
    """Копирует текст в системный буфер; True при успехе."""
    system = platform.system()
    candidates: list[list[str]]
    if system == "Darwin":
        candidates = [["pbcopy"]]
    elif system == "Windows":
        candidates = [["clip"]]
    else:
        candidates = [["xclip", "-selection", "clipboard"], ["xsel", "--clipboard", "--input"]]
    for cmd in candidates:
        if _run_quiet(cmd, input_text=text) is not None:
            return True
    return False


def _system_clipboard_paste() -> str | None:
    """Читает системный буфер; None если утилита недоступна."""
    system = platform.system()
    candidates: list[list[str]]
    if system == "Darwin":
        candidates = [["pbpaste"]]
    elif system == "Windows":
        candidates = [["powershell", "-NoProfile", "-Command", "Get-Clipboard"]]
    else:
        candidates = [["xclip", "-selection", "clipboard", "-o"], ["xsel", "--clipboard", "--output"]]
    for cmd in candidates:
        out = _run_quiet(cmd)
        if out is not None:
            return out
    return None


# ---------------------------------------------------------------------------
# Локальный backend: JSON-файл + системный буфер
# ---------------------------------------------------------------------------
class LocalProductivityBackend(ProductivityBackend):
    """
    Локальный исполнитель: заметки и таймеры — в JSON-файле,
    буфер обмена — через системные утилиты с деградацией в память.

    Файл переписывается атомарно (``.tmp`` + ``replace``), чтение толерантно
    к повреждённому JSON (начинает с пустого хранилища, не падает).
    """

    name = "local"

    def __init__(self, store_path: str | Path = "data/productivity.json") -> None:
        self._path = Path(store_path)
        self._lock = threading.RLock()
        self._notes: dict[str, Note] = {}
        self._timers: dict[str, TimerInfo] = {}
        self._clipboard_fallback = MemoryProductivityBackend()
        self._load()

    # -- персистентность ---------------------------------------------------
    def _load(self) -> None:
        if not self._path.exists():
            return
        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
            self._notes = {
                str(d["id"]): Note.from_dict(d) for d in raw.get("notes", []) if "id" in d
            }
            self._timers = {
                str(d["id"]): TimerInfo.from_dict(d) for d in raw.get("timers", []) if "id" in d
            }
        except (OSError, ValueError, KeyError, TypeError) as exc:
            logger.warning("Хранилище %s повреждено (%s) — начинаю с пустого", self._path, exc)
            self._notes, self._timers = {}, {}

    def _save(self) -> None:
        payload = {
            "notes": [n.to_dict() for n in self._notes.values()],
            "timers": [t.to_dict() for t in self._timers.values()],
        }
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self._path.with_suffix(".tmp")
            tmp.write_text(
                json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            tmp.replace(self._path)
        except OSError as exc:
            raise ProductivityUnavailable(f"не удалось сохранить {self._path}: {exc}") from exc

    # -- заметки -----------------------------------------------------------
    def add_note(self, text: str) -> Note:
        note = Note(id=uuid.uuid4().hex, text=text)
        with self._lock:
            if len(self._notes) >= MAX_NOTES:
                raise ProductivityUnavailable(f"слишком много заметок (максимум {MAX_NOTES})")
            self._notes[note.id] = note
            self._save()
        return note

    def list_notes(self) -> list[Note]:
        with self._lock:
            return sorted(self._notes.values(), key=lambda n: n.created_at, reverse=True)

    def remove_note(self, note_id: str) -> Note:
        with self._lock:
            # переиспользуем логику поиска из Memory-бэкенда
            finder = MemoryProductivityBackend._find_note_locked
            note = finder(self, note_id)  # type: ignore[arg-type]
            del self._notes[note.id]
            self._save()
        return note

    def clear_notes(self) -> int:
        with self._lock:
            count = len(self._notes)
            self._notes.clear()
            self._save()
        return count

    # -- таймеры -----------------------------------------------------------
    def set_timer(self, duration_sec: float, name: str | None = None) -> TimerInfo:
        timer = TimerInfo(id=uuid.uuid4().hex, name=name, duration_sec=duration_sec)
        with self._lock:
            if len(self._timers) >= MAX_TIMERS:
                raise ProductivityUnavailable(f"слишком много таймеров (максимум {MAX_TIMERS})")
            self._timers[timer.id] = timer
            self._save()
        return timer

    def list_timers(self, include_due: bool = False) -> list[TimerInfo]:
        with self._lock:
            timers = list(self._timers.values())
        if not include_due:
            timers = [t for t in timers if not t.is_due()]
        return sorted(timers, key=lambda t: t.due_at)

    def cancel_timer(self, timer_id: str) -> TimerInfo:
        with self._lock:
            finder = MemoryProductivityBackend._find_timer_locked
            timer = finder(self, timer_id)  # type: ignore[arg-type]
            del self._timers[timer.id]
            self._save()
        return timer

    # -- буфер обмена ------------------------------------------------------
    def clipboard_copy(self, text: str) -> None:
        if not _system_clipboard_copy(text):
            logger.debug("Системный буфер недоступен — использую память")
            self._clipboard_fallback.clipboard_copy(text)
            return
        # синхронизируем и память (для paste при падении утилиты)
        self._clipboard_fallback.clipboard_copy(text)

    def clipboard_paste(self) -> str:
        out = _system_clipboard_paste()
        if out is not None:
            return out
        return self._clipboard_fallback.clipboard_paste()


# ---------------------------------------------------------------------------
# Служба команд
# ---------------------------------------------------------------------------
@dataclass
class ProductivityActions:
    """
    Служба команд продуктивности: валидация входа + backend.

    При недоступности backend операции падают контролируемо
    (``ProductivityUnavailable``), без побочных эффектов.
    """

    backend: ProductivityBackend = field(default_factory=MemoryProductivityBackend)

    def _require_backend(self) -> ProductivityBackend:
        if not self.backend.is_available():
            raise ProductivityUnavailable(f"исполнитель '{self.backend.name}' недоступен")
        return self.backend

    # -- заметки -----------------------------------------------------------
    def note_add(self, text: str) -> str:
        """Сохранить заметку."""
        note = self._require_backend().add_note(_validate_text(text))
        logger.info("Заметка добавлена: %s", note.id[:6])
        return f"Заметка сохранена: {note.text}"

    def note_list(self) -> str:
        """Показать заметки."""
        notes = self._require_backend().list_notes()
        if not notes:
            return "Заметок пока нет."
        head = f"Заметок: {len(notes)}."
        lines = [n.describe() for n in notes[:10]]
        if len(notes) > 10:
            lines.append(f"… и ещё {len(notes) - 10}")
        return head + "\n" + "\n".join(lines)

    def note_remove(self, note_id: str) -> str:
        """Удалить заметку по идентификатору (или уникальному префиксу)."""
        if not isinstance(note_id, str) or not note_id.strip():
            raise ProductivityInvalidInput("не указан идентификатор заметки")
        note = self._require_backend().remove_note(note_id.strip())
        logger.info("Заметка удалена: %s", note.id[:6])
        return f"Заметка удалена: {note.text}"

    def note_clear(self) -> str:
        """Удалить все заметки."""
        count = self._require_backend().clear_notes()
        logger.info("Заметки очищены: %s", count)
        return f"Удалено заметок: {count}."

    # -- таймеры -----------------------------------------------------------
    def timer_set(self, duration_sec: float, name: str | None = None) -> str:
        """Поставить таймер (напоминание) на N секунд."""
        duration = _validate_duration(duration_sec)
        label = _validate_name(name)
        timer = self._require_backend().set_timer(duration, label)
        logger.info("Таймер поставлен: %s на %s сек", timer.id[:6], duration)
        title = f"Таймер «{label}» " if label else "Таймер "
        return f"{title}поставлен на {_format_seconds(duration)}."

    def timer_list(self) -> str:
        """Показать активные таймеры."""
        timers = self._require_backend().list_timers()
        if not timers:
            return "Активных таймеров нет."
        head = f"Активных таймеров: {len(timers)}."
        return head + "\n" + "\n".join(t.describe() for t in timers)

    def timer_cancel(self, timer_id: str) -> str:
        """Отменить таймер по идентификатору (или уникальному префиксу)."""
        if not isinstance(timer_id, str) or not timer_id.strip():
            raise ProductivityInvalidInput("не указан идентификатор таймера")
        timer = self._require_backend().cancel_timer(timer_id.strip())
        logger.info("Таймер отменён: %s", timer.id[:6])
        label = f"«{timer.name}» " if timer.name else ""
        return f"Таймер {label}отменён."

    # -- буфер обмена ------------------------------------------------------
    def clipboard_copy(self, text: str) -> str:
        """Скопировать текст в буфер обмена."""
        cleaned = _validate_text(text)
        self._require_backend().clipboard_copy(cleaned)
        logger.info("Буфер обмена: записано %d симв.", len(cleaned))
        return f"Скопировано в буфер обмена ({len(cleaned)} симв.)."

    def clipboard_paste(self) -> str:
        """Прочитать текст из буфера обмена."""
        text = self._require_backend().clipboard_paste()
        if not text:
            return "Буфер обмена пуст."
        return f"В буфере обмена: {text}"


# ---------------------------------------------------------------------------
# Регистрация команд в реестре
# ---------------------------------------------------------------------------
def register_productivity_actions(
    registry: CommandRegistry,
    actions: ProductivityActions | None = None,
) -> list[str]:
    """
    Регистрирует команды продуктивности в ``registry`` (возвращает их имена).

    Уровни риска (ТЗ-6.7): чтение и создание — SAFE; удаление заметок —
    потеря данных → MEDIUM (требует подтверждения); отмена таймера обратима
    (можно поставить заново) → SAFE.
    """
    svc = actions or ProductivityActions()

    defs: list[tuple[str, str, list[ParamSpec], str, Callable[..., Any]]] = [
        (
            "note_add",
            "Сохранить заметку с текстом",
            [ParamSpec(name="text", description="Текст заметки", type="string")],
            RiskLevel.SAFE,
            svc.note_add,
        ),
        (
            "note_list",
            "Показать сохранённые заметки",
            [],
            RiskLevel.SAFE,
            svc.note_list,
        ),
        (
            "note_remove",
            "Удалить заметку по идентификатору",
            [ParamSpec(name="note_id", description="Идентификатор заметки", type="string")],
            RiskLevel.MEDIUM,
            svc.note_remove,
        ),
        (
            "note_clear",
            "Удалить все заметки",
            [],
            RiskLevel.MEDIUM,
            svc.note_clear,
        ),
        (
            "timer_set",
            "Поставить таймер (напоминание) на N секунд",
            [
                ParamSpec(
                    name="duration_sec",
                    description="Длительность в секундах (1..86400)",
                    type="number",
                ),
                ParamSpec(
                    name="name",
                    description="Необязательное имя таймера",
                    type="string",
                    required=False,
                ),
            ],
            RiskLevel.SAFE,
            svc.timer_set,
        ),
        (
            "timer_list",
            "Показать активные таймеры",
            [],
            RiskLevel.SAFE,
            svc.timer_list,
        ),
        (
            "timer_cancel",
            "Отменить таймер по идентификатору",
            [ParamSpec(name="timer_id", description="Идентификатор таймера", type="string")],
            RiskLevel.SAFE,
            svc.timer_cancel,
        ),
        (
            "clipboard_copy",
            "Скопировать текст в буфер обмена",
            [ParamSpec(name="text", description="Текст для копирования", type="string")],
            RiskLevel.SAFE,
            svc.clipboard_copy,
        ),
        (
            "clipboard_paste",
            "Прочитать текст из буфера обмена",
            [],
            RiskLevel.SAFE,
            svc.clipboard_paste,
        ),
    ]

    names: list[str] = []
    for name, description, params, risk, handler in defs:
        registry.register(
            Command(
                name=name,
                description=description,
                params=params,
                handler=handler,
                risk=risk,
                requires_confirmation=REQUIRES_CONFIRMATION.get(risk, False),
            )
        )
        names.append(name)
    logger.debug("Зарегистрированы команды продуктивности: %s", ", ".join(names))
    return names
