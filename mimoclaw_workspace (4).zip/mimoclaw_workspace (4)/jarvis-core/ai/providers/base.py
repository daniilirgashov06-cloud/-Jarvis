"""
Базовый интерфейс LLM-провайдеров JARVIS CORE.

Все провайдеры (локальные и облачные) реализуют единый контракт
``BaseLLMProvider``, чтобы ``LLMRouter`` мог бесшовно переключаться между
Ollama / OpenAI / Anthropic / Gemini и строить fallback-цепочку.
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any, Literal

# Роль сообщения в диалоге
Role = Literal["system", "user", "assistant", "tool"]


class ProviderError(Exception):
    """Базовая ошибка провайдера (сеть, лимиты, некорректный ответ)."""


class ProviderUnavailable(ProviderError):
    """Провайдер недоступен (нет ключа, нет сервера, офлайн) — можно fallback."""


@dataclass
class ToolCall:
    """Унифицированный вызов инструмента (function calling)."""

    id: str
    name: str
    arguments: dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMMessage:
    """Одно сообщение диалога (унифицированное)."""

    role: Role
    content: str = ""
    name: str | None = None
    tool_call_id: str | None = None
    tool_calls: list[ToolCall] = field(default_factory=list)

    @classmethod
    def system(cls, content: str) -> "LLMMessage":
        return cls(role="system", content=content)

    @classmethod
    def user(cls, content: str) -> "LLMMessage":
        return cls(role="user", content=content)

    @classmethod
    def assistant(cls, content: str, tool_calls: list[ToolCall] | None = None) -> "LLMMessage":
        return cls(role="assistant", content=content, tool_calls=tool_calls or [])


@dataclass
class Usage:
    """Расход токенов для учёта бюджета."""

    prompt_tokens: int = 0
    completion_tokens: int = 0

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens


@dataclass
class LLMResponse:
    """Ответ провайдера в едином формате."""

    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    usage: Usage = field(default_factory=Usage)
    provider: str = ""
    model: str = ""
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def has_tool_calls(self) -> bool:
        return bool(self.tool_calls)


class BaseLLMProvider(abc.ABC):
    """
    Контракт LLM-провайдера.

    Подклассы обязаны задать ``name`` и реализовать ``complete``.
    ``is_available`` должен возвращать ``False``, если провайдер нельзя
    использовать (нет ключа / нет локального сервера) — роутер его пропустит.
    """

    name: str = "base"

    @abc.abstractmethod
    def is_available(self) -> bool:
        """Готов ли провайдер отвечать прямо сейчас (ключи/сервер на месте)."""

    @abc.abstractmethod
    async def complete(
        self,
        messages: list[LLMMessage],
        tools: list[dict[str, Any]] | None = None,
        *,
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> LLMResponse:
        """
        Отправить диалог и получить ответ.

        При недоступности обязан бросить ``ProviderUnavailable``;
        при прочих ошибках — ``ProviderError``.
        """
        raise NotImplementedError

    def describe(self) -> dict[str, Any]:
        """Краткое описание для панели (статус, модель)."""
        return {"name": self.name, "available": self.is_available()}
