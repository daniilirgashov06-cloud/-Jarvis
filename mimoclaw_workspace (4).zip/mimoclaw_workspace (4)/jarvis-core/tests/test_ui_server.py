"""
Проверка ui_server/app.py — протокол панели, состояние, рассылка, FastAPI/WS.

Запуск:  python3 tests/test_ui_server.py
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.event_bus import EventBus
from ui_server.app import (
    ClientMessage,
    PANEL_HTML,
    ProtocolError,
    UIServer,
    WSClient,
    encode_frame,
    parse_client_message,
)


# ---------------------------------------------------------------------------
# Фейки
# ---------------------------------------------------------------------------
class FakeClient:
    """WebSocket-клиент без сети: пишет кадры в список."""

    def __init__(self, name: str = "fake") -> None:
        self.name = name
        self.sent: list[str] = []

    async def send_text(self, data: str) -> None:
        self.sent.append(data)

    def frames(self) -> list[dict]:
        return [json.loads(f) for f in self.sent]


class FakeOrchestrator:
    """Мок оркестратора: эхо + опциональный сбой."""

    def __init__(self, fail: bool = False) -> None:
        self.fail = fail
        self.calls: list[str] = []

    async def process_text(self, user_text, history=None):
        self.calls.append(user_text)
        if self.fail:
            raise RuntimeError("llm недоступен")
        return {
            "ok": True,
            "text": f"принято: {user_text}",
            "actions": [{"name": "noop", "ok": True, "output": "ok", "error": None}],
            "provider": "fake",
            "tts": "fake",
        }


class BrokenClient:
    """Клиент, у которого send_text падает (отвалился сокет)."""

    async def send_text(self, data: str) -> None:
        raise ConnectionError("socket closed")


# ---------------------------------------------------------------------------
# Протокол
# ---------------------------------------------------------------------------
def test_protocol_parse() -> None:
    msg = parse_client_message('{"type": "text", "text": "  привет  "}')
    assert msg == ClientMessage(type="text", text="привет", topics=())
    assert parse_client_message('{"type": "ping"}').type == "ping"
    sub = parse_client_message('{"type": "subscribe", "topics": ["stt.*", "ui.*"]}')
    assert sub.topics == ("stt.*", "ui.*")
    assert parse_client_message('{"type": "status"}').topics == ()
    print("  ✓ протокол: валидные сообщения парсятся (text/ping/status/subscribe)")


def test_protocol_errors() -> None:
    for bad in ["", "   ", "{oops", "[1,2]", '{"type": "nuke"}', '{"type": "text"}',
                '{"type": "text", "text": ""}', '{"type": "text", "text": 42}',
                '{"type": "subscribe", "topics": "stt.*"}',
                '{"type": "subscribe", "topics": ["", 5]}']:
        try:
            parse_client_message(bad)
        except ProtocolError:
            continue
        raise AssertionError(f"должно быть ProtocolError для: {bad!r}")
    # лимит длины команды
    try:
        parse_client_message(json.dumps({"type": "text", "text": "я" * 10000}))
    except ProtocolError:
        pass
    else:
        raise AssertionError("слишком длинная команда должна отклоняться")
    print("  ✓ протокол: 10+ невалидных сообщений -> ProtocolError")


def test_encode_frame_unicode() -> None:
    frame = encode_frame({"type": "event", "topic": "ui.reply", "payload": {"text": "привет"}})
    assert "привет" in frame and json.loads(frame)["payload"]["text"] == "привет"
    print("  ✓ протокол: кадры сериализуются в UTF-8 JSON без эскейпов")


# ---------------------------------------------------------------------------
# Состояние панели
# ---------------------------------------------------------------------------
def test_panel_state() -> None:
    server = UIServer(orchestrator=None, bus=EventBus(), history_limit=3)
    st = server.state
    st.set_state("thinking")
    for i in range(5):
        st.record_event("stt.transcript", {"text": f"реплика {i}"})
    st.record_command()
    st.record_error()
    snap = st.snapshot()
    assert snap["state"] == "thinking"
    assert snap["history_size"] == 3, "лента должна быть ограничена history_limit"
    assert snap["counters"] == {"events": 5, "commands": 1, "errors": 1}
    recent = st.recent_events(10)
    assert len(recent) == 3 and recent[-1]["payload"]["text"] == "реплика 4"
    print("  ✓ состояние: статус, счётчики и кольцевая лента истории")


# ---------------------------------------------------------------------------
# Логика UIServer (async, без FastAPI)
# ---------------------------------------------------------------------------
async def test_text_flow_and_reply() -> None:
    bus = EventBus()
    orch = FakeOrchestrator()
    server = UIServer(orchestrator=orch, bus=bus)
    client = FakeClient("author")
    server.attach(client)

    frames = await server.handle_message('{"type": "text", "text": "поставь громкость 50"}', client)
    assert orch.calls == ["поставь громкость 50"]
    assert len(frames) == 1
    reply = json.loads(frames[0])
    assert reply["type"] == "reply" and reply["ok"] is True
    assert reply["text"] == "принято: поставь громкость 50"
    assert reply["actions"][0]["name"] == "noop" and reply["provider"] == "fake"
    # автор не получает дубль события, но история его видит
    assert client.sent == []
    topics = [e["topic"] for e in server.state.recent_events(10)]
    assert topics[-2:] == ["ui.command", "ui.reply"]
    assert server.state.last_reply.startswith("принято")
    print("  ✓ команды: text -> оркестратор -> reply-кадр + запись в ленту")


async def test_reply_broadcasts_to_other_clients() -> None:
    server = UIServer(orchestrator=FakeOrchestrator(), bus=EventBus())
    author = FakeClient("author")
    watcher = FakeClient("watcher")
    server.attach(author, topics=("ui.*",))
    server.attach(watcher, topics=("ui.*",))

    await server.handle_message('{"type": "text", "text": "тест"}', author)
    assert author.sent == [], "автору уходит reply-кадр, а не событие"
    assert [f["topic"] for f in watcher.frames()] == ["ui.command", "ui.reply"]
    print("  ✓ рассылка: реплика видна другим клиентам как событие ui.*")


async def test_bus_events_broadcast_with_filters() -> None:
    bus = EventBus()
    server = UIServer(orchestrator=None, bus=bus)
    all_client = FakeClient("all")
    stt_only = FakeClient("stt")
    server.attach(all_client, topics=("*",))
    server.attach(stt_only, topics=("stt.*",))

    await bus.publish("stt.transcript", {"text": "привет"})
    await bus.publish("wakeword.detected", {"word": "джарвис"})

    assert [f["topic"] for f in all_client.frames()] == [
        "stt.transcript", "wakeword.detected",
    ]
    assert [f["topic"] for f in stt_only.frames()] == ["stt.transcript"]
    assert [e["topic"] for e in server.state.recent_events(10)] == [
        "stt.transcript", "wakeword.detected",
    ]
    print("  ✓ шина: события ядра -> лента + фильтр подписок по топикам")


async def test_ui_events_not_reflected_from_bus() -> None:
    server = UIServer(orchestrator=None, bus=EventBus())
    client = FakeClient("echo")
    server.attach(client, topics=("*",))
    # служебные ui.* события не должны возвращаться через шину
    await server._on_bus_event("ui.reply", {"text": "сам себе"})
    assert client.sent == [], "ui.* не транслируются обратно"
    print("  ✓ шина: служебные события ui.* не зацикливаются")


async def test_protocol_error_and_orchestrator_failure() -> None:
    bus = EventBus()
    server = UIServer(orchestrator=FakeOrchestrator(fail=True), bus=bus)
    client = FakeClient("err")

    frames = await server.handle_message("{не json", client)
    err = json.loads(frames[0])
    assert err["type"] == "error" and "JSON" in err["message"]

    frames = await server.handle_message('{"type": "text", "text": "любая"}', client)
    reply = json.loads(frames[0])
    assert reply["type"] == "reply" and reply["ok"] is False
    assert "llm недоступен" in reply["error"]
    assert server.state.counters["errors"] >= 2
    print("  ✓ ошибки: битый JSON и падение оркестратора не роняют панель")


async def test_ping_status_subscribe_and_connect() -> None:
    server = UIServer(orchestrator=None, bus=EventBus())
    client = FakeClient("ctl")

    frames = await server.on_connect(client)
    assert json.loads(frames[0])["type"] == "status"
    assert json.loads(frames[1])["payload"]["events"] == []

    pong = json.loads((await server.handle_message('{"type": "ping"}', client))[0])
    assert pong["type"] == "pong" and "ts" in pong

    status = json.loads((await server.handle_message('{"type": "status"}', client))[0])
    assert status["state"]["state"] == "idle" and status["state"]["clients"] == 0

    server.attach(client, topics=("stt.transcript",))
    sub = json.loads(
        (await server.handle_message('{"type": "subscribe", "topics": ["ui.*"]}', client))[0]
    )
    assert sub["type"] == "subscribed" and sub["topics"] == ["ui.*"]
    status = json.loads((await server.handle_message('{"type": "status"}', client))[0])
    assert status["state"]["clients"] == 1
    print("  ✓ сервисные кадры: pong/status/subscribed/on_connect")


async def test_broadcast_survives_broken_client() -> None:
    server = UIServer(orchestrator=None, bus=EventBus())
    broken = BrokenClient()
    alive = FakeClient("alive")
    server.attach(broken, topics=("*",))
    server.attach(alive, topics=("*",))

    delivered = await server.broadcast(encode_frame({"type": "event", "topic": "x", "payload": {}}))
    assert delivered == 1 and len(alive.sent) == 1
    assert broken not in server.clients(), "отвалившийся клиент убирается"
    print("  ✓ рассылка: упавший сокет убирается, остальным доставка идёт")


async def test_process_text_without_orchestrator() -> None:
    server = UIServer(orchestrator=None, bus=EventBus())
    result = await server.process_text("привет")
    assert result["ok"] is False and "не подключён" in result["text"] and result["actions"] == []
    print("  ✓ режим эха: панель работает и без оркестратора")


# ---------------------------------------------------------------------------
# FastAPI + WebSocket (пропускается, если fastapi не установлен)
# ---------------------------------------------------------------------------
def test_fastapi_app() -> None:
    try:
        from fastapi.testclient import TestClient
        from ui_server.app import create_app
    except ImportError:
        print("  ⚠ fastapi не установлен — HTTP/WS-тесты пропущены")
        return

    server = UIServer(orchestrator=FakeOrchestrator(), bus=EventBus())
    client = TestClient(create_app(server))

    resp = client.get("/")
    assert resp.status_code == 200
    assert "Dashboard" in resp.text and "Голос" in resp.text and "JARVIS CORE" in resp.text

    resp = client.get("/api/status")
    assert resp.status_code == 200 and resp.json()["state"] == "idle"

    resp = client.post("/api/text", json={"text": "привет"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["ok"] is True and body["text"] == "принято: привет"
    assert [e["topic"] for e in client.get("/api/history").json()][-2:] == [
        "ui.command", "ui.reply",
    ]

    assert client.post("/api/text", json={"text": ""}).status_code == 422
    print("  ✓ fastapi: /, /api/status, /api/text, /api/history работают")


def test_fastapi_websocket() -> None:
    try:
        from fastapi.testclient import TestClient
        from ui_server.app import create_app
    except ImportError:
        print("  ⚠ fastapi не установлен — WS-тест пропущен")
        return

    server = UIServer(orchestrator=FakeOrchestrator(), bus=EventBus())
    client = TestClient(create_app(server))

    with client.websocket_connect("/ws") as ws:
        hello_status = json.loads(ws.receive_text())
        hello_history = json.loads(ws.receive_text())
        assert hello_status["type"] == "status" and hello_status["state"]["clients"] == 1
        assert hello_history["type"] == "event" and hello_history["topic"] == "ui.history"

        ws.send_text('{"type": "ping"}')
        assert json.loads(ws.receive_text())["type"] == "pong"

        ws.send_text("не json")
        assert json.loads(ws.receive_text())["type"] == "error"

        with client.websocket_connect("/ws") as watcher:
            json.loads(watcher.receive_text())  # status
            json.loads(watcher.receive_text())  # history
            watcher.send_text('{"type": "subscribe", "topics": ["ui.*"]}')
            assert json.loads(watcher.receive_text())["type"] == "subscribed"

            ws.send_text('{"type": "text", "text": "сделай что-нибудь"}')
            reply = json.loads(ws.receive_text())
            assert reply["type"] == "reply" and reply["text"] == "принято: сделай что-нибудь"

            ev1 = json.loads(watcher.receive_text())
            ev2 = json.loads(watcher.receive_text())
            assert [ev1["topic"], ev2["topic"]] == ["ui.command", "ui.reply"]

    print("  ✓ fastapi: WebSocket — hello/pong/error/reply + broadcast второму клиенту")


# ---------------------------------------------------------------------------
# Панель HTML
# ---------------------------------------------------------------------------
def test_panel_html_placeholders() -> None:
    assert "__ACCENT__" in PANEL_HTML and "__THEME__" in PANEL_HTML
    assert "/ws" in PANEL_HTML and "st-commands" in PANEL_HTML
    print("  ✓ панель: HTML-шаблон с плейсхолдерами темы и WS-логикой")


async def _run_async() -> None:
    await test_text_flow_and_reply()
    await test_reply_broadcasts_to_other_clients()
    await test_bus_events_broadcast_with_filters()
    await test_ui_events_not_reflected_from_bus()
    await test_protocol_error_and_orchestrator_failure()
    await test_ping_status_subscribe_and_connect()
    await test_broadcast_survives_broken_client()
    await test_process_text_without_orchestrator()


def main() -> int:
    print("JARVIS CORE — проверка ui_server/app.py")
    try:
        test_protocol_parse()
        test_protocol_errors()
        test_encode_frame_unicode()
        test_panel_state()
        asyncio.run(_run_async())
        test_fastapi_app()
        test_fastapi_websocket()
        test_panel_html_placeholders()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки ui_server прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
