"""
Аудит-лог действий JARVIS CORE (ТЗ-6.7).

Фиксирует, *кто*, *что* и *с каким решением* (подтверждено / отклонено /
выполнено / ошибка) делал с командами — особенно с MEDIUM/HIGH/FORBIDDEN.
Данные пишутся в JSONL-файл (одна строка = одно событие) и дублируются
в кольцевой буфер памяти для быстрых запросов панели/диагностики.

Принципы:
- **Приватность**: значения чувствительных полей (password, token, pin, key…)
  заменяются на ``***`` до записи — в лог не утекают секреты.
- **Деградация**: если путь недоступен/диск переполнен — работаем в память
  без падения приложения (``degraded=True``).
- **Потокобезопасность**: все записи под общим ``threading.Lock``.
- **Ротация**: при превышении ``max_bytes`` файл переименовывается в
  ``<name>.1`` … ``<name>.<keep>`` (старые удаляются).

Использование:
    audit = AuditLog(path="data/audit.jsonl")
    audit.record_command("shutdown", risk="high", decision="confirmed",
                         params={"delay": 10})
    audit.query(risk="high", limit=10)
"""

from __future__ import annotations

import json
import logging
import threading
import time
from collections import deque
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable

logger = logging.getLogger(__name__)

# Ключи, значения которых нельзя сохранять в открытом виде
SENSITIVE_KEYS: frozenset[str] = frozenset(
    {
        "password",
        "passwd",
        "pass",
        "pin",
        "pin_code",
        "token",
        "api_key",
        "apikey",
        "secret",
        "key",
        "private_key",
        "authorization",
        "credential",
        "credentials",
    }
)

REDACTED = "***"

# Допустимые решения (decision) — намеренно небольшой словарь
DECISIONS: frozenset[str] = frozenset(
    {"requested", "confirmed", "denied", "auto", "executed", "failed"}
)


def _is_sensitive(key: str) -> bool:
    """Проверяет, является ли ключ чувствительным (без учёта регистра/дефисов)."""
    normalized = key.strip().lower().replace("-", "_").replace(" ", "_")
    return normalized in SENSITIVE_KEYS


def redact(value: Any, *, _depth: int = 0) -> Any:
    """
    Рекурсивно маскирует чувствительные значения в структурах данных.

    Словари/списки обходятся до глубины 6, чтобы не зависнуть на циклах.
    Не-JSON-типы приводятся к строке.
    """
    if _depth > 6:
        return "<...>"
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for key, val in value.items():
            key_str = str(key)
            out[key_str] = REDACTED if _is_sensitive(key_str) else redact(val, _depth=_depth + 1)
        return out
    if isinstance(value, (list, tuple, set, frozenset)):
        return [redact(v, _depth=_depth + 1) for v in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


@dataclass
class AuditEvent:
    """Одна запись аудита."""

    action: str                      # имя команды / операции
    decision: str                    # requested/confirmed/denied/auto/executed/failed
    risk: str = "safe"               # уровень риска команды
    actor: str = "user"              # кто инициировал: user / llm / system
    params: dict[str, Any] = field(default_factory=dict)   # аргументы (с маскированием)
    detail: str = ""                 # свободный комментарий / текст ошибки
    ts: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        if self.decision not in DECISIONS:
            raise ValueError(
                f"Недопустимое решение '{self.decision}', ожидается одно из {sorted(DECISIONS)}"
            )
        self.params = dict(redact(self.params))

    def to_dict(self) -> dict[str, Any]:
        """Сериализует событие в JSON-совместимый словарь."""
        return asdict(self)

    def to_json(self) -> str:
        """Сериализует событие в одну строку JSON."""
        return json.dumps(self.to_dict(), ensure_ascii=False)


class AuditLog:
    """
    Аудит-лог: JSONL-файл + кольцевой буфер в памяти.

    - ``memory_only=True`` — только память (для тестов/офлайн-режима).
    - при ошибке записи файл автоматически переводится в ``degraded``-режим
      (только память), приложение не падает.
    """

    def __init__(
        self,
        path: str | Path | None = None,
        *,
        max_bytes: int = 5 * 1024 * 1024,
        keep: int = 3,
        memory_size: int = 500,
    ) -> None:
        self._path = Path(path) if path is not None else None
        self._max_bytes = max(1024, int(max_bytes))
        self._keep = max(0, int(keep))
        self._memory: deque[AuditEvent] = deque(maxlen=max(1, int(memory_size)))
        self._lock = threading.Lock()
        self._degraded = False
        self._total = 0

        if self._path is not None:
            try:
                self._path.parent.mkdir(parents=True, exist_ok=True)
            except OSError as exc:
                # Папку создать не вышло — живём в памяти, но честно сообщаем.
                logger.warning("Аудит-лог переключён в память: %s", exc)
                self._degraded = True

    # ------------------------------------------------------------------
    # Свойства
    # ------------------------------------------------------------------
    @property
    def path(self) -> Path | None:
        return self._path

    @property
    def degraded(self) -> bool:
        """True, если файловая запись недоступна и события пишутся в память."""
        return self._degraded

    @property
    def total(self) -> int:
        """Сколько событий записано за жизнь объекта."""
        return self._total

    # ------------------------------------------------------------------
    # Запись
    # ------------------------------------------------------------------
    def record(
        self,
        action: str,
        decision: str,
        *,
        risk: str = "safe",
        actor: str = "user",
        params: dict[str, Any] | None = None,
        detail: str = "",
    ) -> AuditEvent:
        """
        Записывает событие аудита. Возвращает созданное событие.

        Ошибки ввода (пустое имя, недопустимое решение) поднимают ValueError;
        ошибки файла не прерывают работу — событие остаётся в памяти.
        """
        if not action or not str(action).strip():
            raise ValueError("Имя действия (action) не может быть пустым")
        event = AuditEvent(
            action=str(action).strip(),
            decision=decision,
            risk=str(risk).strip().lower() or "safe",
            actor=str(actor).strip().lower() or "user",
            params=dict(params or {}),
            detail=str(detail),
        )
        with self._lock:
            self._total += 1
            self._memory.append(event)
            if self._path is not None and not self._degraded:
                self._write_line(event)
        return event

    def record_command(
        self,
        command: str,
        *,
        decision: str,
        risk: str = "safe",
        actor: str = "user",
        params: dict[str, Any] | None = None,
        detail: str = "",
    ) -> AuditEvent:
        """Удобная запись события выполнения команды (синоним ``record``)."""
        return self.record(
            command,
            decision,
            risk=risk,
            actor=actor,
            params=params,
            detail=detail,
        )

    def _write_line(self, event: AuditEvent) -> None:
        """Пишет строку JSONL в файл (вызывается под блокировкой)."""
        assert self._path is not None
        try:
            line = event.to_json() + "\n"
            with self._path.open("a", encoding="utf-8") as fh:
                fh.write(line)
            self._rotate_if_needed()
        except OSError as exc:
            # Диск переполнен / правa / путь превратился в папку — не роняем работу.
            logger.warning("Аудит-лог переключён в память, файл недоступен: %s", exc)
            self._degraded = True

    def _rotate_if_needed(self) -> None:
        """Ротация JSONL-файла при превышении max_bytes (вызывается под блокировкой)."""
        assert self._path is not None
        try:
            if self._path.stat().st_size < self._max_bytes:
                return
            if self._keep == 0:
                # Бэкапы не нужны — просто обнуляем файл.
                self._path.write_text("", encoding="utf-8")
                return
            # Сдвигаем бэкапы: .keep удаляется, .N → .N+1, файл → .1
            for index in range(self._keep, 0, -1):
                src = self._path.with_name(f"{self._path.name}.{index}")
                if index == self._keep:
                    src.unlink(missing_ok=True)
                elif src.exists():
                    src.rename(self._path.with_name(f"{self._path.name}.{index + 1}"))
            self._path.rename(self._path.with_name(f"{self._path.name}.1"))
            # Пересоздаём текущий файл пустым, чтобы записи/чтение не пропадали.
            self._path.touch()
        except OSError as exc:
            logger.warning("Ротация аудит-лога не удалась: %s", exc)

    # ------------------------------------------------------------------
    # Чтение / запросы
    # ------------------------------------------------------------------
    def recent(self, limit: int = 50) -> list[AuditEvent]:
        """Последние события из памяти (от старых к новым)."""
        with self._lock:
            items = list(self._memory)
        return items[-max(1, int(limit)):]

    def query(
        self,
        *,
        action: str | None = None,
        decision: str | None = None,
        risk: str | None = None,
        actor: str | None = None,
        since: float | None = None,
        limit: int = 50,
    ) -> list[AuditEvent]:
        """
        Выборка событий из памяти по фильтрам (все условия — И).

        ``since`` — UNIX-время начала интервала.
        """
        results: list[AuditEvent] = []
        for event in self.recent(limit=max(limit, 1)):
            if action is not None and event.action != action:
                continue
            if decision is not None and event.decision != decision:
                continue
            if risk is not None and event.risk != risk:
                continue
            if actor is not None and event.actor != actor:
                continue
            if since is not None and event.ts < since:
                continue
            results.append(event)
        return results[-max(1, int(limit)):]

    def read_file(self, limit: int | None = None) -> list[dict[str, Any]]:
        """
        Читает события из JSONL-файла (все ротации не трогаем — только текущий).

        Битые строки пропускаются с предупреждением. Если файловая запись
        недоступна — возвращается пустой список.
        """
        if self._path is None or not self._path.exists():
            return []
        events: list[dict[str, Any]] = []
        try:
            with self._path.open("r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        events.append(json.loads(line))
                    except json.JSONDecodeError:
                        logger.warning("Пропущена битая строка аудит-лога")
        except OSError as exc:
            logger.warning("Не удалось прочитать аудит-лог: %s", exc)
            return []
        return events if limit is None else events[-max(1, int(limit)):]

    def export(self, path: str | Path) -> int:
        """
        Экспортирует содержимое файла аудита в новый JSONL-файл.

        Возвращает число экспортированных событий.
        """
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        rows: Iterable[dict[str, Any]] = self.read_file()
        count = 0
        with target.open("w", encoding="utf-8") as fh:
            for row in rows:
                fh.write(json.dumps(row, ensure_ascii=False) + "\n")
                count += 1
        return count

    def clear(self) -> None:
        """Очищает память и (если доступен) файл аудита."""
        with self._lock:
            self._memory.clear()
            self._total = 0
            if self._path is not None and not self._degraded:
                try:
                    self._path.write_text("", encoding="utf-8")
                except OSError as exc:
                    logger.warning("Не удалось очистить файл аудита: %s", exc)
                    self._degraded = True
