"""
Облачный LLM-провайдер OpenAI (GPT-4o, GPT-4o-mini).

Чат-комплишн через ``/v1/chat/completions`` с поддержкой function calling.
Совместим и с любым OpenAI-совместимым эндпоинтом (через ``base_url``),
включая OpenRouter и локальные прокси.
"""

from __future__ import annotations

import json
from typing import Any

from .base import (
    BaseLLMProvider,
    LLMMessage,
    LLMResponse,
    ProviderError,
    ProviderUnavailable,
    ToolCall,
    Usage,
)

DEFAULT_BASE_URL = "https://api.openai.com/v1"


class OpenAIProvider(BaseLLMProvider):
    """Провайдер OpenAI / OpenAI-совместимых API."""

    name = "openai"

    def __init__(
        self,
        model: str = "gpt-4o-mini",
        api_key: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 60.0,
    ) -> None:
        self.model = model
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def is_available(self) -> bool:
        return bool(self.api_key)

    async def complete(
        self,
        messages: list[LLMMessage],
        tools: list[dict[str, Any]] | None = None,
        *,
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> LLMResponse:
        if not self.api_key:
            raise ProviderUnavailable("OpenAI: не задан API-ключ")
        try:
            import httpx
        except ImportError as exc:  # pragma: no cover
            raise ProviderUnavailable("httpx не установлен") from exc

        payload: dict[str, Any] = {
            "model": self.model,
            "messages": self._to_openai_messages(messages),
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(
                    f"{self.base_url}/chat/completions",
                    json=payload,
                    headers={"Authorization": f"Bearer {self.api_key}"},
                )
        except Exception as exc:  # noqa: BLE001
            raise ProviderUnavailable(f"OpenAI недоступен: {exc}") from exc

        if resp.status_code in (401, 403):
            raise ProviderUnavailable(f"OpenAI: авторизация отклонена ({resp.status_code})")
        if resp.status_code != 200:
            raise ProviderError(f"OpenAI HTTP {resp.status_code}: {resp.text[:200]}")

        data = resp.json()
        choice = (data.get("choices") or [{}])[0]
        msg = choice.get("message", {}) or {}
        usage = Usage(
            prompt_tokens=int(data.get("usage", {}).get("prompt_tokens", 0) or 0),
            completion_tokens=int(data.get("usage", {}).get("completion_tokens", 0) or 0),
        )
        return LLMResponse(
            content=msg.get("content", "") or "",
            tool_calls=self._parse_tool_calls(msg.get("tool_calls")),
            usage=usage,
            provider=self.name,
            model=self.model,
            raw=data,
        )

    # -- конвертация --------------------------------------------------------
    @staticmethod
    def _to_openai_messages(messages: list[LLMMessage]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for m in messages:
            if m.role == "tool":
                out.append(
                    {
                        "role": "tool",
                        "tool_call_id": m.tool_call_id or "",
                        "content": m.content,
                    }
                )
                continue
            item: dict[str, Any] = {"role": m.role, "content": m.content}
            if m.tool_calls:
                item["tool_calls"] = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.name,
                            "arguments": json.dumps(tc.arguments, ensure_ascii=False),
                        },
                    }
                    for tc in m.tool_calls
                ]
            out.append(item)
        return out

    @staticmethod
    def _parse_tool_calls(raw: Any) -> list[ToolCall]:
        calls: list[ToolCall] = []
        for tc in raw or []:
            fn = tc.get("function", {}) if isinstance(tc, dict) else {}
            args = fn.get("arguments", "{}") or "{}"
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {}
            calls.append(ToolCall(id=tc.get("id", ""), name=fn.get("name", ""), arguments=args))
        return calls

    def describe(self) -> dict[str, Any]:
        return {**super().describe(), "model": self.model}
