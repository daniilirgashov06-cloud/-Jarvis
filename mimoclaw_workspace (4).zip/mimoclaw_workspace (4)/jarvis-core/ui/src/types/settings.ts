/**
 * Схема настроек JARVIS CORE — зеркало `config/settings.py` (Pydantic).
 *
 * Имена секций и полей совпадают с бэкендом 1-в-1, чтобы REST
 * GET/PUT `/api/settings` работал без адаптеров.
 * Секреты (api_key, token, pin) в UI не отображаются и не редактируются:
 * они читаются из окружения / `.env` и никогда не пишутся в YAML.
 */

export type PrivacyMode = "normal" | "incognito" | "local";
export type MicMode = "always" | "wakeword" | "push" | "muted";

export interface CoreConfig {
  user_name: string;
  language: string;
  persona: string;
  privacy_mode: PrivacyMode;
  offline_only: boolean;
  data_dir: string;
}

export interface AudioConfig {
  sample_rate: number;
  channels: number;
  frame_ms: number;
  input_device: string | number | null;
  output_device: string | number | null;
  mic_mode: MicMode;
  agc: boolean;
  noise_suppression: boolean;
  vad_threshold: number;
  silence_ms: number;
  sfx_volume: number;
  speech_volume: number;
  interrupt_user: boolean;
}

export interface WakeWordConfig {
  enabled: boolean;
  words: string[];
  custom_word: string;
  confidence: number;
  clap_enabled: boolean;
  clap_rms_threshold: number;
  clap_gap_ms_min: number;
  clap_gap_ms_max: number;
  clap_double: boolean;
  stop_phrases: string[];
}

export interface STTConfig {
  engine: string;
  model: string;
  language: string;
  auto_punctuate: boolean;
}

export interface TTSConfig {
  engine: string;
  voice: string;
  speed: number;
  pitch: number;
  effects: string[];
}

export interface LLMProviderConfig {
  enabled: boolean;
  model: string;
  base_url: string | null;
  temperature: number;
  max_tokens: number;
}

export interface AIConfig {
  primary: string;
  fallback_chain: string[];
  openai: LLMProviderConfig;
  anthropic: LLMProviderConfig;
  gemini: LLMProviderConfig;
  ollama: LLMProviderConfig;
  daily_token_limit: number;
  daily_spend_limit_usd: number;
}

export interface VisionConfig {
  enabled: boolean;
  screen_awareness: boolean;
  awareness_interval_s: number;
  capture_fps: number;
  ocr_language: string;
  store_screenshots: boolean;
  retention_days: number;
  mask_passwords: boolean;
}

export interface MemoryConfig {
  enabled: boolean;
  sqlite_path: string;
  chroma_path: string;
  embedding_model: string;
  summarize_every_messages: number;
  rag_top_k: number;
  context_messages: number;
}

export interface TelegramConfig {
  enabled: boolean;
  chat_id: string | null;
  access_level: "full" | "view" | "notify" | string;
  require_pin_for_high: boolean;
  notify_errors: boolean;
}

export interface SecurityConfig {
  require_confirmation_medium: boolean;
  pin_for_high: boolean;
  audit_log: boolean;
  allow_shell_scripts: boolean;
  whitelist_paths: string[];
  forbidden_paths: string[];
}

export interface UIConfig {
  theme: "jarvis" | "friday" | "custom" | string;
  accent_color: string;
  transparency: number;
  overlay_enabled: boolean;
  boot_animation: boolean;
  show_subtitles: boolean;
}

export interface FunConfig {
  easter_eggs: boolean;
  greetings: boolean;
  emotional_tone: boolean;
  mode: "normal" | "stealth" | "focus" | "party" | "alarm" | string;
}

export interface LoggingConfig {
  level: "DEBUG" | "INFO" | "WARNING" | "ERROR" | string;
  dir: string;
  rotation: string;
  retention: string;
}

export interface Settings {
  core: CoreConfig;
  audio: AudioConfig;
  wakeword: WakeWordConfig;
  stt: STTConfig;
  tts: TTSConfig;
  ai: AIConfig;
  vision: VisionConfig;
  memory: MemoryConfig;
  telegram: TelegramConfig;
  security: SecurityConfig;
  ui: UIConfig;
  fun: FunConfig;
  logging: LoggingConfig;
}

export type SettingsSection = keyof Settings;

/** Дефолты зеркалят значения по умолчанию из `config/settings.py`. */
export const DEFAULT_SETTINGS: Settings = {
  core: {
    user_name: "сэр",
    language: "ru",
    persona: "jarvis",
    privacy_mode: "normal",
    offline_only: false,
    data_dir: "data",
  },
  audio: {
    sample_rate: 16000,
    channels: 1,
    frame_ms: 20,
    input_device: null,
    output_device: null,
    mic_mode: "wakeword",
    agc: true,
    noise_suppression: true,
    vad_threshold: 0.5,
    silence_ms: 1200,
    sfx_volume: 0.7,
    speech_volume: 1.0,
    interrupt_user: false,
  },
  wakeword: {
    enabled: true,
    words: ["джарвис", "jarvis", "пятница", "friday"],
    custom_word: "",
    confidence: 0.5,
    clap_enabled: true,
    clap_rms_threshold: 0.35,
    clap_gap_ms_min: 150,
    clap_gap_ms_max: 450,
    clap_double: true,
    stop_phrases: ["хватит", "отбой", "замолчи", "стоп", "отмена"],
  },
  stt: {
    engine: "faster_whisper",
    model: "large-v3",
    language: "auto",
    auto_punctuate: true,
  },
  tts: {
    engine: "local",
    voice: "jarvis",
    speed: 0.96,
    pitch: 0.0,
    effects: ["eq_british", "subtle_reverb", "radio_clarity"],
  },
  ai: {
    primary: "ollama",
    fallback_chain: ["ollama", "openai", "anthropic"],
    openai: { enabled: false, model: "gpt-4o-mini", base_url: null, temperature: 0.7, max_tokens: 2048 },
    anthropic: { enabled: false, model: "claude-3-5-sonnet-latest", base_url: null, temperature: 0.7, max_tokens: 2048 },
    gemini: { enabled: false, model: "gemini-1.5-pro", base_url: null, temperature: 0.7, max_tokens: 2048 },
    ollama: { enabled: true, model: "llama3", base_url: null, temperature: 0.7, max_tokens: 2048 },
    daily_token_limit: 0,
    daily_spend_limit_usd: 0,
  },
  vision: {
    enabled: true,
    screen_awareness: false,
    awareness_interval_s: 60,
    capture_fps: 2,
    ocr_language: "rus+eng",
    store_screenshots: false,
    retention_days: 7,
    mask_passwords: true,
  },
  memory: {
    enabled: true,
    sqlite_path: "data/jarvis.db",
    chroma_path: "data/chroma",
    embedding_model: "sentence-transformers/all-MiniLM-L6-v2",
    summarize_every_messages: 30,
    rag_top_k: 8,
    context_messages: 20,
  },
  telegram: {
    enabled: false,
    chat_id: null,
    access_level: "view",
    require_pin_for_high: true,
    notify_errors: true,
  },
  security: {
    require_confirmation_medium: true,
    pin_for_high: true,
    audit_log: true,
    allow_shell_scripts: false,
    whitelist_paths: [],
    forbidden_paths: ["C:\\Windows", "C:\\Program Files"],
  },
  ui: {
    theme: "jarvis",
    accent_color: "#00E5FF",
    transparency: 0.85,
    overlay_enabled: true,
    boot_animation: true,
    show_subtitles: true,
  },
  fun: {
    easter_eggs: true,
    greetings: true,
    emotional_tone: true,
    mode: "normal",
  },
  logging: {
    level: "INFO",
    dir: "data/logs",
    rotation: "10 MB",
    retention: "30 days",
  },
};
