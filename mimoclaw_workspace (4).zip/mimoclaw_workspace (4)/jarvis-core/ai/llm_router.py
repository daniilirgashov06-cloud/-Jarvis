"""
Роутер LLM — единый интерфейс к провайдерам JARVIS CORE.

Реализует выбор провайдера, **живую смену** (локально ↔ облако) и
**fallback-цепочку**: если основной провайдер недоступен или упал —
автоматически переходим к следующему. Учитывает расход токенов/бюджет.

Использование:
    router = LLMRouter.from_config(cfg.ai)
    await router.set_primary("ollama")          # локально
    await router.set_primary("openai")          # смена на облако
    resp = await router.ask([LLMMessage.user("привет")], tools=...)
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from .providers import (
    AnthropicProvider,
    BaseLLMProvider,
    GeminiProvider,
    LLMMessage,
    LLMResponse,
    OllamaProvider,
    OpenAIProvider,
    ProviderError,
    ProviderUnavailable,
    Usage,
)

logger = logging.getLogger(__name__)

# Ориентировочная цена за 1K токенов (USD) для учёта бюджета (обновляется вручную).
PRICE_PER_1K: dict[str, dict[str, float]] = {
    "openai": {"input": 0.0005, "output": 0.0015},
    "anthropic": {"input": 0.003, "output": 0.015},
    "gemini": {"input": 0.00125, "output": 0.005},
    "ollama": {"input": 0.0, "output": 0.0},  # локально — бесплатно
}


@dataclass
class BudgetStats:
    """Накопленный расход за сессию/день."""

    total_prompt_tokens: int = 0
    total_completion_tokens: int = 0
    total_cost_usd: float = 0.0
    calls: int = 0
    started_at: float = field(default_factory=time.time)

    def add(self, provider: str, usage: Usage) -> None:
        self.total_prompt_tokens += usage.prompt_tokens
        self.total_completion_tokens += usage.completion_tokens
        self.calls += 1
        price = PRICE_PER_1K.get(provider, {"input": 0.0, "output": 0.0})
        self.total_cost_usd += (
            usage.prompt_tokens / 1000 * price["input"]
            + usage.completion_tokens / 1000 * price["output"]
        )

    @property
    def total_tokens(self) -> int:
        return self.total_prompt_tokens + self.total_completion_tokens


class LLMRouter:
    """Маршрутизирует запросы к провайдерам с переключением и fallback."""

    def __init__(
        self,
        providers: dict[str, BaseLLMProvider] | None = None,
        primary: str = "ollama",
        fallback_chain: list[str] | None = None,
        offline_only: bool = False,
    ) -> None:
        self._providers: dict[str, BaseLLMProvider] = providers or {}
        self._primary = primary
        self._fallback_chain = fallback_chain or [primary]
        self.offline_only = offline_only
        self.budget = BudgetStats()
        self.daily_token_limit = 0
        self.daily_spend_limit_usd = 0.0

    # -- фабрика из конфига --------------------------------------------------
    @classmethod
    def from_config(cls, ai_cfg: Any) -> "LLMRouter":
        """
        Собирает роутер из ``config.settings.AIConfig``.

        Провайдеры создаются всегда; доступность определяется ключами/сервером
        в рантайме (``is_available``), поэтому смена работает «на лету».
        """
        providers: dict[str, BaseLLMProvider] = {
            "ollama": OllamaProvider(
                model=ai_cfg.ollama.model,
                base_url=ai_cfg.ollama.base_url or "http://localhost:11434",
            ),
            "openai": OpenAIProvider(
                model=ai_cfg.openai.model,
                api_key=_secret_str(ai_cfg.openai.api_key),
                base_url=ai_cfg.openai.base_url or "https://api.openai.com/v1",
            ),
            "anthropic": AnthropicProvider(
                model=ai_cfg.anthropic.model,
                api_key=_secret_str(ai_cfg.anthropic.api_key),
                base_url=ai_cfg.anthropic.base_url or "https://api.anthropic.com",
            ),
            "gemini": GeminiProvider(
                model=ai_cfg.gemini.model,
                api_key=_secret_str(ai_cfg.gemini.api_key),
                base_url=ai_cfg.gemini.base_url
                or "https://generativelanguage.googleapis.com/v1beta",
            ),
        }
        router = cls(
            providers=providers,
            primary=ai_cfg.primary,
            fallback_chain=list(ai_cfg.fallback_chain),
        )
        router.daily_token_limit = ai_cfg.daily_token_limit
        router.daily_spend_limit_usd = ai_cfg.daily_spend_limit_usd
        return router

    # -- управление провайдерами --------------------------------------------
    @property
    def primary(self) -> str:
        return self._primary

    def register(self, provider: BaseLLMProvider) -> None:
        """Добавить/заменить провайдера."""
        self._providers[provider.name] = provider

    async def set_primary(self, name: str) -> None:
        """Сменить основного провайдера (локально ↔ облако)."""
        if name not in self._providers:
            raise ProviderError(f"Неизвестный провайдер: {name}")
        self._primary = name
        # Ставим нового основного в начало цепочки fallback
        self._fallback_chain = [name] + [
            p for p in self._fallback_chain if p != name
        ]
        logger.info("Основной LLM-провайдер переключён на '%s'", name)

    def available_providers(self) -> list[str]:
        """Список провайдеров, готовых отвечать прямо сейчас."""
        return [n for n, p in self._providers.items() if p.is_available()]

    def provider_status(self) -> list[dict[str, Any]]:
        """Статусы для панели."""
        out = []
        for name, p in self._providers.items():
            info = p.describe()
            info["is_primary"] = name == self._primary
            out.append(info)
        return out

    # -- основной запрос ------------------------------------------------------
    def _within_budget(self) -> bool:
        if self.daily_token_limit and self.budget.total_tokens >= self.daily_token_limit:
            return False
        if (
            self.daily_spend_limit_usd
            and self.budget.total_cost_usd >= self.daily_spend_limit_usd
        ):
            return False
        return True

    def _candidate_chain(self, explicit: str | None) -> list[str]:
        if explicit:
            return [explicit]
        chain = [self._primary] + [p for p in self._fallback_chain if p != self._primary]
        chain += [p for p in self._providers if p not in chain]  # все зарегистрированные
        if self.offline_only:
            # В локальном режиме — только локальные провайдеры
            chain = [n for n in chain if n == "ollama"] or ["ollama"]
        return chain

    async def ask(
        self,
        messages: list[LLMMessage],
        tools: list[dict[str, Any]] | None = None,
        *,
        provider: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> LLMResponse:
        """
        Отправить диалог. Проходит по цепочке провайдеров, пока кто-то не ответит.

        ``provider`` — явно указать провайдера (без fallback), если нужно.
        """
        if not self._within_budget():
            raise ProviderError("Достигнут дневной лимит токенов/расхода")

        chain = self._candidate_chain(provider)
        last_error: Exception | None = None
        for name in chain:
            prov = self._providers.get(name)
            if prov is None:
                continue
            if not prov.is_available():
                logger.debug("Провайдер '%s' недоступен, пробуем следующий", name)
                last_error = ProviderUnavailable(f"{name}: недоступен")
                continue
            try:
                resp = await prov.complete(
                    messages,
                    tools,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                self.budget.add(name, resp.usage)
                return resp
            except ProviderUnavailable as exc:
                logger.warning("Провайдер '%s' выпал из цепочки: %s", name, exc)
                last_error = exc
                continue
            except ProviderError as exc:
                logger.warning("Ошибка провайдера '%s': %s", name, exc)
                last_error = exc
                continue

        raise ProviderError(f"Ни один провайдер не ответил. Последняя ошибка: {last_error}")

    def budget_snapshot(self) -> dict[str, Any]:
        """Срез расхода для панели."""
        return {
            "calls": self.budget.calls,
            "prompt_tokens": self.budget.total_prompt_tokens,
            "completion_tokens": self.budget.total_completion_tokens,
            "total_tokens": self.budget.total_tokens,
            "cost_usd": round(self.budget.total_cost_usd, 6),
        }


def _secret_str(val: Any) -> str | None:
    """Достаёт строку из SecretStr/pydantic-поля или возвращает None."""
    if val is None:
        return None
    if hasattr(val, "get_secret_value"):
        return val.get_secret_value()
    return str(val)
