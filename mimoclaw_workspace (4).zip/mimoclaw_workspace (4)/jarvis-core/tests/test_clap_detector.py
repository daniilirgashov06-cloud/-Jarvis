"""
Проверка модуля audio/clap_detector: конфиг, признаки (RMS/ZCR/спектр),
движок SpectralClapEngine, роутер с fallback, потоковая детекция событий.

Запуск:  python3 tests/test_clap_detector.py
"""

from __future__ import annotations

import math
import random
import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from audio.clap_detector import (
    ClapConfig,
    ClapDetector,
    ClapEngine,
    ClapError,
    ClapEvent,
    ClapFeatures,
    ClapResult,
    ClapRouter,
    ClapUnavailable,
    SpectralClapEngine,
    compute_features,
    create_default_router,
    rms_db,
    spectral_flatness,
    zero_crossing_rate,
)


# ---------------------------------------------------------------------------
# Хелперы синтеза PCM (s16le, 16 кГц, моно)
# ---------------------------------------------------------------------------
SR = 16000


def silence_ms(duration_ms: int = 100) -> bytes:
    return b"\x00\x00" * (SR * duration_ms // 1000)


def tone_ms(
    duration_ms: int = 100, freq: float = 440.0, amplitude: float = 0.5
) -> bytes:
    """Чистый тон — «не хлопок»: низкий ZCR, низкая спектральная плоскость."""
    total = SR * duration_ms // 1000
    out = bytearray()
    for i in range(total):
        s = amplitude * 32767.0 * math.sin(2.0 * math.pi * freq * i / SR)
        out += struct.pack("<h", int(s))
    return bytes(out)


def noise_ms(duration_ms: int = 20, amplitude: float = 0.9, seed: int = 7) -> bytes:
    """Белый шум — модель хлопка: широкополосный, высокий ZCR и плоскость."""
    rng = random.Random(seed)
    total = SR * duration_ms // 1000
    out = bytearray()
    for _ in range(total):
        s = amplitude * 32767.0 * rng.uniform(-1.0, 1.0)
        out += struct.pack("<h", int(s))
    return bytes(out)


def frames(pcm: bytes, frame_bytes: int = 640) -> list[bytes]:
    """Разбить PCM на кадры (неполный хвост дополняется тишиной)."""
    out = [pcm[i : i + frame_bytes] for i in range(0, len(pcm), frame_bytes)]
    if out and len(out[-1]) < frame_bytes:
        out[-1] = out[-1] + b"\x00" * (frame_bytes - len(out[-1]))
    return out


# ---------------------------------------------------------------------------
def test_config_geometry_and_validation() -> None:
    cfg = ClapConfig()
    assert cfg.frame_samples == 320, f"frame_samples={cfg.frame_samples}"
    assert cfg.frame_bytes == 640, f"frame_bytes={cfg.frame_bytes}"
    assert cfg.ms_to_frames(350) == 18, f"ms_to_frames={cfg.ms_to_frames(350)}"
    assert cfg.ms_to_frames(5) == 1

    for bad in (
        {"sample_rate": 0},
        {"frame_ms": -1},
        {"zcr_min": 1.5},
        {"flatness_min": -0.1},
        {"score_threshold": 2.0},
        {"cooldown_ms": -10},
        {"double_window_ms": -1},
    ):
        try:
            ClapConfig(**bad)
        except ValueError:
            continue
        raise AssertionError(f"ClapConfig(**{bad}) должен был бросить ValueError")

    print("  ✓ конфиг: геометрия кадра + валидация параметров")


# ---------------------------------------------------------------------------
def test_feature_primitives() -> None:
    # Тишина → −120 дБ, ZCR = 0, плоскость не определена по-хорошему,
    # но DFT от нуля даёт ~1.0 — проверим только ключевые случаи.
    assert rms_db([0] * 100) == -120.0, "тишина должна давать −120 дБ"
    assert zero_crossing_rate([0] * 100) == 0.0
    assert abs(rms_db([32767] * 100)) < 0.01, "полная шкала ≈ 0 дБФС"

    # Синус 440 Гц: ZCR ≈ 2·f/sr = 0.055.
    sine = [int(0.5 * 32767 * math.sin(2 * math.pi * 440 * i / SR)) for i in range(320)]
    z = zero_crossing_rate(sine)
    assert abs(z - 0.055) < 0.02, f"ZCR синуса={z:.3f} (ожидалось ~0.055)"

    # Шум: ZCR заметно выше, плоскость спектра выше, чем у тона.
    noise = [int(random.Random(3).uniform(-20000, 20000)) for _ in range(256)]
    flat_noise = spectral_flatness(noise)
    flat_sine = spectral_flatness(sine)
    assert flat_noise > flat_sine, f"плоскость шума {flat_noise:.3f} ≤ тона {flat_sine:.3f}"
    assert 0.0 < flat_noise <= 1.0 and 0.0 <= flat_sine <= 1.0

    feats = compute_features(b"\x00\x00" * 40)
    assert isinstance(feats, ClapFeatures) and feats.rms_db == -120.0

    for bad in (b"", b"\x00", [1, 2, 3]):
        try:
            compute_features(bad)
        except ClapError:
            continue
        raise AssertionError(f"compute_features({bad!r}) должен был бросить ClapError")

    print("  ✓ признаки: RMS-дБ, ZCR синуса, плоскость шум > тон, ошибки")


# ---------------------------------------------------------------------------
def test_spectral_engine_decisions() -> None:
    eng = SpectralClapEngine()
    assert eng.is_available() and eng.name == "spectral"

    clap = eng.detect(noise_ms(20), sample_rate=SR)
    assert clap.detected, f"хлопок (шум) не распознан: score={clap.score:.2f}"
    assert clap.score > 0.5 and clap.features is not None

    tone = eng.detect(tone_ms(20), sample_rate=SR)
    assert not tone.detected, f"тон принят за хлопок: score={tone.score:.2f}"

    quiet = eng.detect(noise_ms(20, amplitude=0.01), sample_rate=SR)
    assert not quiet.detected, "тихий шум принят за хлопок"

    # Требование атаки: устойчивый шум после громкого кадра — не хлопок.
    sustained = eng.detect(
        noise_ms(20, seed=11), sample_rate=SR, prev_rms_db=-3.0
    )
    assert not sustained.detected, "устойчивый шум без атаки принят за хлопок"

    for bad in (b"", b"\x00"):
        try:
            eng.detect(bad, sample_rate=SR)
        except ClapError:
            continue
        raise AssertionError(f"detect({bad!r}) должен был бросить ClapError")

    print("  ✓ движок: хлопок ✓ / тон ✗ / тихий шум ✗ / без атаки ✗")


# ---------------------------------------------------------------------------
def test_router_fallback_and_switch() -> None:
    class Broken(ClapEngine):
        name = "broken"

        def is_available(self) -> bool:
            return True

        def detect(self, pcm: bytes, *, sample_rate: int = 16000) -> ClapResult:
            raise ClapError("движок сломан")

    class Unavailable(ClapEngine):
        name = "missing"

        def is_available(self) -> bool:
            return False

        def detect(self, pcm: bytes, *, sample_rate: int = 16000) -> ClapResult:
            raise ClapUnavailable("нет библиотеки")

    router = ClapRouter(
        engines={
            "broken": Broken(),
            "missing": Unavailable(),
            "spectral": SpectralClapEngine(),
        },
        primary="broken",
        fallback_chain=["missing", "broken", "spectral"],
    )
    assert router.primary == "broken"
    assert router.available() == ["broken", "spectral"], router.available()

    res = router.detect(noise_ms(20))
    assert res.detected and res.engine == "spectral", "fallback не дошёл до spectral"

    router.set_primary("spectral")
    assert router.primary == "spectral"
    forced = router.detect(noise_ms(20), engine="spectral")
    assert forced.engine == "spectral"

    try:
        router.set_primary("nope")
    except ClapUnavailable:
        pass
    else:
        raise AssertionError("set_primary('nope') должен был бросить ClapUnavailable")

    dead = ClapRouter(engines={"broken": Broken()}, primary="broken",
                      fallback_chain=["broken"])
    try:
        dead.detect(noise_ms(20))
    except ClapUnavailable:
        pass
    else:
        raise AssertionError("все движки сломаны → ClapUnavailable")

    print("  ✓ роутер: fallback broken→spectral, смена движка, отказ всех")


# ---------------------------------------------------------------------------
def test_detector_events_cooldown_and_double() -> None:
    det = ClapDetector()
    assert det.position_ms == 0

    # 10 кадров тишины → хлопок → событие.
    events: list[ClapEvent] = []
    for i in range(10):
        ev = det.feed(silence_ms(20))
        assert ev is None, f"тишина дала событие на кадре {i}"
    ev = det.feed(noise_ms(20))
    assert ev is not None and ev.is_single, f"хлопок не дал событие: {ev}"
    assert ev.time_ms == 200, f"time_ms={ev.time_ms} (ожидалось 200)"
    assert ev.features is not None and ev.score > 0.5

    # Cooldown: тот же хлопок сразу после — без события.
    assert det.feed(noise_ms(20, seed=8)) is None, "cooldown не сработал"

    # Двойной хлопок: через ~400 мс (> cooldown 350, < окно 700).
    for _ in range(20):
        assert det.feed(silence_ms(20)) is None
    ev2 = det.feed(noise_ms(20, seed=9))
    assert ev2 is not None and ev2.is_double, f"второй хлопок не помечен двойным: {ev2}"

    # Третий хлопок после двойного — снова одиночный.
    for _ in range(40):
        det.feed(silence_ms(20))
    ev3 = det.feed(noise_ms(20, seed=10))
    assert ev3 is not None and ev3.is_single, f"третий хлопок: {ev3}"

    det.reset()
    assert det.position_ms == 0
    assert det.feed(noise_ms(20)) is not None, "после reset детектор не работает"

    print("  ✓ детектор: событие, cooldown, двойной хлопок, reset")


# ---------------------------------------------------------------------------
def test_detector_rejects_tone_stream() -> None:
    det = ClapDetector()
    stream = frames(tone_ms(500) + silence_ms(200))
    events = [det.feed(f) for f in stream]
    assert all(e is None for e in events), "тоновая посылка дала событие хлопка"
    print("  ✓ детектор: поток тона не даёт ложных срабатываний")


# ---------------------------------------------------------------------------
def test_default_router() -> None:
    router = create_default_router()
    assert router.primary == "spectral" and router.available() == ["spectral"]
    res = router.detect(noise_ms(20))
    assert res.detected and res.engine == "spectral"
    assert create_default_router().detect(noise_ms(20)).detected
    print("  ✓ default router: spectral по умолчанию, детекция работает")


# ---------------------------------------------------------------------------
def main() -> int:
    print("JARVIS CORE — проверка audio/clap_detector")
    try:
        test_config_geometry_and_validation()
        test_feature_primitives()
        test_spectral_engine_decisions()
        test_router_fallback_and_switch()
        test_detector_events_cooldown_and_double()
        test_detector_rejects_tone_stream()
        test_default_router()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модуля прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
