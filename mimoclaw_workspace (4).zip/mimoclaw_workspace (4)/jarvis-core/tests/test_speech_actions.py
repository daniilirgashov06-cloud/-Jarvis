"""
Проверка модулей: actions/registry, ai/context_builder, speech/{stt,tts}_engine.

Запуск:  python3 tests/test_speech_actions.py
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from actions.registry import Command, CommandRegistry, RiskLevel, command, registry
from ai.context_builder import ContextBuilder
from ai.personas import JARVIS
from speech.stt_engine import STTEngine, STRouter, STTError, STTUnavailable, Transcript
from speech.tts_engine import SpeechAudio, TTSEngine, TTSRouter, TTSUnavailable, VoicePreset


# ---------------------------------------------------------------------------
# Мок-движки
# ---------------------------------------------------------------------------
class MockSTT(STTEngine):
    def __init__(self, name: str, text: str = "привет", available: bool = True, fail: str | None = None):
        self.name = name
        self.text = text
        self.available = available
        self.fail = fail
        self.calls = 0

    def is_available(self) -> bool:
        return self.available

    async def transcribe(self, pcm, *, sample_rate=16000, language="auto") -> Transcript:
        self.calls += 1
        if self.fail == "unavailable":
            raise STTUnavailable(f"{self.name}: нет")
        return Transcript(text=self.text, engine=self.name)


class MockTTS(TTSEngine):
    def __init__(self, name: str, available: bool = True, fail: str | None = None):
        self.name = name
        self.available = available
        self.fail = fail
        self.calls = 0

    def is_available(self) -> bool:
        return self.available

    async def synthesize(self, text, *, preset=None) -> SpeechAudio:
        self.calls += 1
        if self.fail == "unavailable":
            raise TTSUnavailable(f"{self.name}: нет")
        return SpeechAudio(pcm=text.encode(), engine=self.name)


class SysInfo:
    def snapshot(self):
        return {"cpu": 12, "ram": 40}


class Mem:
    def search(self, query, top_k):
        return ["проект X", "вчера делали отчёт"]


# ---------------------------------------------------------------------------
# Тесты
# ---------------------------------------------------------------------------
def test_registry_command_decorator() -> None:
    reg = CommandRegistry()

    @command(name="open_app", description="Открыть программу",
             params={"name": {"type": "string", "description": "имя"}},
             risk=RiskLevel.SAFE)
    def open_app(name: str) -> str:
        return f"открыл {name}"

    # Декоратор пишет в глобальный registry — проверим на нём
    cmd = registry.get("open_app")
    assert cmd is not None and cmd.risk == RiskLevel.SAFE and cmd.requires_confirmation is False
    tool = cmd.to_tool()
    assert tool.to_openai()["function"]["name"] == "open_app"
    print("  ✓ registry: @command создаёт команду + схему tools (risk=safe, без подтверждения)")


def test_registry_risk_confirmation() -> None:
    @command(name="shutdown", description="Выключить ПК", risk=RiskLevel.HIGH)
    def shutdown() -> str:
        return "выключаю"

    cmd = registry.get("shutdown")
    assert cmd.requires_confirmation is True, "HIGH-риск должен требовать подтверждения"
    print("  ✓ registry: уровни риска -> подтверждение (HIGH требует)")


def test_context_builder() -> None:
    cb = ContextBuilder(
        persona_key="jarvis",
        system_info=SysInfo(),
        memory=Mem(),
        context_messages=5,
        rag_top_k=2,
    )
    msgs = cb.build_messages(
        persona=JARVIS,
        history=[{"role": "user", "content": "старое 1"}, {"role": "assistant", "content": "ответ 1"}],
        user_text="что по проекту?",
    )
    assert msgs[0]["role"] == "system"
    sys_prompt = msgs[0]["content"]
    assert "JARVIS" in sys_prompt and "cpu" in sys_prompt, "персона + состояние ПК в system"
    assert "проект X" in sys_prompt, "RAG-воспоминания добавлены"
    assert msgs[-1] == {"role": "user", "content": "что по проекту?"}
    roles = [m["role"] for m in msgs]
    assert roles[1] == "user" and roles[2] == "assistant", "история сохраняет порядок"
    print("  ✓ context_builder: персона+ПК+RAG+история собираются корректно")


async def test_stt_router_switch_and_fallback() -> None:
    local = MockSTT("faster_whisper", text="локально")
    cloud = MockSTT("openai", text="облако")
    r = STRouter(engines={"faster_whisper": local, "openai": cloud}, primary="faster_whisper")
    t = await r.transcribe(b"\x00\x00")
    assert t.text == "локально" and t.engine == "faster_whisper"
    r.set_primary("openai")
    t2 = await r.transcribe(b"\x00\x00")
    assert t2.text == "облако" and r.primary == "openai"
    # fallback
    broken = MockSTT("faster_whisper", fail="unavailable")
    ok = MockSTT("openai", text="спасло")
    r2 = STRouter(engines={"faster_whisper": broken, "openai": ok}, primary="faster_whisper")
    t3 = await r2.transcribe(b"\x00\x00")
    assert t3.text == "спасло"
    print("  ✓ stt_router: смена локально↔облако + fallback работают")


async def test_tts_router_switch_and_fallback() -> None:
    local = MockTTS("local")
    cloud = MockTTS("elevenlabs")
    r = TTSRouter(engines={"local": local, "elevenlabs": cloud}, primary="local")
    a = await r.synthesize("привет", preset=VoicePreset(key="jarvis"))
    assert a.engine == "local"
    r.set_primary("elevenlabs")
    a2 = await r.synthesize("привет")
    assert a2.engine == "elevenlabs"
    broken = MockTTS("local", fail="unavailable")
    ok = MockTTS("elevenlabs")
    r2 = TTSRouter(engines={"local": broken, "elevenlabs": ok}, primary="local")
    a3 = await r2.synthesize("x")
    assert a3.engine == "elevenlabs"
    print("  ✓ tts_router: смена локально↔облако + fallback работают")


async def test_routers_all_fail() -> None:
    r = STRouter(engines={"openai": MockSTT("openai", fail="unavailable")}, primary="openai")
    try:
        await r.transcribe(b"")
        assert False
    except STTError:
        pass
    print("  ✓ routers: корректная ошибка, когда не справился ни один движок")


# ---------------------------------------------------------------------------
async def _run_async() -> None:
    await test_stt_router_switch_and_fallback()
    await test_tts_router_switch_and_fallback()
    await test_routers_all_fail()


def main() -> int:
    print("JARVIS CORE — проверка registry/context_builder/STT/TTS")
    try:
        test_registry_command_decorator()
        test_registry_risk_confirmation()
        test_context_builder()
        asyncio.run(_run_async())
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модулей прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
