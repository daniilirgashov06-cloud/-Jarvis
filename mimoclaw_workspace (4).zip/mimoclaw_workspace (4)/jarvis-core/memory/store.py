"""
Хранилище долговременной памяти JARVIS CORE (ТЗ-5, «вечная память»).

Локальное персистентное хранилище «фактов/событий/предпочтений», которое
собирается по ходу работы ассистента и позже подаётся в контекст (RAG top-k).
Данные осознанно хранятся **только локально** (SQLite-файл) — приватность
важнее удобства синхронизации.

Архитектура (в стиле ``core/audit_log.py`` и ``actions/productivity_actions.py``):

- ``MemoryKind`` / ``MemoryRecord`` — нормализованная сущность памяти
  (строгая валидация: длина контента, диапазон важности, безопасные теги);
- ``MemoryStore`` — абстрактный контракт «хранилище» (add/get/search/list/
  update/delete/clear/count/export);
- ``InMemoryMemoryStore`` — потокобезопасное хранилище в памяти: используется
  в тестах, в режиме INCOGNITO и как **аварийный fallback** при недоступном диске;
- ``SQLiteMemoryStore`` — «настоящая» локальная реализация на ``sqlite3``
  (WAL, индексы, атомарные транзакции, общий ``threading.Lock``);
- ``default_memory_store`` — фабрика «локально-first»: пробует SQLite,
  при любой ошибке деградирует в память (``degraded=True``) без падения.

Режимы приватности (``PrivacyMode`` из ``config.settings``):
- ``NORMAL``   — полное сохранение;
- ``LOCAL``    — то же, но безо всяких облачных операций (здесь и так локально);
- ``INCOGNITO`` — записи **не персистятся на диск** (живут только в текущей
  сессии), экспорт наружу запрещён (``PrivacyError``).

Использование:
    from memory.store import default_memory_store, MemoryKind, MemoryRecord

    store = default_memory_store("data/jarvis.db")
    rec = store.add(MemoryRecord(kind=MemoryKind.FACT,
                                 content="пользователь любит чай без сахара",
                                 tags=["предпочтение", "еда"]))
    store.search("чай")            # -> [rec]
    store.export("data/memories.json")
    store.clear()                  # «забудь всё»
"""

from __future__ import annotations

import abc
import json
import logging
import re
import sqlite3
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Iterable

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Константы и валидация
# ---------------------------------------------------------------------------
MAX_CONTENT_LEN = 8000      # максимум символов в записи
MAX_TAG_LEN = 64            # максимум символов в одном теге
MAX_TAGS = 16               # максимум тегов на запись
MAX_QUERY_LEN = 512         # максимум символов в поисковом запросе
DEFAULT_SEARCH_LIMIT = 8    # дефолт для RAG top-k (см. MemoryConfig.rag_top_k)

# Тег/контент не должны содержать управляющих символов (антиинъекция в вывод)
_CTRL_RE = re.compile(r"[\x00-\x1f\x7f]")


class MemoryError(Exception):
    """Базовая ошибка хранилища памяти."""


class MemoryUnavailable(MemoryError):
    """Хранилище недоступно (диск/БД) — операция не может быть выполнена."""


class PrivacyError(MemoryError):
    """Операция запрещена текущим режимом приватности."""


class MemoryKind(str, Enum):
    """Тип записи памяти — помогает фильтровать при сборке контекста."""

    FACT = "fact"                # устойчивый факт о пользователе/мире
    PREFERENCE = "preference"    # предпочтение («люблю чай без сахара»)
    EVENT = "event"              # событие («вчера была встреча»)
    SUMMARY = "summary"          # сводка диалога
    NOTE = "note"                # произвольная заметка
    CONVERSATION = "conversation"  # фрагмент диалога (для RAG)


class PrivacyMode(str, Enum):
    """Режим приватности (дублирует ``config.settings.PrivacyMode`` без импорта)."""

    NORMAL = "normal"
    INCOGNITO = "incognito"
    LOCAL = "local"


def _now() -> float:
    """Текущее время в секундах (Unix time)."""
    return time.time()


def _normalize(text: str) -> str:
    """Нормализация для поиска: регистр + ё→е (как в ``vision/ocr.py``)."""
    return text.lower().replace("ё", "е")


def _clean_text(value: str, *, max_len: int, what: str) -> str:
    """Валидация текста: непустой, без управляющих символов, в пределах длины."""
    if not isinstance(value, str):
        raise ValueError(f"{what}: ожидается str")
    cleaned = value.strip()
    if not cleaned:
        raise ValueError(f"{what}: пустое значение")
    if len(cleaned) > max_len:
        raise ValueError(f"{what}: превышена длина {max_len}")
    if _CTRL_RE.search(cleaned):
        raise ValueError(f"{what}: недопустимые управляющие символы")
    return cleaned


def _clean_tags(tags: Iterable[str]) -> tuple[str, ...]:
    """Нормализация тегов: дедупликация (по нормализованной форме), валидация."""
    seen: set[str] = set()
    result: list[str] = []
    for raw in tags:
        tag = _clean_text(str(raw), max_len=MAX_TAG_LEN, what="тег")
        key = _normalize(tag)
        if key in seen:
            continue
        seen.add(key)
        result.append(tag)
        if len(result) > MAX_TAGS:
            raise ValueError(f"тегов больше {MAX_TAGS}")
    return tuple(result)


# ---------------------------------------------------------------------------
# Сущность
# ---------------------------------------------------------------------------
@dataclass
class MemoryRecord:
    """Одна запись памяти.

    Поля ``id``/``created_at``/``updated_at`` назначаются хранилищем при
    ``add`` (их можно передать явно — тогда значение сохранится).
    """

    kind: MemoryKind
    content: str
    id: str = ""
    tags: tuple[str, ...] = ()
    importance: float = 0.5
    session_id: str | None = None
    created_at: float = 0.0
    updated_at: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)
    persisted: bool = True  # False — запись не была сохранена на диск (INCOGNITO)

    def __post_init__(self) -> None:
        # Нормализуем тип/контент/теги/важность — не валим грязь в БД.
        if not isinstance(self.kind, MemoryKind):
            self.kind = MemoryKind(str(self.kind))
        self.content = _clean_text(self.content, max_len=MAX_CONTENT_LEN, what="content")
        self.tags = _clean_tags(self.tags)
        self.importance = _validate_importance(self.importance)
        if not isinstance(self.metadata, dict):
            raise ValueError("metadata: ожидается dict")
        if self.id and _CTRL_RE.search(self.id):
            raise ValueError("id: недопустимые управляющие символы")

    def touch(self) -> None:
        """Обновить метку времени ``updated_at``."""
        self.updated_at = _now()

    def to_dict(self) -> dict[str, Any]:
        """Сериализация в JSON-безопасный словарь."""
        data = asdict(self)
        data["kind"] = self.kind.value
        data["tags"] = list(self.tags)
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MemoryRecord":
        """Десериализация из словаря (с валидацией через ``__post_init__``)."""
        return cls(
            kind=MemoryKind(data.get("kind", MemoryKind.NOTE.value)),
            content=str(data.get("content", "")),
            id=str(data.get("id", "")),
            tags=tuple(data.get("tags", ()) or ()),
            importance=float(data.get("importance", 0.5)),
            session_id=data.get("session_id"),
            created_at=float(data.get("created_at", 0.0)),
            updated_at=float(data.get("updated_at", 0.0)),
            metadata=dict(data.get("metadata", {}) or {}),
            persisted=bool(data.get("persisted", True)),
        )


def _validate_importance(value: Any) -> float:
    """Важность — число в диапазоне [0, 1]."""
    try:
        num = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("importance: ожидается число") from exc
    if not 0.0 <= num <= 1.0:
        raise ValueError("importance: вне диапазона [0, 1]")
    return num


# ---------------------------------------------------------------------------
# Контракт
# ---------------------------------------------------------------------------
class MemoryStore(abc.ABC):
    """Абстрактное хранилище памяти (контракт «что умеем»)."""

    @abc.abstractmethod
    def add(self, record: MemoryRecord) -> MemoryRecord:
        """Сохранить запись (назначает id/таймстемпы, возвращает запись)."""

    @abc.abstractmethod
    def get(self, record_id: str) -> MemoryRecord | None:
        """Получить запись по id (или ``None``)."""

    @abc.abstractmethod
    def search(
        self,
        query: str,
        *,
        kind: MemoryKind | None = None,
        tag: str | None = None,
        limit: int = DEFAULT_SEARCH_LIMIT,
    ) -> list[MemoryRecord]:
        """Нечёткий поиск по контенту/тегам (нормализация ё↔е/регистр)."""

    @abc.abstractmethod
    def list_recent(self, *, limit: int = 50) -> list[MemoryRecord]:
        """Последние записи (по убыванию ``created_at``)."""

    @abc.abstractmethod
    def update(self, record_id: str, **changes: Any) -> MemoryRecord | None:
        """Частично обновить запись (content/tags/importance/metadata)."""

    @abc.abstractmethod
    def delete(self, record_id: str) -> bool:
        """Удалить запись по id (``True`` — если была)."""

    @abc.abstractmethod
    def clear(self) -> int:
        """«Забудь всё» — удалить все записи, вернуть количество."""

    @abc.abstractmethod
    def count(self) -> int:
        """Сколько записей хранится."""

    @abc.abstractmethod
    def export(self, path: str | Path, *, fmt: str = "json") -> int:
        """Экспорт всех записей в файл (``json``/``jsonl``), вернуть количество."""

    def close(self) -> None:
        """Освободить ресурсы (по умолчанию — ничего)."""

    def __enter__(self) -> "MemoryStore":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()


# ---------------------------------------------------------------------------
# In-memory реализация
# ---------------------------------------------------------------------------
class InMemoryMemoryStore(MemoryStore):
    """Потокобезопасное хранилище в памяти (fallback/тесты/INCOGNITO)."""

    #: True — это аварийный fallback (БД/диск недоступны), данные не персистентны.
    degraded: bool = False

    def __init__(self, *, privacy_mode: PrivacyMode = PrivacyMode.NORMAL) -> None:
        self._lock = threading.Lock()
        self._records: dict[str, MemoryRecord] = {}
        self._privacy = privacy_mode

    # -- приватность ---------------------------------------------------
    @property
    def privacy_mode(self) -> PrivacyMode:
        return self._privacy

    def _persist_allowed(self) -> bool:
        return self._privacy is not PrivacyMode.INCOGNITO

    # -- реализация ---------------------------------------------------
    def add(self, record: MemoryRecord) -> MemoryRecord:
        rec = record
        if not rec.id:
            rec.id = uuid.uuid4().hex
        now = _now()
        if not rec.created_at:
            rec.created_at = now
        if not rec.updated_at:
            rec.updated_at = now
        rec.persisted = self._persist_allowed()
        with self._lock:
            self._records[rec.id] = rec
        return rec

    def get(self, record_id: str) -> MemoryRecord | None:
        with self._lock:
            return self._records.get(record_id)

    def search(
        self,
        query: str,
        *,
        kind: MemoryKind | None = None,
        tag: str | None = None,
        limit: int = DEFAULT_SEARCH_LIMIT,
    ) -> list[MemoryRecord]:
        q = _normalize(str(query or "")[:MAX_QUERY_LEN])
        tag_key = _normalize(tag) if tag else None
        with self._lock:
            candidates = list(self._records.values())
        hits: list[tuple[float, MemoryRecord]] = []
        for rec in candidates:
            if kind is not None and rec.kind is not kind:
                continue
            if tag_key is not None and tag_key not in {_normalize(t) for t in rec.tags}:
                continue
            score = _match_score(q, rec)
            if score > 0.0:
                hits.append((score, rec))
        hits.sort(key=lambda pair: (pair[0], pair[1].created_at), reverse=True)
        return [rec for _, rec in hits[: max(0, limit)]]

    def list_recent(self, *, limit: int = 50) -> list[MemoryRecord]:
        with self._lock:
            recs = sorted(self._records.values(), key=lambda r: r.created_at, reverse=True)
        return recs[: max(0, limit)]

    def update(self, record_id: str, **changes: Any) -> MemoryRecord | None:
        with self._lock:
            rec = self._records.get(record_id)
            if rec is None:
                return None
            if "content" in changes:
                rec.content = _clean_text(str(changes["content"]), max_len=MAX_CONTENT_LEN, what="content")
            if "tags" in changes:
                rec.tags = _clean_tags(changes["tags"] or ())
            if "importance" in changes:
                rec.importance = _validate_importance(changes["importance"])
            if "metadata" in changes:
                meta = changes["metadata"]
                if not isinstance(meta, dict):
                    raise ValueError("metadata: ожидается dict")
                rec.metadata = dict(meta)
            rec.touch()
            rec.persisted = self._persist_allowed()
            return rec

    def delete(self, record_id: str) -> bool:
        with self._lock:
            return self._records.pop(record_id, None) is not None

    def clear(self) -> int:
        with self._lock:
            n = len(self._records)
            self._records.clear()
        return n

    def count(self) -> int:
        with self._lock:
            return len(self._records)

    def export(self, path: str | Path, *, fmt: str = "json") -> int:
        if not self._persist_allowed():
            raise PrivacyError("экспорт запрещён в режиме INCOGNITO")
        with self._lock:
            data = [rec.to_dict() for rec in self._records.values()]
        return _write_export(Path(path), data, fmt=fmt)


def _match_score(query_norm: str, rec: MemoryRecord) -> float:
    """Простая оценка релевантности: точное/подстрока/токены, важность как вес."""
    if not query_norm:
        return rec.importance  # пустой запрос = «список всего», сортируем по важности
    content = _normalize(rec.content)
    tags = " ".join(_normalize(t) for t in rec.tags)
    haystack = f"{content} {tags}"
    score = 0.0
    if query_norm == content:
        score = 3.0
    elif query_norm in haystack:
        score = 2.0
    else:
        tokens = [t for t in re.split(r"\s+", query_norm) if t]
        matched = sum(1 for t in tokens if t in haystack)
        if tokens and matched:
            score = matched / len(tokens)
    return score * (1.0 + rec.importance)  # важность усиливает, но не решает одна


# ---------------------------------------------------------------------------
# SQLite реализация
# ---------------------------------------------------------------------------
_SCHEMA = """
CREATE TABLE IF NOT EXISTS memories (
    id          TEXT PRIMARY KEY,
    kind        TEXT NOT NULL,
    content     TEXT NOT NULL,
    tags        TEXT NOT NULL DEFAULT '[]',
    importance  REAL NOT NULL DEFAULT 0.5,
    session_id  TEXT,
    created_at  REAL NOT NULL,
    updated_at  REAL NOT NULL,
    metadata    TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_memories_kind ON memories(kind);
CREATE INDEX IF NOT EXISTS idx_memories_created ON memories(created_at);
"""


class SQLiteMemoryStore(MemoryStore):
    """Локальное хранилище памяти на ``sqlite3`` (файл, потокобезопасно)."""

    def __init__(
        self,
        path: str | Path,
        *,
        privacy_mode: PrivacyMode = PrivacyMode.NORMAL,
        timeout: float = 5.0,
    ) -> None:
        self._path = Path(path)
        self._privacy = privacy_mode
        self._lock = threading.Lock()
        self._conn: sqlite3.Connection | None = None
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(
                str(self._path), timeout=timeout, check_same_thread=False
            )
            self._conn.execute("PRAGMA journal_mode=WAL;")
            self._conn.executescript(_SCHEMA)
            self._conn.commit()
        except (sqlite3.Error, OSError) as exc:  # диск/права/БД недоступны
            self._conn = None
            raise MemoryUnavailable(f"не удалось открыть БД {self._path}: {exc}") from exc

    # -- приватность ---------------------------------------------------
    @property
    def privacy_mode(self) -> PrivacyMode:
        return self._privacy

    def _persist_allowed(self) -> bool:
        return self._privacy is not PrivacyMode.INCOGNITO

    def _require_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            raise MemoryUnavailable("соединение с БД закрыто")
        return self._conn

    # -- реализация ---------------------------------------------------
    def add(self, record: MemoryRecord) -> MemoryRecord:
        rec = record
        if not rec.id:
            rec.id = uuid.uuid4().hex
        now = _now()
        if not rec.created_at:
            rec.created_at = now
        if not rec.updated_at:
            rec.updated_at = now
        rec.persisted = self._persist_allowed()
        if not self._persist_allowed():  # INCOGNITO: держим только в памяти
            return rec
        conn = self._require_conn()
        with self._lock:
            conn.execute(
                "INSERT OR REPLACE INTO memories "
                "(id, kind, content, tags, importance, session_id, created_at, updated_at, metadata) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                _to_row(rec),
            )
            conn.commit()
        return rec

    def get(self, record_id: str) -> MemoryRecord | None:
        conn = self._require_conn()
        with self._lock:
            row = conn.execute(
                "SELECT id, kind, content, tags, importance, session_id, "
                "created_at, updated_at, metadata FROM memories WHERE id = ?",
                (record_id,),
            ).fetchone()
        return _from_row(row) if row else None

    def search(
        self,
        query: str,
        *,
        kind: MemoryKind | None = None,
        tag: str | None = None,
        limit: int = DEFAULT_SEARCH_LIMIT,
    ) -> list[MemoryRecord]:
        conn = self._require_conn()
        clauses = ["1=1"]
        params: list[Any] = []
        if kind is not None:
            clauses.append("kind = ?")
            params.append(kind.value)
        if tag is not None:
            clauses.append("lower(replace(tags, 'ё', 'е')) LIKE ?")
            params.append(f"%{_normalize(tag)}%")
        sql = (
            "SELECT id, kind, content, tags, importance, session_id, "
            "created_at, updated_at, metadata FROM memories WHERE "
            + " AND ".join(clauses)
        )
        with self._lock:
            rows = conn.execute(sql, params).fetchall()
        recs = [_from_row(r) for r in rows]
        # Ранжирование делаем в Python (нормализация ё↔е + важность).
        q = _normalize(str(query or "")[:MAX_QUERY_LEN])
        scored = [(_match_score(q, r), r) for r in recs]
        scored = [(s, r) for s, r in scored if s > 0.0]
        scored.sort(key=lambda pair: (pair[0], pair[1].created_at), reverse=True)
        return [r for _, r in scored[: max(0, limit)]]

    def list_recent(self, *, limit: int = 50) -> list[MemoryRecord]:
        conn = self._require_conn()
        with self._lock:
            rows = conn.execute(
                "SELECT id, kind, content, tags, importance, session_id, "
                "created_at, updated_at, metadata FROM memories "
                "ORDER BY created_at DESC LIMIT ?",
                (max(0, limit),),
            ).fetchall()
        return [_from_row(r) for r in rows]

    def update(self, record_id: str, **changes: Any) -> MemoryRecord | None:
        rec = self.get(record_id)
        if rec is None:
            return None
        if "content" in changes:
            rec.content = _clean_text(str(changes["content"]), max_len=MAX_CONTENT_LEN, what="content")
        if "tags" in changes:
            rec.tags = _clean_tags(changes["tags"] or ())
        if "importance" in changes:
            rec.importance = _validate_importance(changes["importance"])
        if "metadata" in changes:
            meta = changes["metadata"]
            if not isinstance(meta, dict):
                raise ValueError("metadata: ожидается dict")
            rec.metadata = dict(meta)
        rec.touch()
        rec.persisted = self._persist_allowed()
        if not self._persist_allowed():
            return rec
        conn = self._require_conn()
        with self._lock:
            conn.execute(
                "UPDATE memories SET content = ?, tags = ?, importance = ?, "
                "metadata = ?, updated_at = ? WHERE id = ?",
                (
                    rec.content,
                    json.dumps(list(rec.tags), ensure_ascii=False),
                    rec.importance,
                    json.dumps(rec.metadata, ensure_ascii=False),
                    rec.updated_at,
                    rec.id,
                ),
            )
            conn.commit()
        return rec

    def delete(self, record_id: str) -> bool:
        conn = self._require_conn()
        with self._lock:
            cur = conn.execute("DELETE FROM memories WHERE id = ?", (record_id,))
            conn.commit()
            return cur.rowcount > 0

    def clear(self) -> int:
        conn = self._require_conn()
        with self._lock:
            cur = conn.execute("DELETE FROM memories")
            conn.commit()
            return cur.rowcount or 0

    def count(self) -> int:
        conn = self._require_conn()
        with self._lock:
            row = conn.execute("SELECT COUNT(*) FROM memories").fetchone()
        return int(row[0]) if row else 0

    def export(self, path: str | Path, *, fmt: str = "json") -> int:
        if not self._persist_allowed():
            raise PrivacyError("экспорт запрещён в режиме INCOGNITO")
        conn = self._require_conn()
        with self._lock:
            rows = conn.execute(
                "SELECT id, kind, content, tags, importance, session_id, "
                "created_at, updated_at, metadata FROM memories ORDER BY created_at"
            ).fetchall()
        data = [_from_row(r).to_dict() for r in rows]
        return _write_export(Path(path), data, fmt=fmt)

    def close(self) -> None:
        with self._lock:
            if self._conn is not None:
                try:
                    self._conn.close()
                except sqlite3.Error:  # pragma: no cover - уже закрыта
                    pass
                self._conn = None


# ---------------------------------------------------------------------------
# Сериализация строк SQLite и экспорт
# ---------------------------------------------------------------------------
def _to_row(rec: MemoryRecord) -> tuple[Any, ...]:
    """Запись → кортеж для SQL (JSON-безопасно)."""
    return (
        rec.id,
        rec.kind.value,
        rec.content,
        json.dumps(list(rec.tags), ensure_ascii=False),
        rec.importance,
        rec.session_id,
        rec.created_at,
        rec.updated_at,
        json.dumps(rec.metadata, ensure_ascii=False),
    )


def _from_row(row: Iterable[Any]) -> MemoryRecord:
    """Строка SQLite → запись (с валидацией)."""
    (
        rec_id,
        kind,
        content,
        tags_json,
        importance,
        session_id,
        created_at,
        updated_at,
        meta_json,
    ) = row
    try:
        tags = tuple(json.loads(tags_json or "[]"))
    except (TypeError, ValueError):
        tags = ()
    try:
        meta = json.loads(meta_json or "{}")
    except (TypeError, ValueError):
        meta = {}
    return MemoryRecord(
        kind=MemoryKind(kind),
        content=str(content),
        id=str(rec_id),
        tags=tags,
        importance=float(importance),
        session_id=session_id,
        created_at=float(created_at),
        updated_at=float(updated_at),
        metadata=meta if isinstance(meta, dict) else {},
        persisted=True,
    )


_FORBIDDEN_EXPORT_SUFFIXES = {".json", ".jsonl", ".ndjson"}


def _write_export(path: Path, data: list[dict[str, Any]], *, fmt: str) -> int:
    """Запись экспорта в файл (валидация пути/формата, атомарно через tmp)."""
    fmt = fmt.lower()
    if fmt not in {"json", "jsonl"}:
        raise ValueError(f"неподдерживаемый формат экспорта: {fmt}")
    name = path.name
    if name.startswith("-") or _CTRL_RE.search(name):
        raise ValueError("недопустимое имя файла экспорта")
    if path.suffix and path.suffix.lower() not in _FORBIDDEN_EXPORT_SUFFIXES:
        raise ValueError(f"недопустимое расширение экспорта: {path.suffix}")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + ".tmp")
        if fmt == "json":
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        else:
            lines = "\n".join(json.dumps(d, ensure_ascii=False) for d in data)
            tmp.write_text(lines + ("\n" if data else ""), encoding="utf-8")
        tmp.replace(path)
    except OSError as exc:
        raise MemoryUnavailable(f"не удалось записать экспорт {path}: {exc}") from exc
    return len(data)


# ---------------------------------------------------------------------------
# Фабрика «локально-first»
# ---------------------------------------------------------------------------
def default_memory_store(
    path: str | Path = "data/jarvis.db",
    *,
    privacy_mode: PrivacyMode = PrivacyMode.NORMAL,
    fallback_to_memory: bool = True,
) -> MemoryStore:
    """Создать хранилище: пробуем SQLite, при сбое — деградация в память.

    В режиме INCOGNITO используется только ``InMemoryMemoryStore`` — на диск
    ничего не пишется даже при доступном пути (приватность важнее персистентности).
    """
    if privacy_mode is PrivacyMode.INCOGNITO:
        return InMemoryMemoryStore(privacy_mode=privacy_mode)
    try:
        return SQLiteMemoryStore(path, privacy_mode=privacy_mode)
    except MemoryUnavailable as exc:
        if not fallback_to_memory:
            raise
        logger.warning("SQLite-память недоступна (%s), деградация в память", exc)
        fallback = InMemoryMemoryStore(privacy_mode=privacy_mode)
        fallback.degraded = True
        return fallback
