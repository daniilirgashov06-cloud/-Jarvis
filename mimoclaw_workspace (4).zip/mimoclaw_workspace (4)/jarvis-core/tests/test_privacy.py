"""
Проверка memory/privacy.py — режимы приватности (INCOGNITO/ЛОКАЛЬНО/обычный),
маршрутизация записей, единый экспорт с маскировкой секретов, «забудь всё».

Запуск:  python3 tests/test_privacy.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from memory.privacy import (
    ExportReport,
    ForgetReport,
    PrivacyController,
    PrivacySettings,
    default_privacy_controller,
)
from memory.profile import JsonProfileStore, ProfileBuilder, ProfileEntry
from memory.store import (
    InMemoryMemoryStore,
    MemoryKind,
    MemoryRecord,
    MemoryUnavailable,
    PrivacyError,
    PrivacyMode,
    SQLiteMemoryStore,
)


# ---------------------------------------------------------------------------
# Утилиты
# ---------------------------------------------------------------------------
def _rec(content: str, kind: MemoryKind = MemoryKind.FACT, **kw) -> MemoryRecord:
    return MemoryRecord(kind=kind, content=content, **kw)


def _controller(tmp: Path, mode: PrivacyMode = PrivacyMode.NORMAL) -> tuple[PrivacyController, SQLiteMemoryStore]:
    store = SQLiteMemoryStore(tmp / "jarvis.db")
    profile = ProfileBuilder(
        store=JsonProfileStore(tmp / "profile.json"),
        privacy_mode=mode,
    )
    return PrivacyController(store=store, profile=profile, settings=PrivacySettings(mode=mode)), store


# ---------------------------------------------------------------------------
# Настройки
# ---------------------------------------------------------------------------
def test_settings_validation() -> None:
    s = PrivacySettings(mode="local")
    assert s.mode is PrivacyMode.LOCAL
    assert s.redact_exports is True and s.include_profile_in_export is True

    try:
        PrivacySettings(mode="stealth")
    except ValueError:
        pass
    else:
        raise AssertionError("неизвестный режим должен давать ValueError")

    try:
        PrivacySettings(redact_exports="yes")  # type: ignore[arg-type]
    except ValueError:
        pass
    else:
        raise AssertionError("не-bool флаг должен давать ValueError")


# ---------------------------------------------------------------------------
# Гейты по режимам
# ---------------------------------------------------------------------------
def test_mode_gates() -> None:
    normal = PrivacyController(settings=PrivacySettings())
    assert normal.can_persist() and normal.can_export() and normal.can_send_to_cloud()

    local = PrivacyController(settings=PrivacySettings(mode=PrivacyMode.LOCAL))
    assert local.can_persist() and local.can_export() and not local.can_send_to_cloud()

    incognito = PrivacyController(settings=PrivacySettings(mode=PrivacyMode.INCOGNITO))
    assert not incognito.can_persist() and not incognito.can_export() and not incognito.can_send_to_cloud()
    assert incognito.mode is PrivacyMode.INCOGNITO


# ---------------------------------------------------------------------------
# Маршрутизация записей
# ---------------------------------------------------------------------------
def test_add_routes_by_mode() -> None:
    store = InMemoryMemoryStore()
    normal = PrivacyController(store=store)
    rec = normal.remember("пользователь любит чай", tags=["вкус"], importance=0.8)
    assert store.count() == 1 and rec.persisted is True
    assert len(normal.session_records()) == 0

    secret = PrivacyController(store=store, settings=PrivacySettings(mode=PrivacyMode.INCOGNITO))
    rec2 = secret.remember("секретная мысль")
    assert store.count() == 1, "INCOGNITO не должен писать в основное хранилище"
    assert rec2.persisted is False
    assert len(secret.session_records()) == 1


def test_remember_validation() -> None:
    ctrl = PrivacyController()
    try:
        ctrl.remember("   ")
    except ValueError:
        pass
    else:
        raise AssertionError("пустой контент должен давать ValueError")

    try:
        ctrl.add("не запись")  # type: ignore[arg-type]
    except ValueError:
        pass
    else:
        raise AssertionError("add без MemoryRecord должен давать ValueError")


# ---------------------------------------------------------------------------
# INCOGNITO: без диска и без экспорта
# ---------------------------------------------------------------------------
def test_incognito_no_disk_no_export(tmp: Path) -> None:
    ctrl, store = _controller(tmp, PrivacyMode.INCOGNITO)
    ctrl.remember("не должно попасть на диск")
    assert store.count() == 0
    assert len(ctrl.session_records()) == 1

    try:
        ctrl.export(tmp / "leak.json")
    except PrivacyError:
        pass
    else:
        raise AssertionError("экспорт в INCOGNITO должен давать PrivacyError")

    assert not (tmp / "leak.json").exists()
    assert ctrl.save_profile() is False


# ---------------------------------------------------------------------------
# Переключение режима: сброс / перенос сессии
# ---------------------------------------------------------------------------
def test_set_mode_drop_and_carry(tmp: Path) -> None:
    ctrl, store = _controller(tmp, PrivacyMode.INCOGNITO)
    ctrl.remember("мысль 1")
    ctrl.remember("мысль 2")

    # Выход из INCOGNITO по умолчанию сбрасывает буфер (следов не остаётся)
    assert ctrl.set_mode(PrivacyMode.NORMAL) is PrivacyMode.NORMAL
    assert store.count() == 0 and len(ctrl.session_records()) == 0
    assert ctrl.can_persist() and ctrl.can_send_to_cloud()

    # carry_session=True — явное решение «сохранить накопленное»
    ctrl.set_mode(PrivacyMode.INCOGNITO)
    ctrl.remember("мысль 3")
    ctrl.set_mode(PrivacyMode.LOCAL, carry_session=True)
    assert store.count() == 1 and len(ctrl.session_records()) == 0
    assert not ctrl.can_send_to_cloud()

    try:
        ctrl.set_mode("злой-режим")
    except ValueError:
        pass
    else:
        raise AssertionError("неизвестный режим в set_mode должен давать ValueError")


# ---------------------------------------------------------------------------
# Экспорт
# ---------------------------------------------------------------------------
def test_export_json_redacted(tmp: Path) -> None:
    ctrl, store = _controller(tmp)
    store.add(_rec("обычная запись про погоду"))
    store.add(_rec("мой пароль: qwerty123, почта ivan@mail.ru"))
    ctrl.profile.profile.merge(ProfileEntry(key="name", value="Иван"))

    out = tmp / "export.json"
    report = ctrl.export(out)
    assert isinstance(report, ExportReport)
    assert report.memories == 2 and report.profile_entries == 1
    assert report.redacted is True and report.mode == "normal"

    raw = out.read_text(encoding="utf-8")
    assert "qwerty123" not in raw and "ivan@mail.ru" not in raw, "секреты должны быть замаскированы"
    assert "[ПАРОЛЬ]" in raw and "[EMAIL]" in raw

    data = json.loads(raw)
    assert data["format"] == "jarvis-memory-export" and data["version"] == 1
    assert data["redacted"] is True and len(data["memories"]) == 2
    assert data["profile"]["entries"][0]["key"] == "name"


def test_export_no_redact_and_no_profile(tmp: Path) -> None:
    ctrl, _ = _controller(tmp)
    ctrl.remember("мой пароль: qwerty123")

    out = tmp / "raw.json"
    report = ctrl.export(out, redact=False, include_profile=False)
    assert report.redacted is False and report.profile_entries == 0
    raw = out.read_text(encoding="utf-8")
    assert "qwerty123" in raw
    assert json.loads(raw)["profile"] is None


def test_export_jsonl(tmp: Path) -> None:
    ctrl, store = _controller(tmp)
    store.add(_rec("первая"))
    store.add(_rec("вторая", kind=MemoryKind.NOTE))
    ctrl.profile.profile.merge(ProfileEntry(key="city", value="Москва"))

    out = tmp / "export.jsonl"
    report = ctrl.export(out, fmt="jsonl")
    assert report.fmt == "jsonl" and report.memories == 2

    lines = [json.loads(line) for line in out.read_text(encoding="utf-8").splitlines() if line]
    assert lines[0]["type"] == "meta" and lines[0]["format"] == "jarvis-memory-export"
    kinds = [line["type"] for line in lines[1:]]
    assert kinds == ["memory", "memory", "profile_entry"]


def test_export_validation(tmp: Path) -> None:
    ctrl, _ = _controller(tmp)

    for bad in ("xml", "csv"):
        try:
            ctrl.export(tmp / "e.json", fmt=bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"формат {bad} должен давать ValueError")

    try:
        ctrl.export(tmp / "e.txt")
    except ValueError:
        pass
    else:
        raise AssertionError("недопустимое расширение должно давать ValueError")

    try:
        ctrl.export(tmp / "-e.json")
    except ValueError:
        pass
    else:
        raise AssertionError("имя с ведущим дефисом должно давать ValueError")

    empty = PrivacyController()
    try:
        empty.export(tmp / "e.json")
    except MemoryUnavailable:
        pass
    else:
        raise AssertionError("экспорт без хранилища должен давать MemoryUnavailable")


# ---------------------------------------------------------------------------
# «Забудь всё»
# ---------------------------------------------------------------------------
def test_forget_all(tmp: Path) -> None:
    ctrl, store = _controller(tmp, PrivacyMode.INCOGNITO)
    store.add(_rec("старое 1"))
    store.add(_rec("старое 2"))
    ctrl.remember("сессионное 1")
    ctrl.remember("сессионное 2")
    ctrl.profile.profile.merge(ProfileEntry(key="name", value="Иван"))

    report = ctrl.forget_all()
    assert isinstance(report, ForgetReport)
    assert (report.memories, report.session, report.profile) == (2, 2, 1)
    assert report.total == 5
    assert store.count() == 0 and len(ctrl.session_records()) == 0
    assert len(ctrl.profile.profile) == 0
    assert ctrl.status()["profile_entries"] == 0


def test_save_profile_gate(tmp: Path) -> None:
    ctrl, _ = _controller(tmp, PrivacyMode.INCOGNITO)
    ctrl.profile.profile.merge(ProfileEntry(key="job", value="инженер"))
    assert ctrl.save_profile() is False, "INCOGNITO не должен писать профиль на диск"
    assert not (tmp / "profile.json").exists()

    ctrl.set_mode(PrivacyMode.NORMAL)
    assert ctrl.save_profile() is True
    assert (tmp / "profile.json").exists()
    assert "инженер" in ctrl.profile_text()


# ---------------------------------------------------------------------------
# Статус и фабрика
# ---------------------------------------------------------------------------
def test_status(tmp: Path) -> None:
    ctrl, _ = _controller(tmp)
    ctrl.remember("факт")
    status = ctrl.status()
    assert status["mode"] == "normal" and status["memories"] == 1
    assert status["can_persist"] and status["can_export"] and status["can_send_to_cloud"]
    assert status["store"] == "SQLiteMemoryStore" and status["degraded"] is False
    json.dumps(status, ensure_ascii=False)  # JSON-безопасно


def test_default_privacy_controller(tmp: Path) -> None:
    db = tmp / "data" / "jarvis.db"
    prof = tmp / "data" / "profile.json"

    incognito = default_privacy_controller(db, profile_path=prof, mode="incognito")
    incognito.remember("секрет")
    assert not db.exists() and not prof.exists(), "INCOGNITO не должен создавать файлы"
    assert len(incognito.session_records()) == 1

    normal = default_privacy_controller(db, profile_path=prof)
    normal.remember("факт")
    normal.profile.profile.merge(ProfileEntry(key="city", value="Тверь"))
    assert normal.save_profile() is True
    assert db.exists() and prof.exists()
    assert normal.status()["memories"] == 1
    normal.status()  # не падает
    if hasattr(normal, "_store"):
        normal._store.close()  # type: ignore[union-attr]


if __name__ == "__main__":
    import tempfile
    import traceback

    tests = [(k, v) for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    base = Path(".openclaw/tmp")
    base.mkdir(parents=True, exist_ok=True)
    for name, fn in tests:
        try:
            if fn.__code__.co_argcount == 0:
                fn()
            else:
                fn(Path(tempfile.mkdtemp(dir=base)))
            print(f"  ok  {name}")
        except Exception:
            failed += 1
            print(f"FAIL  {name}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
