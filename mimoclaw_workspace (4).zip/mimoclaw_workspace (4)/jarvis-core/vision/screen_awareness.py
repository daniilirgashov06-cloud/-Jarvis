"""
Screen Awareness и приватность (маскировка парольных полей) для JARVIS CORE.

Модуль «осведомлённости об экране»: находит чувствительные регионы и текст
(парольные поля, токены, карты, почта, телефон) и маскирует их ДО того, как
кадр/текст попадут в LLM, облако, логи или сохранённый скриншот.

Компоненты:
  - ``SensitiveRegion`` / ``SensitiveKind`` — типизированный чувствительный
    регион с жёсткой валидацией геометрии и подписи;
  - ``mask_image`` — заливка регионов в растре ``OCRImage`` (BLACK / BLUR /
    PIXELATE) без внешних зависимостей;
  - ``find_text_secrets`` / ``redact_text`` — поиск и замаскировка секретов
    в тексте (email, карты с проверкой Луна, телефоны, «пароль: значение»);
  - ``SensitiveFieldDetector`` — поиск парольных полей по результату OCR
    (подписи «пароль/password/PIN/CVV» + значения «••••» рядом с подписью);
  - ``ScreenGuard`` — фасад: ``protect_image`` / ``protect_frame`` /
    ``protect_text`` / ``prepare_for_cloud`` (облако — только осознанно,
    политика ``PrivacyPolicy.allow_cloud``).

Локально-first: вся обработка — чистый Python, данные наружу не уходят.
Модуль ничего не отправляет по сети сам: он только ГОТОВИТ данные к отправке
и блокирует её при наличии секретов, если политика это запрещает.
"""

from __future__ import annotations

import enum
import logging
import re
from dataclasses import dataclass, replace
from typing import Iterable, Sequence

from vision.capture import ScreenFrame
from vision.ocr import OCRBox, OCRImage, OCRResult, normalize_text

logger = logging.getLogger(__name__)

#: предохранитель от «памяти-бомбы»: максимум площадь размытия (пикселей)
MAX_BLUR_PIXELS: int = 4_000_000

#: максимум найденных регионов на один кадр (список усекается по порядку)
MAX_REGIONS: int = 64

#: максимум символов в подписи региона
MAX_LABEL_CHARS: int = 200

#: токены замены для redact_text
REDACTION_TOKENS: dict["SensitiveKind", str] = {}


class ScreenAwarenessError(Exception):
    """Ошибка screen-awareness/приватности."""


class PrivacyBlocked(ScreenAwarenessError):
    """
    Отправка заблокирована политикой приватности.

    Выбрасывается ``ScreenGuard.prepare_for_cloud`` / ``prepare_text_for_cloud``,
    когда найдены секреты, а ``PrivacyPolicy.allow_cloud`` выключен.
    """


# ---------------------------------------------------------------------------
# Типы
# ---------------------------------------------------------------------------
class SensitiveKind(str, enum.Enum):
    """Категория чувствительного содержимого."""

    PASSWORD = "password"  # пароль / PIN / секретный код
    SECRET = "secret"  # токен, ключ, «звёздочки», прочие секреты
    EMAIL = "email"
    PHONE = "phone"
    CARD = "card"  # номер карты / CVV
    CUSTOM = "custom"  # пользовательский регион


class MaskStyle(str, enum.Enum):
    """Стиль маскирования региона в растре."""

    BLACK = "black"  # заливка чёрным (дефолт, надёжно)
    BLUR = "blur"  # box-blur — «размыто, но видно форму»
    PIXELATE = "pixelate"  # крупные пиксели — форма видна, текст нет


REDACTION_TOKENS = {
    SensitiveKind.PASSWORD: "[ПАРОЛЬ]",
    SensitiveKind.SECRET: "[СЕКРЕТ]",
    SensitiveKind.EMAIL: "[EMAIL]",
    SensitiveKind.PHONE: "[ТЕЛЕФОН]",
    SensitiveKind.CARD: "[КАРТА]",
    SensitiveKind.CUSTOM: "[СКРЫТО]",
}


@dataclass(frozen=True)
class SensitiveRegion:
    """
    Чувствительный прямоугольник в локальных координатах картинки/кадра.

    ``kind`` — категория (``SensitiveKind`` или его строковое значение),
    ``label`` — подпись (например «пароль»), без управляющих символов.
    """

    x: int
    y: int
    width: int
    height: int
    kind: SensitiveKind = SensitiveKind.CUSTOM
    label: str = ""

    def __post_init__(self) -> None:
        for name, value in (
            ("x", self.x),
            ("y", self.y),
            ("width", self.width),
            ("height", self.height),
        ):
            if isinstance(value, bool) or not isinstance(value, int):
                raise ValueError(f"{name} должен быть int, получено: {value!r}")
        if self.x < 0 or self.y < 0:
            raise ValueError("x/y не могут быть отрицательными")
        if self.width <= 0 or self.height <= 0:
            raise ValueError("width/height должны быть положительными")
        try:
            kind = self.kind if isinstance(self.kind, SensitiveKind) else SensitiveKind(self.kind)
        except ValueError as exc:
            raise ValueError(f"неизвестный kind: {self.kind!r}") from exc
        object.__setattr__(self, "kind", kind)
        if not isinstance(self.label, str):
            raise ValueError("label должен быть str")
        if len(self.label) > MAX_LABEL_CHARS:
            raise ValueError(f"слишком длинная подпись (лимит {MAX_LABEL_CHARS})")
        if any(ord(ch) < 32 for ch in self.label):
            raise ValueError("label не может содержать управляющие символы")

    @classmethod
    def from_box(
        cls,
        box: OCRBox,
        *,
        kind: SensitiveKind | str = SensitiveKind.CUSTOM,
        label: str = "",
    ) -> "SensitiveRegion":
        """Строит регион из коробки OCR-слова (``vision.ocr.OCRBox``)."""
        return cls(box.x, box.y, max(1, box.width), max(1, box.height), kind, label)

    @property
    def area(self) -> int:
        """Площадь региона в пикселях."""
        return self.width * self.height

    @property
    def right(self) -> int:
        """X правой границы (не включительно)."""
        return self.x + self.width

    @property
    def bottom(self) -> int:
        """Y нижней границы (не включительно)."""
        return self.y + self.height

    def overlaps(self, other: "SensitiveRegion") -> bool:
        """True, если прямоугольники пересекаются."""
        return (
            self.x < other.right
            and other.x < self.right
            and self.y < other.bottom
            and other.y < self.bottom
        )

    def clipped(self, width: int, height: int) -> "SensitiveRegion | None":
        """
        Обрезает регион по границам картинки ``width``×``height``.

        Полностью вне картинки — ``None``.
        """
        if width <= 0 or height <= 0:
            raise ValueError("width/height должны быть положительными")
        x0 = max(self.x, 0)
        y0 = max(self.y, 0)
        x1 = min(self.right, width)
        y1 = min(self.bottom, height)
        if x1 <= x0 or y1 <= y0:
            return None
        return SensitiveRegion(x0, y0, x1 - x0, y1 - y0, self.kind, self.label)


@dataclass(frozen=True)
class PrivacyPolicy:
    """
    Политика приватности: что маскируем, как маскируем, куда отдаём.

    ``allow_cloud`` — облако только осознанно (по умолчанию False: при
    найденных секретах ``prepare_for_cloud`` блокирует отправку).
    """

    mask_kinds: frozenset[SensitiveKind] = frozenset(SensitiveKind)
    style: MaskStyle = MaskStyle.BLACK
    blur_radius: int = 2
    pixelate_block: int = 8
    redact_text: bool = True
    allow_cloud: bool = False
    max_regions: int = MAX_REGIONS

    def __post_init__(self) -> None:
        try:
            kinds = frozenset(
                k if isinstance(k, SensitiveKind) else SensitiveKind(k) for k in self.mask_kinds
            )
        except ValueError as exc:
            raise ValueError(f"неизвестный kind в mask_kinds: {exc}") from exc
        if not kinds:
            raise ValueError("mask_kinds не может быть пустым")
        object.__setattr__(self, "mask_kinds", kinds)
        try:
            style = self.style if isinstance(self.style, MaskStyle) else MaskStyle(self.style)
        except ValueError as exc:
            raise ValueError(f"неизвестный style: {self.style!r}") from exc
        object.__setattr__(self, "style", style)
        if isinstance(self.blur_radius, bool) or not isinstance(self.blur_radius, int):
            raise ValueError("blur_radius должен быть int")
        if not 1 <= self.blur_radius <= 16:
            raise ValueError("blur_radius должен быть в диапазоне 1..16")
        if isinstance(self.pixelate_block, bool) or not isinstance(self.pixelate_block, int):
            raise ValueError("pixelate_block должен быть int")
        if not 2 <= self.pixelate_block <= 64:
            raise ValueError("pixelate_block должен быть в диапазоне 2..64")
        if not isinstance(self.redact_text, bool):
            raise ValueError("redact_text должен быть bool")
        if not isinstance(self.allow_cloud, bool):
            raise ValueError("allow_cloud должен быть bool")
        if isinstance(self.max_regions, bool) or not isinstance(self.max_regions, int):
            raise ValueError("max_regions должен быть int")
        if not 1 <= self.max_regions <= 1024:
            raise ValueError("max_regions должен быть в диапазоне 1..1024")


def default_privacy_policy() -> PrivacyPolicy:
    """Дефолтная политика: маскируем всё, чёрным, без облака (локально-first)."""
    return PrivacyPolicy()


# ---------------------------------------------------------------------------
# Маскирование растра
# ---------------------------------------------------------------------------
_Rect = tuple[int, int, int, int]  # (x, y, width, height) — локальные координаты


def _clip_rects(width: int, height: int, regions: Iterable[SensitiveRegion]) -> list[_Rect]:
    """Обрезает регионы по границам картинки; пустые отбрасывает."""
    rects: list[_Rect] = []
    for reg in regions:
        local = reg.clipped(width, height)
        if local is not None:
            rects.append((local.x, local.y, local.width, local.height))
    return rects


def _fill_rect(out: bytearray, stride: int, channels: int, rect: _Rect, fill: bytes) -> None:
    """Заливает прямоугольник фиксированным цветом."""
    x0, y0, w, h = rect
    row = fill * w
    for y in range(y0, y0 + h):
        start = y * stride + x0 * channels
        out[start : start + w * channels] = row


def _blur_rect(
    orig: bytes,
    out: bytearray,
    stride: int,
    channels: int,
    rect: _Rect,
    radius: int,
) -> None:
    """Box-blur прямоугольника (усреднение окна (2r+1)², края — по границам региона)."""
    x0, y0, w, h = rect
    for y in range(y0, y0 + h):
        y_lo = max(y0, y - radius)
        y_hi = min(y0 + h - 1, y + radius)
        for x in range(x0, x0 + w):
            x_lo = max(x0, x - radius)
            x_hi = min(x0 + w - 1, x + radius)
            acc = [0] * channels
            n = 0
            for yy in range(y_lo, y_hi + 1):
                for xx in range(x_lo, x_hi + 1):
                    off = yy * stride + xx * channels
                    for c in range(channels):
                        acc[c] += orig[off + c]
                    n += 1
            off = y * stride + x * channels
            for c in range(channels):
                out[off + c] = acc[c] // n


def _pixelate_rect(
    orig: bytes,
    out: bytearray,
    stride: int,
    channels: int,
    rect: _Rect,
    block: int,
) -> None:
    """Пикселизация: каждый блок заливается средним цветом блока."""
    x0, y0, w, h = rect
    by = y0
    while by < y0 + h:
        bh = min(block, y0 + h - by)
        bx = x0
        while bx < x0 + w:
            bw = min(block, x0 + w - bx)
            acc = [0] * channels
            n = 0
            for yy in range(by, by + bh):
                for xx in range(bx, bx + bw):
                    off = yy * stride + xx * channels
                    for c in range(channels):
                        acc[c] += orig[off + c]
                    n += 1
            fill = bytes(acc[c] // n for c in range(channels))
            _fill_rect(out, stride, channels, (bx, by, bw, bh), fill)
            bx += bw
        by += bh


def mask_image(
    image: OCRImage,
    regions: Iterable[SensitiveRegion],
    *,
    style: MaskStyle | str = MaskStyle.BLACK,
    blur_radius: int = 2,
    pixelate_block: int = 8,
) -> OCRImage:
    """
    Маскирует регионы в растре ``OCRImage`` (L/RGB) и возвращает НОВЫЙ растр.

    Стили: ``BLACK`` — заливка чёрным, ``BLUR`` — box-blur (``blur_radius``),
    ``PIXELATE`` — крупные блоки (``pixelate_block``). Регионы вне картинки
    игнорируются; пустой список регионов возвращает исходный растр без копий.
    Огромные регионы при BLUR деградируют в заливку чёрным (предохранитель
    от «памяти-бомбы»).
    """
    if not isinstance(image, OCRImage):
        raise ValueError("image должен быть OCRImage")
    try:
        style = style if isinstance(style, MaskStyle) else MaskStyle(style)
    except ValueError as exc:
        raise ValueError(f"неизвестный style: {style!r}") from exc
    if isinstance(blur_radius, bool) or not isinstance(blur_radius, int):
        raise ValueError("blur_radius должен быть int")
    if not 1 <= blur_radius <= 16:
        raise ValueError("blur_radius должен быть в диапазоне 1..16")
    if isinstance(pixelate_block, bool) or not isinstance(pixelate_block, int):
        raise ValueError("pixelate_block должен быть int")
    if not 2 <= pixelate_block <= 64:
        raise ValueError("pixelate_block должен быть в диапазоне 2..64")

    rects = _clip_rects(image.width, image.height, regions)
    if not rects:
        return image

    channels = image.channels
    stride = image.width * channels
    orig = image.data
    out = bytearray(orig)
    for rect in rects:
        x0, y0, w, h = rect
        if style is MaskStyle.BLACK or (
            style is MaskStyle.BLUR and w * h > MAX_BLUR_PIXELS
        ):
            _fill_rect(out, stride, channels, rect, b"\x00" * channels)
        elif style is MaskStyle.BLUR:
            _blur_rect(orig, out, stride, channels, rect, blur_radius)
        else:
            _pixelate_rect(orig, out, stride, channels, rect, pixelate_block)
    return OCRImage(image.width, image.height, bytes(out), image.mode)


# ---------------------------------------------------------------------------
# Секреты в тексте
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class TextSecret:
    """Найденный секрет в тексте: категория и границы подстроки."""

    kind: SensitiveKind
    start: int
    end: int

    def __post_init__(self) -> None:
        if not isinstance(self.kind, SensitiveKind):
            raise ValueError("kind должен быть SensitiveKind")
        if not isinstance(self.start, int) or not isinstance(self.end, int):
            raise ValueError("start/end должны быть int")
        if self.start < 0 or self.end <= self.start:
            raise ValueError("границы секрета некорректны (0 <= start < end)")


_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,24}")
_CARD_RE = re.compile(r"(?<!\d)\d(?:[ -]?\d){12,18}(?!\d)")
_PHONE_RE = re.compile(r"(?<![\d+])\+?\d(?:[ ()-]?\d){9,14}(?!\d)")
_ASSIGN_RE = re.compile(
    r"(?i)(?<![A-Za-zА-Яа-яЁё])"
    r"(пароль|password|passwd|pwd|pin[- ]?код|pin|секрет|secret|token|токен|"
    r"ключ api|api key|ключ|key|cvv|cvc)\s*[:=]\s*([^\s,;]+)"
)

#: ключи _ASSIGN_RE → категория секрета
_ASSIGN_KINDS: dict[str, SensitiveKind] = {
    "пароль": SensitiveKind.PASSWORD,
    "password": SensitiveKind.PASSWORD,
    "passwd": SensitiveKind.PASSWORD,
    "pwd": SensitiveKind.PASSWORD,
    "pin": SensitiveKind.PASSWORD,
    "pin-код": SensitiveKind.PASSWORD,
    "pin код": SensitiveKind.PASSWORD,
    "секрет": SensitiveKind.SECRET,
    "secret": SensitiveKind.SECRET,
    "token": SensitiveKind.SECRET,
    "токен": SensitiveKind.SECRET,
    "ключ": SensitiveKind.SECRET,
    "key": SensitiveKind.SECRET,
    "api key": SensitiveKind.SECRET,
    "ключ api": SensitiveKind.SECRET,
    "cvv": SensitiveKind.CARD,
    "cvc": SensitiveKind.CARD,
}


def _luhn_ok(digits: str) -> bool:
    """Проверка контрольной суммы Луна (номера карт)."""
    total = 0
    for i, ch in enumerate(reversed(digits)):
        d = int(ch)
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def find_text_secrets(text: str) -> tuple[TextSecret, ...]:
    """
    Ищет секреты в тексте: email, карты (13..19 цифр + Лун), телефоны,
    присваивания вида «пароль: значение».

    Пересечения разрешаются в пользу более раннего и более длинного совпадения.
    Возвращает кортеж ``TextSecret`` по возрастанию ``start``.
    """
    if not isinstance(text, str):
        raise ValueError("text должен быть str")
    candidates: list[TextSecret] = []

    for m in _ASSIGN_RE.finditer(text):
        label = normalize_text(m.group(1))
        kind = _ASSIGN_KINDS.get(label, SensitiveKind.SECRET)
        candidates.append(TextSecret(kind, m.start(2), m.end(2)))

    for m in _EMAIL_RE.finditer(text):
        candidates.append(TextSecret(SensitiveKind.EMAIL, m.start(), m.end()))

    for m in _CARD_RE.finditer(text):
        digits = re.sub(r"\D", "", m.group())
        if 13 <= len(digits) <= 19 and _luhn_ok(digits):
            candidates.append(TextSecret(SensitiveKind.CARD, m.start(), m.end()))

    for m in _PHONE_RE.finditer(text):
        digits = re.sub(r"\D", "", m.group())
        if 10 <= len(digits) <= 15:
            candidates.append(TextSecret(SensitiveKind.PHONE, m.start(), m.end()))

    candidates.sort(key=lambda s: (s.start, -(s.end - s.start)))
    picked: list[TextSecret] = []
    occupied_end = -1
    for secret in candidates:
        if secret.start < occupied_end:
            continue
        picked.append(secret)
        occupied_end = secret.end
    return tuple(picked)


def redact_text(text: str) -> str:
    """
    Заменяет найденные секреты токенами (``[ПАРОЛЬ]``, ``[EMAIL]`` …).

    Текст без секретов возвращается без изменений.
    """
    secrets = find_text_secrets(text)
    if not secrets:
        return text
    parts: list[str] = []
    pos = 0
    for secret in secrets:
        parts.append(text[pos : secret.start])
        parts.append(REDACTION_TOKENS[secret.kind])
        pos = secret.end
    parts.append(text[pos:])
    return "".join(parts)


# ---------------------------------------------------------------------------
# Поиск парольных полей по OCR
# ---------------------------------------------------------------------------
#: нормализованные подписи → категория (парольные поля и не только)
_LABEL_KINDS: dict[str, SensitiveKind] = {
    "пароль": SensitiveKind.PASSWORD,
    "password": SensitiveKind.PASSWORD,
    "passwd": SensitiveKind.PASSWORD,
    "pwd": SensitiveKind.PASSWORD,
    "pin": SensitiveKind.PASSWORD,
    "pin-код": SensitiveKind.PASSWORD,
    "pin код": SensitiveKind.PASSWORD,
    "секретный код": SensitiveKind.PASSWORD,
    "секрет": SensitiveKind.SECRET,
    "secret": SensitiveKind.SECRET,
    "token": SensitiveKind.SECRET,
    "токен": SensitiveKind.SECRET,
    "ключ": SensitiveKind.SECRET,
    "key": SensitiveKind.SECRET,
    "api key": SensitiveKind.SECRET,
    "ключ api": SensitiveKind.SECRET,
    "cvv": SensitiveKind.CARD,
    "cvc": SensitiveKind.CARD,
    "карта": SensitiveKind.CARD,
    "номер карты": SensitiveKind.CARD,
    "card": SensitiveKind.CARD,
    "card number": SensitiveKind.CARD,
    "email": SensitiveKind.EMAIL,
    "e-mail": SensitiveKind.EMAIL,
    "почта": SensitiveKind.EMAIL,
    "эмейл": SensitiveKind.EMAIL,
}

#: символы «замаскированного» значения (••••, ****, xxxx)
_MASKED_CHARS: frozenset[str] = frozenset("•●∗*·хxоo.")


def _label_key(text: str) -> str:
    """Нормализует подпись: без хвостовых «:.?!*…», ё→е, нижний регистр."""
    cleaned = text.strip().strip(":*.!?…•").strip()
    return normalize_text(cleaned)


def _is_masked_value(text: str) -> bool:
    """True, если текст похож на замаскированное значение (≥3 спец-символов)."""
    stripped = text.strip()
    return len(stripped) >= 3 and all(ch in _MASKED_CHARS for ch in stripped)


class SensitiveFieldDetector:
    """
    Ищет чувствительные поля по результату OCR.

    Две эвристики:
      1. подпись из ``_LABEL_KINDS`` («пароль», «PIN», «CVV» …) — регион
        подписи (опционально расширяется вправо на ``expand_right``) плюс
        ближайшее значение справа в пределах ``max_gap``;
      2. значение-«звёздочки» (``•••``, ``****``) — сразу SECRET.
    """

    def __init__(
        self,
        *,
        max_gap: int = 40,
        expand_right: int = 0,
        max_regions: int = MAX_REGIONS,
    ) -> None:
        for name, value in (("max_gap", max_gap), ("expand_right", expand_right)):
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"{name} должен быть неотрицательным int")
        if isinstance(max_regions, bool) or not isinstance(max_regions, int):
            raise ValueError("max_regions должен быть int")
        if not 1 <= max_regions <= 1024:
            raise ValueError("max_regions должен быть в диапазоне 1..1024")
        self._max_gap = max_gap
        self._expand_right = expand_right
        self._max_regions = max_regions

    def detect(self, result: OCRResult) -> tuple[SensitiveRegion, ...]:
        """Возвращает чувствительные регионы по коробкам OCR (порядок — как в тексте)."""
        if not isinstance(result, OCRResult):
            raise ValueError("result должен быть OCRResult")
        boxes = list(result.boxes)
        regions: list[SensitiveRegion] = []
        claimed: set[int] = set()

        for i, box in enumerate(boxes):
            key = _label_key(box.text)
            kind = _LABEL_KINDS.get(key)
            if kind is None:
                if _is_masked_value(box.text):
                    claimed.add(i)
                    regions.append(
                        SensitiveRegion.from_box(box, kind=SensitiveKind.SECRET, label="•••")
                    )
                continue

            claimed.add(i)
            label = box.text.strip()
            box_right = box.x + box.width
            box_bottom = box.y + box.height
            width = box.width + self._expand_right
            regions.append(
                SensitiveRegion(box.x, box.y, max(1, width), max(1, box.height), kind, label)
            )
            # значение справа от подписи: первое незанятое в пределах max_gap
            for j, val in enumerate(boxes):
                if j in claimed or j == i:
                    continue
                gap = val.x - box_right
                if gap < 0 or gap > self._max_gap:
                    continue
                vertical = min(box_bottom, val.y + val.height) - max(box.y, val.y)
                if vertical <= 0:
                    continue
                claimed.add(j)
                regions.append(
                    SensitiveRegion.from_box(val, kind=kind, label=label)
                )
                break

        return tuple(regions[: self._max_regions])


# ---------------------------------------------------------------------------
# Фасад
# ---------------------------------------------------------------------------
class ScreenGuard:
    """
    Фасад приватности: детект → маскировка → (опционально) отдача в облако.

    ``protect_*`` всегда возвращают безопасные данные; ``prepare_for_cloud``
    дополнительно проверяет политику ``allow_cloud`` и бросает
    ``PrivacyBlocked``, если секреты есть, а облако не разрешено.
    """

    def __init__(
        self,
        policy: PrivacyPolicy | None = None,
        detector: SensitiveFieldDetector | None = None,
    ) -> None:
        self._policy = policy or default_privacy_policy()
        self._detector = detector or SensitiveFieldDetector(
            max_regions=self._policy.max_regions
        )

    @property
    def policy(self) -> PrivacyPolicy:
        """Текущая политика приватности."""
        return self._policy

    def detect(self, result: OCRResult) -> tuple[SensitiveRegion, ...]:
        """Регионы из OCR-результата, отфильтрованные по ``policy.mask_kinds``."""
        return tuple(
            r for r in self._detector.detect(result) if r.kind in self._policy.mask_kinds
        )

    def _mask(
        self,
        image: OCRImage,
        regions: Sequence[SensitiveRegion],
    ) -> OCRImage:
        return mask_image(
            image,
            regions,
            style=self._policy.style,
            blur_radius=self._policy.blur_radius,
            pixelate_block=self._policy.pixelate_block,
        )

    def protect_image(
        self,
        image: OCRImage,
        *,
        result: OCRResult | None = None,
        extra_regions: Sequence[SensitiveRegion] = (),
    ) -> tuple[OCRImage, tuple[SensitiveRegion, ...]]:
        """
        Маскирует чувствительные регионы в растре.

        ``result`` — OCR-результат для эвристики парольных полей (опционально),
        ``extra_regions`` — явные регионы (например настроенные вручную).
        Возвращает (защищённый растр, применённые регионы).
        """
        if not isinstance(image, OCRImage):
            raise ValueError("image должен быть OCRImage")
        regions: list[SensitiveRegion] = []
        if result is not None:
            regions.extend(self.detect(result))
        for reg in extra_regions:
            if not isinstance(reg, SensitiveRegion):
                raise ValueError("extra_regions должен содержать SensitiveRegion")
            if reg.kind in self._policy.mask_kinds:
                regions.append(reg)
        regions = regions[: self._policy.max_regions]
        return self._mask(image, regions), tuple(regions)

    def protect_frame(
        self,
        frame: ScreenFrame,
        *,
        extra_regions: Sequence[SensitiveRegion] = (),
    ) -> tuple[ScreenFrame, tuple[SensitiveRegion, ...]]:
        """
        Маскирует регионы в кадре ``ScreenFrame`` (координаты — локальные).

        Возвращает (защищённый кадр с теми же метаданными, применённые регионы).
        """
        if not isinstance(frame, ScreenFrame):
            raise ValueError("frame должен быть ScreenFrame")
        image = OCRImage.from_frame(frame, gray=False)
        masked, regions = self.protect_image(image, extra_regions=extra_regions)
        return replace(frame, pixels=masked.data), regions

    def protect_text(self, text: str) -> str:
        """Маскирует секреты в тексте (согласно ``policy.redact_text``)."""
        if not isinstance(text, str):
            raise ValueError("text должен быть str")
        return redact_text(text) if self._policy.redact_text else text

    def prepare_for_cloud(
        self,
        image: OCRImage,
        *,
        result: OCRResult | None = None,
        extra_regions: Sequence[SensitiveRegion] = (),
    ) -> tuple[OCRImage, tuple[SensitiveRegion, ...]]:
        """
        Готовит растр к отправке в облако.

        Секреты найдены и ``policy.allow_cloud=False`` → ``PrivacyBlocked``.
        Секреты найдены и облако разрешено → растр маскируется (наружу уходит
        только безопасная версия). Секретов нет → растр без изменений.
        """
        protected, regions = self.protect_image(
            image, result=result, extra_regions=extra_regions
        )
        if regions and not self._policy.allow_cloud:
            raise PrivacyBlocked(
                f"наружу не отправляем: найдено секретов {len(regions)}, "
                "allow_cloud=False"
            )
        return (protected if regions else image), regions

    def prepare_text_for_cloud(self, text: str) -> str:
        """Готовит текст к отправке в облако (та же логика, что у ``prepare_for_cloud``)."""
        if not isinstance(text, str):
            raise ValueError("text должен быть str")
        secrets = find_text_secrets(text)
        if secrets and not self._policy.allow_cloud:
            raise PrivacyBlocked(
                f"наружу не отправляем: найдено секретов {len(secrets)}, "
                "allow_cloud=False"
            )
        return self.protect_text(text)

    def describe(self) -> dict[str, object]:
        """Описание для UI/диагностики (без содержимого секретов)."""
        return {
            "style": self._policy.style.value,
            "mask_kinds": sorted(k.value for k in self._policy.mask_kinds),
            "redact_text": self._policy.redact_text,
            "allow_cloud": self._policy.allow_cloud,
        }
