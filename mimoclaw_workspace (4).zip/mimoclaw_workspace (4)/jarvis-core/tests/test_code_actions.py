"""
Проверка actions/code_actions.py.

Запуск:  python3 tests/test_code_actions.py
"""

from __future__ import annotations

import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from actions.code_actions import (
    LANGUAGE_ALIASES,
    MAX_OUTPUT,
    SCRIPT_INTERPRETERS,
    CodeActions,
    CodeError,
    CodeRunResult,
    CodeTimeout,
    CodeUnavailable,
    DryRunCodeBackend,
    ProcResult,
    SubprocessCodeBackend,
    register_code_actions,
    validate_args,
    validate_code,
    validate_language,
    validate_limit,
    validate_repo_dir,
    validate_script_path,
    validate_timeout,
)
from actions.registry import CommandRegistry, RiskLevel


def _tmp_script(suffix: str, content: str) -> str:
    """Создаёт временный скрипт и возвращает путь (для validate/run_script)."""
    fd, name = tempfile.mkstemp(suffix=suffix)
    with open(fd, "w", encoding="utf-8") as fh:
        fh.write(content)
    return name


# ---------------------------------------------------------------------------
# Валидация
# ---------------------------------------------------------------------------
def test_validators() -> None:
    # язык
    assert validate_language("python") == "python"
    assert validate_language(" Py ") == "python"
    assert validate_language("python3") == "python"
    assert set(LANGUAGE_ALIASES.values()) == {"python"}
    for bad in ["js", "", None, 42, ["python"]]:
        try:
            validate_language(bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"язык {bad!r} должен быть отклонён")

    # код
    assert validate_code("print(1)") == "print(1)"
    for bad in ["", "   ", 42, None, "x\x00y", "a" * 300_000]:
        try:
            validate_code(bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"код {bad!r} должен быть отклонён")

    # таймаут
    assert validate_timeout(30) == 30.0
    assert validate_timeout("1.5") == 1.5
    for bad in [0, -5, 1000, True, "abc", None, [1]]:
        try:
            validate_timeout(bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"таймаут {bad!r} должен быть отклонён")

    # лимит git-лога
    assert validate_limit(10) == 10
    assert validate_limit("5") == 5
    for bad in [0, 101, 1.5, True, "x", None]:
        try:
            validate_limit(bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"лимит {bad!r} должен быть отклонён")
    print("  ✓ validators: язык/код/таймаут/лимит — валидные принимаются, мусор — нет")


def test_validate_script_path_and_args() -> None:
    assert set(SCRIPT_INTERPRETERS) >= {".py", ".sh"}
    path = _tmp_script(".py", "print('ok')\n")
    try:
        assert validate_script_path(path) == path
        for bad in [
            42, None, "", "   ",
            "-evil.py",                 # ведущий дефис → инъекция опций
            "a\x00b.py",                # управляющий символ
            "script.js",                # расширение вне allow-list
            "script",                   # без расширения
            "/нет/такого/файла.py",     # не существует
        ]:
            try:
                validate_script_path(bad)
            except ValueError:
                pass
            else:
                raise AssertionError(f"путь {bad!r} должен быть отклонён")

        # аргументы
        assert validate_args(None) == []
        assert validate_args(["a", "--flag", "буквы юникода"]) == ["a", "--flag", "буквы юникода"]
        for bad in [["a", 42], "строка", {"x": 1}, [""], ["a" * 5000], ["a\x00b"], [chr(7)]]:
            try:
                validate_args(bad)
            except ValueError:
                pass
            else:
                raise AssertionError(f"аргументы {bad!r} должны быть отклонены")
    finally:
        Path(path).unlink(missing_ok=True)

    # cwd репозитория
    assert validate_repo_dir(".") == "."
    for bad in [42, None, "", "-x", "a\x00b", "/нет/такой/папки"]:
        try:
            validate_repo_dir(bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"cwd {bad!r} должен быть отклонён")
    print("  ✓ validate_script_path/args/repo_dir: allow-list расширений и антиинъекция")


# ---------------------------------------------------------------------------
# Результат и обрезка вывода
# ---------------------------------------------------------------------------
def test_run_result_truncation() -> None:
    res = CodeRunResult("python", 0, "out", "err", 5)
    assert res.describe() == {
        "language": "python", "exit_code": 0, "stdout": "out", "stderr": "err",
        "duration_ms": 5, "timed_out": False, "truncated": False,
    }
    big = SubprocessCodeBackend(runner=lambda argv, t, cwd: ProcResult(0, "x" * (MAX_OUTPUT + 100), ""))
    out = big.run_python("print('x')", 5.0)
    assert out.truncated is True
    assert len(out.stdout) < MAX_OUTPUT + 100 and "обрезан" in out.stdout
    print("  ✓ CodeRunResult.describe и обрезка вывода до MAX_OUTPUT")


# ---------------------------------------------------------------------------
# DryRun-исполнитель и служба
# ---------------------------------------------------------------------------
def test_dry_run_actions() -> None:
    backend = DryRunCodeBackend()
    svc = CodeActions(backend=backend)

    r1 = svc.run_code("print(1)")
    assert r1["exit_code"] == 0 and "dry-run" in r1["stdout"]
    script = _tmp_script(".py", "print('ok')\n")
    try:
        r2 = svc.run_script(script, ["a"])
        assert r2["exit_code"] == 0
    finally:
        Path(script).unlink(missing_ok=True)
    assert svc.git_status(".")["status"] == "M main.py"
    assert svc.git_diff(".")["diff"] == "(пусто)"
    assert svc.git_log(".", 3)["log"] == "abc123 init"
    assert [c[0] for c in backend.calls] == [
        "run_python", "run_script", "git_status", "git_diff", "git_log",
    ]
    assert backend.calls[1][1][1] == ("a",)

    # недоступный backend → контролируемая ошибка
    svc_off = CodeActions(backend=DryRunCodeBackend(available=False))
    try:
        svc_off.run_code("print(1)")
    except CodeUnavailable:
        pass
    else:
        raise AssertionError("недоступный backend должен давать CodeUnavailable")
    print("  ✓ DryRun: вызовы пишутся в журнал, недоступность → CodeUnavailable")


# ---------------------------------------------------------------------------
# Реальный subprocess: Python-код, скрипты, таймаут
# ---------------------------------------------------------------------------
def test_subprocess_python() -> None:
    backend = SubprocessCodeBackend()
    ok = backend.run_python("print(2 + 2)", 30.0)
    assert ok.exit_code == 0 and ok.stdout.strip() == "4" and not ok.timed_out

    fail = backend.run_python("import sys; print('ошибка', file=sys.stderr); sys.exit(3)", 30.0)
    assert fail.exit_code == 3 and "ошибка" in fail.stderr

    timed = backend.run_python("import time; time.sleep(10)", 0.3)
    assert timed.timed_out is True and timed.exit_code == -1
    assert "таймаут" in timed.stderr
    print("  ✓ subprocess: print(2+2)→4, exit_code из процесса, таймаут → timed_out")


def test_subprocess_script() -> None:
    py = _tmp_script(".py", "import sys; print(','.join(sys.argv[1:]))\n")
    try:
        backend = SubprocessCodeBackend()
        res = backend.run_script(py, ["один", "два"], 30.0)
        assert res.exit_code == 0 and res.stdout.strip() == "один,два"
        assert res.language == "py"
    finally:
        Path(py).unlink(missing_ok=True)

    if shutil.which("bash"):
        sh = _tmp_script(".sh", "#!/bin/bash\necho \"скрипт:$1\"\n")
        try:
            res = SubprocessCodeBackend().run_script(sh, ["hi"], 30.0)
            assert res.exit_code == 0 and res.stdout.strip() == "скрипт:hi"
            assert res.language == "sh"
        finally:
            Path(sh).unlink(missing_ok=True)
    print("  ✓ subprocess: .py через интерпретатор Python, .sh через bash")


def test_default_runner_errors() -> None:
    from actions.code_actions import _default_runner

    try:
        _default_runner(["нет-такой-утилиты-xyz"], 5.0, None)
    except CodeUnavailable:
        pass
    else:
        raise AssertionError("отсутствующий бинарь → CodeUnavailable")

    if shutil.which("sleep"):
        try:
            _default_runner(["sleep", "5"], 0.2, None)
        except CodeTimeout:
            pass
        else:
            raise AssertionError("зависание → CodeTimeout")
    print("  ✓ _default_runner: нет бинаря → CodeUnavailable, зависание → CodeTimeout")


# ---------------------------------------------------------------------------
# Git-помощники (фиксированный argv, cwd, ошибки)
# ---------------------------------------------------------------------------
def test_git_helpers() -> None:
    seen: list[tuple[list[str], str | None]] = []

    def fake_runner(argv: list[str], timeout: float, cwd: str | None) -> ProcResult:
        seen.append((list(argv), cwd))
        if argv[:2] == ["git", "status"]:
            return ProcResult(0, "M main.py\n", "")
        if argv[:1] == ["git"] and argv[1] == "diff":
            return ProcResult(0, "" if "--staged" in argv else "--- a\n+++ b\n", "")
        return ProcResult(0, "abc123 init\ndef456 вторая\n", "")

    backend = SubprocessCodeBackend(runner=fake_runner)
    assert backend.git_status("/repo") == "M main.py"
    assert seen[-1] == (["git", "status", "--short"], "/repo")
    assert backend.git_diff("/repo", staged=False) == "--- a\n+++ b"
    assert seen[-1][0] == ["git", "diff"]
    assert backend.git_diff("/repo", staged=True) == "(пусто)"
    assert seen[-1][0] == ["git", "diff", "--staged"]
    assert backend.git_log("/repo", 5).startswith("abc123")
    assert seen[-1][0] == ["git", "log", "--oneline", "-n", "5"]
    assert all(cwd == "/repo" for _, cwd in seen)

    # git завершился ошибкой (не репозиторий)
    def failing_runner(argv: list[str], timeout: float, cwd: str | None) -> ProcResult:
        return ProcResult(128, "", "fatal: not a git repository")

    try:
        SubprocessCodeBackend(runner=failing_runner).git_status("/repo")
    except CodeError as e:
        assert "128" in str(e)
    else:
        raise AssertionError("ошибка git должна давать CodeError")
    print("  ✓ git: фиксированный argv, cwd пробрасывается, ошибки → CodeError")


# ---------------------------------------------------------------------------
# Регистрация команд
# ---------------------------------------------------------------------------
def test_register_commands() -> None:
    reg = CommandRegistry()
    names = register_code_actions(reg, CodeActions(backend=DryRunCodeBackend()))
    assert names == ["run_code", "run_script", "git_status", "git_diff", "git_log"]
    assert sorted(reg.names()) == sorted(names)

    run = reg.get("run_code")
    assert run is not None
    assert run.risk == RiskLevel.HIGH and run.requires_confirmation is True
    tool = run.to_tool()
    assert [p.name for p in tool.params] == ["code", "language", "timeout"]
    assert tool.params[0].required is True
    assert tool.params[1].required is False and tool.params[1].enum is not None

    script = reg.get("run_script")
    assert script is not None
    assert script.risk == RiskLevel.HIGH and script.requires_confirmation is True
    assert [p.name for p in script.to_tool().params] == ["path", "args", "timeout"]

    for safe in ("git_status", "git_diff", "git_log"):
        cmd = reg.get(safe)
        assert cmd is not None
        assert cmd.risk == RiskLevel.SAFE and cmd.requires_confirmation is False

    # инструменты попадают в function calling
    assert {t.name for t in reg.enabled_tools()} == set(names)
    print("  ✓ register: 5 команд, риски/подтверждения и схемы для LLM верны")


def main() -> int:
    print("JARVIS CORE — проверка code_actions")
    try:
        test_validators()
        test_validate_script_path_and_args()
        test_run_result_truncation()
        test_dry_run_actions()
        test_subprocess_python()
        test_subprocess_script()
        test_default_runner_errors()
        test_git_helpers()
        test_register_commands()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки code_actions прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
