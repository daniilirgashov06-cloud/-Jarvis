"""
Режимы приватности памяти JARVIS CORE: INCOGNITO / ЛОКАЛЬНО / обычный.

Модуль — единая точка приватности для «вечной памяти»: решает, можно ли
писать на диск, можно ли выгружать данные и можно ли отправлять их в облако.
Собирает воедино то, что размазано по `memory/store.py` и `memory/profile.py`:
переключение режимов, экспорт всех данных и «забудь всё».

Режимы (``memory.store.PrivacyMode``):
  - ``NORMAL``    — всё как обычно: память на диск, экспорт разрешён,
    отправка контекста в облачные LLM разрешена;
  - ``LOCAL``     — данные не покидают устройство: пишем на локальный диск,
    экспорт только в локальные файлы, облако запрещено;
  - ``INCOGNITO`` — ничего не сохраняется: новые записи живут в сессионном
    буфере в оперативной памяти (старые записи на диске не трогаем — для
    их удаления есть «забудь всё»), экспорт запрещён (``PrivacyError``),
    облако запрещено, выход из режима сбрасывает буфер.

Компоненты:
  - ``PrivacySettings`` — режим + политика экспорта (маскировка секретов,
    включение профиля) с валидацией;
  - ``PrivacyController`` — фасад: маршрутизация записей по режиму
    (``add``/``remember``), гейты ``can_persist``/``can_export``/
    ``can_send_to_cloud``, единый экспорт памяти + профиля в json/jsonl
    (атомарно, с маскировкой секретов), «забудь всё» (память + профиль +
    сессионный буфер), статус для панели;
  - ``ExportReport`` / ``ForgetReport`` — типизированные отчёты;
  - ``default_privacy_controller`` — сборка «локально-first»: SQLite-память
    с деградацией в память + JSON-профиль, в INCOGNITO — только память.

Локально-first: модуль ничего не отправляет по сети; облако он только
разрешает/запрещает (``can_send_to_cloud``) для внешних вызовов LLM.
"""

from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from memory.profile import JsonProfileStore, ProfileBuilder, ProfileError
from memory.store import (
    InMemoryMemoryStore,
    MemoryKind,
    MemoryRecord,
    MemoryStore,
    MemoryUnavailable,
    PrivacyError,
    PrivacyMode,
    default_memory_store,
)

logger = logging.getLogger(__name__)

#: метка формата экспорта
EXPORT_FORMAT = "jarvis-memory-export"
#: версия схемы экспорта
EXPORT_VERSION = 1

_MAX_PATH_LEN = 512
_CTRL_RE = re.compile(r"[\x00-\x1f\x7f]")
_FORBIDDEN_EXPORT_SUFFIXES = {".json", ".jsonl", ".ndjson"}


# ---------------------------------------------------------------------------
# Настройки
# ---------------------------------------------------------------------------
@dataclass
class PrivacySettings:
    """Политика приватности: режим + правила экспорта."""

    mode: PrivacyMode = PrivacyMode.NORMAL
    #: маскировать секреты (email/карты/телефоны/«пароль: …») при экспорте
    redact_exports: bool = True
    #: включать профиль пользователя в экспорт
    include_profile_in_export: bool = True

    def __post_init__(self) -> None:
        self.mode = _coerce_mode(self.mode)
        for name in ("redact_exports", "include_profile_in_export"):
            if not isinstance(getattr(self, name), bool):
                raise ValueError(f"{name} должен быть bool")


def _coerce_mode(value: Any) -> PrivacyMode:
    """Нормализовать режим приватности (строка → enum) с валидацией."""
    if isinstance(value, PrivacyMode):
        return value
    try:
        return PrivacyMode(str(value).strip().lower())
    except ValueError as exc:
        raise ValueError(f"неизвестный режим приватности: {value!r}") from exc


# ---------------------------------------------------------------------------
# Отчёты
# ---------------------------------------------------------------------------
@dataclass
class ExportReport:
    """Итог экспорта: что и куда выгружено."""

    path: str
    fmt: str
    memories: int
    profile_entries: int
    redacted: bool
    mode: str

    def to_dict(self) -> dict[str, Any]:
        """Сериализация в JSON-безопасный словарь."""
        return {
            "path": self.path,
            "fmt": self.fmt,
            "memories": self.memories,
            "profile_entries": self.profile_entries,
            "redacted": self.redacted,
            "mode": self.mode,
        }


@dataclass
class ForgetReport:
    """Итог «забудь всё»: сколько и чего удалено."""

    memories: int
    session: int
    profile: int

    @property
    def total(self) -> int:
        """Всего удалено записей."""
        return self.memories + self.session + self.profile

    def to_dict(self) -> dict[str, Any]:
        """Сериализация в JSON-безопасный словарь."""
        return {
            "memories": self.memories,
            "session": self.session,
            "profile": self.profile,
            "total": self.total,
        }


# ---------------------------------------------------------------------------
# Контроллер
# ---------------------------------------------------------------------------
class PrivacyController:
    """
    Единая точка приватности памяти: режимы, экспорт, «забудь всё».

    Все записи идут через ``add``/``remember`` — в ``INCOGNITO`` они
    попадают только в сессионный буфер (``session_records``), на диск не
    пишутся и не экспортируются. Хранилище и профиль передаются снаружи
    (dependency injection) — модуль сам их не создаёт, кроме фабрики
    ``default_privacy_controller``.

    Внимание: обучение профиля (``ProfileBuilder.learn_from_text``) может
    сохранять профиль самостоятельно; чтобы не писать на диск в обход
    политики, сохраняйте профиль через ``save_profile()`` контроллера.
    """

    def __init__(
        self,
        *,
        store: MemoryStore | None = None,
        profile: ProfileBuilder | None = None,
        settings: PrivacySettings | None = None,
    ) -> None:
        if settings is not None and not isinstance(settings, PrivacySettings):
            raise ValueError("settings: ожидается PrivacySettings")
        if profile is not None and not isinstance(profile, ProfileBuilder):
            raise ValueError("profile: ожидается ProfileBuilder")
        self._store = store
        self._profile = profile
        self._settings = settings or PrivacySettings()
        # Сессионный буфер INCOGNITO: только оперативная память, без экспорта
        self._session = InMemoryMemoryStore(privacy_mode=PrivacyMode.INCOGNITO)

    # -- режим и гейты -----------------------------------------------------
    @property
    def mode(self) -> PrivacyMode:
        """Текущий режим приватности."""
        return self._settings.mode

    @property
    def settings(self) -> PrivacySettings:
        """Текущая политика (копия не создаётся — читайте как конфигурацию)."""
        return self._settings

    def can_persist(self) -> bool:
        """Можно ли сохранять новые записи на диск (False в INCOGNITO)."""
        return self._settings.mode is not PrivacyMode.INCOGNITO

    def can_export(self) -> bool:
        """Можно ли выгружать данные в файл (False в INCOGNITO)."""
        return self._settings.mode is not PrivacyMode.INCOGNITO

    def can_send_to_cloud(self) -> bool:
        """Можно ли отправлять контекст в облако (только NORMAL)."""
        return self._settings.mode is PrivacyMode.NORMAL

    def set_mode(self, mode: Any, *, carry_session: bool = False) -> PrivacyMode:
        """
        Переключить режим приватности.

        Сессионный буфер (записи, сделанные в ``INCOGNITO``) по умолчанию
        сбрасывается — в этом смысл инкогнито: следов не остаётся. Если
        ``carry_session=True`` и новый режим разрешает персистентность,
        буфер переносится в основное хранилище (явное решение пользователя
        «сохранить то, что накопилось»).
        """
        new_mode = _coerce_mode(mode)
        old_mode = self._settings.mode
        if old_mode is PrivacyMode.INCOGNITO and new_mode is not PrivacyMode.INCOGNITO:
            if carry_session and self._store is not None:
                moved = self._session.list_recent(limit=self._session.count() or 1)
                for record in moved:
                    self._store.add(record)
                logger.debug("сессионный буфер перенесён в хранилище: %d", len(moved))
            self._session.clear()
        self._settings.mode = new_mode
        self._sync_profile_mode(new_mode)
        logger.info("режим приватности: %s → %s", old_mode.value, new_mode.value)
        return new_mode

    def _sync_profile_mode(self, mode: PrivacyMode) -> None:
        """
        Синхронизировать режим профиля с режимом контроллера.

        ``ProfileBuilder`` фиксирует режим при сборке; чтобы фасад не
        расходился сам с собой, пробуем сменить режим и у профиля:
        сначала через публичный ``set_privacy_mode`` (если появится),
        затем — внутреннее поле ``ProfileBuilder``. Если не вышло,
        политика профиля остаётся заданной при сборке (без падения).
        """
        builder = self._profile
        if builder is None:
            return
        setter = getattr(builder, "set_privacy_mode", None)
        if callable(setter):
            setter(mode)
            return
        if hasattr(builder, "_privacy_mode"):
            setattr(builder, "_privacy_mode", mode)

    # -- записи ------------------------------------------------------------
    def add(self, record: MemoryRecord) -> MemoryRecord:
        """
        Запомнить запись с учётом режима.

        В ``INCOGNITO`` запись попадает в сессионный буфер (память процесса),
        иначе — в основное хранилище. Ошибка хранилища не роняет вызов при
        отсутствии хранилища — запись остаётся в сессии.
        """
        if not isinstance(record, MemoryRecord):
            raise ValueError("record: ожидается MemoryRecord")
        if self.can_persist() and self._store is not None:
            return self._store.add(record)
        return self._session.add(record)

    def remember(
        self,
        content: str,
        *,
        kind: MemoryKind = MemoryKind.FACT,
        tags: Iterable[str] = (),
        importance: float = 0.5,
        **meta: Any,
    ) -> MemoryRecord:
        """Создать и запомнить запись (валидация — как в ``MemoryRecord``)."""
        record = MemoryRecord(
            kind=kind,
            content=content,
            tags=tuple(tags),
            importance=importance,
            metadata=dict(meta) if meta else {},
        )
        return self.add(record)

    def session_records(self) -> list[MemoryRecord]:
        """Записи, сделанные в ``INCOGNITO`` (живут только в памяти процесса)."""
        return self._session.list_recent(limit=self._session.count() or 1)

    # -- профиль -----------------------------------------------------------
    @property
    def profile(self) -> ProfileBuilder | None:
        """Фасад профиля пользователя (если задан)."""
        return self._profile

    def save_profile(self) -> bool:
        """
        Сохранить профиль пользователя с учётом режима.

        В ``INCOGNITO`` на диск не пишет (возвращает ``False``); без
        профиля или без хранилища профиля — тоже ``False``.
        """
        if self._profile is None or not self.can_persist():
            return False
        return self._profile.save()

    def profile_text(self) -> str:
        """Компактное «досье» профиля для промпта LLM (пусто без профиля)."""
        return self._profile.to_prompt_text() if self._profile is not None else ""

    # -- экспорт -----------------------------------------------------------
    def export(
        self,
        path: str | Path,
        *,
        fmt: str = "json",
        include_profile: bool | None = None,
        redact: bool | None = None,
    ) -> ExportReport:
        """
        Выгрузить память (+ профиль) в локальный файл json/jsonl.

        В ``INCOGNITO`` запрещено (``PrivacyError``). Секреты (email, карты,
        телефоны, «пароль: значение») маскируются, если ``redact`` (по
        умолчанию — из ``PrivacySettings.redact_exports``). Запись атомарная
        (через tmp-файл), путь валидируется как в ``memory/store.py``.
        """
        if not self.can_export():
            raise PrivacyError("экспорт запрещён в режиме INCOGNITO")
        if self._store is None:
            raise MemoryUnavailable("экспорт невозможен: не задано хранилище памяти")
        do_redact = self._settings.redact_exports if redact is None else bool(redact)
        do_profile = (
            self._settings.include_profile_in_export
            if include_profile is None
            else bool(include_profile)
        )

        records = self._store.list_recent(limit=max(self._store.count(), 1))
        memories: list[dict[str, Any]] = [r.to_dict() for r in records]
        profile_data: dict[str, Any] | None = None
        profile_entries = 0
        if do_profile and self._profile is not None:
            profile_data = self._profile.profile.to_dict()
            profile_entries = len(self._profile.profile)

        if do_redact:
            memories = [_redact_obj(m) for m in memories]
            if profile_data is not None:
                profile_data = _redact_obj(profile_data)

        payload: dict[str, Any] = {
            "format": EXPORT_FORMAT,
            "version": EXPORT_VERSION,
            "exported_at": time.time(),
            "privacy_mode": self._settings.mode.value,
            "redacted": do_redact,
            "memories": memories,
            "profile": profile_data,
        }
        _write_export_file(Path(path), payload, fmt=fmt)
        logger.debug("экспорт памяти: %d записей → %s", len(memories), path)
        return ExportReport(
            path=str(path),
            fmt=fmt.lower(),
            memories=len(memories),
            profile_entries=profile_entries,
            redacted=do_redact,
            mode=self._settings.mode.value,
        )

    # -- «забудь всё» ------------------------------------------------------
    def forget_all(self, *, include_profile: bool = True) -> ForgetReport:
        """
        «Забудь всё»: хранилище памяти, сессионный буфер и профиль.

        Работает во всех режимах (в ``INCOGNITO`` чистит буфер и профиль
        в памяти). Ошибка хранилища профиля не роняет вызов — удаление
        продолжается по остальному.
        """
        memories = self._store.clear() if self._store is not None else 0
        session = self._session.clear()
        profile = 0
        if include_profile and self._profile is not None:
            try:
                profile = self._profile.forget()
            except ProfileError as exc:  # pragma: no cover - хранилище профиля
                logger.warning("профиль не очищен полностью: %s", exc)
                profile = 0
        logger.info("«забудь всё»: память=%d сессия=%d профиль=%d", memories, session, profile)
        return ForgetReport(memories=memories, session=session, profile=profile)

    # -- статус ------------------------------------------------------------
    def status(self) -> dict[str, Any]:
        """Статус для панели (JSON-безопасно)."""
        store_kind = type(self._store).__name__ if self._store is not None else None
        return {
            "mode": self._settings.mode.value,
            "can_persist": self.can_persist(),
            "can_export": self.can_export(),
            "can_send_to_cloud": self.can_send_to_cloud(),
            "memories": self._store.count() if self._store is not None else 0,
            "session_records": self._session.count(),
            "profile_entries": len(self._profile.profile) if self._profile is not None else 0,
            "store": store_kind,
            "degraded": bool(getattr(self._store, "degraded", False)),
            "redact_exports": self._settings.redact_exports,
        }


# ---------------------------------------------------------------------------
# Маскировка секретов в экспорте
# ---------------------------------------------------------------------------
def _redact_obj(value: Any) -> Any:
    """Рекурсивно замаскировать секреты в строках словаря/списка."""
    if isinstance(value, str):
        return _redact_text(value)
    if isinstance(value, dict):
        return {k: _redact_obj(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact_obj(v) for v in value]
    return value


def _redact_text(text: str) -> str:
    """Маскировка секретов: переиспользуем ``vision.screen_awareness.redact_text``."""
    try:
        from vision.screen_awareness import redact_text
    except ImportError:  # pragma: no cover - vision недоступен, деградация без падения
        logger.debug("vision.screen_awareness недоступен — экспорт без маскировки")
        return text
    return redact_text(text)


# ---------------------------------------------------------------------------
# Запись экспорта (валидация пути/формата, атомарно — как в memory/store.py)
# ---------------------------------------------------------------------------
def _write_export_file(path: Path, payload: dict[str, Any], *, fmt: str) -> int:
    """Записать экспорт: json — целиком, jsonl — по объекту на строку.

    Возвращает количество записей памяти в выгрузке.
    """
    fmt = fmt.lower()
    if fmt not in {"json", "jsonl"}:
        raise ValueError(f"неподдерживаемый формат экспорта: {fmt}")
    name = path.name
    if not name or len(str(path)) > _MAX_PATH_LEN:
        raise ValueError("недопустимый путь экспорта")
    if name.startswith("-") or _CTRL_RE.search(name):
        raise ValueError("недопустимое имя файла экспорта")
    if path.suffix and path.suffix.lower() not in _FORBIDDEN_EXPORT_SUFFIXES:
        raise ValueError(f"недопустимое расширение экспорта: {path.suffix}")

    if fmt == "json":
        body = json.dumps(payload, ensure_ascii=False, indent=2)
    else:
        lines: list[str] = [
            json.dumps(
                {
                    "type": "meta",
                    "format": payload["format"],
                    "version": payload["version"],
                    "exported_at": payload["exported_at"],
                    "privacy_mode": payload["privacy_mode"],
                    "redacted": payload["redacted"],
                },
                ensure_ascii=False,
            )
        ]
        for mem in payload.get("memories", []):
            lines.append(json.dumps({"type": "memory", **mem}, ensure_ascii=False))
        profile = payload.get("profile") or {}
        for entry in profile.get("entries", []):
            lines.append(json.dumps({"type": "profile_entry", **entry}, ensure_ascii=False))
        body = "\n".join(lines) + ("\n" if lines else "")

    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + ".tmp")
        tmp.write_text(body, encoding="utf-8")
        tmp.replace(path)
    except OSError as exc:
        raise MemoryUnavailable(f"не удалось записать экспорт {path}: {exc}") from exc
    return len(payload.get("memories", []))


# ---------------------------------------------------------------------------
# Фабрика «локально-first»
# ---------------------------------------------------------------------------
def default_privacy_controller(
    db_path: str | Path = "data/jarvis.db",
    *,
    profile_path: str | Path = "data/profile.json",
    mode: Any = PrivacyMode.NORMAL,
    include_profile: bool = True,
) -> PrivacyController:
    """
    Собрать контроллер «локально-first»: SQLite-память + JSON-профиль.

    - хранилище — через ``default_memory_store`` (SQLite → деградация
      в память при недоступном диске);
    - профиль — ``ProfileBuilder`` поверх ``JsonProfileStore``;
    - в ``INCOGNITO`` диск не используется вообще: память — только в
      оперативной, профиль без хранилища (``store=None``).
    """
    resolved = _coerce_mode(mode)
    settings = PrivacySettings(mode=resolved, include_profile_in_export=include_profile)
    store = default_memory_store(db_path, privacy_mode=resolved)
    profile: ProfileBuilder | None = None
    if include_profile:
        if resolved is PrivacyMode.INCOGNITO:
            profile = ProfileBuilder(privacy_mode=resolved)
        else:
            profile = ProfileBuilder(
                store=JsonProfileStore(profile_path),
                privacy_mode=resolved,
            )
    return PrivacyController(store=store, profile=profile, settings=settings)
