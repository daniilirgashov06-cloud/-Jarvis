"""
Облачный LLM-провайдер Google Gemini.

Через Generative Language API ``/v1beta/models:generateContent``
с поддержкой function calling.
"""

from __future__ import annotations

from typing import Any

from .base import (
    BaseLLMProvider,
    LLMMessage,
    LLMResponse,
    ProviderError,
    ProviderUnavailable,
    ToolCall,
    Usage,
)

DEFAULT_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"


class GeminiProvider(BaseLLMProvider):
    """Провайдер Google Gemini."""

    name = "gemini"

    def __init__(
        self,
        model: str = "gemini-1.5-pro",
        api_key: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 60.0,
    ) -> None:
        self.model = model
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def is_available(self) -> bool:
        return bool(self.api_key)

    async def complete(
        self,
        messages: list[LLMMessage],
        tools: list[dict[str, Any]] | None = None,
        *,
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> LLMResponse:
        if not self.api_key:
            raise ProviderUnavailable("Gemini: не задан API-ключ")
        try:
            import httpx
        except ImportError as exc:  # pragma: no cover
            raise ProviderUnavailable("httpx не установлен") from exc

        system, contents = self._to_gemini_contents(messages)
        payload: dict[str, Any] = {
            "contents": contents,
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
            },
        }
        if system:
            payload["systemInstruction"] = {"parts": [{"text": system}]}
        if tools:
            payload["tools"] = self._to_gemini_tools(tools)

        url = f"{self.base_url}/models/{self.model}:generateContent"
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(
                    url,
                    json=payload,
                    params={"key": self.api_key},
                )
        except Exception as exc:  # noqa: BLE001
            raise ProviderUnavailable(f"Gemini недоступен: {exc}") from exc

        if resp.status_code in (401, 403):
            raise ProviderUnavailable(f"Gemini: авторизация отклонена ({resp.status_code})")
        if resp.status_code != 200:
            raise ProviderError(f"Gemini HTTP {resp.status_code}: {resp.text[:200]}")

        data = resp.json()
        content_text, tool_calls = self._parse_candidate(data)
        meta = data.get("usageMetadata", {}) or {}
        usage = Usage(
            prompt_tokens=int(meta.get("promptTokenCount", 0) or 0),
            completion_tokens=int(meta.get("candidatesTokenCount", 0) or 0),
        )
        return LLMResponse(
            content=content_text,
            tool_calls=tool_calls,
            usage=usage,
            provider=self.name,
            model=self.model,
            raw=data,
        )

    # -- конвертация --------------------------------------------------------
    @staticmethod
    def _to_gemini_contents(
        messages: list[LLMMessage],
    ) -> tuple[str, list[dict[str, Any]]]:
        system_parts: list[str] = []
        contents: list[dict[str, Any]] = []
        for m in messages:
            if m.role == "system":
                system_parts.append(m.content)
                continue
            role = "model" if m.role == "assistant" else "user"
            parts: list[dict[str, Any]] = []
            if m.content:
                parts.append({"text": m.content})
            for tc in m.tool_calls:
                parts.append(
                    {"functionCall": {"name": tc.name, "args": tc.arguments}}
                )
            if m.role == "tool":
                parts = [
                    {
                        "functionResponse": {
                            "name": m.name or "tool",
                            "response": {"content": m.content},
                        }
                    }
                ]
                role = "user"
            contents.append({"role": role, "parts": parts})
        return "\n".join(system_parts), contents

    @staticmethod
    def _to_gemini_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        decls: list[dict[str, Any]] = []
        for t in tools:
            fn = t.get("function", t)
            decls.append(
                {
                    "name": fn.get("name", ""),
                    "description": fn.get("description", ""),
                    "parameters": fn.get("parameters", {"type": "object", "properties": {}}),
                }
            )
        return [{"functionDeclarations": decls}]

    @staticmethod
    def _parse_candidate(data: dict[str, Any]) -> tuple[str, list[ToolCall]]:
        candidates = data.get("candidates") or [{}]
        content = candidates[0].get("content", {}) or {}
        text_parts: list[str] = []
        calls: list[ToolCall] = []
        for i, part in enumerate(content.get("parts", []) or []):
            if "text" in part:
                text_parts.append(part["text"])
            if "functionCall" in part:
                fc = part["functionCall"]
                calls.append(
                    ToolCall(
                        id=f"call_{i}",
                        name=fc.get("name", ""),
                        arguments=fc.get("args", {}) or {},
                    )
                )
        return "\n".join(text_parts), calls

    def describe(self) -> dict[str, Any]:
        return {**super().describe(), "model": self.model}
