"""
Команды приложений JARVIS CORE (ТЗ-6, каталог app).

Команды уровня «приложения»: запуск, фокус окна, закрытие приложений,
список запущенных процессов. Каждая команда имеет уровень риска
(``RiskLevel``) и регистрируется в ``CommandRegistry``, откуда она
попадает в схемы function calling для LLM.

Архитектура (в стиле ``actions/system_actions.py``):

- ``AppBackend`` — контракт «исполнитель» операций над приложениями;
- ``SubprocessAppBackend`` — локальная реализация через subprocess
  (Linux / macOS / Windows), команды строятся под платформу;
- ``DryRunBackend`` — безопасный fallback/отладка: ничего не запускает,
  только записывает операции (используется и в тестах);
- ``AppCatalog`` — словарь дружественных имён («браузер» → firefox…).

«Локально ↔ облако» здесь неприменимо: все операции локальные.
При недоступности исполнителя команда падает контролируемо
(``AppUnavailable``) без побочных эффектов.

Имена приложений проходят строгую валидацию (без shell-метасимволов
и ведущих дефисов), чтобы исключить инъекцию опций в argv.

Использование:
    from actions.registry import CommandRegistry
    from actions.app_actions import AppActions, register_app_actions

    registry = CommandRegistry()
    register_app_actions(registry)           # или со своим backend
"""

from __future__ import annotations

import abc
import logging
import platform
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Any, Callable

from actions.registry import REQUIRES_CONFIRMATION, Command, CommandRegistry, RiskLevel
from ai.function_calling import ParamSpec

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class AppError(Exception):
    """Ошибка команды приложения."""


class AppUnavailable(AppError):
    """Исполнитель недоступен (нет утилиты/прав) — можно fallback."""


class AppNotFound(AppError):
    """Приложение не найдено/не запущено."""


# ---------------------------------------------------------------------------
# Валидация имён
# ---------------------------------------------------------------------------
#: Допустимые символы в имени приложения (буквы, цифры, пробел, -._+())
_APP_NAME_RE = re.compile(r"^[A-Za-zА-Яа-яЁё0-9][A-Za-zА-Яа-яЁё0-9 _.\-+()]{0,63}$")


def validate_app_name(name: Any) -> str:
    """
    Проверяет имя приложения и возвращает его в нормализованном виде.

    Запрещены пустые имена, ведущие дефисы (инъекция опций в argv),
    shell-метасимволы и имена длиннее 64 символов.
    """
    if not isinstance(name, str):
        raise ValueError(f"имя приложения должно быть строкой, получено: {name!r}")
    cleaned = name.strip()
    if not cleaned:
        raise ValueError("имя приложения не может быть пустым")
    if cleaned.startswith("-"):
        raise ValueError(f"имя приложения не может начинаться с '-': {name!r}")
    if not _APP_NAME_RE.fullmatch(cleaned):
        raise ValueError(
            f"недопустимые символы в имени приложения: {name!r} "
            "(разрешены буквы, цифры, пробел, -._+())"
        )
    return cleaned


# ---------------------------------------------------------------------------
# Каталог дружественных имён
# ---------------------------------------------------------------------------
#: дружественное имя (lowercase) → каноническое имя процесса/приложения
DEFAULT_ALIASES: dict[str, str] = {
    "браузер": "firefox",
    "browser": "firefox",
    "файрфокс": "firefox",
    "firefox": "firefox",
    "хром": "google-chrome",
    "chrome": "google-chrome",
    "google chrome": "google-chrome",
    "редактор кода": "code",
    "vs code": "code",
    "vscode": "code",
    "code": "code",
    "терминал": "gnome-terminal",
    "terminal": "gnome-terminal",
    "проводник": "nautilus",
    "explorer": "explorer",
    "музыка": "spotify",
    "spotify": "spotify",
}


@dataclass
class AppCatalog:
    """Словарь дружественных имён приложений («браузер» → firefox)."""

    aliases: dict[str, str] = field(default_factory=lambda: dict(DEFAULT_ALIASES))

    def resolve(self, name: str) -> str:
        """Возвращает каноническое имя приложения (или исходное, если не алиас)."""
        cleaned = validate_app_name(name)
        return self.aliases.get(cleaned.lower(), cleaned)

    def add(self, alias: str, canonical: str) -> None:
        """Добавляет/обновляет алиас (оба имени валидируются)."""
        self.aliases[validate_app_name(alias).lower()] = validate_app_name(canonical)


# ---------------------------------------------------------------------------
# Контракт исполнителя
# ---------------------------------------------------------------------------
class AppBackend(abc.ABC):
    """Контракт исполнителя операций над приложениями."""

    name: str = "base"

    @abc.abstractmethod
    def is_available(self) -> bool: ...

    @abc.abstractmethod
    def launch(self, app: str) -> None: ...

    @abc.abstractmethod
    def close(self, app: str) -> None: ...

    @abc.abstractmethod
    def focus(self, app: str) -> None: ...

    @abc.abstractmethod
    def list_running(self) -> list[str]: ...

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "available": self.is_available()}


# ---------------------------------------------------------------------------
# Реальный исполнитель (subprocess)
# ---------------------------------------------------------------------------
#: Тип «запуск argv -> stdout» (подменяется в тестах)
Runner = Callable[[list[str]], str]


def _default_runner(argv: list[str]) -> str:
    """Выполняет argv и возвращает stdout; ошибки оборачивает в AppError."""
    try:
        proc = subprocess.run(  # noqa: S603 — argv формируем сами, shell=False
            argv,
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
    except FileNotFoundError as e:
        raise AppUnavailable(f"утилита не найдена: {argv[0]}") from e
    except subprocess.TimeoutExpired as e:
        raise AppError(f"таймаут команды: {' '.join(argv)}") from e
    if proc.returncode != 0:
        raise AppError(
            f"команда завершилась с кодом {proc.returncode}: {' '.join(argv)}"
            f" ({proc.stderr.strip()[:200]})"
        )
    return proc.stdout


@dataclass
class SubprocessAppBackend(AppBackend):
    """
    Локальный исполнитель: строит и выполняет команды под текущую ОС.

    runner подменяется в тестах; platform_name позволяет сымитировать
    другую платформу (linux / darwin / windows).
    """

    name: str = "subprocess"
    runner: Runner = field(default=_default_runner)
    platform_name: str = field(default_factory=platform.system)

    def _plat(self) -> str:
        return self.platform_name.lower()

    def is_available(self) -> bool:
        return self._plat() in {"linux", "darwin", "windows"}

    # -- запуск/закрытие ---------------------------------------------------
    def launch(self, app: str) -> None:
        plat = self._plat()
        if plat == "darwin":
            self.runner(["open", "-a", app])
        elif plat == "windows":
            self.runner(["powershell", "-NoProfile", "-Command",
                         f"Start-Process '{app}'"])
        else:
            # Linux: пробуем прямой запуск исполняемого файла
            self.runner([app])

    def close(self, app: str) -> None:
        plat = self._plat()
        if plat == "darwin":
            self.runner(["osascript", "-e", f'tell application "{app}" to quit'])
        elif plat == "windows":
            self.runner(["taskkill", "/IM", f"{app}.exe", "/F"])
        else:
            self.runner(["pkill", "-x", app])

    # -- фокус окна ---------------------------------------------------------
    def focus(self, app: str) -> None:
        plat = self._plat()
        if plat == "darwin":
            self.runner(["open", "-a", app])
        elif plat == "windows":
            self.runner(["powershell", "-NoProfile", "-Command",
                         f"(New-Object -ComObject WScript.Shell).AppActivate('{app}')"])
        else:
            if shutil.which("wmctrl"):
                self.runner(["wmctrl", "-a", app])
            elif shutil.which("xdotool"):
                self.runner(["xdotool", "search", "--name", app, "windowactivate"])
            else:
                raise AppUnavailable("нет wmctrl/xdotool для фокуса окна")

    # -- список запущенных ---------------------------------------------------
    def list_running(self) -> list[str]:
        plat = self._plat()
        if plat == "windows":
            out = self.runner(["tasklist", "/fo", "csv", "/nh"])
            names = []
            for line in out.splitlines():
                parts = line.strip().strip('"').split('","')
                if parts and parts[0]:
                    names.append(parts[0].removesuffix(".exe"))
        else:
            out = self.runner(["ps", "-A", "-o", "comm="])
            names = [line.strip() for line in out.splitlines() if line.strip()]
        return sorted(set(names))


# ---------------------------------------------------------------------------
# Безопасный исполнитель (fallback / отладка / тесты)
# ---------------------------------------------------------------------------
@dataclass
class DryRunBackend(AppBackend):
    """
    Ничего не запускает: записывает операции в ``calls``, поддерживает
    фиктивный список запущенных приложений. Используется в тестах.
    """

    name: str = "dry-run"
    available: bool = True
    running: set[str] = field(default_factory=lambda: {"terminal", "browser"})
    calls: list[tuple[str, tuple[Any, ...]]] = field(default_factory=list)

    def is_available(self) -> bool:
        return self.available

    def launch(self, app: str) -> None:
        self.calls.append(("launch", (app,)))
        self.running.add(app)

    def close(self, app: str) -> None:
        self.calls.append(("close", (app,)))
        self.running.discard(app)

    def focus(self, app: str) -> None:
        self.calls.append(("focus", (app,)))

    def list_running(self) -> list[str]:
        self.calls.append(("list_running", ()))
        return sorted(self.running)


# ---------------------------------------------------------------------------
# Служба команд приложений
# ---------------------------------------------------------------------------
@dataclass
class AppActions:
    """
    Служба команд приложений: валидация входа + резолв алиасов + backend.

    При недоступности backend операции падают контролируемо
    (``AppUnavailable``), без побочных эффектов.
    """

    backend: AppBackend = field(default_factory=SubprocessAppBackend)
    catalog: AppCatalog = field(default_factory=AppCatalog)

    def _require_backend(self) -> AppBackend:
        if not self.backend.is_available():
            raise AppUnavailable(f"исполнитель '{self.backend.name}' недоступен")
        return self.backend

    def _resolve(self, name: Any) -> str:
        """Валидация + резолв алиаса в каноническое имя."""
        return self.catalog.resolve(validate_app_name(name))

    # -- команды ------------------------------------------------------------
    def launch_app(self, name: str) -> str:
        """Запустить приложение (по имени или алиасу)."""
        app = self._resolve(name)
        self._require_backend().launch(app)
        logger.info("Запущено приложение: %s", app)
        return f"Запускаю {app}."

    def close_app(self, name: str) -> str:
        """Закрыть приложение (по имени процесса или алиасу)."""
        app = self._resolve(name)
        self._require_backend().close(app)
        logger.info("Закрыто приложение: %s", app)
        return f"Закрываю {app}."

    def focus_app(self, name: str) -> str:
        """Перевести окно приложения на передний план."""
        app = self._resolve(name)
        self._require_backend().focus(app)
        return f"Фокусирую окно {app}."

    def list_running_apps(self) -> list[str]:
        """Список запущенных приложений/процессов (по алфавиту)."""
        return self._require_backend().list_running()


# ---------------------------------------------------------------------------
# Регистрация команд в реестре
# ---------------------------------------------------------------------------
def _spec(name: str, type_: str, description: str, **kw: Any) -> ParamSpec:
    return ParamSpec(
        name=name,
        type=type_,
        description=description,
        required=kw.get("required", True),
        enum=kw.get("enum"),
        default=kw.get("default"),
    )


def register_app_actions(
    registry: CommandRegistry,
    actions: AppActions | None = None,
) -> list[str]:
    """
    Регистрирует команды приложений в ``registry`` (возвращает их имена).

    Уровни риска (ТЗ-6.7):
      - SAFE:   list_running_apps, focus_app
      - MEDIUM: launch_app, close_app (требуют подтверждения)
    """
    svc = actions or AppActions()

    defs: list[tuple[str, str, list[ParamSpec], str, Callable[..., Any]]] = [
        (
            "list_running_apps",
            "Список запущенных приложений и процессов",
            [],
            RiskLevel.SAFE,
            svc.list_running_apps,
        ),
        (
            "focus_app",
            "Вывести окно приложения на передний план",
            [_spec("name", "string", "имя приложения или алиас")],
            RiskLevel.SAFE,
            svc.focus_app,
        ),
        (
            "launch_app",
            "Запустить приложение по имени",
            [_spec("name", "string", "имя приложения или алиас")],
            RiskLevel.MEDIUM,
            svc.launch_app,
        ),
        (
            "close_app",
            "Закрыть приложение по имени (после подтверждения)",
            [_spec("name", "string", "имя приложения или алиас")],
            RiskLevel.MEDIUM,
            svc.close_app,
        ),
    ]

    names: list[str] = []
    for name, description, params, risk, handler in defs:
        registry.register(
            Command(
                name=name,
                description=description,
                params=params,
                handler=handler,
                risk=risk,
                requires_confirmation=REQUIRES_CONFIRMATION.get(risk, False),
            )
        )
        names.append(name)
    logger.debug("Зарегистрированы команды приложений: %s", ", ".join(names))
    return names
