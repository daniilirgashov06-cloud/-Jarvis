"""
Реестр команд JARVIS CORE.

Каждая команда описывается декоратором ``@command`` с именем, описанием,
параметрами и уровнем риска — так LLM автоматически получает схемы для
function calling, а ядро знает, требовать ли подтверждения.

Использование:
    from actions.registry import command, registry, RiskLevel

    @command(name="set_volume", description="Установить громкость",
             params={"level": {"type": "number", "description": "0..100"}},
             risk=RiskLevel.SAFE)
    def set_volume(level: float) -> str:
        ...
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable

from ai.function_calling import ParamSpec, Tool

logger = logging.getLogger(__name__)


class RiskLevel(str):
    """Уровни риска команд (см. ТЗ-6.7)."""

    SAFE = "safe"
    MEDIUM = "medium"
    HIGH = "high"
    FORBIDDEN = "forbidden"


# Какие уровни требуют подтверждения по умолчанию
REQUIRES_CONFIRMATION: dict[str, bool] = {
    RiskLevel.SAFE: False,
    RiskLevel.MEDIUM: True,
    RiskLevel.HIGH: True,
    RiskLevel.FORBIDDEN: True,  # и вовсе запрещено без явного whitelist
}


@dataclass
class Command:
    """Зарегистрированная команда (инструмент для LLM + обработчик)."""

    name: str
    description: str
    params: list[ParamSpec] = field(default_factory=list)
    handler: Callable[..., Any] | None = None
    risk: str = RiskLevel.SAFE
    enabled: bool = True
    requires_confirmation: bool = False

    def to_tool(self) -> Tool:
        """Конвертирует команду в инструмент для function calling."""
        return Tool(
            name=self.name,
            description=self.description,
            params=self.params,
            handler=self.handler,
            risk_level=self.risk,
        )

    async def run(self, **kwargs: Any) -> Any:
        """Выполнить команду с аргументами."""
        if self.handler is None:
            raise RuntimeError(f"У команды '{self.name}' нет обработчика")
        result = self.handler(**kwargs)
        # Поддержка async-обработчиков
        if hasattr(result, "__await__"):
            return await result  # type: ignore[misc]
        return result


class CommandRegistry:
    """Реестр всех команд приложения."""

    def __init__(self) -> None:
        self._commands: dict[str, Command] = {}

    def register(self, cmd: Command) -> Command:
        """Регистрирует команду (перезаписывает при дубликате имени)."""
        if cmd.name in self._commands:
            logger.warning("Команда '%s' перезаписана", cmd.name)
        self._commands[cmd.name] = cmd
        return cmd

    def get(self, name: str) -> Command | None:
        return self._commands.get(name)

    def all(self) -> list[Command]:
        return list(self._commands.values())

    def enabled_tools(self) -> list[Tool]:
        """Инструменты (для LLM) только по включённым командам."""
        return [c.to_tool() for c in self._commands.values() if c.enabled]

    def names(self) -> list[str]:
        return list(self._commands.keys())

    def clear(self) -> None:
        self._commands.clear()


# Глобальный реестр приложения
registry = CommandRegistry()


def command(
    name: str,
    description: str,
    params: dict[str, dict[str, Any]] | None = None,
    risk: str = RiskLevel.SAFE,
    requires_confirmation: bool | None = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """
    Декоратор регистрации команды.

    params: {имя: {"type", "description", "required", "enum", "default"}}
    risk: safe | medium | high | forbidden
    """
    specs = [
        ParamSpec(
            name=pname,
            type=pdata.get("type", "string"),
            description=pdata.get("description", ""),
            required=pdata.get("required", True),
            enum=pdata.get("enum"),
            default=pdata.get("default"),
        )
        for pname, pdata in (params or {}).items()
    ]
    confirm = (
        REQUIRES_CONFIRMATION.get(risk, False)
        if requires_confirmation is None
        else requires_confirmation
    )

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        registry.register(
            Command(
                name=name,
                description=description,
                params=specs,
                handler=fn,
                risk=risk,
                requires_confirmation=confirm,
            )
        )
        return fn

    return decorator
