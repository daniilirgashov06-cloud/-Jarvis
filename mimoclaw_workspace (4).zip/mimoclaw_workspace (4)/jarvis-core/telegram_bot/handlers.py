"""
Обработчики Telegram-бота JARVIS CORE (aiogram 3).

Слой над ``telegram_bot/bridge.py``: формирование ответов, инлайн-кнопки
подтверждения («ПОДТВЕРДИТЬ» / «ОТМЕНА»), whitelist chat_id и маршруты
(/start, /status, /screenshot, текст → оркестратор).

**Устойчивость к отсутствию aiogram**: модуль импортируется и без
aiogram — вся логика (``BotHandlers``, форматтеры, callback-кодек) работает
на чистом Python. Aiogram нужен только для реальной отправки сообщений:
``build_inline_keyboard`` / ``setup_handlers`` в таком случае бросают
``TelegramDependencyError`` с сообщением «aiogram не установлен».

Типовой сценарий (внутри bot.py)::

    handlers = BotHandlers(bridge=bridge, confirmations=conf,
                           whitelist=whitelist, status_provider=...)
    reply = handlers.start(chat_id, user_name="Тони")
    await message.answer(reply.text, parse_mode=reply.parse_mode)
"""

from __future__ import annotations

import html
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from telegram_bot.bridge import (
    CALLBACK_APPROVE,
    CALLBACK_CANCEL,
    AccessDenied,
    AccessLevel,
    ChatWhitelist,
    CommandBridge,
    ConfirmationManager,
    ConfirmationUnknown,
    PendingConfirmation,
    RiskLevel,
    decode_callback,
    requires_confirmation,
)

logger = logging.getLogger(__name__)

__all__ = [
    "AIOGRAM_AVAILABLE",
    "TelegramDependencyError",
    "require_aiogram",
    "ButtonSpec",
    "HandlerReply",
    "BotHandlers",
    "format_status",
    "format_confirmation",
    "build_inline_keyboard",
    "setup_handlers",
]


# ---------------------------------------------------------------------------
# Зависимость от aiogram (мягкая)
# ---------------------------------------------------------------------------
try:  # pragma: no cover - зависит от окружения
    import aiogram as _aiogram

    AIOGRAM_AVAILABLE: bool = True
except ImportError:  # pragma: no cover - зависит от окружения
    _aiogram = None
    AIOGRAM_AVAILABLE = False


class TelegramDependencyError(RuntimeError):
    """aiogram не установлен — работа с Telegram невозможна."""


def require_aiogram() -> Any:
    """
    Вернуть модуль ``aiogram`` или бросить понятную ошибку.

    Сообщение прямо говорит, что нужно установить: «aiogram не установлен».
    """
    if not AIOGRAM_AVAILABLE:
        raise TelegramDependencyError(
            "aiogram не установлен: выполните `pip install \"aiogram>=3.7\"`, "
            "чтобы включить Telegram-бота"
        )
    return _aiogram


# ---------------------------------------------------------------------------
# Ответ бота
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ButtonSpec:
    """Описание инлайн-кнопки (без привязки к aiogram)."""

    text: str
    callback_data: str


@dataclass(frozen=True)
class HandlerReply:
    """
    Ответ обработчика: текст + кнопки + вложение.

    ``attachment`` — ``bytes``/``Path`` для отправки файла (скриншот)
    или ``None`` для обычного текста.
    """

    text: str
    buttons: tuple[ButtonSpec, ...] = ()
    parse_mode: str | None = "HTML"
    attachment: bytes | Path | None = None
    attachment_caption: str = ""


def format_status(status: Mapping[str, Any]) -> str:
    """
    Красиво отформатировать статус системы для Telegram (HTML).

    Принимает словарь (например, ``HudState.snapshot()["status"]`` или
    произвольный mapping с ключами вида ``{"name": ..., "value": ...}``).
    """
    lines: list[str] = ["<b>📊 Статус системы</b>"]
    overall = str(status.get("overall", "")).upper()
    if overall:
        icon = {"OK": "🟢", "WARN": "🟡", "CRIT": "🔴"}.get(overall, "⚪")
        lines.append(f"{icon} Общий уровень: <b>{html.escape(overall)}</b>")
    items = status.get("items")
    if isinstance(items, Sequence) and not isinstance(items, (str, bytes)):
        for item in items:
            if not isinstance(item, Mapping):
                continue
            name = html.escape(str(item.get("name", "—")))
            value = html.escape(str(item.get("value", "")))
            unit = html.escape(str(item.get("unit", "")))
            level = str(item.get("level", "ok"))
            icon = {"ok": "🟢", "warn": "🟡", "crit": "🔴"}.get(level, "⚪")
            lines.append(f"{icon} {name}: <b>{value}{(' ' + unit) if unit else ''}</b>")
    for key, value in status.items():
        if key in ("overall", "items"):
            continue
        lines.append(f"• {html.escape(str(key))}: <b>{html.escape(str(value))}</b>")
    return "\n".join(lines)


def format_confirmation(pending: PendingConfirmation) -> str:
    """Текст запроса подтверждения опасного действия (HTML)."""
    risk_icons = {
        RiskLevel.MEDIUM: "⚠️",
        RiskLevel.HIGH: "🔴",
        RiskLevel.FORBIDDEN: "⛔",
    }
    icon = risk_icons.get(pending.risk, "⚠️")
    args_text = ", ".join(f"{k}={v}" for k, v in pending.args.items()) or "—"
    lines = [
        f"{icon} <b>Требуется подтверждение</b>",
        f"Действие: <b>{html.escape(pending.action)}</b>",
        f"Параметры: {html.escape(args_text)}",
        f"Уровень риска: <b>{html.escape(pending.risk.value)}</b>",
    ]
    if pending.note:
        lines.append(html.escape(pending.note))
    lines.append("Нажмите кнопку, чтобы подтвердить или отменить.")
    return "\n".join(lines)


def build_inline_keyboard(buttons: Sequence[ButtonSpec]) -> Any:
    """
    Собрать инлайн-клавиатуру aiogram из описаний кнопок.

    Требует установленного aiogram (иначе ``TelegramDependencyError``).
    """
    require_aiogram()
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    rows = [[InlineKeyboardButton(text=b.text, callback_data=b.callback_data)] for b in buttons]
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ---------------------------------------------------------------------------
# Логика обработчиков (без aiogram)
# ---------------------------------------------------------------------------
@dataclass
class BotHandlers:
    """
    Обработчик команд Telegram-бота (чистая логика, без сети).

    Все методы сначала проверяют whitelist (``AccessDenied`` для чужих
    chat_id), затем выполняют действие и возвращают ``HandlerReply``.
    Опасные действия не исполняются сразу — создаётся подтверждение
    с кнопками «ПОДТВЕРДИТЬ» / «ОТМЕНА».
    """

    bridge: CommandBridge
    confirmations: ConfirmationManager
    whitelist: ChatWhitelist
    status_provider: Callable[[], Mapping[str, Any]] = dict
    screenshot_provider: Callable[[], bytes | Path | None] = lambda: None
    bot_name: str = "JARVIS"

    # -- вспомогательное --------------------------------------------------
    def _guard(self, chat_id: Any, required: AccessLevel = AccessLevel.VIEW) -> str:
        """Проверить whitelist и уровень доступа; вернуть нормализованный chat_id."""
        return self.whitelist.check_access(chat_id, required)

    # -- команды ----------------------------------------------------------
    def start(self, chat_id: Any, user_name: str = "сэр") -> HandlerReply:
        """/start — приветствие и описание возможностей."""
        normalized = self._guard(chat_id, AccessLevel.VIEW)
        level = self.whitelist.default_level.value
        text = "\n".join(
            [
                f"<b>🤖 {html.escape(self.bot_name)} на связи</b>",
                f"Приветствую, {html.escape(user_name)}!",
                f"Ваш уровень доступа: <b>{html.escape(level)}</b>",
                "",
                "Команды: /status — статус системы, /screenshot — скриншот,",
                "любой текст — команда оркестратору.",
                "Опасные действия требуют подтверждения кнопками.",
            ]
        )
        logger.info("telegram /start chat_id=%s", normalized)
        return HandlerReply(text=text)

    def status(self, chat_id: Any) -> HandlerReply:
        """/status — сводка состояния системы."""
        self._guard(chat_id, AccessLevel.VIEW)
        data = dict(self.status_provider() or {})
        return HandlerReply(text=format_status(data))

    def screenshot(self, chat_id: Any) -> HandlerReply:
        """/screenshot — снять скриншот экрана и отправить его."""
        self._guard(chat_id, AccessLevel.VIEW)
        shot = self.screenshot_provider()
        if shot is None:
            return HandlerReply(text="📷 Скриншот недоступен: захват экрана не настроен.")
        caption = "📷 Скриншот рабочего стола"
        return HandlerReply(text=caption, attachment=shot, attachment_caption=caption)

    def request_action(
        self,
        chat_id: Any,
        action: str,
        args: Mapping[str, Any] | None = None,
        risk: RiskLevel | str = RiskLevel.SAFE,
        note: str = "",
    ) -> HandlerReply:
        """
        Запросить выполнение действия (команды оркестратора).

        Безопасные действия кладутся в мост сразу; medium/high — создают
        подтверждение с кнопками; forbidden — отклоняются.
        """
        level = RiskLevel(risk) if not isinstance(risk, RiskLevel) else risk
        if level is RiskLevel.FORBIDDEN:
            raise AccessDenied(f"действие {action!r} запрещено (risk=forbidden)")
        required = AccessLevel.FULL if requires_confirmation(level) else AccessLevel.NOTIFY
        normalized = self._guard(chat_id, required)
        if requires_confirmation(level):
            pending = self.confirmations.create(
                normalized, action, args=args, risk=level, note=note
            )
            return HandlerReply(
                text=format_confirmation(pending),
                buttons=(
                    ButtonSpec("✅ ПОДТВЕРДИТЬ", pending.callback_approve),
                    ButtonSpec("❌ ОТМЕНА", pending.callback_cancel),
                ),
            )
        request = self.bridge.submit(normalized, action, args=args, risk=level)
        return HandlerReply(
            text=f"✅ Команда <b>{html.escape(action)}</b> принята (id {html.escape(request.request_id)})."
        )

    def text(self, chat_id: Any, message_text: str) -> HandlerReply:
        """Свободный текст → команда оркестратору (``chat``)."""
        text = str(message_text).strip()
        if not text:
            return HandlerReply(text="Пустая команда — уточните запрос.")
        return self.request_action(chat_id, "chat", args={"text": text}, risk=RiskLevel.SAFE)

    # -- подтверждения ----------------------------------------------------
    def handle_callback(self, chat_id: Any, callback_data: str) -> HandlerReply:
        """
        Нажатие инлайн-кнопки подтверждения/отмены.

        ``callback_data`` — строка из ``PendingConfirmation.callback_*``.
        Одобрение кладёт действие в мост, отмена — просто закрывает запрос.
        """
        normalized = self._guard(chat_id, AccessLevel.FULL)
        kind, token = decode_callback(callback_data)
        try:
            pending, approved = self.confirmations.resolve(token, approved=kind == CALLBACK_APPROVE)
        except ConfirmationUnknown:
            return HandlerReply(text="⌛ Это подтверждение уже неактивно.")
        if not approved:
            logger.info("telegram: действие %r отменено chat_id=%s", pending.action, normalized)
            return HandlerReply(text=f"❌ Действие <b>{html.escape(pending.action)}</b> отменено.")
        request = self.bridge.submit(
            pending.chat_id, pending.action, args=pending.args, risk=pending.risk
        )
        logger.info("telegram: действие %r подтверждено chat_id=%s", pending.action, normalized)
        return HandlerReply(
            text=(
                f"▶️ Действие <b>{html.escape(pending.action)}</b> подтверждено "
                f"и отправлено в очередь (id {html.escape(request.request_id)})."
            )
        )

    def confirm_buttons(self, pending: PendingConfirmation) -> tuple[ButtonSpec, ...]:
        """Кнопки «ПОДТВЕРДИТЬ» / «ОТМЕНА» для ожидающего действия."""
        return (
            ButtonSpec("✅ ПОДТВЕРДИТЬ", pending.callback_approve),
            ButtonSpec("❌ ОТМЕНА", pending.callback_cancel),
        )


# ---------------------------------------------------------------------------
# Регистрация маршрутов aiogram (только если aiogram установлен)
# ---------------------------------------------------------------------------
def setup_handlers(router: Any, handlers: BotHandlers) -> None:
    """
    Зарегистрировать маршруты бота на aiogram-роутере.

    Требует установленного aiogram (иначе ``TelegramDependencyError``).
    Маршруты: /start, /status, /screenshot, callback-кнопки подтверждения,
    свободный текст → оркестратор.
    """
    require_aiogram()
    from aiogram import F
    from aiogram.filters import Command
    from aiogram.types import BufferedInputPhoto, CallbackQuery, FSInputFile, Message

    async def _reply(message: Message, reply: HandlerReply) -> None:
        """Отправить HandlerReply (текст + кнопки + вложение)."""
        markup = build_inline_keyboard(reply.buttons) if reply.buttons else None
        if reply.attachment is not None:
            caption = reply.attachment_caption or reply.text
            if isinstance(reply.attachment, Path):
                media = FSInputFile(reply.attachment)
            else:
                media = BufferedInputPhoto(reply.attachment)
            await message.answer_photo(media, caption=caption, reply_markup=markup)
        else:
            await message.answer(reply.text, parse_mode=reply.parse_mode, reply_markup=markup)

    async def _safe(call: Callable[[], HandlerReply], message: Message) -> None:
        """Выполнить обработчик, превратив AccessDenied в понятный ответ."""
        try:
            reply = call()
        except AccessDenied as exc:
            await message.answer(f"⛔ Доступ запрещён: {html.escape(str(exc))}")
            return
        await _reply(message, reply)

    async def on_start(message: Message) -> None:
        """/start"""
        name = message.from_user.full_name if message.from_user else "сэр"
        await _safe(lambda: handlers.start(message.chat.id, user_name=name), message)

    async def on_status(message: Message) -> None:
        """/status"""
        await _safe(lambda: handlers.status(message.chat.id), message)

    async def on_screenshot(message: Message) -> None:
        """/screenshot"""
        await _safe(lambda: handlers.screenshot(message.chat.id), message)

    async def on_text(message: Message) -> None:
        """Свободный текст → оркестратору."""
        await _safe(lambda: handlers.text(message.chat.id, message.text or ""), message)

    async def on_callback(query: CallbackQuery) -> None:
        """Кнопки «ПОДТВЕРДИТЬ» / «ОТМЕНА»."""
        if query.message is None:
            await query.answer("Сообщение недоступно")
            return
        try:
            reply = handlers.handle_callback(query.from_user.id, query.data or "")
        except AccessDenied as exc:
            await query.answer(f"⛔ {str(exc)}", show_alert=True)
            return
        await query.answer()
        await query.message.answer(reply.text, parse_mode=reply.parse_mode)

    router.message.register(on_start, Command("start"))
    router.message.register(on_status, Command("status"))
    router.message.register(on_screenshot, Command("screenshot"))
    router.message.register(on_text, F.text)
    router.callback_query.register(
        on_callback, F.data.startswith((f"{CALLBACK_APPROVE}:", f"{CALLBACK_CANCEL}:"))
    )
