"""
Проверка модуля fun/sfx: DSP, темы, сэмплы, библиотека клипов, плеер.

Запуск:  python3 tests/test_sfx.py
"""

from __future__ import annotations

import asyncio
import sys
import tempfile
import wave
from array import array
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import fun.sfx as sfx_mod
from audio.playback import (
    AudioPlayer,
    AudioSink,
    PlaybackClip,
    PlaybackRouter,
    builtin_sfx,
)
from fun.sfx import (
    SampleBank,
    SfxConfig,
    SfxError,
    SfxEvent,
    SfxLibrary,
    SfxPlayer,
    SfxTheme,
    chirp,
    echo,
    fade_edges,
    mix_layers,
    render_event,
    silence,
    sine_wave,
)


# ---------------------------------------------------------------------------
# Хелперы
# ---------------------------------------------------------------------------
def _samples(pcm: bytes) -> array:
    out = array("h")
    out.frombytes(pcm)
    return out


def _peak(pcm: bytes) -> int:
    return max((abs(s) for s in _samples(pcm)), default=0)


def _write_wav(path: Path, samples: list[int], *, rate: int = 16000, channels: int = 1) -> None:
    """Записать s16le WAV (для проверки SampleBank)."""
    data = array("h")
    for s in samples:
        for _ in range(channels):
            data.append(s)
    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(2)
        wf.setframerate(rate)
        wf.writeframes(data.tobytes())


# ---------------------------------------------------------------------------
# Тесты: DSP
# ---------------------------------------------------------------------------
def test_dsp() -> None:
    tone = sine_wave(440.0, 0.1, sample_rate=16000)
    assert len(tone) == 3200, "0.1 с @ 16 кГц s16le = 3200 байт"

    sweep = chirp(300.0, 1200.0, 0.1, sample_rate=16000)
    assert len(sweep) == 3200
    assert _peak(sweep) > 1000, "чрп не должен быть тишиной"

    faded = fade_edges(tone, fade_ms=5.0, sample_rate=16000)
    first = abs(_samples(faded)[0])
    assert first < 0.1 * _peak(faded), "fade-in: первый сэмпл ≈ 0"

    assert silence(0.05, 16000) == b"\x00\x00" * 800

    # микс: сумма + жёсткое ограничение шкалы
    loud = sine_wave(440.0, 0.02, amplitude=0.9, sample_rate=16000)
    mixed = mix_layers([(loud, 2.0), (loud, 2.0)])
    assert all(-32768 <= s <= 32767 for s in _samples(mixed)), "переполнение int16 должно зажиматься"
    try:
        mix_layers([])
    except SfxError:
        pass
    else:
        raise AssertionError("mix_layers([]) должен был бросить SfxError")

    # эхо удлиняет звук
    echoed = echo(tone, delay_ms=50.0, decay=0.5, repeats=2, sample_rate=16000)
    assert len(_samples(echoed)) >= 1600 + 800 * 2, "эхо должно удлинять PCM"
    print("  ✓ DSP: sine/chirp/fade/mix/echo/silence")


# ---------------------------------------------------------------------------
# Тесты: события и темы
# ---------------------------------------------------------------------------
def test_events_and_themes() -> None:
    for theme in SfxTheme:
        for event in SfxEvent:
            pcm = render_event(event, theme, 16000)
            dur = len(pcm) / 32000.0
            assert 0.03 <= dur <= 3.0, f"{theme.value}/{event.value}: странная длительность {dur:.3f} с"
            assert _peak(pcm) > 500, f"{theme.value}/{event.value}: слишком тихо"

    scifi = render_event(SfxEvent.ACTIVATE, SfxTheme.SCIFI, 16000)
    minimal = render_event(SfxEvent.ACTIVATE, SfxTheme.MINIMAL, 16000)
    assert scifi != minimal, "темы SCIFI и MINIMAL должны звучать по-разному"
    assert len(_samples(scifi)) > len(_samples(minimal)), "SCIFI с эхом должен быть длиннее MINIMAL"

    for bad in ("нет_такого", "beep"):
        try:
            render_event(bad, SfxTheme.SCIFI, 16000)  # type: ignore[arg-type]
        except SfxError:
            pass
        else:
            raise AssertionError(f"неизвестное событие {bad!r} должно бросать SfxError")
    try:
        render_event(SfxEvent.CONFIRM, "нет_темы", 16000)  # type: ignore[arg-type]
    except SfxError:
        pass
    else:
        raise AssertionError("неизвестная тема должна бросать SfxError")
    print(f"  ✓ События и темы: {len(SfxTheme)} × {len(SfxEvent)} комбинаций синтезируются")


# ---------------------------------------------------------------------------
# Тесты: SampleBank
# ---------------------------------------------------------------------------
def test_sample_bank() -> None:
    with tempfile.TemporaryDirectory(dir=str(Path(__file__).resolve().parent)) as tmp:
        bank = SampleBank(tmp, sample_rate=16000)

        # сэмпла нет → None
        assert bank.get(SfxEvent.CONFIRM) is None

        # моно 16 кГц: загружается как есть
        _write_wav(Path(tmp) / "confirm.wav", [1000] * 1600, rate=16000)
        pcm = bank.get(SfxEvent.CONFIRM)
        assert pcm is not None and len(_samples(pcm)) == 1600
        assert all(s == 1000 for s in _samples(pcm))

        # стерео 8 кГц: сводится к моно и пересэмплируется (×2)
        _write_wav(Path(tmp) / "error.wav", [2000] * 800, rate=8000, channels=2)
        pcm = bank.get(SfxEvent.ERROR)
        assert pcm is not None
        assert abs(len(_samples(pcm)) - 1600) <= 2, "8 кГц → 16 кГц: вдвое больше сэмплов"
        assert all(s == 2000 for s in _samples(pcm)), "стерео должно сходиться в моно без искажений"

        # битый файл: предупреждение + деградация в None
        (Path(tmp) / "activate.wav").write_bytes(b"not a wav at all")
        assert bank.get(SfxEvent.ACTIVATE) is None

        assert sorted(e.value for e in bank.events()) == ["confirm", "error"]
        assert bank.describe()["events"] == ["confirm", "error"]
    print("  ✓ SampleBank: WAV-сэмплы, стерео→моно, ресемплинг, устойчивость к битым файлам")


# ---------------------------------------------------------------------------
# Тесты: SfxLibrary
# ---------------------------------------------------------------------------
def test_library() -> None:
    library = SfxLibrary(SfxConfig(theme=SfxTheme.SCIFI))
    assert library.preload() == len(SfxEvent), "preload должен собрать все события"

    # кэш: повторный вызов возвращает тот же клип
    clip1 = library.clip(SfxEvent.ACTIVATE)
    clip2 = library.clip("activate")
    assert clip1 is clip2, "клипы должны кэшироваться"
    assert clip1.kind == "sfx" and clip1.name == "activate" and clip1.priority == -1

    # неизвестное событие
    try:
        library.clip("нет_такого")
    except SfxError:
        pass
    else:
        raise AssertionError("неизвестное событие должно бросать SfxError")

    # смена темы сбрасывает кэш
    before = library.clip(SfxEvent.CONFIRM)
    library.set_theme(SfxTheme.MINIMAL)
    after = library.clip(SfxEvent.CONFIRM)
    assert before is not after, "set_theme должен пересобрать клипы"
    assert library.theme is SfxTheme.MINIMAL
    try:
        library.set_theme("нет_темы")
    except SfxError:
        pass
    else:
        raise AssertionError("неизвестная тема должна бросать SfxError")

    # громкость применяется при сборке клипа
    loud = SfxLibrary(SfxConfig(theme=SfxTheme.MINIMAL, volume=1.0)).clip(SfxEvent.CONFIRM)
    quiet = SfxLibrary(SfxConfig(theme=SfxTheme.MINIMAL, volume=0.5)).clip(SfxEvent.CONFIRM)
    assert _peak(quiet.pcm) < _peak(loud.pcm), "volume=0.5 должен делать тише"

    # сэмпл из каталога важнее темы
    with tempfile.TemporaryDirectory(dir=str(Path(__file__).resolve().parent)) as tmp:
        _write_wav(Path(tmp) / "confirm.wav", [1234] * 800, rate=16000)
        lib = SfxLibrary(SfxConfig(theme=SfxTheme.SCIFI, sample_dir=Path(tmp)))
        clip = lib.clip(SfxEvent.CONFIRM)
        assert all(s == 1234 for s in _samples(clip.pcm)), "сэмпл должен переопределить синтез"
        assert lib.describe()["samples"]["events"] == ["confirm"]

    # fallback на builtin: синтез падает, но клип всё равно есть
    original = sfx_mod.render_event

    def _boom(*args: object, **kwargs: object) -> bytes:
        raise RuntimeError("синтез сломан")

    sfx_mod.render_event = _boom  # type: ignore[assignment]
    try:
        lib = SfxLibrary(SfxConfig(theme=SfxTheme.SCIFI))
        clip = lib.clip(SfxEvent.ACTIVATE)
        expected = builtin_sfx("activate", sample_rate=16000)
        assert clip.pcm == expected.pcm, "упавший синтез должен деградировать в builtin_sfx"
    finally:
        sfx_mod.render_event = original  # type: ignore[assignment]
    print("  ✓ SfxLibrary: кэш, темы, громкость, сэмплы > тема > builtin")


# ---------------------------------------------------------------------------
# Тесты: SfxPlayer
# ---------------------------------------------------------------------------
class MockSink(AudioSink):
    name = "mock"

    def __init__(self) -> None:
        self.played: list[PlaybackClip] = []

    def is_available(self) -> bool:
        return True

    async def play(self, clip: PlaybackClip) -> None:
        self.played.append(clip)


async def _run_async() -> None:
    sink = MockSink()
    router = PlaybackRouter({"mock": sink}, primary="mock")
    player = AudioPlayer(router)
    sfx_player = SfxPlayer(player, SfxLibrary(SfxConfig(theme=SfxTheme.SCIFI)))

    await sfx_player.play(SfxEvent.CONFIRM, wait=True)
    assert len(sink.played) == 1, "звук должен дойти до приёмника"
    clip = sink.played[0]
    assert clip.name == "confirm" and clip.kind == "sfx" and clip.priority < 0
    assert "library" in sfx_player.describe()

    await player.close()
    print("  ✓ SfxPlayer: событие → очередь AudioPlayer → приёмник")


def main() -> int:
    print("Проверка fun/sfx ...")
    try:
        test_dsp()
        test_events_and_themes()
        test_sample_bank()
        test_library()
        asyncio.run(_run_async())
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модуля прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
