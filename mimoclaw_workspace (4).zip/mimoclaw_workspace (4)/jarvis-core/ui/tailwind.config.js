/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // База тёмной HUD-темы
        abyss: "#05070A",
        panel: "#0A0F14",
        "panel-2": "#0D141B",
        line: "#16222C",
        "line-bright": "#1E3240",
        muted: "#5C7484",
        text: "#C9E6F2",
        // Акцент берётся из CSS-переменной: циан (JARVIS) / красный (FRIDAY)
        accent: "rgb(var(--accent-rgb) / <alpha-value>)",
        jarvis: "#00E5FF",
        friday: "#FF3B30",
        ok: "#2ECC71",
        warn: "#F5A623",
        danger: "#FF3B30",
      },
      fontFamily: {
        display: ["Orbitron", "Rajdhani", "sans-serif"],
        heading: ["Rajdhani", "Orbitron", "sans-serif"],
        body: ["Inter", "system-ui", "sans-serif"],
      },
      boxShadow: {
        neon: "0 0 24px -6px rgb(var(--accent-rgb) / 0.45)",
        "neon-strong": "0 0 42px -4px rgb(var(--accent-rgb) / 0.65)",
        card: "0 8px 28px -12px rgba(0, 0, 0, 0.8)",
      },
      keyframes: {
        "pulse-glow": {
          "0%, 100%": { opacity: "1", transform: "scale(1)" },
          "50%": { opacity: "0.55", transform: "scale(1.06)" },
        },
        "ring-spin": {
          from: { transform: "rotate(0deg)" },
          to: { transform: "rotate(360deg)" },
        },
        "scan-line": {
          from: { transform: "translateY(-100%)" },
          to: { transform: "translateY(400%)" },
        },
        "vu-jump": {
          "0%, 100%": { transform: "scaleY(0.4)" },
          "50%": { transform: "scaleY(1)" },
        },
      },
      animation: {
        "pulse-glow": "pulse-glow 2.4s ease-in-out infinite",
        "ring-spin": "ring-spin 14s linear infinite",
        "scan-line": "scan-line 6s linear infinite",
      },
    },
  },
  plugins: [],
};
