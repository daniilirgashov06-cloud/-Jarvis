"""
Проверка модуля audio/playback: приёмники, роутер с fallback, плеер с очередью.

Запуск:  python3 tests/test_playback.py
"""

from __future__ import annotations

import asyncio
import sys
import wave
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from audio.playback import (
    AudioPlayer,
    AudioSink,
    NullSink,
    PlaybackClip,
    PlaybackConfig,
    PlaybackError,
    PlaybackRouter,
    PlaybackUnavailable,
    SfxKind,
    ToneGenerator,
    WavFileSink,
    apply_volume,
    builtin_sfx,
)


# ---------------------------------------------------------------------------
# Мок-приёмники
# ---------------------------------------------------------------------------
class MockSink(AudioSink):
    def __init__(self, name: str, available: bool = True, fail: bool = False):
        self.name = name
        self.available = available
        self.fail = fail
        self.played: list[PlaybackClip] = []
        self.stops = 0

    def is_available(self) -> bool:
        return self.available

    async def play(self, clip: PlaybackClip) -> None:
        if self.fail:
            raise PlaybackUnavailable(f"{self.name}: нет звука")
        self.played.append(clip)

    def stop(self) -> None:
        self.stops += 1


# ---------------------------------------------------------------------------
# Тесты
# ---------------------------------------------------------------------------
def test_pcm_volume() -> None:
    silence = b"\x00\x00" * 10
    assert apply_volume(silence, 0.0) == silence
    assert apply_volume(silence, 1.0) == silence, "volume=1.0 не должен менять PCM"

    # сэмпл 1000 при 0.5 → 500
    pcm = (1000).to_bytes(2, "little", signed=True)
    half = apply_volume(pcm, 0.5)
    assert int.from_bytes(half, "little", signed=True) == 500

    # клиппинг: 30000 × 2.0 = 60000 → зажимается до 32767
    loud = (30000).to_bytes(2, "little", signed=True)
    clipped = int.from_bytes(apply_volume(loud, 2.0), "little", signed=True)
    assert clipped == 32767
    print("  ✓ apply_volume: масштабирование + ограничение клиппинга")


def test_tones_and_builtin_sfx() -> None:
    tone = ToneGenerator.sine(440.0, 0.1, sample_rate=16000)
    assert len(tone) == 2 * 1600, "0.1 с @ 16 кГц s16le = 3200 байт"
    # огибание: первый сэмпл ≈ 0 (fade-in)
    first = int.from_bytes(tone[:2], "little", signed=True)
    assert abs(first) < 100, "fade-in должен начинаться с тишины"

    for kind in SfxKind:
        clip = builtin_sfx(kind)
        assert clip.kind == "sfx" and clip.name == kind.value
        assert len(clip.pcm) > 0 and clip.duration > 0
        assert clip.priority < 0, "SFX не должны перебивать речь"
    try:
        builtin_sfx("нет_такого")
        assert False, "неизвестный SFX должен падать"
    except PlaybackError:
        pass
    print("  ✓ ToneGenerator + builtin_sfx: тоны и 4 сигнала генерируются")


async def test_router_switch_and_fallback() -> None:
    speakers = MockSink("speakers")
    wav = MockSink("wav")
    r = PlaybackRouter(sinks={"speakers": speakers, "wav": wav}, primary="speakers")

    who = await r.play(builtin_sfx(SfxKind.CONFIRM))
    assert who == "speakers" and len(speakers.played) == 1 and r.fallbacks_used == 0

    r.set_primary("wav")
    who2 = await r.play(builtin_sfx(SfxKind.ACTIVATE))
    assert who2 == "wav" and r.primary == "wav"

    # fallback: основной «сломан» → играет запасной
    broken = MockSink("speakers", fail=True)
    ok = MockSink("wav")
    r2 = PlaybackRouter(sinks={"speakers": broken, "wav": ok}, primary="speakers")
    who3 = await r2.play(builtin_sfx(SfxKind.ERROR))
    assert who3 == "wav" and r2.fallbacks_used == 1 and r2.last_sink == "wav"
    print("  ✓ playback_router: смена приёмника + fallback работают")


async def test_router_all_fail() -> None:
    r = PlaybackRouter(
        sinks={"a": MockSink("a", available=False), "b": MockSink("b", fail=True)},
        primary="a",
    )
    try:
        await r.play(builtin_sfx(SfxKind.CONFIRM))
        assert False, "когда все приёмники мертвы — нужна ошибка"
    except PlaybackUnavailable:
        pass
    print("  ✓ playback_router: корректная ошибка, когда никто не смог сыграть")


async def test_player_queue_priority_and_drain() -> None:
    null = NullSink()
    player = AudioPlayer(PlaybackRouter(sinks={"null": null}, primary="null"))

    await player.play_sfx(SfxKind.ACTIVATE)  # priority -1
    await player.speak(b"\x01\x00" * 100, name="ответ")  # priority 0
    await player.drain()

    names = [c.name for c in null.played]
    assert names == ["ответ", "activate"], f"речь должна обгонять SFX, получили {names}"
    assert null.played[0].kind == "speech" and null.played[1].kind == "sfx"
    await player.close()
    print("  ✓ audio_player: очередь по приоритету (речь > SFX) + drain()")


async def test_player_wait_stop_and_overflow() -> None:
    null = NullSink()
    cfg = PlaybackConfig(queue_size=2)
    player = AudioPlayer(PlaybackRouter(sinks={"null": null}, primary="null"), cfg)

    await player.speak(b"\x02\x00" * 10, name="короткий", wait=True)
    assert len(null.played) == 1 and player.queued == 0, "wait=True должен дождаться конца"

    player.stop()  # не должно падать даже без активной очереди
    assert null.stopped >= 1

    # переполнение очереди: ставим больше, чем queue_size, без ожидания
    try:
        for i in range(10):
            await player.speak(b"\x03\x00" * 10, name=f"x{i}")
        assert False, "переполнение очереди должно давать PlaybackError"
    except PlaybackError:
        pass
    await player.close()
    print("  ✓ audio_player: wait() / stop() / защита от переполнения очереди")


async def test_wav_file_sink() -> None:
    import tempfile

    with tempfile.TemporaryDirectory(dir=str(Path(__file__).resolve().parent)) as tmp:
        sink = WavFileSink(tmp, prefix="t")
        assert sink.is_available()
        clip = builtin_sfx(SfxKind.CONFIRM, sample_rate=16000)
        await sink.play(clip)
        assert len(sink.written) == 1
        with wave.open(str(sink.written[0]), "rb") as w:
            assert w.getframerate() == 16000 and w.getnchannels() == 1
            assert w.getnframes() * w.getsampwidth() == len(clip.pcm)
    print("  ✓ wav_file_sink: клип корректно пишется в WAV (16 кГц, моно)")


# ---------------------------------------------------------------------------
async def _run_async() -> None:
    await test_router_switch_and_fallback()
    await test_router_all_fail()
    await test_player_queue_priority_and_drain()
    await test_player_wait_stop_and_overflow()
    await test_wav_file_sink()


def main() -> int:
    print("JARVIS CORE — проверка audio/playback")
    try:
        test_pcm_volume()
        test_tones_and_builtin_sfx()
        asyncio.run(_run_async())
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модуля прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
