"""
Движки синтеза речи (TTS) JARVIS CORE.

Единый контракт ``TTSEngine`` + диспетчер ``TTSRouter`` с **живой сменой**
локально ↔ облако и fallback. Локально — Piper/XTTS (без интернета);
облако — ElevenLabs (кастомные голоса). Голоса — стилизация, не клонирование
реальных актёров (см. примечание по голосам в ТЗ).

Результат — PCM bytes (16 кГц, моно, s16le) для audio/playback.
"""

from __future__ import annotations

import abc
import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class VoicePreset:
    """Пресет голоса персоны (см. ТЗ-4.4)."""

    key: str
    provider: str = "local"
    voice_id: str = ""
    stability: float = 0.55
    similarity: float = 0.82
    style: float = 0.35
    speed: float = 0.96
    pitch: float = 0.0
    effects: list[str] = field(default_factory=lambda: ["eq_british", "subtle_reverb"])


@dataclass
class SpeechAudio:
    """Синтезированная речь."""

    pcm: bytes
    sample_rate: int = 16000
    engine: str = ""


class TTSError(Exception):
    """Ошибка синтеза."""


class TTSUnavailable(TTSError):
    """Движок недоступен — можно fallback."""


class TTSEngine(abc.ABC):
    """Контракт движка TTS."""

    name: str = "base"

    @abc.abstractmethod
    def is_available(self) -> bool: ...

    @abc.abstractmethod
    async def synthesize(
        self,
        text: str,
        *,
        preset: VoicePreset | None = None,
    ) -> SpeechAudio: ...

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "available": self.is_available()}


class LocalTTS(TTSEngine):
    """
    Локальный TTS (Piper / Coqui XTTS) — работает без интернета.

    Предпочтительно Piper (лёгкий). Если недоступен — можно поднять XTTS.
    Здесь — интерфейс + безопасный fallback-заглушка-синтез через `say`/espeak,
    чтобы ядро не падало при отсутствии тяжёлых движков.
    """

    name = "local"

    def __init__(self, voice_path: str | None = None) -> None:
        self.voice_path = voice_path

    def is_available(self) -> bool:
        # Доступен, если есть любой локальный синтезатор
        return self._has_piper() or self._has_espeak()

    @staticmethod
    def _has_piper() -> bool:
        try:
            import piper  # noqa: F401

            return True
        except ImportError:
            return False

    @staticmethod
    def _has_espeak() -> bool:
        import shutil

        return shutil.which("espeak-ng") or shutil.which("espeak") is not None

    async def synthesize(self, text, *, preset=None) -> SpeechAudio:
        if self._has_piper():
            return await self._synth_piper(text, preset)
        if self._has_espeak():
            return await self._synth_espeak(text, preset)
        raise TTSUnavailable("Локальный TTS не установлен (piper/espeak)")

    async def _synth_piper(self, text: str, preset: VoicePreset | None) -> SpeechAudio:
        # Реализация через piper CLI/модель; сокращено до интерфейса.
        raise TTSUnavailable("Piper: требуется модель голоса (настройка в панели)")

    async def _synth_espeak(self, text: str, preset: VoicePreset | None) -> SpeechAudio:
        """Деградация через espeak-ng (синтез WAV -> PCM)."""
        import asyncio
        import shutil
        import tempfile

        binary = shutil.which("espeak-ng") or shutil.which("espeak")
        if not binary:
            raise TTSUnavailable("espeak не найден")
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            out_path = tmp.name
        proc = await asyncio.create_subprocess_exec(
            binary, "-v", "ru", "-w", out_path, text,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.wait()
        pcm = _wav_to_pcm(_read_bytes(out_path))
        return SpeechAudio(pcm=pcm, engine=self.name)


class ElevenLabsTTS(TTSEngine):
    """Облачный TTS ElevenLabs (кастомные голоса)."""

    name = "elevenlabs"

    def __init__(self, api_key: str | None = None, default_voice_id: str = "") -> None:
        self.api_key = api_key
        self.default_voice_id = default_voice_id

    def is_available(self) -> bool:
        return bool(self.api_key)

    async def synthesize(self, text, *, preset=None) -> SpeechAudio:
        if not self.api_key:
            raise TTSUnavailable("ElevenLabs: не задан API-ключ")
        try:
            import httpx
        except ImportError as exc:  # pragma: no cover
            raise TTSUnavailable("httpx не установлен") from exc

        voice_id = (preset.voice_id if preset and preset.voice_id else self.default_voice_id)
        if not voice_id:
            raise TTSUnavailable("ElevenLabs: не задан voice_id")
        url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
        payload = {
            "text": text,
            "model_id": "eleven_multilingual_v2",
            "voice_settings": {
                "stability": preset.stability if preset else 0.55,
                "similarity_boost": preset.similarity if preset else 0.82,
                "style": preset.style if preset else 0.35,
                "speed": preset.speed if preset else 0.96,
            },
        }
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                resp = await client.post(
                    url,
                    json=payload,
                    headers={"xi-api-key": self.api_key, "Accept": "audio/mpeg"},
                )
        except Exception as exc:  # noqa: BLE001
            raise TTSUnavailable(f"ElevenLabs недоступен: {exc}") from exc
        if resp.status_code != 200:
            raise TTSError(f"ElevenLabs HTTP {resp.status_code}: {resp.text[:200]}")
        # ElevenLabs отдаёт mp3; для MVP возвращаем как есть (декод в playback).
        return SpeechAudio(pcm=resp.content, engine=self.name)


class TTSRouter:
    """Диспетчер TTS: смена движков + fallback."""

    def __init__(
        self,
        engines: dict[str, TTSEngine] | None = None,
        primary: str = "local",
        fallback_chain: list[str] | None = None,
    ) -> None:
        self._engines = engines or {}
        self._primary = primary
        self._fallback_chain = fallback_chain or [primary]

    @property
    def primary(self) -> str:
        return self._primary

    def set_primary(self, name: str) -> None:
        if name not in self._engines:
            raise TTSError(f"Неизвестный TTS-движок: {name}")
        self._primary = name
        self._fallback_chain = [name] + [e for e in self._fallback_chain if e != name]
        logger.info("TTS-движок переключён на '%s'", name)

    def available(self) -> list[str]:
        return [n for n, e in self._engines.items() if e.is_available()]

    def _chain(self, explicit: str | None) -> list[str]:
        if explicit:
            return [explicit]
        order = self._fallback_chain or list(self._engines.keys())
        chain = [self._primary] + [n for n in order if n != self._primary]
        chain += [n for n in self._engines if n not in chain]  # все зарегистрированные
        return chain

    async def synthesize(
        self,
        text: str,
        *,
        preset: VoicePreset | None = None,
        engine: str | None = None,
    ) -> SpeechAudio:
        last_err: Exception | None = None
        for name in self._chain(engine):
            eng = self._engines.get(name)
            if eng is None or not eng.is_available():
                last_err = TTSUnavailable(f"{name}: недоступен")
                continue
            try:
                return await eng.synthesize(text, preset=preset)
            except TTSUnavailable as exc:
                last_err = exc
                continue
            except TTSError as exc:
                last_err = exc
                continue
        raise TTSError(f"Ни один TTS-движок не справился. Последняя ошибка: {last_err}")


def _read_bytes(path: str) -> bytes:
    with open(path, "rb") as fh:
        return fh.read()


def _wav_to_pcm(wav: bytes) -> bytes:
    """Достаёт PCM-данные из WAV (пропускает заголовок)."""
    idx = wav.find(b"data")
    if idx == -1:
        return wav
    return wav[idx + 8 :]
