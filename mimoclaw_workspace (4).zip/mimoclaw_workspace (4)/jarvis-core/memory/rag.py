"""
RAG-адаптер памяти JARVIS CORE (ТЗ-5, «вечная память» → контекст LLM).

Связывает накопленную память с ``ai.context_builder.ContextBuilder``: подаёт
релевантные воспоминания (top-8 по умолчанию) в системный промпт LLM.
Контракт совместим с ``ai.context_builder.MemorySearch`` — любой объект с
``search(query, top_k) -> list[str]`` подставляется в
``ContextBuilder(memory=...)`` как есть (``VectorStore`` тоже подходит).

``RagMemory`` — гибридный адаптер поверх двух источников памяти:

- **факты** — ``memory.store.MemoryStore`` (структурированные записи:
  факты/предпочтения/сводки, их пишут ``summarizer``/``profile``/``store``);
- **семантика** — ``memory.vector_store.VectorStore`` (векторный индекс
  фрагментов диалога/событий, ChromaDB либо TF-IDF fallback).

Поиск объединяет оба источника с дедупликацией (факты — первыми, они
«отобранные»; дальше — семантически похожие фрагменты) и **никогда не падает**:
недоступный источник мягко пропускается, остальные продолжают отвечать.

Использование:
    from memory.rag import default_rag
    from ai.context_builder import ContextBuilder

    rag = default_rag(db_path="data/jarvis.db")   # факты + векторный индекс
    rag.remember("сёр включил тёмную тему", metadata={"kind": "event"})
    context = ContextBuilder(memory=rag)          # top-8 воспоминаний в промпт
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from memory.store import MemoryRecord, MemoryStore, default_memory_store
from memory.vector_store import (
    DEFAULT_TOP_K,
    MAX_TOP_K,
    VectorStore,
    default_vector_store,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Константы
# ---------------------------------------------------------------------------
MAX_QUERY_LEN = 512        # максимум символов в поисковом запросе
MAX_RESULT_CHARS = 600     # усечение готового «воспоминания» для промпта
DEFAULT_RAG_TOP_K = DEFAULT_TOP_K  # top-8 по умолчанию (ТЗ: RAG top-8)


@runtime_checkable
class MemorySearch(Protocol):
    """Поиск по памяти для ``ai.context_builder.ContextBuilder``.

    Структурно совместим с ``ai.context_builder.MemorySearch``: принимает
    запрос и ``top_k``, возвращает список текстов-воспоминаний.
    """

    def search(self, query: str, top_k: int) -> list[str]: ...


# ---------------------------------------------------------------------------
# Вспомогательные функции
# ---------------------------------------------------------------------------
def _normalize(text: str) -> str:
    """Нормализация ключа дедупликации: регистр + ё→е (как в ``memory/store.py``)."""
    return text.lower().replace("ё", "е").strip()


def _shorten(text: str, max_chars: int = MAX_RESULT_CHARS) -> str:
    """Усечь длинное воспоминание по границе слова, не разрывая смысл."""
    if len(text) <= max_chars:
        return text
    cut = text[: max_chars - 1]
    boundary = max(cut.rfind(" "), cut.rfind("\n"))
    if boundary > max_chars // 2:
        cut = cut[:boundary]
    return cut.rstrip(" ,.;:—-") + "…"


def _clean_top_k(top_k: int) -> int:
    """Top-k: целое число, зажимается в диапазон [0, MAX_TOP_K] (как в vector_store)."""
    if isinstance(top_k, bool) or not isinstance(top_k, int):
        raise ValueError("top_k: ожидается int")
    return max(0, min(top_k, MAX_TOP_K))


def format_record(record: MemoryRecord) -> str:
    """Запись памяти → строка для промпта: ``[kind] контент`` (усечённая)."""
    return _shorten(f"[{record.kind.value}] {record.content}")


# ---------------------------------------------------------------------------
# Гибридный адаптер
# ---------------------------------------------------------------------------
@dataclass
class RagMemory:
    """Гибридная память для RAG: факты (``MemoryStore``) + семантика (``VectorStore``).

    Пишется через ``remember`` в векторный индекс; факты приходят извне
    (``store.add`` / ``summarizer`` / ``profile``) и только **читаются** здесь.
    Все поисковые операции мягкие: сломанный источник не роняет конвейер.
    """

    vectors: VectorStore = field(default_factory=default_vector_store)
    facts: MemoryStore | None = None
    top_k: int = DEFAULT_RAG_TOP_K

    def __post_init__(self) -> None:
        self.top_k = _clean_top_k(self.top_k)

    # -- запись -------------------------------------------------------
    def remember(
        self,
        text: str,
        *,
        id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Запомнить фрагмент (диалог/событие/заметка) в векторный индекс.

        Возвращает id фрагмента (``delete``/``forget`` по нему же).
        """
        return self.vectors.add(id or "", text, metadata)

    # -- поиск (контракт MemorySearch) --------------------------------
    def search(self, query: str, top_k: int = DEFAULT_RAG_TOP_K) -> list[str]:
        """Релевантные воспоминания по запросу: факты + семантика, с дедупом.

        Никогда не бросает исключений: недоступный источник пропускается
        (``ContextBuilder`` и промпт продолжают работать).
        """
        try:
            limit = _clean_top_k(top_k)
        except ValueError as exc:
            logger.warning("RAG: некорректный top_k=%r (%s)", top_k, exc)
            return []
        if limit == 0:
            return []
        q = str(query or "").strip()[:MAX_QUERY_LEN]
        if not q:
            return []

        results: list[str] = []
        seen: set[str] = set()

        def _push(display: str, key: str) -> None:
            """Добавить воспоминание с дедупликацией по нормализованному тексту."""
            norm = _normalize(key)
            if not norm or norm in seen or len(results) >= limit:
                return
            seen.add(norm)
            results.append(_shorten(display))

        # 1) Факты: отобранные знания (ранжирует MemoryStore)
        if self.facts is not None:
            try:
                for rec in self.facts.search(q, limit=limit):
                    _push(format_record(rec), rec.content)
            except Exception as exc:  # noqa: BLE001 — источник не должен ронять RAG
                logger.debug("RAG: факты недоступны (%s)", exc)

        # 2) Семантика: похожие фрагменты (ранжирует VectorStore)
        if len(results) < limit:
            try:
                for text in self.vectors.search(q, limit):
                    _push(text, text)
            except Exception as exc:  # noqa: BLE001
                logger.debug("RAG: векторный поиск недоступен (%s)", exc)

        return results[:limit]

    # -- администрирование --------------------------------------------
    def forget(self, id: str) -> bool:
        """Удалить фрагмент из векторного индекса по id."""
        return bool(self.vectors.delete(id))

    def count(self) -> int:
        """Размер векторного индекса (факты считаются отдельно: ``facts.count()``)."""
        return self.vectors.count()

    def clear(self) -> int:
        """Очистить векторный индекс (факты не трогаем — ими владеет MemoryStore)."""
        return self.vectors.clear()


# ---------------------------------------------------------------------------
# Фабрика «локально-first»
# ---------------------------------------------------------------------------
def default_rag(
    *,
    db_path: str | Path | None = None,
    persist_dir: str | Path | None = None,
    top_k: int = DEFAULT_RAG_TOP_K,
    prefer_chroma: bool = True,
) -> RagMemory:
    """Собрать RAG-память: факты (опциональный SQLite ``db_path``) + векторный индекс.

    Оба источника — с мягким fallback (см. ``default_memory_store`` /
    ``default_vector_store``): без тяжёлых зависимостей и недоступного диска
    получаем рабочую in-memory память, а не исключение.
    """
    facts: MemoryStore | None = None
    if db_path:
        facts = default_memory_store(db_path)
    return RagMemory(
        vectors=default_vector_store(persist_dir, prefer_chroma=prefer_chroma),
        facts=facts,
        top_k=top_k,
    )
