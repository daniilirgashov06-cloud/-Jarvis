/**
 * Память — долговременное хранилище, RAG и контекст диалога.
 */

import { useEffect } from "react";
import { Card, PageHeader } from "../components/ui/panels";
import { SettingsSaveBar } from "../components/SettingsSaveBar";
import { FieldRow, Slider, TextField, Toggle } from "../components/ui/controls";
import { useSettingsStore } from "../stores/settingsStore";

export function MemoryPage() {
  const memory = useSettingsStore((s) => s.data.memory);
  const loaded = useSettingsStore((s) => s.loaded);
  const patch = useSettingsStore((s) => s.patch);

  useEffect(() => {
    if (!loaded) void useSettingsStore.getState().load();
  }, [loaded]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Память"
        subtitle="SQLite + векторное хранилище: что ассистент помнит о диалогах и фактах."
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card title="Хранилище">
          <FieldRow
            label="Память включена"
            hint="Сохранять диалоги и факты"
            control={<Toggle checked={memory.enabled} onChange={(v) => patch("memory", { enabled: v })} />}
          />
          <div className="mt-3 space-y-3">
            <TextField
              label="Путь к SQLite"
              value={memory.sqlite_path}
              onChange={(e) => patch("memory", { sqlite_path: e.target.value })}
            />
            <TextField
              label="Путь к векторной БД"
              value={memory.chroma_path}
              onChange={(e) => patch("memory", { chroma_path: e.target.value })}
            />
            <TextField
              label="Модель эмбеддингов"
              value={memory.embedding_model}
              onChange={(e) => patch("memory", { embedding_model: e.target.value })}
              hint="Локальная модель для поиска по смыслу"
            />
          </div>
        </Card>

        <Card title="Контекст и RAG" subtitle="Сколько памяти подставляется в запрос" delay={0.05}>
          <Slider
            label="Суммировать каждые N сообщений"
            min={5}
            max={100}
            step={5}
            value={memory.summarize_every_messages}
            onChange={(v) => patch("memory", { summarize_every_messages: v })}
            format={(v) => `${v} сообщ.`}
            hint="Периодичность компакт-саммари диалога"
          />
          <div className="mt-4">
            <Slider
              label="RAG top-k"
              min={1}
              max={30}
              step={1}
              value={memory.rag_top_k}
              onChange={(v) => patch("memory", { rag_top_k: v })}
              format={(v) => `${v} фрагм.`}
              hint="Сколько релевантных фрагментов подставлять"
            />
          </div>
          <div className="mt-4">
            <Slider
              label="Контекст диалога"
              min={5}
              max={100}
              step={1}
              value={memory.context_messages}
              onChange={(v) => patch("memory", { context_messages: v })}
              format={(v) => `${v} сообщ.`}
            />
          </div>
        </Card>
      </div>

      <SettingsSaveBar />
    </div>
  );
}
