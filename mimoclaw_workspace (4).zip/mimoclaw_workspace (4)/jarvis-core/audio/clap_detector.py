"""
Детектор хлопков JARVIS CORE.

Хлопок — короткий широкополосный импульс: всплеск энергии на 1–3 кадра,
умеренно высокий ZCR (переходы через ноль) и «плоский» спектр (шипение,
а не тон). Именно эта тройка признаков — **RMS + ZCR + спектральная
плоскость** — и используется здесь, без внешних зависимостей (чистый
Python + stdlib ``array``/``math``).

Детектор работает **только локально** (on-device): слушать микрофон
постоянно и стримить его в облако ради хлопка — бессмысленно и небезопасно
(приватность + задержка). Локально ↔ облако уместно лишь дальше по пайплайну
(см. ``speech/stt_engine``, ``ai/llm_router``).

Контракт модуля (по образцу ``audio/vad`` / ``audio/wakeword``):

  * ``ClapFeatures``/``ClapResult`` — признаки кадра и вердикт движка;
  * ``SpectralClapEngine`` — движок на RMS+ZCR+спектре (чистый Python);
  * ``ClapRouter`` — смена движков + fallback;
  * ``ClapDetector`` — поток кадров → события ``ClapEvent`` (одиночный /
    двойной хлопок) с cooldown от ложных повторов.
"""

from __future__ import annotations

import abc
import inspect
import logging
import math
import sys
from array import array
from dataclasses import dataclass
from typing import Any, Sequence

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class ClapError(Exception):
    """Ошибка детекции хлопков."""


class ClapUnavailable(ClapError):
    """Движок недоступен — можно fallback на другой."""


# ---------------------------------------------------------------------------
# Конфигурация, признаки, результат
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ClapConfig:
    """Параметры детектора хлопков.

    Дефолты подобраны под типичный хлопок ладоней в 20–50 см от микрофона
    при 16 кГц моно; при необходимости подкручиваются из ``config/settings``.
    """

    sample_rate: int = 16000
    #: Длина кадра анализа, мс (20 мс — как у VAD/wake-word).
    frame_ms: int = 20
    #: Порог энергии кадра, дБФС: тише — это не хлопок.
    rms_threshold_db: float = -25.0
    #: Минимальный ZCR (доля сэмплов смены знака): отделить «глухой» стук.
    zcr_min: float = 0.08
    #: Минимальная спектральная плоскость [0..1]: отделить тон/гудение.
    flatness_min: float = 0.35
    #: Порог итоговой уверенности [0..1].
    score_threshold: float = 0.5
    #: Требовать «всплеск из тишины» (атака) — защита от фонового шума.
    require_transient: bool = True
    #: На сколько дБ кадр-хлопок должен быть громче предыдущего (атака).
    transient_delta_db: float = 6.0
    #: «Тихий период» после срабатывания — защита от двойных срабатываний.
    cooldown_ms: int = 350
    #: Окно для распознавания ДВОЙНОГО хлопка (второй хлопок в эти мс).
    double_window_ms: int = 700

    def __post_init__(self) -> None:
        if self.sample_rate <= 0:
            raise ValueError("sample_rate должен быть положительным")
        if self.frame_ms <= 0:
            raise ValueError("frame_ms должен быть положительным")
        if not 0.0 <= self.zcr_min <= 1.0:
            raise ValueError("zcr_min должен быть в диапазоне [0..1]")
        if not 0.0 <= self.flatness_min <= 1.0:
            raise ValueError("flatness_min должен быть в диапазоне [0..1]")
        if not 0.0 <= self.score_threshold <= 1.0:
            raise ValueError("score_threshold должен быть в диапазоне [0..1]")
        if self.cooldown_ms < 0 or self.double_window_ms < 0:
            raise ValueError("cooldown_ms/double_window_ms не могут быть отрицательными")

    @property
    def frame_samples(self) -> int:
        """Число сэмплов на кадр (20 мс @ 16 кГц = 320)."""
        return self.sample_rate * self.frame_ms // 1000

    @property
    def frame_bytes(self) -> int:
        """Размер кадра PCM s16le в байтах."""
        return self.frame_samples * 2

    def ms_to_frames(self, ms: int) -> int:
        """Перевести миллисекунды в целое число кадров (минимум 1)."""
        return max(1, round(ms / self.frame_ms))


@dataclass(frozen=True)
class ClapFeatures:
    """Признаки кадра PCM: энергия + ZCR + спектральная плоскость."""

    rms_db: float
    zcr: float
    flatness: float


@dataclass(frozen=True)
class ClapResult:
    """Вердикт движка: похож ли кадр на хлопок и с какой уверенностью."""

    detected: bool
    score: float = 0.0
    features: ClapFeatures | None = None
    engine: str = ""

    def __post_init__(self) -> None:
        if not 0.0 <= self.score <= 1.0:
            object.__setattr__(self, "score", min(1.0, max(0.0, float(self.score))))


# ---------------------------------------------------------------------------
# Утилиты признаков (чистый Python)
# ---------------------------------------------------------------------------
def _to_samples(pcm: bytes | bytearray | memoryview | Sequence[int]) -> list[int]:
    """Привести вход к списку целых сэмплов s16le (нечётный хвост отбрасывается)."""
    if isinstance(pcm, (bytes, bytearray, memoryview)):
        buf = array("h")
        raw = bytes(pcm)[: len(pcm) - (len(pcm) % 2)]
        try:
            buf.frombytes(raw)
        except ValueError as e:  # pragma: no cover — почти невозможно
            raise ClapError(f"Некорректный PCM: {e}") from e
        if sys.byteorder == "big":  # pragma: no cover — на наших x64 не встречается
            buf.byteswap()
        return list(buf)
    try:
        return [int(s) for s in pcm]
    except (TypeError, ValueError) as e:
        raise ClapError(f"Некорректный PCM-последовательность: {e}") from e


def rms_db(samples: Sequence[int]) -> float:
    """RMS-уровень сэмплов в дБФС (−120 при полной тишине)."""
    if not samples:
        return -120.0
    mean_sq = sum(s * s for s in samples) / len(samples)
    if mean_sq <= 0.0:
        return -120.0
    return 20.0 * math.log10(math.sqrt(mean_sq) / 32768.0)


def zero_crossing_rate(samples: Sequence[int]) -> float:
    """Доля сэмплов, на которых знак сигнала сменился (ZCR, [0..1])."""
    if len(samples) < 2:
        return 0.0
    crossings = 0
    prev = samples[0]
    for cur in samples[1:]:
        if (prev >= 0 > cur) or (prev < 0 <= cur):
            crossings += 1
        prev = cur
    return crossings / (len(samples) - 1)


def spectral_flatness(
    samples: Sequence[int], *, max_samples: int = 256
) -> float:
    """Спектральная плоскость [0..1] через наивный DFT.

    1.0 — белый шум («шипение» хлопка), близко к 0 — тон/гудение.
    Берём не более ``max_samples`` сэмплов, чтобы DFT O(n²) оставался быстрым;
    DC-компоненту исключаем (вычитаем среднее).
    """
    data = list(samples[:max_samples])
    n = len(data)
    if n < 8:
        raise ClapError("Слишком маленький кусок PCM для спектрального анализа")
    mean = sum(data) / n
    centered = [s - mean for s in data]
    half = n // 2
    powers: list[float] = []
    for k in range(1, half):
        re = 0.0
        im = 0.0
        for t, s in enumerate(centered):
            ang = 2.0 * math.pi * k * t / n
            re += s * math.cos(ang)
            im += s * math.sin(ang)
        powers.append((re * re + im * im) / (n * n) + 1e-12)
    if not powers:
        raise ClapError("Спектр пуст — увеличьте окно анализа")
    log_mean = sum(math.log(p) for p in powers) / len(powers)
    arith_mean = sum(powers) / len(powers)
    # exp(log_mean − log(arith_mean)) численно устойчивее отношения,
    # а зажим в [0..1] убирает ошибки округления (белый шум даёт ≈1.0).
    flatness = math.exp(log_mean - math.log(arith_mean))
    return min(1.0, max(0.0, flatness))


def compute_features(
    pcm: bytes | bytearray | memoryview | Sequence[int],
) -> ClapFeatures:
    """Посчитать признаки кадра: RMS (дБ), ZCR, спектральная плоскость."""
    samples = _to_samples(pcm)
    if not samples:
        raise ClapError("Пустой PCM: нечего анализировать")
    return ClapFeatures(
        rms_db=rms_db(samples),
        zcr=zero_crossing_rate(samples),
        flatness=spectral_flatness(samples),
    )


# ---------------------------------------------------------------------------
# Движки
# ---------------------------------------------------------------------------
class ClapEngine(abc.ABC):
    """Контракт движка детекции хлопков (кадр PCM → вердикт)."""

    name: str = "abstract"

    def is_available(self) -> bool:
        """Движок готов к работе (библиотеки/модели загружены)."""
        return True

    @abc.abstractmethod
    def detect(self, pcm: bytes, *, sample_rate: int = 16000) -> ClapResult:
        """Вердикт по одному кадру PCM s16le."""

    def describe(self) -> dict[str, Any]:
        """Краткое описание движка (для /diagnostics и логов)."""
        return {"name": self.name, "available": self.is_available()}


class SpectralClapEngine(ClapEngine):
    """Движок на RMS + ZCR + спектральной плоскости (чистый Python).

    Работает всегда — эталонный движок без внешних зависимостей.
    Компоненты оценки:

      * энергия (дБФС против порога) — 0.5 веса;
      * ZCR против ``zcr_min``               — 0.25 веса;
      * спектральная плоскость               — 0.25 веса.

    Жёсткие гейты (пороги ``ClapConfig``) выполняются всегда: кадр с низкой
    энергией или «глухим» спектром не становится хлопком ни при каком score.
    """

    name = "spectral"

    def __init__(self, config: ClapConfig | None = None) -> None:
        self.config = config or ClapConfig()

    def is_available(self) -> bool:
        return True

    @staticmethod
    def _score_energy(db: float, threshold_db: float) -> float:
        """Компонент энергии [0..1]: шумовой пол −60 дБФС → 0, 0 дБФС → 1."""
        if db <= -60.0:
            return 0.0
        if threshold_db <= -60.0:
            return 1.0
        return min(1.0, max(0.0, (db + 60.0) / (threshold_db + 60.0)))

    def detect(
        self,
        pcm: bytes,
        *,
        sample_rate: int = 16000,
        prev_rms_db: float | None = None,
    ) -> ClapResult:
        """Вердикт по кадру PCM.

        ``prev_rms_db`` — RMS предыдущего кадра для проверки «атаки»
        (всплеск из тишины); если ``None`` и ``require_transient`` — считаем,
        что атака подтверждена (одиночный анализ без истории).
        """
        if len(pcm) < 2:
            raise ClapError("Слишком маленький кусок PCM")
        cfg = self.config
        feats = compute_features(pcm)

        # Жёсткие гейты: энергия, ZCR, «плоскость» спектра.
        if feats.rms_db < cfg.rms_threshold_db:
            return ClapResult(False, 0.0, feats, self.name)
        if feats.zcr < cfg.zcr_min:
            return ClapResult(False, 0.0, feats, self.name)
        if feats.flatness < cfg.flatness_min:
            return ClapResult(False, 0.0, feats, self.name)
        # Атака: кадр заметно громче предыдущего.
        if cfg.require_transient and prev_rms_db is not None:
            if feats.rms_db - prev_rms_db < cfg.transient_delta_db:
                return ClapResult(False, 0.0, feats, self.name)

        score = (
            0.5 * self._score_energy(feats.rms_db, cfg.rms_threshold_db)
            + 0.25 * min(1.0, feats.zcr / 0.5)
            + 0.25 * min(1.0, feats.flatness / 0.6)
        )
        return ClapResult(score >= cfg.score_threshold, score, feats, self.name)


# ---------------------------------------------------------------------------
# Диспетчер движков
# ---------------------------------------------------------------------------
def _accepts_prev_rms(eng: ClapEngine) -> bool:
    """Поддерживает ли движок необязательный параметр ``prev_rms_db``.

    Контракт ``ClapEngine.detect`` — только ``pcm`` и ``sample_rate``;
    ``prev_rms_db`` (история для проверки «атаки») расширение, поэтому
    роутер передаёт его только движкам, которые его принимают.
    """
    try:
        params = inspect.signature(eng.detect).parameters
    except (TypeError, ValueError):  # встроенные/C-обёртки без сигнатуры
        return False
    return "prev_rms_db" in params or any(
        p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values()
    )


class ClapRouter:
    """Диспетчер движков детекции хлопков: смена + fallback (по образцу VADRouter)."""

    def __init__(
        self,
        engines: dict[str, ClapEngine] | None = None,
        primary: str = "spectral",
        fallback_chain: list[str] | None = None,
    ) -> None:
        self._engines = engines or {"spectral": SpectralClapEngine()}
        self._primary = primary
        self._fallback_chain = fallback_chain or [primary]

    @property
    def primary(self) -> str:
        """Имя основного движка."""
        return self._primary

    def set_primary(self, name: str) -> None:
        """Сменить основной движок (ошибка, если такого нет)."""
        if name not in self._engines:
            raise ClapUnavailable(f"Неизвестный движок детекции хлопков: {name!r}")
        self._primary = name

    def available(self) -> list[str]:
        """Список доступных движков."""
        return [n for n, e in self._engines.items() if e.is_available()]

    def _chain(self, explicit: str | None) -> list[str]:
        order = [explicit] if explicit else list(self._fallback_chain)
        seen: list[str] = []
        for name in order:
            if name and name not in seen:
                seen.append(name)
        if self._primary not in seen:
            seen.append(self._primary)
        return seen

    def detect(
        self,
        pcm: bytes,
        *,
        sample_rate: int = 16000,
        engine: str | None = None,
        prev_rms_db: float | None = None,
    ) -> ClapResult:
        """Вердикт через основной движок; при недоступности — fallback-цепочка."""
        errors: list[str] = []
        for name in self._chain(engine):
            eng = self._engines.get(name)
            if eng is None:
                errors.append(f"{name}: нет такого движка")
                continue
            if not eng.is_available():
                errors.append(f"{name}: недоступен")
                continue
            try:
                if _accepts_prev_rms(eng):
                    return eng.detect(
                        pcm, sample_rate=sample_rate, prev_rms_db=prev_rms_db
                    )
                return eng.detect(pcm, sample_rate=sample_rate)
            except ClapError as e:
                errors.append(f"{name}: {e}")
        raise ClapUnavailable(
            "Ни один движок детекции хлопков не сработал: " + "; ".join(errors)
        )


def create_default_router(config: ClapConfig | None = None) -> ClapRouter:
    """Роутер по умолчанию: spectral-движок (чистый Python, работает везде)."""
    return ClapRouter(
        engines={"spectral": SpectralClapEngine(config)}, primary="spectral"
    )


# ---------------------------------------------------------------------------
# Потоковая детекция: события
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ClapEvent:
    """Событие детектора: одиночный или двойной хлопок."""

    #: Момент события, мс от старта потока кадров.
    time_ms: int
    #: True — второй хлопок пары («двойной хлопок»).
    is_double: bool = False
    score: float = 0.0
    features: ClapFeatures | None = None

    @property
    def is_single(self) -> bool:
        """Одиночный хлопок (не часть двойного)."""
        return not self.is_double


class ClapDetector:
    """Потоковая детекция хлопков: кадры PCM → события ``ClapEvent``.

    Держит состояние (предыдущий кадр, cooldown, окно двойного хлопка) —
    поэтому один экземпляр на один поток аудио. Порядок кадров сохраняется.
    """

    def __init__(
        self,
        router: ClapRouter | None = None,
        config: ClapConfig | None = None,
    ) -> None:
        self.config = config or ClapConfig()
        self.router = router or create_default_router(self.config)
        self._frame_index = 0
        self._prev_rms_db: float | None = None
        self._last_clap_ms: int | None = None
        self._last_single_ms: int | None = None

    def reset(self) -> None:
        """Сбросить состояние (новый поток аудио)."""
        self._frame_index = 0
        self._prev_rms_db = None
        self._last_clap_ms = None
        self._last_single_ms = None

    @property
    def position_ms(self) -> int:
        """Текущая позиция потока, мс."""
        return self._frame_index * self.config.frame_ms

    def feed(self, pcm: bytes) -> ClapEvent | None:
        """Обработать кадр PCM; вернуть событие хлопка или ``None``."""
        cfg = self.config
        t_ms = self.position_ms
        self._frame_index += 1

        result = self.router.detect(
            pcm, sample_rate=cfg.sample_rate, prev_rms_db=self._prev_rms_db
        )
        feats = result.features
        self._prev_rms_db = feats.rms_db if feats is not None else self._prev_rms_db

        if not result.detected:
            return None
        # Cooldown: повторные кадры того же хлопка не создают событий.
        if self._last_clap_ms is not None and t_ms - self._last_clap_ms < cfg.cooldown_ms:
            return None

        # Двойной хлопок: второй хлопок в окне после одиночного.
        is_double = False
        if (
            self._last_single_ms is not None
            and t_ms - self._last_single_ms <= cfg.double_window_ms
        ):
            is_double = True
            self._last_single_ms = None
        else:
            self._last_single_ms = t_ms
        self._last_clap_ms = t_ms

        event = ClapEvent(
            time_ms=t_ms, is_double=is_double, score=result.score, features=feats
        )
        logger.debug(
            "ClapEvent t=%dms double=%s score=%.2f", t_ms, is_double, result.score
        )
        return event
