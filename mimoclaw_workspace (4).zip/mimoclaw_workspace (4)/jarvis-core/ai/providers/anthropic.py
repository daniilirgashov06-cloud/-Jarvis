"""
Облачный LLM-провайдер Anthropic (Claude).

Через Messages API ``/v1/messages`` с поддержкой tool use (function calling).
"""

from __future__ import annotations

import json
from typing import Any

from .base import (
    BaseLLMProvider,
    LLMMessage,
    LLMResponse,
    ProviderError,
    ProviderUnavailable,
    ToolCall,
    Usage,
)

DEFAULT_BASE_URL = "https://api.anthropic.com"
ANTHROPIC_VERSION = "2023-06-01"


class AnthropicProvider(BaseLLMProvider):
    """Провайдер Anthropic Claude."""

    name = "anthropic"

    def __init__(
        self,
        model: str = "claude-3-5-sonnet-latest",
        api_key: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 60.0,
    ) -> None:
        self.model = model
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def is_available(self) -> bool:
        return bool(self.api_key)

    async def complete(
        self,
        messages: list[LLMMessage],
        tools: list[dict[str, Any]] | None = None,
        *,
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> LLMResponse:
        if not self.api_key:
            raise ProviderUnavailable("Anthropic: не задан API-ключ")
        try:
            import httpx
        except ImportError as exc:  # pragma: no cover
            raise ProviderUnavailable("httpx не установлен") from exc

        system, api_messages = self._to_anthropic_messages(messages)
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": api_messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        if system:
            payload["system"] = system
        if tools:
            payload["tools"] = self._to_anthropic_tools(tools)

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(
                    f"{self.base_url}/v1/messages",
                    json=payload,
                    headers={
                        "x-api-key": self.api_key,
                        "anthropic-version": ANTHROPIC_VERSION,
                    },
                )
        except Exception as exc:  # noqa: BLE001
            raise ProviderUnavailable(f"Anthropic недоступен: {exc}") from exc

        if resp.status_code in (401, 403):
            raise ProviderUnavailable(f"Anthropic: авторизация отклонена ({resp.status_code})")
        if resp.status_code != 200:
            raise ProviderError(f"Anthropic HTTP {resp.status_code}: {resp.text[:200]}")

        data = resp.json()
        content_text, tool_calls = self._parse_content(data.get("content", []))
        usage = Usage(
            prompt_tokens=int(data.get("usage", {}).get("input_tokens", 0) or 0),
            completion_tokens=int(data.get("usage", {}).get("output_tokens", 0) or 0),
        )
        return LLMResponse(
            content=content_text,
            tool_calls=tool_calls,
            usage=usage,
            provider=self.name,
            model=self.model,
            raw=data,
        )

    # -- конвертация --------------------------------------------------------
    @staticmethod
    def _to_anthropic_messages(
        messages: list[LLMMessage],
    ) -> tuple[str, list[dict[str, Any]]]:
        system_parts: list[str] = []
        out: list[dict[str, Any]] = []
        for m in messages:
            if m.role == "system":
                system_parts.append(m.content)
                continue
            if m.role == "tool":
                out.append(
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "tool_result",
                                "tool_use_id": m.tool_call_id or "",
                                "content": m.content,
                            }
                        ],
                    }
                )
                continue
            if m.role == "assistant" and m.tool_calls:
                blocks: list[dict[str, Any]] = []
                if m.content:
                    blocks.append({"type": "text", "text": m.content})
                for tc in m.tool_calls:
                    blocks.append(
                        {
                            "type": "tool_use",
                            "id": tc.id,
                            "name": tc.name,
                            "input": tc.arguments,
                        }
                    )
                out.append({"role": "assistant", "content": blocks})
            else:
                out.append({"role": m.role, "content": m.content})
        return "\n".join(system_parts), out

    @staticmethod
    def _to_anthropic_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        # Принимаем схемы в формате OpenAI и конвертируем в Anthropic.
        converted: list[dict[str, Any]] = []
        for t in tools:
            fn = t.get("function", t)
            converted.append(
                {
                    "name": fn.get("name", ""),
                    "description": fn.get("description", ""),
                    "input_schema": fn.get("parameters", {"type": "object", "properties": {}}),
                }
            )
        return converted

    @staticmethod
    def _parse_content(blocks: list[dict[str, Any]]) -> tuple[str, list[ToolCall]]:
        text_parts: list[str] = []
        calls: list[ToolCall] = []
        for b in blocks or []:
            btype = b.get("type")
            if btype == "text":
                text_parts.append(b.get("text", ""))
            elif btype == "tool_use":
                calls.append(
                    ToolCall(
                        id=b.get("id", ""),
                        name=b.get("name", ""),
                        arguments=b.get("input", {}) or {},
                    )
                )
        return "\n".join(text_parts), calls

    def describe(self) -> dict[str, Any]:
        return {**super().describe(), "model": self.model}
