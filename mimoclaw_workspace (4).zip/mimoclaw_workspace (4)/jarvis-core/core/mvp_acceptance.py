"""
Приёмка MVP JARVIS CORE — сквозная проверка «Джарвис» → команда → голосовой ответ».

Реализует пункт ROADMAP «Приёмка MVP ... за <2 сек»: прогоняет полную цепочку
(ключевое слово → STT → LLM/function calling → действия → TTS → воспроизведение)
через **реальные** компоненты ядра (``Orchestrator``, реестр команд, роутеры)
и замеряет время каждого этапа против бюджета latency.

Аппаратные края (микрофон, динамики) и «железо» детектора подставляются извне
через тонкие протоколы ``WakeProbe`` / ``SpeechSink`` — структурно им подходят
``WakeWordRouter`` (audio/wakeword) и ``AudioPlayer`` (audio/playback).
Благодаря этому приёмка одним и тем же кодом прогоняется и в тестах, и на живом
ПК пользователя (см. ключевое инженерное решение №7 в README).

Использование:
    acc = MvpAcceptance(orchestrator, wake=wake_router, sink=player)
    report = await acc.run_voice(pcm_from_mic)
    print(report.summary())
    assert report.ok

Ошибки этапов и превышение бюджета **не поднимают исключений** — они
фиксируются в ``AcceptanceReport``: приёмка обязана отчитаться, а не упасть.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol

from core.orchestrator import Orchestrator

if TYPE_CHECKING:  # только для аннотаций — без лишних runtime-зависимостей
    from audio.wakeword import WakeWordResult

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Имена этапов конвейера (в порядке выполнения)
# ---------------------------------------------------------------------------
STAGE_WAKE = "wake"
STAGE_STT = "stt"
STAGE_ASSISTANT = "assistant"  # LLM + function calling + действия + озвучка
STAGE_PLAYBACK = "playback"

# Бюджет latency по ТЗ-14: полный ответ ассистента — быстрее 2 секунд
DEFAULT_BUDGET_MS = 2000.0


# ---------------------------------------------------------------------------
# Краевые протоколы (инжектируемые зависимости)
# ---------------------------------------------------------------------------
class WakeProbe(Protocol):
    """Детектор ключевого слова (структурно подходит ``WakeWordRouter``)."""

    def detect(self, pcm: bytes, *, sample_rate: int) -> "WakeWordResult": ...


class SpeechSink(Protocol):
    """Приёмник озвученной речи (структурно подходит ``AudioPlayer.speak``)."""

    async def speak(self, pcm: bytes) -> None: ...


# ---------------------------------------------------------------------------
# Бюджеты и отчёт
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class AcceptanceBudget:
    """Бюджеты latency: суммарный и (опционально) по этапам конвейера."""

    total_ms: float = DEFAULT_BUDGET_MS
    stage_ms: dict[str, float] = field(default_factory=dict)

    def stage_limit(self, stage: str) -> float | None:
        """Лимит этапа (мс) или None, если лимит не задан."""
        return self.stage_ms.get(stage)


@dataclass
class StageTiming:
    """Итог одного этапа конвейера."""

    name: str
    ms: float = 0.0
    ok: bool = True
    skipped: bool = False
    note: str = ""


@dataclass
class AcceptanceReport:
    """Отчёт о приёмке: этапы, тайминги, провалы и итоговый вердикт."""

    scenario: str
    budget: AcceptanceBudget
    stages: list[StageTiming] = field(default_factory=list)
    total_ms: float = 0.0
    transcript: str = ""
    reply: str = ""
    actions: list[str] = field(default_factory=list)
    played: bool = False
    failures: list[str] = field(default_factory=list)

    @property
    def within_budget(self) -> bool:
        """Уложились ли в суммарный бюджет latency."""
        return self.total_ms <= self.budget.total_ms

    @property
    def ok(self) -> bool:
        """Приёмка пройдена: нет ни одной провали/превышения бюджета."""
        return not self.failures

    def stage(self, name: str) -> StageTiming | None:
        """Тайминг этапа по имени (или None, если этапа не было)."""
        for st in self.stages:
            if st.name == name:
                return st
        return None

    def summary(self) -> str:
        """Человекочитаемая сводка для консоли/лога."""
        verdict = "OK" if self.ok else "FAIL"
        lines = [
            f"Приёмка MVP [{self.scenario}]: {verdict} — {self.total_ms:.1f} мс "
            f"при бюджете {self.budget.total_ms:.0f} мс",
        ]
        for st in self.stages:
            mark = "✓" if st.ok else ("−" if st.skipped else "✗")
            note = f"  {st.note}" if st.note else ""
            lines.append(f"  {st.name:<10} {st.ms:8.1f} мс  {mark}{note}")
        if self.transcript:
            lines.append(f"  распознано: {self.transcript}")
        if self.reply:
            lines.append(f"  ответ:      {self.reply}")
        if self.actions:
            lines.append(f"  действия:   {', '.join(self.actions)}")
        for failure in self.failures:
            lines.append(f"  ! {failure}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Приёмочный прогон
# ---------------------------------------------------------------------------
class MvpAcceptance:
    """
    Сквозная приёмка MVP поверх реального ``Orchestrator``.

    Этапы: ``wake`` → ``stt`` → ``assistant`` (LLM + действия + озвучка) →
    ``playback``. Провал этапа останавливает сценарий (как в бою: без команды
    нет и ответа), остальные этапы помечаются как пропущенные.
    """

    def __init__(
        self,
        orchestrator: Orchestrator,
        *,
        wake: WakeProbe | None = None,
        sink: SpeechSink | None = None,
        budget: AcceptanceBudget | None = None,
        clock: Callable[[], float] = time.perf_counter,
    ) -> None:
        self.orchestrator = orchestrator
        self.wake = wake
        self.sink = sink
        self.budget = budget or AcceptanceBudget()
        self._clock = clock

    # -- публичный API -----------------------------------------------------
    async def run_voice(
        self,
        pcm: bytes,
        *,
        wake_pcm: bytes | None = None,
        sample_rate: int = 16000,
        language: str = "auto",
        history: list[dict[str, Any]] | None = None,
    ) -> AcceptanceReport:
        """
        Полный голосовой сценарий: ключевое слово → STT → ответ → озвучка → вывод.

        ``pcm`` — фраза команды (что слышит STT), ``wake_pcm`` — окно с ключевым
        словом (по умолчанию берётся тот же кусок аудио).
        """
        report = AcceptanceReport(scenario="voice", budget=self.budget)
        start = self._clock()

        # 1. Ключевое слово (детектор синхронный — см. audio/wakeword)
        if self.wake is None:
            self._skip(report, STAGE_WAKE, "детектор ключевого слова не подключён")
        elif not self._run_wake(report, wake_pcm if wake_pcm is not None else pcm, sample_rate):
            self._skip(report, STAGE_STT, "этап пропущен: нет ключевого слова")
            self._skip(report, STAGE_ASSISTANT, "этап пропущен: нет ключевого слова")
            self._skip(report, STAGE_PLAYBACK, "этап пропущен: нет ключевого слова")
            return self._finalize(report, start)

        # 2. Распознавание речи (реальный STRouter с fallback-цепочкой)
        if self.orchestrator.stt is None:
            self._fail(report, STAGE_STT, "STT-роутер не подключён")
            self._skip(report, STAGE_ASSISTANT, "этап пропущен: нет распознанной речи")
            self._skip(report, STAGE_PLAYBACK, "этап пропущен: нет распознанной речи")
            return self._finalize(report, start)

        stt = self.orchestrator.stt

        async def _transcribe() -> Any:
            return await stt.transcribe(pcm, sample_rate=sample_rate, language=language)

        transcript = await self._stage(report, STAGE_STT, _transcribe)
        if transcript is None:
            self._skip(report, STAGE_ASSISTANT, "этап пропущен: нет распознанной речи")
            self._skip(report, STAGE_PLAYBACK, "этап пропущен: нет распознанной речи")
            return self._finalize(report, start)
        report.transcript = transcript.text

        # 3-4. Ответ ассистента и воспроизведение
        return await self._converse(report, start, transcript.text, history)

    async def run_text(
        self,
        text: str,
        *,
        history: list[dict[str, Any]] | None = None,
    ) -> AcceptanceReport:
        """
        Ускоренный сценарий без микрофона: текст → ответ → озвучка → вывод.

        Этапы ``wake`` и ``stt`` не выполняются — это приёмка «мозгов» и озвучки.
        """
        report = AcceptanceReport(scenario="text", budget=self.budget)
        start = self._clock()
        report.transcript = text
        return await self._converse(report, start, text, history)

    # -- этапы -------------------------------------------------------------
    async def _converse(
        self,
        report: AcceptanceReport,
        start: float,
        text: str,
        history: list[dict[str, Any]] | None,
    ) -> AcceptanceReport:
        """Этапы assistant (LLM + действия + озвучка) и playback."""
        result = await self._stage(
            report,
            STAGE_ASSISTANT,
            lambda: self.orchestrator.process_text(text, history=history),
        )
        if result is None:
            self._skip(report, STAGE_PLAYBACK, "этап пропущен: нет ответа ассистента")
            return self._finalize(report, start)

        report.reply = result.reply
        report.actions = [a.name for a in result.actions if a.ok]
        note = f"провайдер {result.used_provider or '—'}"
        if report.actions:
            note += f", действия: {', '.join(report.actions)}"
        self._set_note(report, STAGE_ASSISTANT, note)

        audio: bytes = result.audio or b""
        if self.sink is None:
            self._skip(report, STAGE_PLAYBACK, "приёмник звука не подключён")
        elif not audio:
            # Критерий приёмки — именно ГОЛОСОвой ответ: тишина = провал.
            self._fail(report, STAGE_PLAYBACK, "ответ не озвучен (TTS не вернул PCM)")
        else:

            async def _speak() -> bool:
                await self.sink.speak(audio)  # type: ignore[union-attr]
                return True

            played = await self._stage(report, STAGE_PLAYBACK, _speak)
            if played is not None:
                report.played = True
                self._set_note(report, STAGE_PLAYBACK, f"PCM {len(audio)} байт")
        return self._finalize(report, start)

    def _run_wake(self, report: AcceptanceReport, pcm: bytes, sample_rate: int) -> bool:
        """Этап ключевого слова (синхронный): True — слово распознано."""
        t0 = self._clock()
        try:
            verdict = self.wake.detect(pcm, sample_rate=sample_rate)  # type: ignore[union-attr]
        except Exception as exc:  # noqa: BLE001 — приёмка отчитывается, а не падает
            self._record(report, STAGE_WAKE, (self._clock() - t0) * 1000.0,
                         note=f"{type(exc).__name__}: {exc}")
            report.failures.append(f"этап «{STAGE_WAKE}»: {type(exc).__name__}: {exc}")
            return False

        ms = (self._clock() - t0) * 1000.0
        if not verdict.detected:
            self._record(report, STAGE_WAKE, ms, ok=False, note="ключевое слово не распознано")
            report.failures.append("этап «wake»: ключевое слово «Джарвис» не распознано")
            return False

        word = verdict.word or "джарвис"
        self._record(report, STAGE_WAKE, ms, note=f"«{word}» score={verdict.score:.2f}")
        self._check_stage_budget(report, STAGE_WAKE, ms)
        return True

    # -- служебное ---------------------------------------------------------
    async def _stage(
        self,
        report: AcceptanceReport,
        name: str,
        fn: Callable[[], Awaitable[Any]],
    ) -> Any | None:
        """
        Выполнить этап с замером времени.

        Возвращает результат ``fn`` или None, если этап провален (ошибка уже
        записана в отчёт).
        """
        t0 = self._clock()
        try:
            value = await fn()
        except Exception as exc:  # noqa: BLE001 — приёмка отчитывается, а не падает
            ms = (self._clock() - t0) * 1000.0
            self._record(report, name, ms, ok=False, note=f"{type(exc).__name__}: {exc}")
            report.failures.append(f"этап «{name}»: {type(exc).__name__}: {exc}")
            return None
        ms = (self._clock() - t0) * 1000.0
        self._record(report, name, ms)
        self._check_stage_budget(report, name, ms)
        return value

    @staticmethod
    def _record(
        report: AcceptanceReport,
        name: str,
        ms: float,
        *,
        ok: bool = True,
        skipped: bool = False,
        note: str = "",
    ) -> None:
        report.stages.append(StageTiming(name=name, ms=ms, ok=ok, skipped=skipped, note=note))

    @staticmethod
    def _skip(report: AcceptanceReport, name: str, note: str) -> None:
        report.stages.append(StageTiming(name=name, ok=True, skipped=True, note=note))

    def _fail(self, report: AcceptanceReport, name: str, note: str) -> None:
        self._record(report, name, 0.0, ok=False, note=note)
        report.failures.append(f"этап «{name}»: {note}")

    @staticmethod
    def _set_note(report: AcceptanceReport, name: str, note: str) -> None:
        stage = report.stage(name)
        if stage is not None:
            stage.note = note

    def _check_stage_budget(self, report: AcceptanceReport, name: str, ms: float) -> None:
        limit = self.budget.stage_limit(name)
        if limit is not None and ms > limit:
            report.failures.append(
                f"этап «{name}»: {ms:.1f} мс превышает лимит {limit:.1f} мс"
            )

    def _finalize(self, report: AcceptanceReport, start: float) -> AcceptanceReport:
        """Итог: суммарное время + сверка с бюджетом (всегда возвращает отчёт)."""
        report.total_ms = (self._clock() - start) * 1000.0
        if not report.within_budget:
            report.failures.append(
                f"итого {report.total_ms:.1f} мс превышает бюджет "
                f"{report.budget.total_ms:.1f} мс"
            )
        logger.info(
            "Приёмка MVP [%s]: %s (%.1f мс при бюджете %.0f мс)",
            report.scenario,
            "OK" if report.ok else "FAIL",
            report.total_ms,
            report.budget.total_ms,
        )
        return report
