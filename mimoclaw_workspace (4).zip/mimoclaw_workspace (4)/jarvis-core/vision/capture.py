"""
Захват экрана для зрительного конвейера (vision) JARVIS CORE.

Единый контракт ``ScreenCaptureBackend`` + диспетчер ``CaptureRouter``
(живая смена бэкендов + fallback) + высокоуровневый ``ScreenCapture``.

Бэкенды:
  - ``MssBackend`` — через ``mss`` (быстро, локально, кроссплатформенно);
  - ``PillowBackend`` — через ``PIL.ImageGrab`` (локально, простой путь);
  - ``SyntheticBackend`` — генерация детерминированных тестовых кадров
    (отладка, тесты, аварийный fallback без графического окружения).

Приватность: перед выдачей/сохранением кадра настроенные регионы
(парольные поля, личные окна) заливаются чёрным (``privacy_regions``).
Дедупликация кадров — по отпечатку ``ScreenFrame.fingerprint()``
(SHA-1 пикселей). Сохранение — чистый PNG (кодировщик без зависимостей).
"""

from __future__ import annotations

import abc
import hashlib
import logging
import struct
import time
import zlib
from collections import deque
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Iterable, Sequence

logger = logging.getLogger(__name__)

#: допустимые расширения файлов захвата
CAPTURE_EXTS: frozenset[str] = frozenset({".png"})

#: предохранитель от «памяти-бомбы»: разрешённый размер кадра, Мпикс
MAX_FRAME_MEGAPIXELS: int = 32


class CaptureError(Exception):
    """Ошибка захвата экрана."""


class CaptureUnavailable(CaptureError):
    """Бэкенд недоступен (нет библиотеки/дисплея) — можно fallback."""


# ---------------------------------------------------------------------------
# Геометрия
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class CaptureRegion:
    """Прямоугольник захвата в абсолютных координатах экрана."""

    x: int
    y: int
    width: int
    height: int

    def __post_init__(self) -> None:
        for name, value in (
            ("x", self.x),
            ("y", self.y),
            ("width", self.width),
            ("height", self.height),
        ):
            if isinstance(value, bool) or not isinstance(value, int):
                raise ValueError(f"{name} должен быть int, получено: {value!r}")
        if self.width <= 0 or self.height <= 0:
            raise ValueError("width/height должны быть положительными")
        if self.width * self.height > MAX_FRAME_MEGAPIXELS * 1_000_000:
            raise ValueError(
                f"регион слишком большой: {self.width}x{self.height} "
                f"(лимит {MAX_FRAME_MEGAPIXELS} Мпикс)"
            )

    @classmethod
    def from_monitor(cls, mon: "MonitorInfo") -> "CaptureRegion":
        """Регион, покрывающий весь монитор."""
        return cls(mon.left, mon.top, mon.width, mon.height)

    @property
    def box(self) -> tuple[int, int, int, int]:
        """Кортеж (x, y, x2, y2) — правая/нижняя границы невключительно."""
        return (self.x, self.y, self.x + self.width, self.y + self.height)

    def intersection(self, other: "CaptureRegion") -> "CaptureRegion | None":
        """Пересечение с другим регионом или ``None``, если не пересекаются."""
        x1, y1, x2, y2 = self.box
        ox1, oy1, ox2, oy2 = other.box
        nx1, ny1 = max(x1, ox1), max(y1, oy1)
        nx2, ny2 = min(x2, ox2), min(y2, oy2)
        if nx2 <= nx1 or ny2 <= ny1:
            return None
        return CaptureRegion(nx1, ny1, nx2 - nx1, ny2 - ny1)

    def to_local(self, frame_region: "CaptureRegion") -> "CaptureRegion | None":
        """
        Переводит абсолютный регион в координаты кадра ``frame_region``.

        Возвращает ``None``, если регион не пересекается с кадром.
        """
        common = self.intersection(frame_region)
        if common is None:
            return None
        return CaptureRegion(
            common.x - frame_region.x,
            common.y - frame_region.y,
            common.width,
            common.height,
        )


@dataclass(frozen=True)
class MonitorInfo:
    """Описание физического монитора."""

    index: int
    left: int
    top: int
    width: int
    height: int

    @property
    def region(self) -> CaptureRegion:
        return CaptureRegion(self.left, self.top, self.width, self.height)


# ---------------------------------------------------------------------------
# Кадр
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ScreenFrame:
    """
    Захваченный кадр экрана.

    ``pixels`` — сырые байты RGB (3 байта/пиксель, строка за строкой).
    """

    width: int
    height: int
    pixels: bytes
    region: CaptureRegion
    monitor: int = 0
    backend: str = ""
    timestamp: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        expected = self.width * self.height * 3
        if len(self.pixels) != expected:
            raise ValueError(
                f"размер пикселей не совпадает с геометрией: "
                f"{len(self.pixels)} != {self.width}x{self.height}x3"
            )
        if (self.region.width, self.region.height) != (self.width, self.height):
            raise ValueError("геометрия кадра не совпадает с регионом")

    def pixel(self, x: int, y: int) -> tuple[int, int, int]:
        """Цвет пикселя (R, G, B) в локальных координатах кадра."""
        if not (0 <= x < self.width and 0 <= y < self.height):
            raise ValueError(f"пиксель ({x}, {y}) вне кадра {self.width}x{self.height}")
        off = (y * self.width + x) * 3
        return (self.pixels[off], self.pixels[off + 1], self.pixels[off + 2])

    def fingerprint(self) -> str:
        """Отпечаток кадра (SHA-1 геометрии + пикселей) — для дедупликации."""
        digest = hashlib.sha1()
        digest.update(struct.pack(">II", self.width, self.height))
        digest.update(self.pixels)
        return digest.hexdigest()

    def is_duplicate_of(self, other: "ScreenFrame | None") -> bool:
        """True, если кадры идентичны по содержимому и геометрии."""
        if other is None:
            return False
        return (
            self.width == other.width
            and self.height == other.height
            and self.fingerprint() == other.fingerprint()
        )


# ---------------------------------------------------------------------------
# Маскирование приватных регионов
# ---------------------------------------------------------------------------
def mask_frame(frame: ScreenFrame, regions: Iterable[CaptureRegion]) -> ScreenFrame:
    """
    Заливает чёрным абсолютные регионы ``regions``, попавшие в кадр.

    Регионы вне кадра игнорируются; маскировка ничего не ломает
    (возвращается новый ``ScreenFrame`` с тем же метаданными).
    """
    rects: list[CaptureRegion] = []
    for reg in regions:
        local = reg.to_local(frame.region)
        if local is not None:
            rects.append(local)
    if not rects:
        return frame

    data = bytearray(frame.pixels)
    stride = frame.width * 3
    for rect in rects:
        for y in range(rect.y, rect.y + rect.height):
            start = y * stride + rect.x * 3
            data[start : start + rect.width * 3] = b"\x00" * (rect.width * 3)
    return replace(frame, pixels=bytes(data))


# ---------------------------------------------------------------------------
# PNG-кодировщик (без внешних зависимостей)
# ---------------------------------------------------------------------------
def _png_chunk(tag: bytes, payload: bytes) -> bytes:
    """Упаковывает чанк PNG (длина + tag + данные + CRC32)."""
    return (
        struct.pack(">I", len(payload))
        + tag
        + payload
        + struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF)
    )


def encode_png(frame: ScreenFrame) -> bytes:
    """Кодирует кадр RGB в PNG (8 бит/канал, color type 2)."""
    raw = bytearray()
    stride = frame.width * 3
    for y in range(frame.height):
        raw.append(0)  # фильтр строки: None
        raw += frame.pixels[y * stride : (y + 1) * stride]
    ihdr = struct.pack(">IIBBBBB", frame.width, frame.height, 8, 2, 0, 0, 0)
    return (
        b"\x89PNG\r\n\x1a\n"
        + _png_chunk(b"IHDR", ihdr)
        + _png_chunk(b"IDAT", zlib.compress(bytes(raw)))
        + _png_chunk(b"IEND", b"")
    )


def validate_capture_path(
    path: Any,
    output_dir: str | Path | None = None,
    forbidden_paths: Sequence[str] | None = None,
) -> Path:
    """
    Проверяет путь сохранения кадра и возвращает абсолютный ``Path``.

    Правила (единая политика с actions/screen_actions.py):
      - путь — непустая строка без управляющих символов и ведущего '-';
      - расширение из ``CAPTURE_EXTS``;
      - родительская папка создаётся при необходимости;
      - путь не попадает в ``forbidden_paths`` (политика безопасности);
      - при ``path=None`` файл создаётся в ``output_dir`` с именем
        ``capture_<epoch>.png``.
    """
    if path is None:
        base = Path(output_dir or "captures").expanduser()
        target = base / f"capture_{int(time.time() * 1000)}.png"
    else:
        if not isinstance(path, str):
            raise ValueError(f"путь должен быть строкой, получено: {path!r}")
        if not path.strip():
            raise ValueError("путь не может быть пустым")
        if any(ord(ch) < 32 for ch in path):
            raise ValueError("путь содержит управляющие символы")
        if path.startswith("-"):
            raise ValueError(
                "путь не должен начинаться с '-' (инъекция опций в argv)"
            )
        target = Path(path).expanduser()
        if target.suffix.lower() not in CAPTURE_EXTS:
            raise ValueError(
                f"неподдерживаемое расширение захвата: {target.suffix!r} "
                f"(допустимы: {', '.join(sorted(CAPTURE_EXTS))})"
            )

    resolved = target.resolve()
    for bad in forbidden_paths or []:
        if bad and str(resolved).startswith(str(Path(bad).expanduser().resolve())):
            raise CaptureError(f"Путь запрещён политикой безопасности: {resolved}")
    resolved.parent.mkdir(parents=True, exist_ok=True)
    return resolved


# ---------------------------------------------------------------------------
# Бэкенды
# ---------------------------------------------------------------------------
class ScreenCaptureBackend(abc.ABC):
    """Контракт бэкенда захвата экрана."""

    name: str = "base"

    @abc.abstractmethod
    def is_available(self) -> bool: ...

    @abc.abstractmethod
    def monitors(self) -> list[MonitorInfo]: ...

    @abc.abstractmethod
    def grab(self, region: CaptureRegion | None = None, *, monitor: int = 0) -> ScreenFrame: ...

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "available": self.is_available()}


class MssBackend(ScreenCaptureBackend):
    """Захват через ``mss`` (быстро, локально)."""

    name = "mss"

    def is_available(self) -> bool:
        try:
            import mss  # noqa: F401

            return True
        except ImportError:
            return False

    def monitors(self) -> list[MonitorInfo]:
        if not self.is_available():
            raise CaptureUnavailable("mss не установлен")
        import mss

        try:
            with mss.mss() as sct:
                real = list(sct.monitors[1:])  # monitors[0] — виртуальный «все экраны»
        except Exception as exc:  # noqa: BLE001
            raise CaptureUnavailable(f"mss: список мониторов недоступен: {exc}") from exc
        return [
            MonitorInfo(i, mon["left"], mon["top"], mon["width"], mon["height"])
            for i, mon in enumerate(real)
        ]

    def grab(self, region: CaptureRegion | None = None, *, monitor: int = 0) -> ScreenFrame:
        if not self.is_available():
            raise CaptureUnavailable("mss не установлен")
        import mss

        mons = self.monitors()
        if not mons:
            raise CaptureUnavailable("mss: мониторы не найдены")
        if monitor < 0 or monitor >= len(mons):
            raise CaptureError(f"монитор {monitor} вне диапазона 0..{len(mons) - 1}")
        box = region or CaptureRegion.from_monitor(mons[monitor])
        try:
            with mss.mss() as sct:
                shot = sct.grab(
                    {"left": box.x, "top": box.y, "width": box.width, "height": box.height}
                )
                pixels = bytes(shot.rgb)
        except Exception as exc:  # noqa: BLE001
            raise CaptureUnavailable(f"mss: захват не удался: {exc}") from exc
        return ScreenFrame(
            width=box.width,
            height=box.height,
            pixels=pixels,
            region=box,
            monitor=monitor,
            backend=self.name,
        )


class PillowBackend(ScreenCaptureBackend):
    """Захват через ``PIL.ImageGrab`` (локально)."""

    name = "pillow"

    def is_available(self) -> bool:
        try:
            from PIL import ImageGrab  # noqa: F401

            return True
        except ImportError:
            return False

    def monitors(self) -> list[MonitorInfo]:
        if not self.is_available():
            raise CaptureUnavailable("Pillow не установлен")
        frame = self.grab()
        return [MonitorInfo(0, frame.region.x, frame.region.y, frame.width, frame.height)]

    def grab(self, region: CaptureRegion | None = None, *, monitor: int = 0) -> ScreenFrame:
        if not self.is_available():
            raise CaptureUnavailable("Pillow не установлен")
        from PIL import ImageGrab

        if region is None:
            try:
                img = ImageGrab.grab(all_screens=True)
            except Exception as exc:  # noqa: BLE001
                raise CaptureUnavailable(f"Pillow: захват не удался: {exc}") from exc
            img = img.convert("RGB")
            box = CaptureRegion(0, 0, img.width, img.height)
            return ScreenFrame(
                width=img.width,
                height=img.height,
                pixels=img.tobytes(),
                region=box,
                monitor=monitor,
                backend=self.name,
            )
        box = region
        try:
            img = ImageGrab.grab(
                bbox=(box.x, box.y, box.x + box.width, box.y + box.height),
                all_screens=True,
            ).convert("RGB")
        except Exception as exc:  # noqa: BLE001
            raise CaptureUnavailable(f"Pillow: захват не удался: {exc}") from exc
        return ScreenFrame(
            width=img.width,
            height=img.height,
            pixels=img.tobytes(),
            region=box,
            monitor=monitor,
            backend=self.name,
        )


class SyntheticBackend(ScreenCaptureBackend):
    """
    Генерация детерминированных тестовых кадров.

    Используется в тестах/отладке и как аварийный fallback,
    когда графическое окружение недоступно.
    """

    name = "synthetic"

    def __init__(self, width: int = 1024, height: int = 768, *, seed: int = 0) -> None:
        self.width = width
        self.height = height
        self.seed = seed

    def is_available(self) -> bool:
        return self.width > 0 and self.height > 0

    def monitors(self) -> list[MonitorInfo]:
        return [MonitorInfo(0, 0, 0, self.width, self.height)]

    def grab(self, region: CaptureRegion | None = None, *, monitor: int = 0) -> ScreenFrame:
        if not self.is_available():
            raise CaptureUnavailable("SyntheticBackend: некорректная геометрия")
        full = CaptureRegion(0, 0, self.width, self.height)
        box = region or full
        if box.intersection(full) is None:
            raise CaptureError(f"регион {box} вне виртуального экрана {full}")
        pixels = self._render(box)
        return ScreenFrame(
            width=box.width,
            height=box.height,
            pixels=pixels,
            region=box,
            monitor=monitor,
            backend=self.name,
        )

    def _render(self, box: CaptureRegion) -> bytes:
        """Детерминированный градиент: пиксель зависит от координат и seed."""
        out = bytearray(box.width * box.height * 3)
        i = 0
        for y in range(box.height):
            gy = box.y + y
            for x in range(box.width):
                gx = box.x + x
                out[i] = (gx * 3 + self.seed * 13) % 256
                out[i + 1] = (gy * 5 + self.seed * 7) % 256
                out[i + 2] = ((gx + gy) * 2 + self.seed * 29) % 256
                i += 3
        return bytes(out)


# ---------------------------------------------------------------------------
# Диспетчер
# ---------------------------------------------------------------------------
class CaptureRouter:
    """Диспетчер бэкендов захвата: смена + fallback."""

    def __init__(
        self,
        backends: dict[str, ScreenCaptureBackend] | None = None,
        primary: str = "mss",
        fallback_chain: list[str] | None = None,
    ) -> None:
        self._backends = backends or {}
        self._primary = primary
        self._fallback_chain = fallback_chain or [primary]

    @property
    def primary(self) -> str:
        return self._primary

    def set_primary(self, name: str) -> None:
        if name not in self._backends:
            raise CaptureError(f"Неизвестный бэкенд захвата: {name}")
        self._primary = name
        self._fallback_chain = [name] + [e for e in self._fallback_chain if e != name]
        logger.info("Бэкенд захвата переключён на '%s'", name)

    def available(self) -> list[str]:
        return [n for n, b in self._backends.items() if b.is_available()]

    def _chain(self, explicit: str | None) -> list[str]:
        if explicit:
            return [explicit]
        order = self._fallback_chain or list(self._backends.keys())
        chain = [self._primary] + [n for n in order if n != self._primary]
        chain += [n for n in self._backends if n not in chain]
        return chain

    def grab(
        self,
        region: CaptureRegion | None = None,
        *,
        monitor: int = 0,
        backend: str | None = None,
    ) -> ScreenFrame:
        """Захватывает кадр, обходя цепочку fallback при отказах."""
        last_err: Exception | None = None
        for name in self._chain(backend):
            be = self._backends.get(name)
            if be is None or not be.is_available():
                last_err = CaptureUnavailable(f"{name}: недоступен")
                continue
            try:
                return be.grab(region, monitor=monitor)
            except CaptureError as exc:
                last_err = exc
                continue
        raise CaptureError(f"Ни один бэкенд захвата не справился. Последняя ошибка: {last_err}")

    def monitors(self, *, backend: str | None = None) -> list[MonitorInfo]:
        """Список мониторов (по цепочке fallback)."""
        last_err: Exception | None = None
        for name in self._chain(backend):
            be = self._backends.get(name)
            if be is None or not be.is_available():
                last_err = CaptureUnavailable(f"{name}: недоступен")
                continue
            try:
                return be.monitors()
            except CaptureError as exc:
                last_err = exc
                continue
        raise CaptureError(
            f"Ни один бэкенд не дал список мониторов. Последняя ошибка: {last_err}"
        )

    def describe(self) -> dict[str, Any]:
        return {
            "primary": self._primary,
            "available": self.available(),
            "backends": {n: b.describe() for n, b in self._backends.items()},
        }


# ---------------------------------------------------------------------------
# Высокоуровневый сервис
# ---------------------------------------------------------------------------
class ScreenCapture:
    """
    Сервис захвата экрана поверх ``CaptureRouter``.

    Дополнительно: дедупликация кадров (``capture_if_changed``),
    маскирование приватных регионов, кольцевая история кадров,
    сохранение в PNG.
    """

    def __init__(
        self,
        router: CaptureRouter,
        *,
        history: int = 8,
        privacy_regions: Iterable[CaptureRegion] | None = None,
        output_dir: str | Path | None = None,
        forbidden_paths: Sequence[str] | None = None,
    ) -> None:
        if history < 1:
            raise ValueError("history должен быть >= 1")
        self._router = router
        self._history: deque[ScreenFrame] = deque(maxlen=history)
        self._privacy: list[CaptureRegion] = list(privacy_regions or [])
        self._output_dir = output_dir
        self._forbidden_paths = list(forbidden_paths or [])
        self._last_fp: dict[tuple[int, tuple[int, int, int, int]], str] = {}

    # --- приватность -----------------------------------------------------
    @property
    def privacy_regions(self) -> tuple[CaptureRegion, ...]:
        return tuple(self._privacy)

    def add_privacy_region(self, region: CaptureRegion) -> None:
        """Добавляет регион, который нужно маскировать в каждом кадре."""
        self._privacy.append(region)

    def clear_privacy_regions(self) -> None:
        self._privacy.clear()

    # --- захват ----------------------------------------------------------
    def _grab_frame(
        self,
        region: CaptureRegion | None,
        *,
        monitor: int,
        mask: bool,
        backend: str | None,
    ) -> ScreenFrame:
        """Общий путь захвата: grab → маскирование → история."""
        frame = self._router.grab(region, monitor=monitor, backend=backend)
        if mask and self._privacy:
            frame = mask_frame(frame, self._privacy)
        self._history.append(frame)
        return frame

    def _record(self, frame: ScreenFrame) -> None:
        self._last_fp[(frame.monitor, frame.region.box)] = frame.fingerprint()

    def capture(
        self,
        region: CaptureRegion | None = None,
        *,
        monitor: int = 0,
        mask: bool = True,
        backend: str | None = None,
    ) -> ScreenFrame:
        """Захватывает кадр (с маскированием приватных регионов по умолчанию)."""
        frame = self._grab_frame(region, monitor=monitor, mask=mask, backend=backend)
        self._record(frame)
        return frame

    def capture_if_changed(
        self,
        region: CaptureRegion | None = None,
        *,
        monitor: int = 0,
        mask: bool = True,
        backend: str | None = None,
    ) -> ScreenFrame | None:
        """
        Захватывает кадр только если он отличается от предыдущего
        для той же геометрии (с учётом кадров из ``capture``);
        иначе возвращает ``None``.
        """
        frame = self._grab_frame(region, monitor=monitor, mask=mask, backend=backend)
        key = (frame.monitor, frame.region.box)
        changed = self._last_fp.get(key) != frame.fingerprint()
        self._record(frame)
        return frame if changed else None

    def history_frames(self) -> tuple[ScreenFrame, ...]:
        """Последние кадры (кольцевой буфер)."""
        return tuple(self._history)

    @property
    def last_frame(self) -> ScreenFrame | None:
        return self._history[-1] if self._history else None

    # --- сохранение -----------------------------------------------------
    def save_png(self, frame: ScreenFrame, path: Any = None) -> Path:
        """Сохраняет кадр в PNG и возвращает путь к файлу."""
        target = validate_capture_path(
            path,
            output_dir=self._output_dir,
            forbidden_paths=self._forbidden_paths,
        )
        try:
            target.write_bytes(encode_png(frame))
        except OSError as exc:
            raise CaptureError(f"не удалось сохранить кадр в {target}: {exc}") from exc
        logger.debug("Кадр сохранён: %s (%d байт)", target, target.stat().st_size)
        return target
