/**
 * Настройки — профиль пользователя, внешний вид HUD и журналирование.
 */

import { useEffect } from "react";
import { Card, PageHeader } from "../components/ui/panels";
import { SettingsSaveBar } from "../components/SettingsSaveBar";
import { SelectField, Slider, TextField, Toggle, FieldRow } from "../components/ui/controls";
import { useSettingsStore } from "../stores/settingsStore";
import { useUiStore, type Persona } from "../stores/uiStore";

const ACCENTS = ["#00E5FF", "#FF3B30", "#7C5CFF", "#2ECC71", "#F5A623"];

export function SettingsPage() {
  const data = useSettingsStore((s) => s.data);
  const loaded = useSettingsStore((s) => s.loaded);
  const patch = useSettingsStore((s) => s.patch);
  const setPersona = useUiStore((s) => s.setPersona);

  useEffect(() => {
    if (!loaded) void useSettingsStore.getState().load();
  }, [loaded]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Настройки"
        subtitle="Профиль, внешний вид HUD, приватность и журналирование ядра."
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card title="Профиль" subtitle="Обращение, язык и персона">
          <TextField
            label="Обращение к пользователю"
            value={data.core.user_name}
            onChange={(e) => patch("core", { user_name: e.target.value })}
            hint="Например: сэр, господин, босс"
          />
          <div className="mt-3 grid grid-cols-2 gap-3">
            <SelectField
              label="Язык"
              value={data.core.language}
              onChange={(e) => patch("core", { language: e.target.value })}
              options={[
                { value: "ru", label: "Русский" },
                { value: "en", label: "English" },
              ]}
            />
            <SelectField
              label="Персона"
              value={data.core.persona}
              onChange={(e) => {
                const persona = e.target.value;
                patch("core", { persona });
                if (persona === "jarvis" || persona === "friday") setPersona(persona as Persona);
              }}
              options={[
                { value: "jarvis", label: "JARVIS" },
                { value: "friday", label: "FRIDAY" },
                { value: "custom", label: "Своя" },
              ]}
            />
          </div>
          <div className="mt-3">
            <SelectField
              label="Режим приватности"
              value={data.core.privacy_mode}
              onChange={(e) => patch("core", { privacy_mode: e.target.value as "normal" | "incognito" | "local" })}
              options={[
                { value: "normal", label: "Обычный — память и облако разрешены" },
                { value: "incognito", label: "Инкогнито — диалоги не сохраняются" },
                { value: "local", label: "Только локальные модели" },
              ]}
            />
          </div>
          <div className="mt-2 divide-y divide-line">
            <FieldRow
              label="Только локальные модели"
              hint="Запрет любых сетевых вызовов LLM"
              control={<Toggle checked={data.core.offline_only} onChange={(v) => patch("core", { offline_only: v })} />}
            />
          </div>
          <div className="mt-3">
            <TextField
              label="Каталог данных"
              value={data.core.data_dir}
              onChange={(e) => patch("core", { data_dir: e.target.value })}
            />
          </div>
        </Card>

        <Card title="HUD / Внешний вид" subtitle="Тема панели и оверлей" delay={0.05}>
          <SelectField
            label="Тема"
            value={data.ui.theme}
            onChange={(e) => {
              const theme = e.target.value;
              patch("ui", {
                theme,
                accent_color: theme === "friday" ? "#FF3B30" : theme === "jarvis" ? "#00E5FF" : data.ui.accent_color,
              });
              if (theme === "jarvis" || theme === "friday") setPersona(theme);
            }}
            options={[
              { value: "jarvis", label: "JARVIS — циан" },
              { value: "friday", label: "FRIDAY — красный" },
              { value: "custom", label: "Своя" },
            ]}
          />

          <div className="mt-4">
            <p className="text-sm text-text">Акцентный цвет</p>
            <div className="mt-2 flex items-center gap-2">
              {ACCENTS.map((color) => (
                <button
                  key={color}
                  type="button"
                  aria-label={`Акцент ${color}`}
                  onClick={() => patch("ui", { accent_color: color, theme: "custom" })}
                  className="h-8 w-8 rounded-full border-2 transition-transform hover:scale-110"
                  style={{
                    background: color,
                    borderColor: data.ui.accent_color === color ? "#fff" : "transparent",
                    boxShadow: `0 0 12px ${color}66`,
                  }}
                />
              ))}
              <input
                type="color"
                value={data.ui.accent_color}
                onChange={(e) => patch("ui", { accent_color: e.target.value, theme: "custom" })}
                className="h-8 w-12 cursor-pointer rounded border border-line bg-panel-2"
              />
            </div>
          </div>

          <div className="mt-4">
            <Slider
              label="Прозрачность оверлея"
              min={0}
              max={1}
              value={data.ui.transparency}
              onChange={(v) => patch("ui", { transparency: v })}
              format={(v) => `${Math.round(v * 100)}%`}
            />
          </div>

          <div className="mt-2 divide-y divide-line">
            <FieldRow
              label="Оверлей поверх окон"
              hint="HUD-слой поверх рабочего стола"
              control={<Toggle checked={data.ui.overlay_enabled} onChange={(v) => patch("ui", { overlay_enabled: v })} />}
            />
            <FieldRow
              label="Анимация загрузки"
              hint="Бут-анимация при старте"
              control={<Toggle checked={data.ui.boot_animation} onChange={(v) => patch("ui", { boot_animation: v })} />}
            />
            <FieldRow
              label="Субтитры речи"
              hint="Показывать реплики текстом"
              control={<Toggle checked={data.ui.show_subtitles} onChange={(v) => patch("ui", { show_subtitles: v })} />}
            />
          </div>
        </Card>
      </div>

      <Card title="Журналирование" subtitle="Уровень логов и ротация файлов">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          <SelectField
            label="Уровень"
            value={data.logging.level}
            onChange={(e) => patch("logging", { level: e.target.value })}
            options={["DEBUG", "INFO", "WARNING", "ERROR"].map((l) => ({ value: l, label: l }))}
          />
          <TextField
            label="Каталог логов"
            value={data.logging.dir}
            onChange={(e) => patch("logging", { dir: e.target.value })}
          />
          <TextField
            label="Ротация"
            value={data.logging.rotation}
            onChange={(e) => patch("logging", { rotation: e.target.value })}
            hint="Например: 10 MB"
          />
          <TextField
            label="Хранение"
            value={data.logging.retention}
            onChange={(e) => patch("logging", { retention: e.target.value })}
            hint="Например: 30 days"
          />
        </div>
      </Card>

      <SettingsSaveBar />
    </div>
  );
}
