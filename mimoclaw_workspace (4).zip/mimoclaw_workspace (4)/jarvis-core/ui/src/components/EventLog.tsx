/**
 * EventLog — живая лента событий шины (WS-топики).
 */

import { motion } from "framer-motion";
import { useEffect, useRef } from "react";
import { clsx, formatClock } from "../lib/format";
import type { BusEvent } from "../types/api";
import { EmptyState } from "./ui/panels";

const TOPIC_TONE: Array<[RegExp, string]> = [
  [/^ui\.error|error/i, "border-danger/40 bg-danger/10 text-danger"],
  [/^(stt|wakeword|clap)/i, "border-accent/40 bg-accent/10 text-accent"],
  [/^(tts|speech|audio)/i, "border-ok/40 bg-ok/10 text-ok"],
  [/^pipeline/i, "border-warn/40 bg-warn/10 text-warn"],
  [/^ui\./i, "border-line-bright bg-panel-2 text-muted"],
];

function topicClass(topic: string): string {
  for (const [pattern, className] of TOPIC_TONE) {
    if (pattern.test(topic)) return className;
  }
  return "border-line-bright bg-panel-2 text-text";
}

interface EventLogProps {
  events: BusEvent[];
  limit?: number;
  height?: string;
}

export function EventLog({ events, limit = 60, height = "h-80" }: EventLogProps) {
  const boxRef = useRef<HTMLDivElement>(null);
  const shown = events.slice(-limit);

  useEffect(() => {
    const box = boxRef.current;
    if (box) box.scrollTop = box.scrollHeight;
  }, [events.length]);

  return (
    <div ref={boxRef} className={clsx("overflow-y-auto rounded-xl border border-line bg-panel-2/40 p-2", height)}>
      {shown.length === 0 ? (
        <EmptyState title="Лента событий пуста" hint="События шины ядра появятся здесь в реальном времени" />
      ) : (
        <ul className="space-y-1">
          {shown.map((event, i) => (
            <motion.li
              key={`${event.ts}-${i}`}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.2 }}
              className="flex items-start gap-2 rounded-lg px-2 py-1.5 text-xs hover:bg-panel/70"
            >
              <span className="shrink-0 tabular-nums text-muted">{formatClock(event.ts)}</span>
              <span className={clsx("shrink-0 rounded-md border px-1.5 py-0.5 font-medium", topicClass(event.topic))}>
                {event.topic}
              </span>
              <span className="min-w-0 flex-1 truncate text-text/80">{summarize(event.payload)}</span>
            </motion.li>
          ))}
        </ul>
      )}
    </div>
  );
}

function summarize(payload: Record<string, unknown>): string {
  try {
    const text = JSON.stringify(payload);
    return text.length > 160 ? `${text.slice(0, 160)}…` : text;
  } catch {
    return "—";
  }
}
