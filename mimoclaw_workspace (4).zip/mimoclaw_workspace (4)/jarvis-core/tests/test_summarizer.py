"""
Проверка memory/summarizer.py — экстрактивная и LLM-сводка, роутер с
fallback, сводка записей/диалога, сохранение сводки в память.

Запуск:  python3 tests/test_summarizer.py
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from memory.store import InMemoryMemoryStore, MemoryKind, MemoryRecord
from memory.summarizer import (
    MAX_INPUT_LEN,
    ExtractiveSummarizer,
    LLMSummarizer,
    MemorySummarizer,
    SummaryError,
    SummarizerRouter,
    SummarizerUnavailable,
    default_summarizer_router,
    split_sentences,
)

# ---------------------------------------------------------------------------
# Тестовые данные
# ---------------------------------------------------------------------------
LONG_TEXT = (
    "Джарвис был запущен в штатном режиме. "
    "Пользователь предпочитает чай без сахара и работает по утрам. "
    "Вчера состоялась встреча с командой, где обсудили релиз версии 2.0. "
    "Релиз перенесли на пятницу из-за найденного бага в модуле памяти. "
    "Баг исправили за два часа, тесты прошли полностью зелёными. "
    "На утро запланирован брифинг в десять часов."
)


class FakeResponse:
    """Мини-ответ LLM (как LLMResponse из ai.providers)."""

    def __init__(self, content: str) -> None:
        self.content = content


class FakeLLM:
    """Клиент LLM с настраиваемым поведением (для тестов)."""

    def __init__(self, reply: str = "Короткая сводка.", fail: bool = False) -> None:
        self.reply = reply
        self.fail = fail
        self.calls: list[list[dict]] = []

    async def ask(self, messages, **kw) -> FakeResponse:
        self.calls.append(list(messages))
        if self.fail:
            raise RuntimeError("сеть недоступна")
        return FakeResponse(self.reply)

    def available_providers(self) -> list[str]:
        return ["fake"]


# ---------------------------------------------------------------------------
# Экстрактивная сводка
# ---------------------------------------------------------------------------
def test_extractive_summary(tmp: Path) -> None:
    eng = ExtractiveSummarizer()
    result = asyncio.run(eng.summarize(LONG_TEXT, max_sentences=3, max_chars=600))

    assert result.engine == "extractive", result.engine
    assert 1 <= result.used_sentences <= 3, result.used_sentences
    assert result.source_sentences == 6, result.source_sentences
    assert result.ratio < 1.0, result.ratio
    assert len(result.text) <= 600
    # Порядок предложений сохранён (как в источнике)
    sentences = split_sentences(result.text)
    positions = [LONG_TEXT.find(s[:30]) for s in sentences]
    assert positions == sorted(positions), positions
    # Словарь результата JSON-безопасен
    data = result.to_dict()
    assert data["engine"] == "extractive" and 0 < data["ratio"] < 1


def test_extractive_short_and_truncated(tmp: Path) -> None:
    eng = ExtractiveSummarizer()
    # Короткий текст — не теряем предложения
    short = "Привет. Как дела?"
    result = asyncio.run(eng.summarize(short, max_sentences=5, max_chars=600))
    assert result.used_sentences == 2, result.text

    # Одно длинное предложение ужимается до max_chars с многоточием
    long_sent = "Слово " * 200 + "конец."
    result2 = asyncio.run(eng.summarize(long_sent, max_sentences=1, max_chars=60))
    assert len(result2.text) <= 60, result2.text
    assert result2.text.endswith("…"), result2.text


def test_params_and_input_validation(tmp: Path) -> None:
    eng = ExtractiveSummarizer()

    for bad_text in ("", "   ", "привет\x00мир", "а" * (MAX_INPUT_LEN + 1)):
        try:
            asyncio.run(eng.summarize(bad_text))
        except ValueError:
            pass
        else:
            raise AssertionError(f"ожидался ValueError для text={bad_text[:10]!r}...")

    for bad_kwargs in (
        {"max_sentences": 0},
        {"max_sentences": 51},
        {"max_sentences": "3"},
        {"max_chars": 10},
        {"max_chars": 10**6},
        {"max_chars": True},
    ):
        try:
            asyncio.run(eng.summarize(LONG_TEXT, **bad_kwargs))
        except ValueError:
            pass
        else:
            raise AssertionError(f"ожидался ValueError для {bad_kwargs}")


# ---------------------------------------------------------------------------
# LLM-сводка
# ---------------------------------------------------------------------------
def test_llm_summarizer(tmp: Path) -> None:
    llm = FakeLLM(reply="Пользователь любит чай. Релиз в пятницу.")
    eng = LLMSummarizer(llm)
    result = asyncio.run(eng.summarize(LONG_TEXT, max_sentences=3, max_chars=600))

    assert result.engine == "llm", result.engine
    assert result.text == "Пользователь любит чай. Релиз в пятницу."
    # В промпт ушёл исходный текст и инструкция по лимитам
    prompt = " ".join(m["content"] for m in llm.calls[0])
    assert "чай без сахара" in prompt
    assert "не более 3 предложений" in prompt

    # Ответ длиннее max_chars — ужимается с многоточием
    llm2 = FakeLLM(reply="Да " * 100)
    result2 = asyncio.run(LLMSummarizer(llm2).summarize(LONG_TEXT, max_chars=50))
    assert len(result2.text) <= 50 and result2.text.endswith("…")

    # Сбой клиента / пустой ответ → SummarizerUnavailable
    for bad in (FakeLLM(fail=True), FakeLLM(reply="   ")):
        try:
            asyncio.run(LLMSummarizer(bad).summarize(LONG_TEXT))
        except SummarizerUnavailable:
            pass
        else:
            raise AssertionError("ожидался SummarizerUnavailable")

    try:
        LLMSummarizer(None)
    except ValueError:
        pass
    else:
        raise AssertionError("ожидался ValueError для llm=None")


# ---------------------------------------------------------------------------
# Роутер
# ---------------------------------------------------------------------------
def test_router_fallback_and_switch(tmp: Path) -> None:
    broken = LLMSummarizer(FakeLLM(fail=True))
    router = SummarizerRouter([broken, ExtractiveSummarizer()], primary="llm")

    # Основной упал — молча деградируем в локальный extractive
    result = asyncio.run(router.summarize(LONG_TEXT))
    assert result.engine == "extractive", result.engine

    # Явный выбор упавшего движка — ошибка уходит наружу, без тихих подмен
    try:
        asyncio.run(router.summarize(LONG_TEXT, engine="llm"))
    except SummarizerUnavailable:
        pass
    else:
        raise AssertionError("ожидался SummarizerUnavailable для engine='llm'")

    try:
        asyncio.run(router.summarize(LONG_TEXT, engine="нет-такого"))
    except SummaryError:
        pass
    else:
        raise AssertionError("ожидался SummaryError для неизвестного движка")

    # Смена основного движка (локально ↔ облако)
    router.set_primary("extractive")
    assert router.primary == "extractive"
    assert asyncio.run(router.summarize(LONG_TEXT)).engine == "extractive"
    try:
        router.set_primary("нет-такого")
    except SummaryError:
        pass
    else:
        raise AssertionError("ожидался SummaryError в set_primary")

    assert router.available() == ["llm", "extractive"] or router.available() == ["extractive"]


def test_router_last_resort_and_default(tmp: Path) -> None:
    # Только падающие движки — роутер всё равно не падает
    router = SummarizerRouter([LLMSummarizer(FakeLLM(fail=True))], primary="llm")
    result = asyncio.run(router.summarize(LONG_TEXT))
    assert result.engine == "extractive", result.engine

    # Фабрика: без LLM — только extractive; с LLM — llm основным
    r1 = default_summarizer_router()
    assert [s["name"] for s in r1.engine_status()] == ["extractive"]
    assert asyncio.run(r1.summarize(LONG_TEXT)).engine == "extractive"

    r2 = default_summarizer_router(FakeLLM(reply="Сводка."))
    assert r2.primary == "llm"
    assert asyncio.run(r2.summarize(LONG_TEXT)).engine == "llm"
    assert not default_summarizer_router(FakeLLM(fail=True)).available() == []


# ---------------------------------------------------------------------------
# Фасад MemorySummarizer
# ---------------------------------------------------------------------------
def _record(content: str, kind: MemoryKind = MemoryKind.FACT, **kw) -> MemoryRecord:
    return MemoryRecord(kind=kind, content=content, **kw)


def test_summarize_records_and_conversation(tmp: Path) -> None:
    sm = MemorySummarizer(default_summarizer_router())

    records = [
        _record("Пользователь любит чай без сахара", tags=("предпочтение",)),
        _record("Релиз перенесли на пятницу", kind=MemoryKind.EVENT),
    ]
    digest = asyncio.run(sm.summarize_records(records, max_sentences=2))
    assert digest.engine == "extractive"
    assert digest.source_chars > 0 and digest.used_sentences <= 2

    try:
        asyncio.run(sm.summarize_records([]))
    except ValueError:
        pass
    else:
        raise AssertionError("ожидался ValueError для пустого списка записей")

    messages = [
        {"role": "user", "content": "Какой план на день?"},
        {"role": "assistant", "content": "Утром брифинг, потом релиз."},
        {"role": "user", "content": ""},  # пустой контент пропускается
    ]
    summary = asyncio.run(sm.summarize_conversation(messages, max_sentences=2))
    assert "user: Какой план" in summary.text or summary.used_sentences >= 1
    assert summary.source_sentences == 2, summary.text

    for bad in ([{"role": 1, "content": "ок"}], [("user", "привет")], [{"role": "u"}]):
        try:
            asyncio.run(sm.summarize_conversation(bad))
        except ValueError:
            pass
        else:
            raise AssertionError(f"ожидался ValueError для messages={bad!r}")


def test_summarize_and_store(tmp: Path) -> None:
    store = InMemoryMemoryStore()
    sm = MemorySummarizer(default_summarizer_router(), store=store, session_id="s1")

    rec = asyncio.run(
        sm.summarize_and_store(LONG_TEXT, tags=("брифинг", "утро"), importance=0.7)
    )
    assert rec.kind is MemoryKind.SUMMARY
    assert rec.session_id == "s1"
    assert rec.tags == ("брифинг", "утро")
    assert rec.importance == 0.7
    assert rec.metadata.get("engine") == "extractive"
    assert store.count() == 1
    assert store.search("сводк") or store.search("релиз")

    # Альтернативное хранилище через параметр
    other = InMemoryMemoryStore()
    asyncio.run(sm.summarize_and_store("Раз. Два. Три.", store=other))
    assert other.count() == 1 and store.count() == 1

    # Без хранилища — явная ошибка (не тихая потеря сводки)
    bare = MemorySummarizer()
    try:
        asyncio.run(bare.summarize_and_store(LONG_TEXT))
    except SummaryError:
        pass
    else:
        raise AssertionError("ожидался SummaryError без хранилища")

    # Некорректная важность — валидация MemoryRecord
    try:
        asyncio.run(sm.summarize_and_store(LONG_TEXT, importance=1.5))
    except ValueError:
        pass
    else:
        raise AssertionError("ожидался ValueError для importance=1.5")


if __name__ == "__main__":
    import tempfile
    import traceback

    tests = [(k, v) for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    base = Path(".openclaw/tmp")
    base.mkdir(parents=True, exist_ok=True)
    for name, fn in tests:
        try:
            if fn.__code__.co_argcount == 0:
                fn()
            else:
                fn(Path(tempfile.mkdtemp(dir=base)))
            print(f"  ok  {name}")
        except Exception:
            failed += 1
            print(f"FAIL  {name}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
