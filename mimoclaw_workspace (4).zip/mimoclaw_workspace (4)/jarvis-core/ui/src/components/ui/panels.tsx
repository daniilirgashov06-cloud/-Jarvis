/**
 * Панели и каркасные элементы: неоновая карточка, заголовок страницы,
 * бейджи и служебные уведомления.
 */

import { motion } from "framer-motion";
import type { ReactNode } from "react";
import { clsx } from "../../lib/format";

/* ------------------------------------------------------------------- Card */

interface CardProps {
  title?: string;
  subtitle?: string;
  right?: ReactNode;
  children: ReactNode;
  className?: string;
  delay?: number;
}

export function Card({ title, subtitle, right, children, className, delay = 0 }: CardProps) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay, ease: "easeOut" }}
      className={clsx("neon-panel p-5", className)}
    >
      {title ? (
        <header className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h3 className="hud-title text-sm text-accent">{title}</h3>
            {subtitle ? <p className="mt-1 text-xs text-muted">{subtitle}</p> : null}
          </div>
          {right ? <div className="shrink-0">{right}</div> : null}
        </header>
      ) : null}
      {children}
    </motion.section>
  );
}

/* ------------------------------------------------------------- PageHeader */

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
}

export function PageHeader({ title, subtitle, actions }: PageHeaderProps) {
  return (
    <motion.header
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="mb-6 flex flex-wrap items-end justify-between gap-4"
    >
      <div>
        <h1 className="font-display text-2xl font-bold uppercase tracking-[0.18em] text-text">
          {title}
        </h1>
        {subtitle ? <p className="mt-1.5 max-w-2xl text-sm text-muted">{subtitle}</p> : null}
      </div>
      {actions ? <div className="flex items-center gap-2">{actions}</div> : null}
    </motion.header>
  );
}

/* ------------------------------------------------------------------ Badge */

interface BadgeProps {
  children: ReactNode;
  className?: string;
  pulse?: boolean;
}

export function Badge({ children, className, pulse }: BadgeProps) {
  return (
    <span
      className={clsx(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-medium uppercase tracking-wider",
        className,
      )}
    >
      {pulse ? (
        <motion.span
          animate={{ opacity: [1, 0.35, 1] }}
          transition={{ duration: 1.6, repeat: Infinity }}
          className="h-1.5 w-1.5 rounded-full bg-current"
        />
      ) : null}
      {children}
    </span>
  );
}

/* ----------------------------------------------------------------- Notice */

export function Notice({ tone = "info", children }: { tone?: "info" | "warn" | "error"; children: ReactNode }) {
  const tones = {
    info: "border-accent/30 bg-accent/5 text-accent",
    warn: "border-warn/40 bg-warn/10 text-warn",
    error: "border-danger/40 bg-danger/10 text-danger",
  } as const;
  return (
    <div className={clsx("rounded-xl border px-4 py-2.5 text-sm", tones[tone])}>{children}</div>
  );
}

/* ------------------------------------------------------------- EmptyState */

export function EmptyState({ icon = "◌", title, hint }: { icon?: string; title: string; hint?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-10 text-center">
      <div className="text-3xl text-accent/60">{icon}</div>
      <p className="hud-title text-sm text-text">{title}</p>
      {hint ? <p className="max-w-sm text-xs text-muted">{hint}</p> : null}
    </div>
  );
}
