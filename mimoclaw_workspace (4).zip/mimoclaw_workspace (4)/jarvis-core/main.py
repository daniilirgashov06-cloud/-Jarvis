"""
JARVIS CORE — точка входа.

Собирает все подсистемы (конфиг, логи, LLM/STT/TTS, реестр команд,
оркестратор) и запускает в выбранном режиме.

Запуск:
    python main.py --text "поставь громкость 50"   # быстрый текстовый прогон (без микрофона)
    python main.py --headless                       # фон (голосовой цикл, MVP)
    python main.py --ui                             # веб-панель (ui_server)

Опции:
    --persona  jarvis|friday        активная персона
    --provider ollama|openai|...    принудительный LLM-провайдер
    --offline                       только локальные модели (без интернета)
"""

from __future__ import annotations

import argparse
import asyncio
import importlib
import sys
from pathlib import Path

# Делаем пакеты проекта импортируемыми при запуске как `python main.py`
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config.logging import logger, setup_logging  # noqa: E402
from config.settings import Settings, load_settings  # noqa: E402


def _load_action_modules() -> list[str]:
    """
    Импортирует модули actions/* и регистрирует их команды в глобальный реестр.

    Модули предоставляют функцию ``register_<name>_actions(registry)`` —
    вызываем её с глобальным реестром. Устойчиво к отсутствию опциональных
    зависимостей: упавший модуль логируется, но не роняет запуск.
    """
    from actions.registry import registry as global_registry

    candidates = [
        "actions.system_actions",
        "actions.app_actions",
        "actions.media_actions",
        "actions.file_actions",
        "actions.productivity_actions",
        "actions.input_actions",
        "actions.screen_actions",
        "actions.browser_actions",
        "actions.code_actions",
        "actions.user_actions",
    ]
    loaded: list[str] = []
    for mod_name in candidates:
        try:
            mod = importlib.import_module(mod_name)
            # вызываем register_*_actions(registry), если модуль его даёт
            for attr in dir(mod):
                if attr.startswith("register_") and attr.endswith("_actions"):
                    fn = getattr(mod, attr)
                    if callable(fn):
                        fn(global_registry)
            loaded.append(mod_name)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Модуль команд '%s' не загружен: %s", mod_name, exc)
    return loaded


def build_orchestrator(cfg: Settings, persona: str, offline: bool):
    """Собирает оркестратор из конфига (лениво импортируя тяжёлые движки)."""
    from actions.registry import registry
    from ai.context_builder import ContextBuilder
    from ai.llm_router import LLMRouter
    from core.orchestrator import Orchestrator

    # LLM
    llm = LLMRouter.from_config(cfg.ai)
    llm.offline_only = offline or cfg.core.offline_only

    # STT (движки подключаются по мере наличия библиотек)
    try:
        from speech.stt_engine import FasterWhisperSTT, OpenAISTT, STRouter

        stt = STRouter(
            engines={
                "faster_whisper": FasterWhisperSTT(model=cfg.stt.model),
                "openai": OpenAISTT(),
            },
            primary=cfg.stt.engine,
            fallback_chain=["faster_whisper", "openai"],
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("STT недоступен: %s", exc)
        stt = None

    # TTS
    try:
        from speech.tts_engine import ElevenLabsTTS, LocalTTS, TTSRouter

        tts = TTSRouter(
            engines={"local": LocalTTS(), "elevenlabs": ElevenLabsTTS()},
            primary=cfg.tts.engine,
            fallback_chain=["local", "elevenlabs"],
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("TTS недоступен: %s", exc)
        tts = None

    context = ContextBuilder(persona_key=persona)
    return Orchestrator(
        llm=llm,
        tts=tts,
        stt=stt,
        registry=registry,
        context=context,
        persona_key=persona,
        speak=tts is not None,
    )


async def _run_text(cfg: Settings, args: argparse.Namespace) -> int:
    """Текстовый прогон: строит пайплайн и обрабатывает реплику (без аудио)."""
    loaded = _load_action_modules()
    logger.info("Загружено модулей команд: %d | доступно команд: %d",
                len(loaded), len(_sys_registry_names()))
    if args.provider:
        cfg.ai.primary = args.provider
    orch = build_orchestrator(cfg, args.persona, args.offline)
    try:
        result = await orch.process_text(args.text)
    except Exception as exc:  # noqa: BLE001 — нет LLM/Ollama и т.п.
        print(f"\n=== JARVIS ===\nНе удалось получить ответ от LLM: {exc}")
        print("Подсказка: запустите Ollama (ollama serve) или добавьте API-ключи в config/.env")
        return 2
    print("\n=== JARVIS ===")
    print(f"вы:       {result.transcript}")
    print(f"ответ:    {result.reply}")
    if result.actions:
        for a in result.actions:
            mark = "✓" if a.ok else "✗"
            print(f"  {mark} {a.name}: {a.output if a.ok else a.error}")
    print(f"провайдер: {result.used_provider or '—'} | tts: {result.used_tts or '—'}")
    return 0


def _sys_registry_names() -> list[str]:
    from actions.registry import registry

    return registry.names()


def _run_headless(cfg: Settings, args: argparse.Namespace) -> int:
    """Голосовой цикл (MVP). Требует аудио-подсистему на реальной машине."""
    _load_action_modules()
    logger.info("Headless-режим: голосовой цикл. Для MVP используй --text для проверки.")
    logger.info("Аудио-ядро (capture/VAD/wakeword/playback) подключается в main-цикле.")
    # TODO(интеграция): связать audio.capture -> vad -> wakeword -> orchestrator.process_audio.
    # Здесь сознательно не блокируем запуск отсутствием микрофона в dev-окружении.
    print("Голосовой цикл: подключите микрофон и запустите аудио-ядро (см. ROADMAP).")
    return 0


def _run_ui(cfg: Settings, args: argparse.Namespace) -> int:
    """Запуск веб-панели (FastAPI + WebSocket)."""
    _load_action_modules()
    try:
        import uvicorn

        from ui_server.app import create_app

        app = create_app(cfg)
        logger.info("Веб-панель: http://127.0.0.1:8765")
        uvicorn.run(app, host="127.0.0.1", port=8765)
        return 0
    except Exception as exc:  # noqa: BLE001
        logger.error("UI-сервер не запустился: %s", exc)
        return 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="jarvis", description="JARVIS CORE")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--text", help="обработать одну текстовую реплику и выйти")
    mode.add_argument("--headless", action="store_true", help="фон (голосовой цикл)")
    mode.add_argument("--ui", action="store_true", help="веб-панель настроек")
    parser.add_argument("--persona", default="jarvis", help="jarvis|friday")
    parser.add_argument("--provider", default=None, help="принудительный LLM-провайдер")
    parser.add_argument("--offline", action="store_true", help="только локальные модели")
    args = parser.parse_args(argv)

    cfg = load_settings()
    setup_logging(cfg.logging)
    logger.info("JARVIS CORE стартует | персона=%s | offline=%s", args.persona, args.offline)

    if args.text:
        return asyncio.run(_run_text(cfg, args))
    if args.ui:
        return _run_ui(cfg, args)
    return _run_headless(cfg, args)


if __name__ == "__main__":
    raise SystemExit(main())
