"""
Команды кода JARVIS CORE (ТЗ-6, каталог code).

Команды уровня «код»: запуск фрагмента кода, запуск скрипта из файла
и чтение состояния git-репозитория (статус / дифф / лог). Каждая команда
имеет уровень риска (``RiskLevel``) и регистрируется в ``CommandRegistry``,
откуда попадает в схемы function calling для LLM.

Архитектура (в стиле ``actions/browser_actions.py`` / ``actions/file_actions.py``):

- ``CodeBackend`` — контракт «исполнитель» операций с кодом и git;
- ``SubprocessCodeBackend`` — локальная реализация через subprocess
  (``sys.executable -c`` для Python, интерпретатор по расширению для
  скриптов, утилита ``git`` для репозитория);
- ``DryRunCodeBackend`` — безопасный fallback/отладка: ничего не выполняет,
  пишет вызовы в журнал (используется и в тестах).

«Локально ↔ облако» здесь неприменимо: код выполняется только локально
(облачного исполнения нет и не планируется — это вопрос безопасности).
При недоступности исполнителя команда падает контролируемо
(``CodeUnavailable``) без побочных эффектов.

Безопасность (ТЗ-6.7):
  - запуск кода/скриптов — HIGH (требуют подтверждения), git-чтение — SAFE;
  - все аргументы проходят строгую валидацию (тип, длина, управляющие
    символы, ведущий '-' → антиинъекция опций в argv) и передаются в
    subprocess списком без shell=True;
  - скрипты принимаются только с allow-list расширений (``.py`` / ``.sh``)
    и запускаются явным интерпретатором, а не «как есть»;
  - вывод обрезается до ``MAX_OUTPUT`` символов, время выполнения
    ограничено таймаутом (1..300 с) — защита от зависших процессов;
  - git-команды — фиксированный argv (только чтение: status/diff/log),
    пользовательская строка не попадает в аргументы git.

Использование:
    from actions.registry import CommandRegistry
    from actions.code_actions import CodeActions, register_code_actions

    registry = CommandRegistry()
    register_code_actions(registry)       # или со своим backend
"""

from __future__ import annotations

import abc
import logging
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from actions.registry import REQUIRES_CONFIRMATION, Command, CommandRegistry, RiskLevel
from ai.function_calling import ParamSpec

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class CodeError(Exception):
    """Ошибка команды кода."""


class CodeUnavailable(CodeError):
    """Исполнитель недоступен (нет интерпретатора/git/прав) — можно fallback."""


class CodeTimeout(CodeError):
    """Превышен таймаут выполнения."""


# ---------------------------------------------------------------------------
# Константы
# ---------------------------------------------------------------------------
#: Язык → каноническое имя (пока поддержан только Python)
LANGUAGE_ALIASES: dict[str, str] = {
    "python": "python",
    "py": "python",
    "python3": "python",
}

#: Максимальная длина исходного кода (символов)
MAX_CODE_LENGTH = 200_000

#: Максимальная длина одного аргумента скрипта (символов)
MAX_ARG_LENGTH = 4_000

#: Максимальное число аргументов скрипта
MAX_ARGS = 64

#: Максимальный объём stdout/stderr (символов) — всё сверх обрезается
MAX_OUTPUT = 20_000

#: Границы таймаута выполнения (секунды)
MIN_TIMEOUT = 1.0
MAX_TIMEOUT = 300.0
DEFAULT_TIMEOUT = 30.0

#: Расширение скрипта → интерпретатор (argv-префикс; allow-list)
SCRIPT_INTERPRETERS: dict[str, list[str]] = {
    ".py": [sys.executable],
    ".sh": ["bash"],
    ".bash": ["bash"],
}


# ---------------------------------------------------------------------------
# Результат выполнения
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class CodeRunResult:
    """Результат запуска кода/скрипта (без исключений — статус в полях)."""

    language: str
    exit_code: int
    stdout: str
    stderr: str
    duration_ms: int
    timed_out: bool = False
    truncated: bool = False

    def describe(self) -> dict[str, Any]:
        """Словарь для ответа LLM/панели."""
        return {
            "language": self.language,
            "exit_code": self.exit_code,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "duration_ms": self.duration_ms,
            "timed_out": self.timed_out,
            "truncated": self.truncated,
        }


def _truncate(text: str) -> tuple[str, bool]:
    """Обрезает вывод до ``MAX_OUTPUT`` символов; признак обрезки."""
    if len(text) <= MAX_OUTPUT:
        return text, False
    return text[:MAX_OUTPUT] + "\n…[вывод обрезан]", True


# ---------------------------------------------------------------------------
# Валидация входных данных (антиинъекция)
# ---------------------------------------------------------------------------
def validate_language(language: Any) -> str:
    """Канонизирует имя языка (``py`` → ``python``); иначе ``ValueError``."""
    if not isinstance(language, str):
        raise ValueError(f"language должен быть строкой, получено: {language!r}")
    key = language.strip().lower()
    if key not in LANGUAGE_ALIASES:
        raise ValueError(
            f"неподдерживаемый язык: {language!r} "
            f"(допустимо: {sorted(set(LANGUAGE_ALIASES))})"
        )
    return LANGUAGE_ALIASES[key]


def validate_code(code: Any) -> str:
    """Проверяет исходный код: непустой, без NUL, в пределах лимита длины."""
    if not isinstance(code, str):
        raise ValueError(f"code должен быть строкой, получено: {code!r}")
    if not code.strip():
        raise ValueError("code пуст")
    if "\x00" in code:
        raise ValueError("code содержит управляющий символ NUL")
    if len(code) > MAX_CODE_LENGTH:
        raise ValueError(f"code длиннее лимита {MAX_CODE_LENGTH} символов")
    return code


def validate_timeout(timeout: Any) -> float:
    """Проверяет таймаут (1..300 с); строки-числа принимаются."""
    value: Any = timeout
    if isinstance(value, str):
        try:
            value = float(value.strip())
        except ValueError as e:
            raise ValueError(f"timeout не число: {timeout!r}") from e
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"timeout должен быть числом, получено: {timeout!r}")
    if not (MIN_TIMEOUT <= float(value) <= MAX_TIMEOUT):
        raise ValueError(f"timeout вне диапазона {MIN_TIMEOUT}..{MAX_TIMEOUT}: {value}")
    return float(value)


def validate_script_path(path: Any) -> str:
    """
    Проверяет путь к скрипту: строка, без управляющих символов и ведущего
    ``-``, allow-list расширений, файл существует.
    """
    if not isinstance(path, str):
        raise ValueError(f"path должен быть строкой, получено: {path!r}")
    text = path.strip()
    if not text:
        raise ValueError("path пуст")
    if text.startswith("-"):
        raise ValueError("path не может начинаться с '-' (антиинъекция опций)")
    if any(ord(ch) < 32 or ch == "\x7f" for ch in text):
        raise ValueError("path содержит управляющие символы")
    suffix = Path(text).suffix.lower()
    if suffix not in SCRIPT_INTERPRETERS:
        raise ValueError(
            f"неподдерживаемое расширение скрипта: {suffix or '«нет»'} "
            f"(допустимо: {sorted(SCRIPT_INTERPRETERS)})"
        )
    if not Path(text).is_file():
        raise ValueError(f"скрипт не найден: {text}")
    return text


def validate_args(args: Any) -> list[str]:
    """Проверяет аргументы скрипта: список строк без управляющих символов."""
    if args is None:
        return []
    if not isinstance(args, (list, tuple)):
        raise ValueError(f"args должен быть списком строк, получено: {args!r}")
    if len(args) > MAX_ARGS:
        raise ValueError(f"слишком много аргументов: {len(args)} > {MAX_ARGS}")
    clean: list[str] = []
    for item in args:
        if not isinstance(item, str):
            raise ValueError(f"аргумент должен быть строкой, получено: {item!r}")
        if not item or len(item) > MAX_ARG_LENGTH:
            raise ValueError(f"аргумент пуст или слишком длинный: {item[:40]!r}…")
        if any(ord(ch) < 32 or ch == "\x7f" for ch in item):
            raise ValueError(f"аргумент содержит управляющие символы: {item[:40]!r}")
        clean.append(item)
    return clean


def validate_repo_dir(cwd: Any) -> str:
    """Проверяет рабочую папку git: существующая директория без инъекций."""
    if not isinstance(cwd, str):
        raise ValueError(f"cwd должен быть строкой, получено: {cwd!r}")
    text = cwd.strip()
    if not text:
        raise ValueError("cwd пуст")
    if text.startswith("-"):
        raise ValueError("cwd не может начинаться с '-' (антиинъекция опций)")
    if any(ord(ch) < 32 or ch == "\x7f" for ch in text):
        raise ValueError("cwd содержит управляющие символы")
    if not Path(text).is_dir():
        raise ValueError(f"не директория: {text}")
    return text


def validate_limit(limit: Any) -> int:
    """Проверяет число записей git-лога (1..100)."""
    value: Any = limit
    if isinstance(value, str):
        try:
            value = int(value.strip())
        except ValueError as e:
            raise ValueError(f"limit не число: {limit!r}") from e
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"limit должен быть целым, получено: {limit!r}")
    if not (1 <= value <= 100):
        raise ValueError(f"limit вне диапазона 1..100: {value}")
    return value


# ---------------------------------------------------------------------------
# Исполнитель (контракт)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ProcResult:
    """Сырой результат процесса (exit_code, stdout, stderr)."""

    exit_code: int
    stdout: str
    stderr: str


#: Запуск argv: (argv, timeout, cwd) → ProcResult
Runner = Callable[[list[str], float, str | None], ProcResult]


def _default_runner(argv: list[str], timeout: float, cwd: str | None) -> ProcResult:
    """Выполняет argv и возвращает сырой результат; ошибки — контролируемые."""
    try:
        proc = subprocess.run(  # noqa: S603 — argv формируем сами, shell=False
            argv,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=cwd,
            check=False,
        )
    except FileNotFoundError as e:
        raise CodeUnavailable(f"исполнитель не найден: {argv[0]}") from e
    except subprocess.TimeoutExpired as e:
        raise CodeTimeout(f"превышен таймаут {timeout} с: {' '.join(argv[:2])}…") from e
    except OSError as e:
        raise CodeError(f"не удалось запустить: {' '.join(argv[:2])}… ({e})") from e
    return ProcResult(proc.returncode, proc.stdout, proc.stderr)


class CodeBackend(abc.ABC):
    """Контракт исполнителя операций с кодом и git."""

    name: str = "abstract"

    @abc.abstractmethod
    def is_available(self) -> bool:
        """Доступен ли исполнитель (иначе команда падает с CodeUnavailable)."""

    @abc.abstractmethod
    def run_python(self, code: str, timeout: float) -> CodeRunResult:
        """Выполнить фрагмент Python-кода."""

    @abc.abstractmethod
    def run_script(self, path: str, args: list[str], timeout: float) -> CodeRunResult:
        """Выполнить скрипт из файла с аргументами."""

    @abc.abstractmethod
    def git_status(self, cwd: str) -> str:
        """Короткий статус рабочей копии git."""

    @abc.abstractmethod
    def git_diff(self, cwd: str, staged: bool) -> str:
        """Дифф рабочей копии (или индекса при ``staged=True``)."""

    @abc.abstractmethod
    def git_log(self, cwd: str, limit: int) -> str:
        """Последние коммиты в формате ``oneline``."""


# ---------------------------------------------------------------------------
# Локальный исполнитель
# ---------------------------------------------------------------------------
@dataclass
class SubprocessCodeBackend(CodeBackend):
    """
    Локальный исполнитель: subprocess без shell=True, с таймаутом и
    обрезкой вывода. ``runner`` подменяется в тестах.
    """

    name: str = "subprocess"
    runner: Runner = field(default=_default_runner)

    def is_available(self) -> bool:
        # Интерпретатор — тот же, что выполняет процесс, он есть по определению.
        return bool(sys.executable)

    def _execute(self, language: str, argv: list[str], timeout: float) -> CodeRunResult:
        """Общий запуск: замер времени, таймаут → timed_out, обрезка вывода."""
        started = time.monotonic()
        try:
            raw = self.runner(argv, timeout, None)
        except CodeTimeout:
            duration_ms = int((time.monotonic() - started) * 1000)
            return CodeRunResult(
                language=language,
                exit_code=-1,
                stdout="",
                stderr=f"превышен таймаут {timeout} с",
                duration_ms=duration_ms,
                timed_out=True,
            )
        duration_ms = int((time.monotonic() - started) * 1000)
        out, cut_out = _truncate(raw.stdout)
        err, cut_err = _truncate(raw.stderr)
        return CodeRunResult(
            language=language,
            exit_code=raw.exit_code,
            stdout=out,
            stderr=err,
            duration_ms=duration_ms,
            truncated=cut_out or cut_err,
        )

    def run_python(self, code: str, timeout: float) -> CodeRunResult:
        argv = [sys.executable, "-c", code]
        return self._execute("python", argv, timeout)

    def run_script(self, path: str, args: list[str], timeout: float) -> CodeRunResult:
        interpreter = SCRIPT_INTERPRETERS[Path(path).suffix.lower()]
        language = Path(path).suffix.lower().lstrip(".")
        argv = [*interpreter, path, *args]
        return self._execute(language, argv, timeout)

    # -- git (только чтение) ---------------------------------------------------
    def _git(self, cwd: str, argv: list[str]) -> str:
        try:
            raw = self.runner(["git", *argv], 30.0, cwd)
        except CodeTimeout as e:
            raise CodeError(f"git не ответил вовремя: {e}") from e
        if raw.exit_code != 0:
            raise CodeError(
                f"git {' '.join(argv)} завершился с кодом {raw.exit_code}: "
                f"{raw.stderr.strip()[:200]}"
            )
        return raw.stdout

    def git_status(self, cwd: str) -> str:
        out = self._git(cwd, ["status", "--short"])
        return out.strip() or "(изменений нет)"

    def git_diff(self, cwd: str, staged: bool) -> str:
        argv = ["diff", "--staged"] if staged else ["diff"]
        out = self._git(cwd, argv)
        text, _ = _truncate(out)
        return text.strip() or "(пусто)"

    def git_log(self, cwd: str, limit: int) -> str:
        out = self._git(cwd, ["log", "--oneline", "-n", str(limit)])
        return out.strip() or "(история пуста)"


# ---------------------------------------------------------------------------
# Безопасный исполнитель (fallback / отладка / тесты)
# ---------------------------------------------------------------------------
@dataclass
class DryRunCodeBackend(CodeBackend):
    """
    Ничего не выполняет: записывает вызовы в ``calls`` и возвращает
    предзаполненные результаты. Используется в тестах и как fallback
    при недоступности интерпретатора/git (headless-контейнер).
    """

    name: str = "dry-run"
    available: bool = True
    stdout: str = "dry-run: выполнено без побочных эффектов"
    git_status_text: str = "M main.py"
    git_diff_text: str = ""
    git_log_text: str = "abc123 init"
    calls: list[tuple[str, tuple[Any, ...]]] = field(default_factory=list)

    def is_available(self) -> bool:
        return self.available

    def run_python(self, code: str, timeout: float) -> CodeRunResult:
        self.calls.append(("run_python", (code, timeout)))
        return CodeRunResult("python", 0, self.stdout, "", 0)

    def run_script(self, path: str, args: list[str], timeout: float) -> CodeRunResult:
        self.calls.append(("run_script", (path, tuple(args), timeout)))
        language = Path(path).suffix.lower().lstrip(".") or "script"
        return CodeRunResult(language, 0, self.stdout, "", 0)

    def git_status(self, cwd: str) -> str:
        self.calls.append(("git_status", (cwd,)))
        return self.git_status_text

    def git_diff(self, cwd: str, staged: bool) -> str:
        self.calls.append(("git_diff", (cwd, staged)))
        return self.git_diff_text or "(пусто)"

    def git_log(self, cwd: str, limit: int) -> str:
        self.calls.append(("git_log", (cwd, limit)))
        return self.git_log_text


# ---------------------------------------------------------------------------
# Служба команд кода
# ---------------------------------------------------------------------------
@dataclass
class CodeActions:
    """
    Служба команд кода: валидация входных данных + backend.

    При недоступности backend операции падают контролируемо
    (``CodeUnavailable``), без побочных эффектов. Таймаут выполнения не
    роняет команду: возвращается результат с ``timed_out=True``.
    """

    backend: CodeBackend = field(default_factory=SubprocessCodeBackend)

    def _require_backend(self) -> CodeBackend:
        if not self.backend.is_available():
            raise CodeUnavailable(f"исполнитель '{self.backend.name}' недоступен")
        return self.backend

    # -- команды (HIGH: выполнение кода) ---------------------------------------
    def run_code(
        self,
        code: Any,
        language: Any = "python",
        timeout: Any = DEFAULT_TIMEOUT,
    ) -> dict[str, Any]:
        """
        Выполнить фрагмент кода локально (после подтверждения).

        Поддержан только Python; ``timeout`` — 1..300 с. При превышении
        таймаута возвращается результат с ``timed_out=True``, без исключения.
        """
        lang = validate_language(language)
        source = validate_code(code)
        limit = validate_timeout(timeout)
        result = self._require_backend().run_python(source, limit)
        logger.info(
            "Выполнен код (%s): exit=%d, %d мс", lang, result.exit_code, result.duration_ms
        )
        return result.describe()

    def run_script(
        self,
        path: Any,
        args: Any = None,
        timeout: Any = DEFAULT_TIMEOUT,
    ) -> dict[str, Any]:
        """
        Выполнить скрипт из файла (после подтверждения).

        Расширения: ``.py`` (Python), ``.sh`` / ``.bash`` (bash). Аргументы —
        список строк без управляющих символов; передаются в argv без shell.
        """
        script = validate_script_path(path)
        argv = validate_args(args)
        limit = validate_timeout(timeout)
        result = self._require_backend().run_script(script, argv, limit)
        logger.info(
            "Выполнен скрипт %s: exit=%d, %d мс", script, result.exit_code, result.duration_ms
        )
        return result.describe()

    # -- команды (SAFE: чтение git) --------------------------------------------
    def git_status(self, cwd: Any = ".") -> dict[str, Any]:
        """Короткий статус git-репозитория (изменённые файлы)."""
        repo = validate_repo_dir(cwd)
        text = self._require_backend().git_status(repo)
        return {"repo": repo, "status": text}

    def git_diff(self, cwd: Any = ".", staged: Any = False) -> dict[str, Any]:
        """Дифф git: рабочей копии (по умолчанию) или индекса (``staged``)."""
        if not isinstance(staged, bool):
            raise ValueError(f"staged должен быть bool, получено: {staged!r}")
        repo = validate_repo_dir(cwd)
        text = self._require_backend().git_diff(repo, staged)
        return {"repo": repo, "staged": staged, "diff": text}

    def git_log(self, cwd: Any = ".", limit: Any = 10) -> dict[str, Any]:
        """Последние коммиты git (oneline)."""
        repo = validate_repo_dir(cwd)
        count = validate_limit(limit)
        text = self._require_backend().git_log(repo, count)
        return {"repo": repo, "limit": count, "log": text}


# ---------------------------------------------------------------------------
# Регистрация команд в реестре
# ---------------------------------------------------------------------------
def _spec(name: str, type_: str, description: str, **kw: Any) -> ParamSpec:
    return ParamSpec(
        name=name,
        type=type_,
        description=description,
        required=kw.get("required", True),
        enum=kw.get("enum"),
        default=kw.get("default"),
    )


def register_code_actions(
    registry: CommandRegistry,
    actions: CodeActions | None = None,
) -> list[str]:
    """
    Регистрирует команды кода в ``registry`` (возвращает их имена).

    Уровни риска (ТЗ-6.7):
      - SAFE:   git_status, git_diff, git_log (только чтение)
      - HIGH:   run_code, run_script (произвольное выполнение — подтверждение)
    """
    svc = actions or CodeActions()

    defs: list[tuple[str, str, list[ParamSpec], str, Callable[..., Any]]] = [
        (
            "run_code",
            "Выполнить фрагмент кода локально (после подтверждения)",
            [
                _spec("code", "string", "исходный код для выполнения"),
                _spec(
                    "language",
                    "string",
                    "язык кода",
                    required=False,
                    enum=sorted(set(LANGUAGE_ALIASES)),
                    default="python",
                ),
                _spec(
                    "timeout",
                    "number",
                    f"таймаут в секундах ({MIN_TIMEOUT}..{MAX_TIMEOUT})",
                    required=False,
                    default=DEFAULT_TIMEOUT,
                ),
            ],
            RiskLevel.HIGH,
            svc.run_code,
        ),
        (
            "run_script",
            "Выполнить скрипт из файла (.py/.sh; после подтверждения)",
            [
                _spec("path", "string", "путь к скрипту"),
                _spec(
                    "args",
                    "array",
                    "аргументы командной строки (список строк)",
                    required=False,
                ),
                _spec(
                    "timeout",
                    "number",
                    f"таймаут в секундах ({MIN_TIMEOUT}..{MAX_TIMEOUT})",
                    required=False,
                    default=DEFAULT_TIMEOUT,
                ),
            ],
            RiskLevel.HIGH,
            svc.run_script,
        ),
        (
            "git_status",
            "Короткий статус git-репозитория (изменённые файлы)",
            [
                _spec("cwd", "string", "папка репозитория", required=False, default="."),
            ],
            RiskLevel.SAFE,
            svc.git_status,
        ),
        (
            "git_diff",
            "Показать изменения в git (рабочей копии или индекса)",
            [
                _spec("cwd", "string", "папка репозитория", required=False, default="."),
                _spec(
                    "staged",
                    "boolean",
                    "показать индексированные изменения (git diff --staged)",
                    required=False,
                    default=False,
                ),
            ],
            RiskLevel.SAFE,
            svc.git_diff,
        ),
        (
            "git_log",
            "Показать последние коммиты git (oneline)",
            [
                _spec("cwd", "string", "папка репозитория", required=False, default="."),
                _spec("limit", "number", "сколько коммитов (1..100)", required=False, default=10),
            ],
            RiskLevel.SAFE,
            svc.git_log,
        ),
    ]

    names: list[str] = []
    for name, description, params, risk, handler in defs:
        registry.register(
            Command(
                name=name,
                description=description,
                params=params,
                handler=handler,
                risk=risk,
                requires_confirmation=REQUIRES_CONFIRMATION.get(risk, False),
            )
        )
        names.append(name)
    logger.debug("Зарегистрированы команды кода: %s", ", ".join(names))
    return names
