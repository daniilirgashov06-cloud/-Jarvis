"""
Telegram-бот JARVIS CORE (aiogram 3): сборка и запуск.

Модуль собирает бота из настроек (``config/settings.py`` + переменные
окружения) и подключает его к оркестратору через ``telegram_bot/bridge``.
Секреты нигде не зашиты: токен берётся из ``TELEGRAM_BOT_TOKEN`` или
``telegram.token`` настроек; без токена бот не стартует и объясняет, чего
не хватает.

**Устойчивость к отсутствию aiogram**: ``import telegram_bot.bot`` работает
и без aiogram; ``run()`` в таком случае возвращает ``False`` и пишет в лог
сообщение «aiogram не установлен» — без исключений и падений.

Использование::

    from telegram_bot.bot import BotConfig, TelegramBotApp

    config = BotConfig.from_settings(load_settings())
    app = TelegramBotApp(config, status_provider=..., screenshot_provider=...)
    asyncio.run(app.run())

CLI:  ``python3 -m telegram_bot.bot``
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping

from telegram_bot.bridge import (
    AccessLevel,
    ChatWhitelist,
    CommandBridge,
    ConfirmationManager,
)
from telegram_bot.handlers import (
    AIOGRAM_AVAILABLE,
    BotHandlers,
    TelegramDependencyError,
    require_aiogram,
    setup_handlers,
)

logger = logging.getLogger(__name__)

__all__ = [
    "TelegramConfigError",
    "resolve_token",
    "BotConfig",
    "TelegramBotApp",
    "main",
]


# ---------------------------------------------------------------------------
# Ошибки конфигурации
# ---------------------------------------------------------------------------
class TelegramConfigError(RuntimeError):
    """Некорректная/неполная конфигурация Telegram-бота (например, нет токена)."""


# ---------------------------------------------------------------------------
# Токен и конфигурация
# ---------------------------------------------------------------------------
def resolve_token(
    env: Mapping[str, str] | None = None,
    settings: Any = None,
) -> str:
    """
    Найти токен бота: ``TELEGRAM_BOT_TOKEN`` (окружение) → ``telegram.token``.

    Секреты в коде не хардкодятся: при отсутствии токена бросается
    ``TelegramConfigError`` с подсказкой, где его указать.
    """
    environ = os.environ if env is None else env
    token = str(environ.get("TELEGRAM_BOT_TOKEN", "")).strip()
    if token:
        return token
    section = getattr(settings, "telegram", None) if settings is not None else None
    secret = getattr(section, "token", None) if section is not None else None
    if secret is not None:
        value = secret.get_secret_value() if hasattr(secret, "get_secret_value") else str(secret)
        if str(value).strip():
            return str(value).strip()
    raise TelegramConfigError(
        "токен Telegram-бота не задан: укажите переменную окружения "
        "TELEGRAM_BOT_TOKEN или telegram.token в config/settings.yaml"
    )


@dataclass(frozen=True)
class BotConfig:
    """Конфигурация Telegram-бота (без секретов в коде)."""

    token: str
    allowed_chats: frozenset[str] = frozenset()
    allow_all: bool = False
    access_level: AccessLevel = AccessLevel.VIEW
    confirm_ttl_s: float = 120.0
    notify_errors: bool = True
    bot_name: str = "JARVIS"

    def __post_init__(self) -> None:
        if not str(self.token).strip():
            raise TelegramConfigError("токен Telegram-бота пуст")
        if self.confirm_ttl_s <= 0:
            raise ValueError(f"confirm_ttl_s должен быть > 0, получено: {self.confirm_ttl_s!r}")

    @classmethod
    def from_settings(
        cls,
        settings: Any = None,
        *,
        env: Mapping[str, str] | None = None,
    ) -> "BotConfig":
        """
        Собрать конфигурацию из настроек ``config.settings`` + окружения.

        ``settings`` не обязателен: без него токен ищется только в env.
        """
        token = resolve_token(env=env, settings=settings)
        section = getattr(settings, "telegram", None) if settings is not None else None
        chat_id = getattr(section, "chat_id", None) if section is not None else None
        level_raw = getattr(section, "access_level", "view") if section is not None else "view"
        notify_errors = bool(getattr(section, "notify_errors", True)) if section is not None else True
        whitelist = ChatWhitelist.from_config(
            chat_id, default_level=AccessLevel(str(level_raw or "view"))
        )
        return cls(
            token=token,
            allowed_chats=whitelist.allowed,
            allow_all=whitelist.allow_all,
            access_level=whitelist.default_level,
            notify_errors=notify_errors,
        )

    def describe(self) -> dict[str, Any]:
        """Описание конфигурации **без токена** (для /status и логов)."""
        return {
            "token_set": bool(self.token),
            "allowed_chats": sorted(self.allowed_chats),
            "allow_all": self.allow_all,
            "access_level": self.access_level.value,
            "confirm_ttl_s": self.confirm_ttl_s,
            "notify_errors": self.notify_errors,
            "bot_name": self.bot_name,
        }


# ---------------------------------------------------------------------------
# Приложение бота
# ---------------------------------------------------------------------------
@dataclass
class TelegramBotApp:
    """
    Приложение Telegram-бота: мост + подтверждения + обработчики.

    ``run()`` стартует long-polling aiogram; если aiogram не установлен,
    метод вежливо возвращает ``False`` с сообщением в лог («aiogram не
    установлен») и не бросает исключений.
    """

    config: BotConfig
    bridge: CommandBridge = field(default_factory=CommandBridge)
    confirmations: ConfirmationManager | None = None
    status_provider: Callable[[], Mapping[str, Any]] = dict
    screenshot_provider: Callable[[], bytes | Path | None] = lambda: None

    def __post_init__(self) -> None:
        if self.confirmations is None:
            self.confirmations = ConfirmationManager(ttl_s=self.config.confirm_ttl_s)

    @property
    def whitelist(self) -> ChatWhitelist:
        """Whitelist chat_id из конфигурации."""
        return ChatWhitelist(
            allowed=self.config.allowed_chats,
            allow_all=self.config.allow_all,
            default_level=self.config.access_level,
        )

    @property
    def handlers(self) -> BotHandlers:
        """Обработчики команд (чистая логика, без сети)."""
        assert self.confirmations is not None  # гарантировано __post_init__
        return BotHandlers(
            bridge=self.bridge,
            confirmations=self.confirmations,
            whitelist=self.whitelist,
            status_provider=self.status_provider,
            screenshot_provider=self.screenshot_provider,
            bot_name=self.config.bot_name,
        )

    def describe(self) -> dict[str, Any]:
        """Сводка о приложении (без секретов)."""
        return {
            "aiogram_available": AIOGRAM_AVAILABLE,
            "config": self.config.describe(),
            "bridge": self.bridge.describe(),
        }

    async def run(self, polling_timeout: float = 30.0) -> bool:
        """
        Запустить бота (long polling). Возвращает ``True``, если запуск
        состоялся, и ``False``, если aiogram не установлен (без исключений).
        """
        if not AIOGRAM_AVAILABLE:
            logger.warning("aiogram не установлен: Telegram-бот не запущен")
            return False
        try:
            require_aiogram()
            from aiogram import Bot, Dispatcher
        except TelegramDependencyError:
            logger.warning("aiogram не установлен: Telegram-бот не запущен")
            return False

        bot = Bot(token=self.config.token)
        dp = Dispatcher()
        setup_handlers(dp, self.handlers)
        logger.info("Telegram-бот запущен (polling %.0f с)", polling_timeout)
        try:
            await dp.start_polling(bot, polling_timeout=polling_timeout)
        finally:
            await bot.session.close()
        return True


def _load_settings_optional() -> Any:
    """Загрузить настройки проекта, если модуль config доступен; иначе None."""
    try:
        from config.settings import load_settings
    except Exception:  # noqa: BLE001 - настройки необязательны для бота
        return None
    try:
        return load_settings()
    except Exception:  # noqa: BLE001 - битые настройки не должны ронять бота
        logger.warning("не удалось загрузить config/settings — использую только окружение")
        return None


def main() -> int:
    """
    Точка входа CLI: ``python3 -m telegram_bot.bot``.

    Не падает при отсутствии aiogram/токена — печатает понятное сообщение.
    """
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    try:
        config = BotConfig.from_settings(_load_settings_optional())
    except TelegramConfigError as exc:
        print(f"Telegram-бот не запущен: {exc}", file=sys.stderr)
        return 1
    app = TelegramBotApp(config)
    started = asyncio.run(app.run())
    if not started:
        print("aiogram не установлен: Telegram-бот не запущен (pip install \"aiogram>=3.7\")")
        return 0
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
