"""
Проверка actions/input_actions.py — команды ввода (текст/клавиши/мышь).

Запуск:  python3 tests/test_input_actions.py
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from actions.input_actions import (
    DryRunInputBackend,
    InputActions,
    InputError,
    InputUnavailable,
    SubprocessInputBackend,
    normalize_key,
    parse_hotkey,
    register_input_actions,
    validate_click,
    validate_coords,
    validate_scroll,
    validate_text,
)
from actions.registry import CommandRegistry, RiskLevel


# ---------------------------------------------------------------------------
# Хелперы
# ---------------------------------------------------------------------------
def _raises(exc_type, fn, *args, **kwargs) -> str:
    """Проверяет, что fn бросает exc_type; возвращает текст ошибки."""
    try:
        fn(*args, **kwargs)
    except exc_type as e:
        return str(e)
    raise AssertionError(f"ожидался {exc_type.__name__}, но ошибки не было")


# ---------------------------------------------------------------------------
# Тесты: валидация текста
# ---------------------------------------------------------------------------
def test_validate_text() -> None:
    assert validate_text("  привет, джарвис!  ") == "  привет, джарвис!  "
    assert validate_text("a" * 2000) == "a" * 2000

    for bad in ["", "-rf", "-набор", "a" * 2001,
                "со\nпереносом", "таб\tсимвол", "\x07", None, 42]:
        msg = _raises(ValueError, validate_text, bad)
        assert msg, "текст ошибки не должен быть пустым"


# ---------------------------------------------------------------------------
# Тесты: клавиши и комбинации
# ---------------------------------------------------------------------------
def test_normalize_key_aliases() -> None:
    assert normalize_key("Enter") == "enter"
    assert normalize_key("  ВВОД  ") == "enter"
    assert normalize_key("Escape") == "esc"
    assert normalize_key("пробел") == "space"
    assert normalize_key("Ctrl") == "ctrl"
    assert normalize_key("Win") == "meta"
    assert normalize_key("F5") == "f5"
    assert normalize_key("a") == "a"
    assert normalize_key("7") == "7"

    for bad in ["", "  ", "плагин", "f13", "a+b", None, 5]:
        msg = _raises(ValueError, normalize_key, bad)
        assert msg


def test_parse_hotkey() -> None:
    assert parse_hotkey("ctrl+alt+t") == ("ctrl", "alt", "t")
    assert parse_hotkey("Ctrl + Shift + S") == ("ctrl", "shift", "s")
    assert parse_hotkey("ввод") == ("enter",)
    assert parse_hotkey("alt+F4") == ("alt", "f4")
    # порядок модификаторов канонизируется
    assert parse_hotkey("shift+ctrl+p") == ("ctrl", "shift", "p")

    for bad in ["", "  ", "ctrl+shift", "ctrl+ctrl+t", "ctrl+t+a",
                "ctrl+alt+shift+meta+t+x", "ctrl+плагин", None, 7]:
        msg = _raises(ValueError, parse_hotkey, bad)
        assert msg


# ---------------------------------------------------------------------------
# Тесты: мышиные параметры
# ---------------------------------------------------------------------------
def test_validate_mouse_params() -> None:
    assert validate_coords(0, 10000) == (0, 10000)
    assert validate_coords(10.0, 20.0) == (10, 20)
    assert validate_click("LEFT", 2) == ("left", 2)
    assert validate_scroll(-5, 10) == (-5, 10)

    for bad in [(-1, 0), (0, 10001), (1.5, 2), ("x", 2), (True, 2)]:
        msg = _raises(ValueError, validate_coords, *bad)
        assert msg
    for bad in [("wheel", 1), ("left", 0), ("left", 4), ("left", "2"),
                ("left", True)]:
        msg = _raises(ValueError, validate_click, *bad)
        assert msg
    for bad in [(0, 0), (101, 0), (-101, 0), (0, 1.5), (0, "5")]:
        msg = _raises(ValueError, validate_scroll, *bad)
        assert msg


# ---------------------------------------------------------------------------
# Тесты: dry-run исполнитель + служба
# ---------------------------------------------------------------------------
def test_dry_run_operations() -> None:
    backend = DryRunInputBackend()
    svc = InputActions(backend=backend)

    assert "Ввожу текст" in svc.type_text("привет")
    assert "ctrl+alt+t" in svc.press_hotkey("Ctrl+Alt+T")
    assert svc.mouse_move(100, 200)
    assert "Двойной клик" in svc.mouse_click("right", 2)
    assert "dy=3" in svc.mouse_scroll(dy=3)

    assert backend.calls == [
        ("type_text", ("привет", 12)),
        ("press_hotkey", (("ctrl", "alt", "t"),)),
        ("mouse_move", (100, 200)),
        ("mouse_click", ("right", 2)),
        ("mouse_scroll", (0, 3)),
    ]


def test_service_validation_and_delay() -> None:
    backend = DryRunInputBackend()
    svc = InputActions(backend=backend)

    assert "0 символов" not in svc.type_text("ok", delay_ms=0)
    assert backend.calls[-1] == ("type_text", ("ok", 0))

    msg = _raises(ValueError, svc.type_text, "ok", delay_ms=-1)
    assert "0..500" in msg
    msg = _raises(ValueError, svc.type_text, "ok", delay_ms=1.5)
    assert msg
    msg = _raises(ValueError, svc.press_hotkey, "ctrl+shift")
    assert msg


# ---------------------------------------------------------------------------
# Тесты: недоступный исполнитель
# ---------------------------------------------------------------------------
def test_unavailable_backend() -> None:
    backend = DryRunInputBackend(available=False)
    svc = InputActions(backend=backend)

    for fn, args in [
        (svc.type_text, ("текст",)),
        (svc.press_hotkey, ("ctrl+c",)),
        (svc.mouse_move, (1, 2)),
        (svc.mouse_click, ("left", 1)),
        (svc.mouse_scroll, (0, 1)),
    ]:
        msg = _raises(InputUnavailable, fn, *args)
        assert "недоступен" in msg
    assert backend.calls == [], "при отказе не должно быть побочных эффектов"


# ---------------------------------------------------------------------------
# Тесты: subprocess-исполнитель (Linux)
# ---------------------------------------------------------------------------
def test_subprocess_linux_commands() -> None:
    calls: list[list[str]] = []

    def runner(argv: list[str]) -> str:
        calls.append(argv)
        return ""

    backend = SubprocessInputBackend(
        runner=runner,
        platform_name="Linux",
        which=lambda name: "/usr/bin/" + name if name == "xdotool" else None,
    )
    assert backend.is_available()

    backend.type_text("привет", delay_ms=12)
    backend.press_hotkey(("ctrl", "alt", "t"))
    backend.mouse_move(100, 200)
    backend.mouse_click("left", 2)
    backend.mouse_scroll(3, -2)

    assert calls[0] == ["xdotool", "type", "--clearmodifiers",
                        "--delay", "12", "привет"]
    assert calls[1] == ["xdotool", "key", "--clearmodifiers", "ctrl+alt+t"]
    assert calls[2] == ["xdotool", "mousemove", "100", "200"]
    assert calls[3] == ["xdotool", "click", "--repeat", "2", "1"]
    # вертикаль (вниз=5) первая, затем горизонтально (вправо=7)
    assert calls[4] == ["xdotool", "click", "--repeat", "2", "5"]
    assert calls[5] == ["xdotool", "click", "--repeat", "3", "7"]


def test_subprocess_linux_ydotool() -> None:
    calls: list[list[str]] = []

    def runner(argv: list[str]) -> str:
        calls.append(argv)
        return ""

    backend = SubprocessInputBackend(
        runner=runner,
        platform_name="Linux",
        which=lambda name: "/usr/bin/ydotool" if name == "ydotool" else None,
    )
    backend.type_text("hello", delay_ms=0)
    assert calls[0] == ["ydotool", "type", "hello"]

    # горячие клавиши через ydotool не поддерживаются
    msg = _raises(InputUnavailable, backend.press_hotkey, ("ctrl", "c"))
    assert "xdotool" in msg


def test_subprocess_no_tools() -> None:
    backend = SubprocessInputBackend(
        runner=lambda argv: "",
        platform_name="Linux",
        which=lambda name: None,
    )
    assert not backend.is_available()
    msg = _raises(InputUnavailable, backend.type_text, "текст", 0)
    assert "нет утилиты" in msg


# ---------------------------------------------------------------------------
# Тесты: subprocess-исполнитель (macOS / Windows)
# ---------------------------------------------------------------------------
def test_subprocess_darwin_windows_commands() -> None:
    calls: list[list[str]] = []

    def runner(argv: list[str]) -> str:
        calls.append(argv)
        return ""

    mac = SubprocessInputBackend(
        runner=runner, platform_name="Darwin",
        which=lambda name: "/usr/bin/" + name,
    )
    mac.type_text('скажи "да"', delay_ms=0)
    mac.press_hotkey(("meta", "shift", "t"))
    mac.press_hotkey(("enter",))
    mac.mouse_move(10, 20)
    mac.mouse_click("left", 1)
    # прокрутка на macOS не поддерживается
    msg = _raises(InputUnavailable, mac.mouse_scroll, 0, 1)
    assert "macOS" in msg

    assert calls[0][0] == "osascript" and "keystroke" in calls[0][2]
    assert '\\"да\\"' in calls[0][2], "кавычки должны быть экранированы"
    assert "command down" in calls[1][2] and "shift down" in calls[1][2]
    assert "key code 36" in calls[2][2], "enter → key code 36"
    assert calls[3] == ["cliclick", "m:10,20"]
    assert calls[4] == ["cliclick", "c:."]

    win = SubprocessInputBackend(
        runner=runner, platform_name="Windows",
        which=lambda name: "C:/ps/powershell" if name == "powershell" else None,
    )
    win.type_text("100% + готово", delay_ms=0)
    win.press_hotkey(("ctrl", "alt", "t"))
    win.mouse_click("left", 1)
    win.mouse_scroll(0, 2)

    ps_type = calls[5]
    assert ps_type[0].endswith("powershell") and ps_type[1] == "-NoProfile"
    assert "SendWait" in ps_type[3]
    assert "{%}" in ps_type[3] and "{+}" in ps_type[3], "SendKeys-экранирование"
    ps_key = calls[6]
    assert "'^%t'" in ps_key[3], "SendKeys: ctrl+alt+t → ^%t"
    ps_click = calls[7]
    assert "mouse_event(2, 0, 0, 0, 0)" in ps_click[3]
    assert "mouse_event(4, 0, 0, 0, 0)" in ps_click[3], "down/up пары"
    ps_scroll = calls[8]
    assert "0x0800" in ps_scroll[3] and "240" in ps_scroll[3], "2 * 120 = 240"

    # meta (Win) SendKeys не поддерживает
    msg = _raises(InputError, win.press_hotkey, ("meta", "r"))
    assert "SendKeys" in msg


# ---------------------------------------------------------------------------
# Тесты: регистрация команд
# ---------------------------------------------------------------------------
def test_register_input_actions() -> None:
    reg = CommandRegistry()
    backend = DryRunInputBackend()
    names = register_input_actions(reg, InputActions(backend=backend))

    assert sorted(names) == sorted([
        "type_text", "press_hotkey", "mouse_move", "mouse_click", "mouse_scroll",
    ])
    assert sorted(reg.names()) == sorted(names)

    # уровни риска и подтверждения (ТЗ-6.7)
    assert reg.get("mouse_move").risk == RiskLevel.SAFE
    assert reg.get("mouse_scroll").risk == RiskLevel.SAFE
    for name in ("type_text", "press_hotkey", "mouse_click"):
        cmd = reg.get(name)
        assert cmd.risk == RiskLevel.MEDIUM
        assert cmd.requires_confirmation, f"{name} требует подтверждения"
    assert not reg.get("mouse_move").requires_confirmation

    # схемы для function calling
    tools = {t.name: t for t in reg.enabled_tools()}
    assert set(tools) == set(names)
    assert [p.name for p in tools["type_text"].params] == ["text", "delay_ms"]
    click_params = {p.name: p for p in tools["mouse_click"].params}
    assert click_params["button"].enum == ["left", "middle", "right"]
    assert click_params["count"].default == 1

    # выполнение через реестр
    result = asyncio.run(reg.get("mouse_move").run(x=5, y=6))
    assert "5, 6" in result
    assert backend.calls[-1] == ("mouse_move", (5, 6))


# ---------------------------------------------------------------------------
# Запуск
# ---------------------------------------------------------------------------
def main() -> int:
    print("JARVIS CORE — проверка actions/input_actions")
    try:
        test_validate_text()
        test_normalize_key_aliases()
        test_parse_hotkey()
        test_validate_mouse_params()
        test_dry_run_operations()
        test_service_validation_and_delay()
        test_unavailable_backend()
        test_subprocess_linux_commands()
        test_subprocess_linux_ydotool()
        test_subprocess_no_tools()
        test_subprocess_darwin_windows_commands()
        test_register_input_actions()
    except AssertionError as e:
        import traceback

        print(f"\n✗ FAIL: {e}")
        traceback.print_exc()
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки input_actions прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
