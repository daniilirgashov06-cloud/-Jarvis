/**
 * Голос — настройки микрофона, VAD, wake-word, хлопков, TTS-пресетов
 * и командная консоль (живой диалог с ядром через WS/REST).
 */

import { motion } from "framer-motion";
import { useEffect, useState, type FormEvent } from "react";
import { Badge, Card, Notice, PageHeader } from "../components/ui/panels";
import { Button, Chip, FieldRow, SelectField, Slider, TextField, Toggle } from "../components/ui/controls";
import { useSocket } from "../hooks/useSocket";
import type { MicMode } from "../types/settings";
import { useSettingsStore } from "../stores/settingsStore";
import { useSystemStore } from "../stores/systemStore";

/* ---------------------------------------------------------------- пресеты */

interface VoicePreset {
  id: string;
  name: string;
  hint: string;
  apply: () => void;
}

/* ------------------------------------------------------------------ page */

export function VoicePage() {
  const settings = useSettingsStore((s) => s.data);
  const loaded = useSettingsStore((s) => s.loaded);
  const patch = useSettingsStore((s) => s.patch);
  const notice = useSettingsStore((s) => s.notice);
  const save = useSettingsStore((s) => s.save);
  const isDirty = useSettingsStore((s) => s.isDirty);
  const remote = useSettingsStore((s) => s.remote);

  const replies = useSystemStore((s) => s.replies);
  const { sendCommand } = useSocket();

  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [wordDraft, setWordDraft] = useState("");
  const [stopDraft, setStopDraft] = useState("");

  useEffect(() => {
    if (!loaded) void useSettingsStore.getState().load();
  }, [loaded]);

  const presets: VoicePreset[] = [
    {
      id: "night",
      name: "Ночной дежурный",
      hint: "Тихие SFX, wake-word, без приветствий",
      apply: () => {
        patch("audio", { mic_mode: "wakeword", sfx_volume: 0.25, speech_volume: 0.6 });
        patch("wakeword", { enabled: true, confidence: 0.6 });
        patch("fun", { greetings: false });
      },
    },
    {
      id: "office",
      name: "Офис",
      hint: "Шумоподавление, подтверждения, спокойный голос",
      apply: () => {
        patch("audio", { mic_mode: "wakeword", noise_suppression: true, agc: true, speech_volume: 1.0 });
        patch("tts", { speed: 0.96, effects: ["eq_british", "radio_clarity"] });
        patch("security", { require_confirmation_medium: true });
      },
    },
    {
      id: "privacy",
      name: "Приватный",
      hint: "Инкогнито: без памяти и скриншотов",
      apply: () => {
        patch("core", { privacy_mode: "incognito" });
        patch("memory", { enabled: false });
        patch("vision", { store_screenshots: false, screen_awareness: false });
      },
    },
    {
      id: "party",
      name: "Вечеринка",
      hint: "Микрофон всегда открыт, громкие эффекты",
      apply: () => {
        patch("audio", { mic_mode: "always", sfx_volume: 1.0, interrupt_user: true });
        patch("fun", { mode: "party", easter_eggs: true, emotional_tone: true });
      },
    },
    {
      id: "text",
      name: "Только текст",
      hint: "Микрофон и wake-word выключены",
      apply: () => {
        patch("audio", { mic_mode: "muted" });
        patch("wakeword", { enabled: false, clap_enabled: false });
      },
    },
  ];

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const command = text.trim();
    if (!command || busy) return;
    setBusy(true);
    try {
      await sendCommand(command);
      setText("");
    } finally {
      setBusy(false);
    }
  };

  const addWord = () => {
    const word = wordDraft.trim().toLowerCase();
    if (!word || settings.wakeword.words.includes(word)) return;
    patch("wakeword", { words: [...settings.wakeword.words, word] });
    setWordDraft("");
  };

  const addStopPhrase = () => {
    const phrase = stopDraft.trim().toLowerCase();
    if (!phrase || settings.wakeword.stop_phrases.includes(phrase)) return;
    patch("wakeword", { stop_phrases: [...settings.wakeword.stop_phrases, phrase] });
    setStopDraft("");
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Голос"
        subtitle="Микрофон, VAD, активация по слову и хлопкам, голос ассистента и пресеты сцен."
        actions={
          <>
            <Badge className={remote ? "border-ok/40 bg-ok/10 text-ok" : "border-warn/40 bg-warn/10 text-warn"}>
              {remote ? "REST настроек активен" : "демо-режим"}
            </Badge>
            <Button variant="primary" onClick={() => void save()} disabled={!isDirty()}>
              Сохранить
            </Button>
          </>
        }
      />

      {notice ? <Notice tone="info">{notice}</Notice> : null}

      {/* --- консоль ------------------------------------------------------ */}
      <Card title="Командная консоль" subtitle="Текстовая команда напрямую в оркестратор (как фраза в микрофон)">
        <form onSubmit={submit} className="flex flex-wrap gap-2">
          <input
            className="hud-input flex-1"
            placeholder="Например: поставь громкость 50"
            value={text}
            onChange={(e) => setText(e.target.value)}
            maxLength={8000}
          />
          <Button variant="primary" type="submit" disabled={busy || !text.trim()}>
            {busy ? "Думаю…" : "Отправить"}
          </Button>
        </form>

        <div className="mt-4 space-y-2">
          {replies
            .slice(-6)
            .reverse()
            .map((reply, i) => (
              <motion.div
                key={`${i}-${reply.text.slice(0, 12)}`}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className={clsxRound(reply.ok)}
              >
                <div className="flex items-center gap-2 text-xs">
                  <Badge className={reply.ok ? "border-ok/40 bg-ok/10 text-ok" : "border-danger/40 bg-danger/10 text-danger"}>
                    {reply.ok ? "ответ" : "ошибка"}
                  </Badge>
                  {reply.provider ? <span className="text-muted">модель: {reply.provider}</span> : null}
                  {reply.tts ? <span className="text-muted">tts: {reply.tts}</span> : null}
                  {reply.actions.length > 0 ? (
                    <span className="text-muted">
                      действия: {reply.actions.map((a) => a.name).join(", ")}
                    </span>
                  ) : null}
                </div>
                <p className="mt-1.5 text-sm text-text">{reply.text || reply.error || "—"}</p>
              </motion.div>
            ))}
          {replies.length === 0 ? (
            <p className="text-xs text-muted">Ответы ядра появятся здесь после отправки команды.</p>
          ) : null}
        </div>
      </Card>

      {/* --- микрофон + VAD ----------------------------------------------- */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card title="Микрофон" subtitle="Захват звука и режим работы">
          <SelectField
            label="Режим микрофона"
            value={settings.audio.mic_mode}
            onChange={(e) => patch("audio", { mic_mode: e.target.value as MicMode })}
            options={[
              { value: "always", label: "Всегда слушает" },
              { value: "wakeword", label: "По wake-word / хлопку" },
              { value: "push", label: "По хоткею (push-to-talk)" },
              { value: "muted", label: "Выключен" },
            ]}
            hint="Определяет, когда ядро слушает микрофон"
          />
          <div className="mt-3 grid grid-cols-2 gap-3">
            <TextField
              label="Устройство ввода"
              value={String(settings.audio.input_device ?? "")}
              placeholder="по умолчанию"
              onChange={(e) => patch("audio", { input_device: e.target.value || null })}
            />
            <TextField
              label="Устройство вывода"
              value={String(settings.audio.output_device ?? "")}
              placeholder="по умолчанию"
              onChange={(e) => patch("audio", { output_device: e.target.value || null })}
            />
          </div>
          <div className="mt-3 divide-y divide-line">
            <FieldRow
              label="Автоматическое усиление (AGC)"
              hint="Выравнивает громкость голоса"
              control={<Toggle checked={settings.audio.agc} onChange={(v) => patch("audio", { agc: v })} />}
            />
            <FieldRow
              label="Шумоподавление"
              hint="Фильтр фона перед распознаванием"
              control={
                <Toggle
                  checked={settings.audio.noise_suppression}
                  onChange={(v) => patch("audio", { noise_suppression: v })}
                />
              }
            />
            <FieldRow
              label="Перебивать пользователя"
              hint="Ассистент может говорить поверх речи"
              control={
                <Toggle
                  checked={settings.audio.interrupt_user}
                  onChange={(v) => patch("audio", { interrupt_user: v })}
                />
              }
            />
          </div>
        </Card>

        <Card title="VAD и голос" subtitle="Детекция речи и синтез (TTS)" delay={0.05}>
          <Slider
            label="Порог VAD"
            min={0}
            max={1}
            step={0.01}
            value={settings.audio.vad_threshold}
            onChange={(v) => patch("audio", { vad_threshold: v })}
            format={(v) => v.toFixed(2)}
            hint="Чувствительность определения речи"
          />
          <div className="mt-3">
            <Slider
              label="Пауза до конца реплики"
              min={300}
              max={3000}
              step={50}
              value={settings.audio.silence_ms}
              onChange={(v) => patch("audio", { silence_ms: v })}
              format={(v) => `${v} мс`}
            />
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <SelectField
              label="Движок TTS"
              value={settings.tts.engine}
              onChange={(e) => patch("tts", { engine: e.target.value })}
              options={[
                { value: "local", label: "Локальный" },
                { value: "piper", label: "Piper" },
                { value: "xtts", label: "XTTS" },
                { value: "elevenlabs", label: "ElevenLabs" },
              ]}
            />
            <TextField
              label="Голос"
              value={settings.tts.voice}
              placeholder="jarvis"
              onChange={(e) => patch("tts", { voice: e.target.value })}
              hint="Пресет тембра"
            />
          </div>
          <div className="mt-3">
            <Slider
              label="Скорость речи"
              min={0.5}
              max={2}
              step={0.01}
              value={settings.tts.speed}
              onChange={(v) => patch("tts", { speed: v })}
              format={(v) => `${v.toFixed(2)}×`}
            />
          </div>
          <div className="mt-3">
            <Slider
              label="Тон (pitch)"
              min={-12}
              max={12}
              step={0.5}
              value={settings.tts.pitch}
              onChange={(v) => patch("tts", { pitch: v })}
              format={(v) => `${v > 0 ? "+" : ""}${v} полутонов`}
            />
          </div>
          <div className="mt-4 space-y-3">
            <Slider
              label="Громкость речи"
              min={0}
              max={1}
              value={settings.audio.speech_volume}
              onChange={(v) => patch("audio", { speech_volume: v })}
              format={(v) => `${Math.round(v * 100)}%`}
            />
            <Slider
              label="Громкость эффектов"
              min={0}
              max={1}
              value={settings.audio.sfx_volume}
              onChange={(v) => patch("audio", { sfx_volume: v })}
              format={(v) => `${Math.round(v * 100)}%`}
            />
          </div>
        </Card>
      </div>

      {/* --- wake-word + хлопки ------------------------------------------- */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card title="Wake-word и стоп-фразы" subtitle="Слова активации ассистента" delay={0.05}>
          <FieldRow
            label="Детектор wake-word"
            hint="Слушает микрофон в фоне"
            control={<Toggle checked={settings.wakeword.enabled} onChange={(v) => patch("wakeword", { enabled: v })} />}
          />
          <div className="mt-3">
            <Slider
              label="Порог уверенности"
              min={0}
              max={1}
              value={settings.wakeword.confidence}
              onChange={(v) => patch("wakeword", { confidence: v })}
              format={(v) => v.toFixed(2)}
            />
          </div>

          <p className="mt-4 text-sm text-text">Слова активации</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {settings.wakeword.words.map((word) => (
              <Chip
                key={word}
                accent
                onRemove={() =>
                  patch("wakeword", { words: settings.wakeword.words.filter((w) => w !== word) })
                }
              >
                {word}
              </Chip>
            ))}
          </div>
          <div className="mt-2 flex gap-2">
            <input
              className="hud-input flex-1"
              placeholder="добавить слово…"
              value={wordDraft}
              onChange={(e) => setWordDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  addWord();
                }
              }}
            />
            <Button onClick={addWord}>Добавить</Button>
          </div>

          <div className="mt-4">
            <TextField
              label="Пользовательское слово"
              value={settings.wakeword.custom_word}
              placeholder="например: компьютер"
              onChange={(e) => patch("wakeword", { custom_word: e.target.value })}
              hint="Дополнительное слово активации"
            />
          </div>

          <p className="mt-4 text-sm text-text">Фразы-стоп</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {settings.wakeword.stop_phrases.map((phrase) => (
              <Chip
                key={phrase}
                onRemove={() =>
                  patch("wakeword", {
                    stop_phrases: settings.wakeword.stop_phrases.filter((p) => p !== phrase),
                  })
                }
              >
                {phrase}
              </Chip>
            ))}
          </div>
          <div className="mt-2 flex gap-2">
            <input
              className="hud-input flex-1"
              placeholder="добавить фразу-стоп…"
              value={stopDraft}
              onChange={(e) => setStopDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  addStopPhrase();
                }
              }}
            />
            <Button onClick={addStopPhrase}>Добавить</Button>
          </div>
        </Card>

        <Card title="Активация хлопком" subtitle="Альтернативный триггер без слов" delay={0.1}>
          <FieldRow
            label="Детектор хлопков"
            hint="Двойной хлопок будит ассистента"
            control={
              <Toggle checked={settings.wakeword.clap_enabled} onChange={(v) => patch("wakeword", { clap_enabled: v })} />
            }
          />
          <div className="mt-3">
            <Slider
              label="Порог громкости хлопка (RMS)"
              min={0}
              max={1}
              value={settings.wakeword.clap_rms_threshold}
              onChange={(v) => patch("wakeword", { clap_rms_threshold: v })}
              format={(v) => v.toFixed(2)}
            />
          </div>
          <div className="mt-3">
            <Slider
              label="Мин. интервал между хлопками"
              min={50}
              max={400}
              step={10}
              value={settings.wakeword.clap_gap_ms_min}
              onChange={(v) => patch("wakeword", { clap_gap_ms_min: v })}
              format={(v) => `${v} мс`}
            />
          </div>
          <div className="mt-3">
            <Slider
              label="Макс. интервал между хлопками"
              min={200}
              max={900}
              step={10}
              value={settings.wakeword.clap_gap_ms_max}
              onChange={(v) => patch("wakeword", { clap_gap_ms_max: v })}
              format={(v) => `${v} мс`}
            />
          </div>
          <div className="mt-2 divide-y divide-line">
            <FieldRow
              label="Только двойной хлопок"
              hint="Один хлопок игнорируется"
              control={<Toggle checked={settings.wakeword.clap_double} onChange={(v) => patch("wakeword", { clap_double: v })} />}
            />
          </div>

          <div className="mt-5">
            <p className="hud-title text-xs text-muted">Эффекты голоса</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {["eq_british", "subtle_reverb", "radio_clarity"].map((effect) => {
                const active = settings.tts.effects.includes(effect);
                return (
                  <Chip
                    key={effect}
                    accent={active}
                    onRemove={undefined}
                  >
                    <button
                      type="button"
                      className="uppercase tracking-wider"
                      onClick={() =>
                        patch("tts", {
                          effects: active
                            ? settings.tts.effects.filter((e) => e !== effect)
                            : [...settings.tts.effects, effect],
                        })
                      }
                    >
                      {effect}
                    </button>
                  </Chip>
                );
              })}
            </div>
          </div>
        </Card>
      </div>

      {/* --- пресеты ------------------------------------------------------ */}
      <Card title="Пресеты сцен" subtitle="Один клик — согласованный набор настроек">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-5">
          {presets.map((preset, i) => (
            <motion.button
              key={preset.id}
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              onClick={preset.apply}
              className="rounded-xl border border-line bg-panel-2/60 p-4 text-left transition-colors hover:border-accent/60 hover:shadow-neon"
            >
              <p className="hud-title text-xs text-accent">{preset.name}</p>
              <p className="mt-1.5 text-xs text-muted">{preset.hint}</p>
            </motion.button>
          ))}
        </div>
        <p className="mt-3 text-xs text-muted">
          Пресеты применяют изменения локально — не забудьте «Сохранить», чтобы отправить их в ядро.
        </p>
      </Card>
    </div>
  );
}

function clsxRound(ok: boolean): string {
  return ok
    ? "rounded-xl border border-line bg-panel-2/50 px-3 py-2"
    : "rounded-xl border border-danger/40 bg-danger/5 px-3 py-2";
}
