"""
Проверка vision/capture.py.

Запуск:  python3 tests/test_vision_capture.py
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from vision.capture import (
    CaptureError,
    CaptureRegion,
    CaptureRouter,
    CaptureUnavailable,
    MonitorInfo,
    ScreenCapture,
    ScreenCaptureBackend,
    ScreenFrame,
    SyntheticBackend,
    encode_png,
    mask_frame,
    validate_capture_path,
)


# ---------------------------------------------------------------------------
# Геометрия: валидация и пересечения
# ---------------------------------------------------------------------------
def test_region_geometry() -> None:
    r = CaptureRegion(10, 20, 100, 50)
    assert r.box == (10, 20, 110, 70)
    # пересечение
    inter = r.intersection(CaptureRegion(60, 40, 100, 100))
    assert inter == CaptureRegion(60, 40, 50, 30)
    assert r.intersection(CaptureRegion(200, 200, 10, 10)) is None
    # перевод в локальные координаты кадра
    frame_region = CaptureRegion(50, 30, 200, 200)
    local = CaptureRegion(60, 40, 30, 20).to_local(frame_region)
    assert local == CaptureRegion(10, 10, 30, 20)
    assert CaptureRegion(0, 0, 5, 5).to_local(frame_region) is None
    # некорректные регионы отклоняются
    for bad in [
        (0, 0, 0, 10),
        (0, 0, 10, -1),
        (0, 0, True, 10),
        (0, 0, "10", 10),
        (0, 0, 100_000, 100_000),  # память-бомба
    ]:
        try:
            CaptureRegion(*bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"регион {bad!r} должен быть отклонён")
    print("  ✓ geometry: box/intersection/to_local + валидация регионов")


# ---------------------------------------------------------------------------
# SyntheticBackend: детерминированный кадр
# ---------------------------------------------------------------------------
def test_synthetic_backend() -> None:
    be = SyntheticBackend(width=64, height=32, seed=3)
    assert be.is_available()
    mons = be.monitors()
    assert len(mons) == 1 and mons[0].width == 64 and mons[0].height == 32

    frame = be.grab()
    assert (frame.width, frame.height) == (64, 32)
    assert len(frame.pixels) == 64 * 32 * 3
    assert frame.backend == "synthetic"
    # детерминизм + влияние seed
    again = be.grab()
    assert frame.fingerprint() == again.fingerprint()
    other = SyntheticBackend(width=64, height=32, seed=4).grab()
    assert frame.fingerprint() != other.fingerprint()
    # подрегион: размер и содержимое согласованы
    sub = be.grab(CaptureRegion(8, 4, 16, 8))
    assert (sub.width, sub.height) == (16, 8)
    assert sub.pixel(0, 0) == frame.pixel(8, 4)
    # регион вне экрана
    try:
        be.grab(CaptureRegion(1000, 1000, 10, 10))
    except CaptureError:
        pass
    else:
        raise AssertionError("регион вне экрана должен быть отклонён")
    print("  ✓ synthetic: детерминизм, подрегионы, отказ вне экрана")


# ---------------------------------------------------------------------------
# CaptureRouter: fallback и смена бэкенда
# ---------------------------------------------------------------------------
class _BrokenBackend(ScreenCaptureBackend):
    """Бэкенд, который есть, но падает при захвате."""

    name = "broken"

    def is_available(self) -> bool:
        return True

    def monitors(self) -> list[MonitorInfo]:
        raise CaptureUnavailable("broken: дисплей недоступен")

    def grab(self, region=None, *, monitor: int = 0) -> ScreenFrame:
        raise CaptureUnavailable("broken: дисплей недоступен")


def test_router_fallback() -> None:
    good = SyntheticBackend(width=32, height=32)
    router = CaptureRouter(
        backends={"broken": _BrokenBackend(), "synthetic": good},
        primary="broken",
        fallback_chain=["broken", "synthetic"],
    )
    frame = router.grab()
    assert frame.backend == "synthetic"  # упал primary → подхватил fallback
    assert router.available() == ["broken", "synthetic"]
    # явный выбор бэкенда
    assert router.grab(backend="synthetic").backend == "synthetic"
    # смена primary
    router.set_primary("synthetic")
    assert router.primary == "synthetic"
    try:
        router.set_primary("nope")
    except CaptureError:
        pass
    else:
        raise AssertionError("неизвестный бэкенд должен быть отклонён")
    # полный отказ цепочки → контролируемая ошибка
    dead = CaptureRouter(backends={"broken": _BrokenBackend()}, primary="broken")
    try:
        dead.grab()
    except CaptureError as exc:
        assert "Ни один бэкенд" in str(exc)
    else:
        raise AssertionError("полный отказ должен давать CaptureError")
    print("  ✓ router: fallback, смена primary, полный отказ")


# ---------------------------------------------------------------------------
# Маскирование приватных регионов
# ---------------------------------------------------------------------------
def test_privacy_masking() -> None:
    be = SyntheticBackend(width=64, height=64, seed=1)
    frame = be.grab()
    # абсолютный регион маски (совпадает с координатами кадра 0,0)
    masked = mask_frame(frame, [CaptureRegion(10, 10, 8, 4)])
    assert masked.pixel(10, 10) == (0, 0, 0)
    assert masked.pixel(17, 13) == (0, 0, 0)
    assert masked.pixel(18, 10) == frame.pixel(18, 10)  # вне маски
    assert masked.pixel(10, 14) == frame.pixel(10, 14)  # ниже маски
    # маска за пределами кадра игнорируется
    untouched = mask_frame(frame, [CaptureRegion(500, 500, 10, 10)])
    assert untouched.fingerprint() == frame.fingerprint()
    # маска, вылезающая за край кадра, обрезается без падения
    edge = mask_frame(frame, [CaptureRegion(60, 60, 100, 100)])
    assert edge.pixel(63, 63) == (0, 0, 0)
    print("  ✓ masking: заливка чёрным, обрезка по краю, игнор вне кадра")


# ---------------------------------------------------------------------------
# ScreenCapture: дедупликация, история, маски через сервис
# ---------------------------------------------------------------------------
def test_capture_service() -> None:
    backend = SyntheticBackend(width=32, height=32, seed=7)
    router = CaptureRouter(backends={"synthetic": backend}, primary="synthetic")
    svc = ScreenCapture(
        router,
        history=2,
        privacy_regions=[CaptureRegion(0, 0, 4, 4)],
    )
    f1 = svc.capture()
    assert f1.pixel(0, 0) == (0, 0, 0)  # приватный угол замаскирован
    assert svc.last_frame is f1
    assert len(svc.history_frames()) == 1

    # дедупликация: тот же кадр → None
    assert svc.capture_if_changed() is None
    # сменили содержимое → кадр проходит
    backend.seed = 8
    changed = svc.capture_if_changed()
    assert changed is not None and changed.pixel(10, 10) != (0, 0, 0)
    # кольцевая история ограничена history=2
    svc.capture()
    assert len(svc.history_frames()) == 2
    # управление приватными регионами
    svc.clear_privacy_regions()
    plain = svc.capture()
    assert plain.pixel(0, 0) != (0, 0, 0)
    assert svc.privacy_regions == ()
    print("  ✓ service: маски, дедупликация, кольцевая история")


# ---------------------------------------------------------------------------
# PNG и валидация пути
# ---------------------------------------------------------------------------
def test_png_and_paths() -> None:
    frame = SyntheticBackend(width=20, height=10).grab()
    png = encode_png(frame)
    assert png.startswith(b"\x89PNG\r\n\x1a\n")
    # IHDR: ширина/высота в заголовке
    assert png[16:24] == (20).to_bytes(4, "big") + (10).to_bytes(4, "big")

    with tempfile.TemporaryDirectory() as tmp:
        svc = ScreenCapture(
            CaptureRouter(backends={"synthetic": SyntheticBackend()}, primary="synthetic"),
            output_dir=str(Path(tmp) / "caps"),
            forbidden_paths=[str(Path(tmp) / "forbidden")],
        )
        saved = svc.save_png(frame)
        assert saved.exists() and saved.read_bytes().startswith(b"\x89PNG")
        # автоимя в output_dir
        auto = svc.save_png(frame, None)
        assert auto.parent == (Path(tmp) / "caps").resolve() and auto.exists()
        # запрещённый путь
        try:
            svc.save_png(frame, str(Path(tmp) / "forbidden" / "x.png"))
        except CaptureError:
            pass
        else:
            raise AssertionError("forbidden_paths должен блокировать запись")
        # некорректные пути
        for bad in ["", "  ", "-x.png", "shot.txt", "sh\x00ot.png", 42]:
            try:
                validate_capture_path(bad, forbidden_paths=[])
            except ValueError:
                pass
            else:
                raise AssertionError(f"путь {bad!r} должен быть отклонён")
    print("  ✓ png: сигнатура/IHDR, сохранение, политика путей")


def main() -> int:
    print("JARVIS CORE — проверка vision/capture")
    try:
        test_region_geometry()
        test_synthetic_backend()
        test_router_fallback()
        test_privacy_masking()
        test_capture_service()
        test_png_and_paths()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки vision/capture прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
