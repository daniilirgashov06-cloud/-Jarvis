/**
 * Хук `useSocket` — живое подключение панели к ядру JARVIS.
 *
 * Поднимает singleton WebSocket (`lib/ws.ts`), привязывает кадры к сторам,
 * стартует VU/метрики и первичную загрузку (настройки, команды, статус,
 * лента). Команды отправляются по WS, при отсутствии соединения — REST.
 */

import { useEffect, useMemo } from "react";
import { fetchHistory, fetchStatus, sendTextRest } from "../lib/api";
import {
  connectSocket,
  getConnState,
  onConnectionChange,
  onFrame,
  reconnectSocket,
  sendCommandWs,
  sendFrame,
} from "../lib/ws";
import type { CommandReply, ConnectionState, ServerFrame } from "../types/api";
import { useCommandsStore } from "../stores/commandsStore";
import { useSettingsStore } from "../stores/settingsStore";
import { useSystemStore } from "../stores/systemStore";

// --- разовая инициализация --------------------------------------------------
let bootstrapped = false;
let vuTimer: ReturnType<typeof setInterval> | null = null;
let metricsTimer: ReturnType<typeof setInterval> | null = null;

/** Нормализовать уровень из payload события (0..1 или 0..100). */
function levelFromPayload(payload: Record<string, unknown>): number | null {
  for (const key of ["level", "rms", "vu", "amplitude", "volume", "db"]) {
    const raw = payload[key];
    if (typeof raw === "number" && Number.isFinite(raw)) {
      return raw > 1 ? Math.min(1, raw / 100) : Math.min(1, Math.max(0, raw));
    }
  }
  return null;
}

function handleFrame(frame: ServerFrame): void {
  const system = useSystemStore.getState();
  switch (frame.type) {
    case "status":
      system.setStatus(frame.state);
      break;
    case "event":
      system.pushEvent({ ts: Date.now() / 1000, topic: frame.topic, payload: frame.payload });
      if (/audio|vu|level|mic|stt|tts/i.test(frame.topic)) {
        const level = levelFromPayload(frame.payload);
        if (level !== null) system.setVu(level);
      }
      break;
    case "reply":
      system.pushReply({
        ok: frame.ok,
        text: frame.text,
        error: frame.error ?? null,
        actions: frame.actions ?? [],
        provider: frame.provider,
        tts: frame.tts,
      });
      break;
    case "error":
      system.pushEvent({
        ts: Date.now() / 1000,
        topic: "ui.error",
        payload: { message: frame.message },
      });
      break;
    default:
      break;
  }
}

function tickVu(): void {
  const system = useSystemStore.getState();
  const state = system.status?.state ?? "idle";
  // Плавный спад + синтетическая активность, когда ядро слушает/говорит.
  system.decayVu();
  if (state === "listening" || state === "speaking") {
    const base = state === "speaking" ? 0.45 : 0.3;
    const wave = Math.random() * 0.35;
    system.setVu(Math.max(system.vu, base + wave));
  } else if (state === "thinking" && Math.random() > 0.7) {
    system.setVu(Math.max(system.vu, 0.12 + Math.random() * 0.12));
  }
}

async function bootstrap(): Promise<void> {
  // Первичная загрузка настроек и реестра команд (демо-фолбэки внутри api.ts).
  void useSettingsStore.getState().load();
  void useCommandsStore.getState().load();

  // Снимок статуса и лента событий — REST работает и без WS.
  const status = await fetchStatus();
  if (status) useSystemStore.getState().setStatus(status);
  const history = await fetchHistory(60);
  const system = useSystemStore.getState();
  for (const event of history) system.pushEvent(event);

  // Периодическое обновление статуса (WS-запрос или REST-фолбэк).
  setInterval(() => {
    if (getConnState() === "online") {
      sendFrame({ type: "status" });
    } else {
      void fetchStatus().then((s) => s && useSystemStore.getState().setStatus(s));
    }
  }, 20000);
}

function ensureStarted(): void {
  if (bootstrapped) return;
  bootstrapped = true;

  onFrame(handleFrame);
  onConnectionChange((state: ConnectionState) => {
    useSystemStore.getState().setConnection(state);
    if (state === "online") {
      // После реконнекта подтягиваем свежую ленту.
      void fetchHistory(30).then((events) => {
        const system = useSystemStore.getState();
        for (const event of events) system.pushEvent(event);
      });
    }
  });

  vuTimer = setInterval(tickVu, 160);
  metricsTimer = setInterval(() => useSystemStore.getState().sampleMetrics(), 1500);

  connectSocket();
  void bootstrap();
}

export interface SocketApi {
  connection: ConnectionState;
  online: boolean;
  /** Отправить команду ядру (WS, фолбэк — REST) и вернуть ответ. */
  sendCommand: (text: string) => Promise<CommandReply>;
  /** Пинг ядра (проверка связи). */
  ping: () => void;
  /** Запросить свежий статус. */
  requestStatus: () => void;
  /** Переподключиться принудительно. */
  reconnect: () => void;
}

export function useSocket(): SocketApi {
  const connection = useSystemStore((s) => s.connection);

  useEffect(() => {
    ensureStarted();
  }, []);

  return useMemo<SocketApi>(
    () => ({
      connection,
      online: connection === "online",
      sendCommand: async (text: string) => {
        let reply: CommandReply;
        if (getConnState() === "online") {
          reply = await sendCommandWs(text);
        } else {
          reply = await sendTextRest(text);
          useSystemStore.getState().pushReply(reply);
        }
        return reply;
      },
      ping: () => {
        if (getConnState() === "online") {
          sendFrame({ type: "ping" });
        } else {
          void fetchStatus();
        }
      },
      requestStatus: () => {
        if (getConnState() === "online") {
          sendFrame({ type: "status" });
        } else {
          void fetchStatus().then((s) => s && useSystemStore.getState().setStatus(s));
        }
      },
      reconnect: reconnectSocket,
    }),
    [connection],
  );
}

/** Для тестов/разработки: сброс singleton (не используется в UI). */
export function __resetSocketRuntime(): void {
  bootstrapped = false;
  if (vuTimer) clearInterval(vuTimer);
  if (metricsTimer) clearInterval(metricsTimer);
  vuTimer = null;
  metricsTimer = null;
}
