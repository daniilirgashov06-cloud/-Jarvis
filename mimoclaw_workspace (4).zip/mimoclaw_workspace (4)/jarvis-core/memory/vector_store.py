"""
Векторное хранилище памяти JARVIS CORE (ТЗ-5, RAG top-k).

Семантический индекс воспоминаний: по запросу находит «похожие» фрагменты
(диалоги, факты, заметки) и отдаёт их тексты для сборки контекста LLM
(``ai.context_builder.ContextBuilder(memory=...)``). Работает по принципу
**локально-first** с мягким fallback:

- ``ChromaVectorStore`` — «настоящая» векторная БД на ``chromadb``
  (эмбеддинги ``sentence-transformers`` если установлены, иначе встроенная
  функция Chroma); персистентность на диск опциональна (``persist_dir``);
- ``InMemoryVectorStore`` — лёгкий поиск на чистом Python (TF-IDF + косинус),
  без внешних зависимостей и без сети — работает **всегда**, это гарантированный
  fallback; потокобезопасен;
- ``default_vector_store`` — фабрика «локально-first»: пробует ChromaDB,
  при любой ошибке (не установлен пакет, нет места/прав, сломанный движок)
  молча деградирует в TF-IDF-поиск (``degraded=True``) **без падения**.

Интерфейс (по ТЗ) у всех реализаций одинаковый::

    add(id, text, metadata) -> str      # upsert: повторный id заменяет запись
    search(query, top_k) -> list[str]   # top-k текстов по убыванию релевантности
    count() -> int
    delete(id) -> bool
    clear() -> int

``search`` возвращает именно **тексты** (не id) — это готовые «воспоминания»
для ``MemorySearch.search`` из ``ai.context_builder``. Пустой/невалидный запрос
даёт пустой список (не ошибку). Ошибки зависимостей превращаются в типизированный
``VectorStoreUnavailable`` — конвейер RAG их мягко обрабатывает.

Использование:
    from memory.vector_store import default_vector_store

    store = default_vector_store()            # ChromaDB или TF-IDF fallback
    store.add("m1", "пользователь любит чай без сахара", {"kind": "fact"})
    store.search("что любит пользователь?", top_k=8)  # -> ["пользователь ..."]
    store.delete("m1")
    store.clear()
"""

from __future__ import annotations

import abc
import logging
import math
import re
import threading
import uuid
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Константы и валидация
# ---------------------------------------------------------------------------
MAX_TEXT_LEN = 8000          # максимум символов в индексируемом тексте (как в store.py)
MAX_ID_LEN = 128             # максимум символов в id
MAX_QUERY_LEN = 512          # максимум символов в поисковом запросе
MAX_METADATA_KEYS = 32       # максимум ключей метаданных
MAX_METADATA_KEY_LEN = 64    # максимум символов в ключе метаданных
DEFAULT_TOP_K = 8            # дефолт top-k (совпадает с ContextBuilder.rag_top_k)
MAX_TOP_K = 64               # жёсткий потолок top-k
DEFAULT_COLLECTION = "jarvis-memory"  # имя коллекции ChromaDB

# Управляющие символы (антиинъекция в вывод LLM) — как в memory/store.py
_CTRL_RE = re.compile(r"[\x00-\x1f\x7f]")

# Токены для TF-IDF: латиница/кириллица/цифры, длина >= 2 (как в summarizer.py)
_WORD_RE = re.compile(r"[0-9a-zа-яё]{2,}")


class VectorStoreError(Exception):
    """Базовая ошибка векторного хранилища."""


class VectorStoreUnavailable(VectorStoreError):
    """Хранилище/движок недоступен (нет зависимости, диска, прав) — вызывающая
    сторона должна мягко деградировать, а не падать."""


def _normalize(text: str) -> str:
    """Нормализация для поиска: регистр + ё→е (как в ``memory/store.py``)."""
    return text.lower().replace("ё", "е")


def _tokenize(text: str) -> list[str]:
    """Разбить нормализованный текст на токены для TF-IDF."""
    return _WORD_RE.findall(_normalize(text))


def _clean_text(value: str, *, max_len: int, what: str) -> str:
    """Валидация текста: непустой, без управляющих символов, в пределах длины."""
    if not isinstance(value, str):
        raise ValueError(f"{what}: ожидается str")
    cleaned = value.strip()
    if not cleaned:
        raise ValueError(f"{what}: пустое значение")
    if len(cleaned) > max_len:
        raise ValueError(f"{what}: превышена длина {max_len}")
    if _CTRL_RE.search(cleaned):
        raise ValueError(f"{what}: недопустимые управляющие символы")
    return cleaned


def _clean_id(value: str | None) -> str:
    """Валидация id: непустой (иначе генерируем), без управляющих символов."""
    if value is None or value == "":
        return uuid.uuid4().hex
    if not isinstance(value, str):
        raise ValueError("id: ожидается str")
    cleaned = value.strip()
    if not cleaned:
        raise ValueError("id: пустое значение")
    if len(cleaned) > MAX_ID_LEN:
        raise ValueError(f"id: превышена длина {MAX_ID_LEN}")
    if _CTRL_RE.search(cleaned):
        raise ValueError("id: недопустимые управляющие символы")
    return cleaned


def _clean_metadata(metadata: dict[str, Any] | None) -> dict[str, Any]:
    """Метаданные: плоский словарь примитивов (str/int/float/bool), ``None`` — мимо."""
    if metadata is None:
        return {}
    if not isinstance(metadata, dict):
        raise ValueError("metadata: ожидается dict")
    if len(metadata) > MAX_METADATA_KEYS:
        raise ValueError(f"metadata: больше {MAX_METADATA_KEYS} ключей")
    result: dict[str, Any] = {}
    for key, value in metadata.items():
        if not isinstance(key, str):
            raise ValueError("metadata: ключи должны быть str")
        clean_key = key.strip()
        if not clean_key or len(clean_key) > MAX_METADATA_KEY_LEN:
            raise ValueError(f"metadata: некорректный ключ {key!r}")
        if _CTRL_RE.search(clean_key):
            raise ValueError(f"metadata: ключ {key!r} содержит управляющие символы")
        if value is None:
            continue  # None — «значения нет», в хранилище не идёт
        if isinstance(value, bool):
            result[clean_key] = value
        elif isinstance(value, (int, float)):
            result[clean_key] = value
        elif isinstance(value, str):
            if _CTRL_RE.search(value):
                raise ValueError(f"metadata[{clean_key}]: недопустимые управляющие символы")
            result[clean_key] = value
        else:
            raise ValueError(
                f"metadata[{clean_key}]: ожидается str/int/float/bool, получен {type(value).__name__}"
            )
    return result


def _clean_top_k(top_k: int) -> int:
    """Top-k: целое число, зажимается в диапазон [0, MAX_TOP_K]."""
    if isinstance(top_k, bool) or not isinstance(top_k, int):
        raise ValueError("top_k: ожидается int")
    return max(0, min(top_k, MAX_TOP_K))


# ---------------------------------------------------------------------------
# Контракт
# ---------------------------------------------------------------------------
class VectorStore(abc.ABC):
    """Абстрактное векторное хранилище (контракт «что умеем»).

    Атрибуты класса/экземпляра:
        backend  — имя движка (``"chroma"`` / ``"memory"``), для логов и панели;
        degraded — True, если это аварийный fallback (данные не персистентны).
    """

    backend: str = "base"
    degraded: bool = False

    @abc.abstractmethod
    def add(self, id: str, text: str, metadata: dict[str, Any] | None = None) -> str:
        """Добавить/заменить фрагмент (upsert по ``id``), вернуть итоговый id.

        Пустой ``id`` → генерируется автоматически.
        """

    @abc.abstractmethod
    def search(self, query: str, top_k: int = DEFAULT_TOP_K) -> list[str]:
        """Top-k текстов, наиболее похожих на ``query`` (по убыванию релевантности)."""

    @abc.abstractmethod
    def count(self) -> int:
        """Сколько фрагментов хранится."""

    @abc.abstractmethod
    def delete(self, id: str) -> bool:
        """Удалить фрагмент по id (``True`` — если был)."""

    @abc.abstractmethod
    def clear(self) -> int:
        """Удалить все фрагменты, вернуть количество удалённых."""

    def describe(self) -> dict[str, Any]:
        """Статус для панели/логов."""
        return {"backend": self.backend, "degraded": self.degraded, "count": self.count()}

    def close(self) -> None:
        """Освободить ресурсы (по умолчанию — ничего)."""

    def __enter__(self) -> "VectorStore":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()


# ---------------------------------------------------------------------------
# Лёгкая реализация: TF-IDF + косинус (fallback, работает всегда)
# ---------------------------------------------------------------------------
@dataclass
class _Doc:
    """Один индексированный фрагмент."""

    id: str
    text: str
    metadata: dict[str, Any]
    tokens: tuple[str, ...]
    seq: int  # порядок вставки — стабильный тай-брейк при равных скорах
    term_counts: Counter = field(default_factory=Counter)


class InMemoryVectorStore(VectorStore):
    """TF-IDF-поиск на чистом Python: без зависимостей, потокобезопасно.

    Это гарантированный fallback для ``ChromaVectorStore``: работает в песочнице,
    в тестах и везде, где тяжёлые пакеты (chromadb/sentence-transformers)
    недоступны. Ранжирование — косинусное сходство TF-IDF-векторов
    (idf сглаженный, ё↔е/регистр нормализуются).
    """

    backend = "memory"

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._docs: dict[str, _Doc] = {}
        self._df: Counter = Counter()  # document frequency по токенам (по уникальным)
        self._seq = 0

    def _prune_df(self) -> None:
        """Убрать нулевые/отрицательные счётчики document frequency."""
        for tok, n in list(self._df.items()):
            if n <= 0:
                del self._df[tok]

    # -- реализация ---------------------------------------------------
    def add(self, id: str, text: str, metadata: dict[str, Any] | None = None) -> str:
        doc_id = _clean_id(id)
        clean_text = _clean_text(text, max_len=MAX_TEXT_LEN, what="text")
        meta = _clean_metadata(metadata)
        tokens = tuple(_tokenize(clean_text))
        with self._lock:
            old = self._docs.pop(doc_id, None)
            if old is not None:  # upsert: пересчитываем document frequency
                self._df.subtract(set(old.tokens))
                self._prune_df()
            self._seq += 1
            self._docs[doc_id] = _Doc(
                id=doc_id,
                text=clean_text,
                metadata=meta,
                tokens=tokens,
                seq=self._seq,
                term_counts=Counter(tokens),
            )
            self._df.update(set(tokens))
        return doc_id

    def search(self, query: str, top_k: int = DEFAULT_TOP_K) -> list[str]:
        limit = _clean_top_k(top_k)
        if limit == 0:
            return []
        if not isinstance(query, str):
            raise ValueError("query: ожидается str")
        q_tokens = [t for t in _tokenize(query[:MAX_QUERY_LEN]) if self._df.get(t, 0) > 0]
        if not q_tokens:
            return []  # пустой запрос или ни одного известного слова — не ошибка
        with self._lock:
            docs = list(self._docs.values())
            df = self._df.copy()
        n_docs = len(docs)
        if n_docs == 0:
            return []

        def _idf(token: str) -> float:
            return math.log((1.0 + n_docs) / (1.0 + df.get(token, 0))) + 1.0

        q_counts = Counter(q_tokens)
        q_weights = {t: c * _idf(t) for t, c in q_counts.items()}
        q_norm = math.sqrt(sum(w * w for w in q_weights.values())) or 1.0

        hits: list[tuple[float, _Doc]] = []
        for doc in docs:
            if not doc.tokens:
                continue
            d_weights = {t: c * _idf(t) for t, c in doc.term_counts.items()}
            d_norm = math.sqrt(sum(w * w for w in d_weights.values())) or 1.0
            dot = sum(q_weights[t] * d_weights.get(t, 0.0) for t in q_weights)
            score = dot / (q_norm * d_norm)
            if score > 0.0:
                hits.append((score, doc))
        # Релевантность, при равенстве — более свежая вставка (как в store.py)
        hits.sort(key=lambda pair: (pair[0], pair[1].seq), reverse=True)
        return [doc.text for _, doc in hits[:limit]]

    def count(self) -> int:
        with self._lock:
            return len(self._docs)

    def delete(self, id: str) -> bool:
        with self._lock:
            doc = self._docs.pop(id, None)
            if doc is None:
                return False
            self._df.subtract(set(doc.tokens))
            self._prune_df()
            return True

    def clear(self) -> int:
        with self._lock:
            n = len(self._docs)
            self._docs.clear()
            self._df.clear()
        return n


# ---------------------------------------------------------------------------
# ChromaDB реализация
# ---------------------------------------------------------------------------
def _default_embedding_function() -> Any | None:
    """Функция эмбеддингов для Chroma: sentence-transformers если есть, иначе None
    (встроенная функция Chroma). Любая ошибка — просто ``None``, не падаем."""
    try:
        from chromadb.utils import embedding_functions  # type: ignore[import-not-found]

        return embedding_functions.SentenceTransformerEmbeddingFunction()
    except Exception as exc:  # noqa: BLE001 — нет sentence-transformers/модели
        logger.debug("sentence-transformers недоступны (%s), эмбеддинг по умолчанию", exc)
        return None


class ChromaVectorStore(VectorStore):
    """Векторное хранилище на ``chromadb`` (персистентное при ``persist_dir``).

    Конструктор **мягкий**: если ``chromadb`` не установлен или движок не
    поднялся — кидается ``VectorStoreUnavailable``, и ``default_vector_store``
    молча переключается на ``InMemoryVectorStore``. Ошибки времени выполнения
    тоже превращаются в ``VectorStoreUnavailable`` (конвейер RAG не падает).
    """

    backend = "chroma"

    def __init__(
        self,
        persist_dir: str | Path | None = None,
        *,
        collection_name: str = DEFAULT_COLLECTION,
        embedding: Any | None = None,
    ) -> None:
        self._collection: Any | None = None
        self._lock = threading.RLock()
        self.collection_name = collection_name
        try:
            import chromadb  # type: ignore[import-not-found]  # лениво: без пакета — ImportError
        except ImportError as exc:
            raise VectorStoreUnavailable("chromadb не установлен") from exc
        try:
            if persist_dir is not None:
                path = Path(persist_dir)
                path.mkdir(parents=True, exist_ok=True)
                client = chromadb.PersistentClient(path=str(path))
            else:
                client = chromadb.Client()
            ef = embedding if embedding is not None else _default_embedding_function()
            self._client = client
            self._collection = client.get_or_create_collection(
                name=collection_name, embedding_function=ef
            )
            self._collection.count()  # смоук-тест: движок реально жив
        except Exception as exc:  # noqa: BLE001 — любой сбой движка = «недоступно»
            self._collection = None
            raise VectorStoreUnavailable(f"ChromaDB недоступна: {exc}") from exc

    def _require(self) -> Any:
        if self._collection is None:
            raise VectorStoreUnavailable("коллекция ChromaDB не открыта")
        return self._collection

    def _op(self, what: str, fn: Any) -> Any:
        """Обёртка операций: любая ошибка Chroma → типизированный «недоступно»."""
        try:
            with self._lock:
                return fn(self._require())
        except VectorStoreError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise VectorStoreUnavailable(f"ошибка ChromaDB ({what}): {exc}") from exc

    # -- реализация ---------------------------------------------------
    def add(self, id: str, text: str, metadata: dict[str, Any] | None = None) -> str:
        doc_id = _clean_id(id)
        clean_text = _clean_text(text, max_len=MAX_TEXT_LEN, what="text")
        meta = _clean_metadata(metadata)
        self._op(
            "add",
            lambda col: col.upsert(ids=[doc_id], documents=[clean_text], metadatas=[meta]),
        )
        return doc_id

    def search(self, query: str, top_k: int = DEFAULT_TOP_K) -> list[str]:
        limit = _clean_top_k(top_k)
        if limit == 0:
            return []
        if not isinstance(query, str):
            raise ValueError("query: ожидается str")
        clean_query = query.strip()[:MAX_QUERY_LEN]
        if not clean_query:
            return []

        def _query(col: Any) -> list[str]:
            n = max(1, min(limit, int(col.count()) or limit))
            res = col.query(query_texts=[clean_query], n_results=n)
            rows = (res.get("documents") or [[]])[0] or []
            return [str(d) for d in rows if d]

        return self._op("search", _query)[:limit]

    def count(self) -> int:
        return int(self._op("count", lambda col: col.count()))

    def delete(self, id: str) -> bool:
        def _delete(col: Any) -> bool:
            existing = (col.get(ids=[id], include=[]) or {}).get("ids") or []
            if not existing:
                return False
            col.delete(ids=[id])
            return True

        return bool(self._op("delete", _delete))

    def clear(self) -> int:
        def _clear(col: Any) -> int:
            total = int(col.count())
            ids = (col.get(include=[]) or {}).get("ids") or []
            for i in range(0, len(ids), 1000):
                col.delete(ids=list(ids[i : i + 1000]))
            return total

        return int(self._op("clear", _clear))

    def close(self) -> None:
        with self._lock:
            self._collection = None


# ---------------------------------------------------------------------------
# Фабрика «локально-first»
# ---------------------------------------------------------------------------
def default_vector_store(
    persist_dir: str | Path | None = None,
    *,
    collection_name: str = DEFAULT_COLLECTION,
    embedding: Any | None = None,
    prefer_chroma: bool = True,
) -> VectorStore:
    """Создать векторное хранилище: пробуем ChromaDB, при сбое — TF-IDF в памяти.

    Мягкий fallback (по ТЗ): отсутствующий ``chromadb``/``sentence-transformers``,
    сломанный движок, диск/права — **не роняют** вызывающий код, мы молча
    деградируем на лёгкий поиск (``degraded=True``). ``prefer_chroma=False`` —
    осознанный выбор in-memory реализации (без признака деградации).
    """
    if prefer_chroma:
        try:
            return ChromaVectorStore(
                persist_dir,
                collection_name=collection_name,
                embedding=embedding,
            )
        except VectorStoreUnavailable as exc:
            logger.warning("ChromaDB недоступна (%s), деградация на TF-IDF в памяти", exc)
    store = InMemoryVectorStore()
    store.degraded = prefer_chroma  # True только если это аварийный fallback
    return store
