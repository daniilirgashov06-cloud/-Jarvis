/**
 * Типы протокола панели JARVIS CORE (REST + WebSocket).
 *
 * Соответствует `ui_server/app.py`:
 *   REST: GET /api/status, GET /api/history, POST /api/text
 *   WS:   {"type": "text"|"ping"|"status"|"subscribe"} -> клиент
 *         {"type": "status"|"event"|"reply"|"pong"|"subscribed"|"error"} <- сервер
 */

/** Состояние пайплайна: idle | listening | thinking | speaking. */
export type PipelineState = "idle" | "listening" | "thinking" | "speaking" | (string & {});

export interface StatusSnapshot {
  state: PipelineState;
  theme: string;
  accent_color: string;
  uptime_s: number;
  counters: {
    events: number;
    commands: number;
    errors: number;
  };
  history_size: number;
  last_reply: string;
  /** Число подключённых WS-клиентов (есть в снимке с сервера). */
  clients?: number;
  /** Подключён ли оркестратор ядра. */
  orchestrator?: boolean;
}

/** Событие шины (лента панели). */
export interface BusEvent {
  ts: number;
  topic: string;
  payload: Record<string, unknown>;
}

/** Одно действие из ответа оркестратора. */
export interface ActionResult {
  name: string;
  ok: boolean;
  output?: unknown;
  error?: string | null;
}

/** Ответ оркестратора на текстовую команду. */
export interface CommandReply {
  ok: boolean;
  text: string;
  error?: string | null;
  actions: ActionResult[];
  provider: string;
  tts: string;
}

/** Кадры сервер -> клиент. */
export type ServerFrame =
  | { type: "status"; state: StatusSnapshot }
  | { type: "event"; topic: string; payload: Record<string, unknown> }
  | ({ type: "reply" } & CommandReply)
  | { type: "pong"; ts: number }
  | { type: "subscribed"; topics: string[] }
  | { type: "error"; message: string };

/** Кадры клиент -> сервер. */
export type ClientFrame =
  | { type: "text"; text: string }
  | { type: "ping" }
  | { type: "status" }
  | { type: "subscribe"; topics: string[] };

/** Состояние WS-соединения панели. */
export type ConnectionState = "connecting" | "online" | "offline";
