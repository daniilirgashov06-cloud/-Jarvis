"""
Проверка модуля audio/capture: конфиг кадров, источники, кольцевой буфер,
запись (record / record_until), async-поток, WAV-хелперы.

Запуск:  python3 tests/test_audio_capture.py
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from audio.capture import (
    AudioCapture,
    AudioFrame,
    AudioSource,
    CaptureConfig,
    CaptureEOF,
    CaptureError,
    CaptureUnavailable,
    MicrophoneSource,
    RingBuffer,
    WavFileSource,
    pcm_to_wav,
    wav_header_size,
    wav_to_pcm,
)


# ---------------------------------------------------------------------------
# Мок-источник (синтезирует кадры без железа)
# ---------------------------------------------------------------------------
class FakeSource(AudioSource):
    """Источник-заглушка: выдаёт кадры с заданным паттерном."""

    name = "fake"
    blocking = False

    def __init__(self, frames: list[bytes], config: CaptureConfig | None = None,
                 available: bool = True, fail_open: bool = False, loop: bool = False):
        super().__init__(config)
        self._template = list(frames)
        self.frames = list(frames)
        self.available = available
        self.fail_open = fail_open
        self.loop = loop
        self.opened = False
        self.reads = 0

    def is_available(self) -> bool:
        return self.available

    def open(self) -> None:
        if self.fail_open:
            raise CaptureUnavailable("fake: устройство недоступно")
        self.opened = True

    def close(self) -> None:
        self.opened = False

    def read_frame(self) -> AudioFrame:
        self.reads += 1
        if not self.frames:
            if not self.loop or not self._template:
                raise CaptureEOF("fake: кадры кончились")
            self.frames = list(self._template)
        return AudioFrame(pcm=self.frames.pop(0), sample_rate=self.config.sample_rate)


def make_frames(n: int, config: CaptureConfig, tag: int = 7) -> list[bytes]:
    """Кадры с узнаваемым паттерном (байт = номер кадра)."""
    return [bytes([tag]) * config.frame_bytes for _ in range(n)]


# ---------------------------------------------------------------------------
# Тесты
# ---------------------------------------------------------------------------
def test_capture_config_geometry() -> None:
    cfg = CaptureConfig()
    assert cfg.sample_rate == 16000 and cfg.channels == 1 and cfg.frame_ms == 20
    assert cfg.frame_samples == 320, "20 мс @ 16 кГц = 320 сэмпла"
    assert cfg.frame_bytes == 640, "320 сэмплов × 2 байта = 640 байт на кадр"
    assert cfg.seconds_to_bytes(1.0) == 32000
    assert abs(cfg.bytes_to_seconds(32000) - 1.0) < 1e-9
    print("  ✓ capture_config: 16 кГц / моно / 20 мс / 640 байт на кадр")


def test_record_fixed_duration() -> None:
    cfg = CaptureConfig()
    src = FakeSource(make_frames(10, cfg, tag=1), cfg)
    cap = AudioCapture(src, ring_seconds=1.0)
    with cap:
        pcm = cap.record(0.1)  # 5 кадров
    assert len(pcm) == cfg.seconds_to_bytes(0.1), f"ожидали 3200 байт, получили {len(pcm)}"
    assert src.reads == 5, "ровно 5 кадров по 20 мс"
    assert src.opened is False, "close() должен закрыть источник"
    print("  ✓ record: 0.1 с = 5 кадров = 3200 байт, источник открыт/закрыт")


def test_record_exact_and_overflow_trim() -> None:
    cfg = CaptureConfig()
    src = FakeSource(make_frames(4, cfg, tag=2), cfg)
    cap = AudioCapture(src, ring_seconds=0.04)  # ёмкость = 2 кадра
    with cap:
        for _ in range(4):
            cap.read_frame()
        recent = cap.recent(1.0)  # просим больше, чем есть в буфере
    assert len(recent) == cfg.seconds_to_bytes(0.04), "кольцевой буфер хранит только ёмкость"
    assert len(cap._ring) == cfg.seconds_to_bytes(0.04), "старые кадры вытеснены"
    print("  ✓ ring_buffer: переполнение обрезает старые кадры, recent() отдаёт хвост")


def test_record_until_condition_and_timeout() -> None:
    cfg = CaptureConfig()
    frames = make_frames(3, cfg, tag=3) + [b"\xff" * cfg.frame_bytes] + make_frames(2, cfg, tag=4)
    src = FakeSource(frames, cfg)
    cap = AudioCapture(src)

    def marker(frame: AudioFrame) -> bool:
        return frame.pcm[0] == 0xFF

    with cap:
        pcm = cap.record_until(marker, timeout=5.0)
    assert len(pcm) == 4 * cfg.frame_bytes, "запись останавливается на кадре-маркере (включая его)"

    # таймаут: условие никогда не выполнится (источник бесконечный)
    src2 = FakeSource(make_frames(3, cfg, tag=5), cfg, loop=True)
    cap2 = AudioCapture(src2)
    with cap2:
        try:
            cap2.record_until(lambda f: False, timeout=0.05, max_seconds=10_000.0)
            assert False, "должен быть CaptureError по таймауту"
        except CaptureError as exc:
            assert "таймаут" in str(exc)
    print("  ✓ record_until: стоп-условие работает + таймаут даёт CaptureError")


def test_stream_async_and_blocking_flag() -> None:
    cfg = CaptureConfig()
    src = FakeSource(make_frames(3, cfg, tag=6), cfg)
    cap = AudioCapture(src)

    async def collect() -> int:
        got = 0
        async for frame in cap.stream(max_frames=3):
            got += 1
            assert len(frame.pcm) == cfg.frame_bytes
        return got

    n = asyncio.run(collect())
    assert n == 3, "async-поток отдал все 3 кадра"
    assert cap.frames_read == 3
    print("  ✓ stream: async-генератор отдаёт кадры, счётчик frames_read работает")


def test_source_errors() -> None:
    cfg = CaptureConfig()
    # источник недоступен при открытии
    cap = AudioCapture(FakeSource([], cfg, fail_open=True))
    try:
        cap.open()
        assert False, "ожидали CaptureUnavailable"
    except CaptureUnavailable:
        pass
    # конец файла
    cap2 = AudioCapture(FakeSource([], cfg))
    cap2.open()
    try:
        cap2.read_frame()
        assert False, "ожидали CaptureEOF"
    except CaptureEOF:
        pass
    # пустая запись — ошибка
    try:
        AudioCapture(FakeSource([], cfg)).record(0)
        assert False, "ожидали CaptureError"
    except CaptureError:
        pass
    print("  ✓ errors: CaptureUnavailable / CaptureEOF / CaptureError на своих местах")


def test_wav_roundtrip() -> None:
    cfg = CaptureConfig()
    pcm = bytes(range(256)) * 16  # 4096 байт
    wav = pcm_to_wav(pcm, cfg)
    assert wav_header_size() == 44
    assert wav[:4] == b"RIFF" and wav[8:12] == b"WAVE"
    out, cfg2 = wav_to_pcm(wav)
    assert out == pcm and cfg2.sample_rate == 16000 and cfg2.channels == 1

    # чтение через WavFileSource из памяти + loop
    src = WavFileSource(data=wav, config=cfg, loop=True)
    cap = AudioCapture(src)
    with cap:
        chunk = cap.record(0.05)  # 1600 байт (2.5 кадра)
    assert len(chunk) == cfg.seconds_to_bytes(0.05), "loop-источник не заканчивается"
    assert cap.frames_read == 3, "2 полных кадра + 1 недокачанный (loop)"

    # без loop — исчерпание
    src2 = WavFileSource(data=wav, config=cfg)
    cap2 = AudioCapture(src2)
    with cap2:
        try:
            cap2.record(10.0)
            assert False, "ожидали CaptureEOF"
        except CaptureEOF:
            pass

    # WAV с неверной геометрией — ошибка
    bad = pcm_to_wav(pcm, CaptureConfig(channels=2))
    src3 = WavFileSource(data=bad, config=cfg)
    try:
        src3.open()
        assert False, "ожидали CaptureError для WAV с 2 каналами"
    except CaptureError:
        pass
    print("  ✓ wav: pcm↔wav конвертация, loop-чтение, EOF и проверка геометрии")


def test_microphone_source_describe() -> None:
    mic = MicrophoneSource()
    info = mic.describe()
    assert info["name"] == "microphone" and info["sample_rate"] == 16000
    assert isinstance(info["available"], bool), "is_available не должен падать без sounddevice"
    if not mic.is_available():
        try:
            mic.open()
            assert False, "ожидали CaptureUnavailable без sounddevice"
        except CaptureUnavailable:
            pass
    print("  ✓ microphone: describe() работает, недоступность = CaptureUnavailable")


# ---------------------------------------------------------------------------
def main() -> int:
    print("JARVIS CORE — проверка audio/capture")
    try:
        test_capture_config_geometry()
        test_record_fixed_duration()
        test_record_exact_and_overflow_trim()
        test_record_until_condition_and_timeout()
        test_stream_async_and_blocking_flag()
        test_source_errors()
        test_wav_roundtrip()
        test_microphone_source_describe()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модуля прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
