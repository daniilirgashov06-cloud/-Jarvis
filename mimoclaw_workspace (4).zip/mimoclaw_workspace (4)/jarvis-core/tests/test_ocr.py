"""
Проверка vision/ocr.py (OCR экрана).

Запуск:  python3 tests/test_ocr.py
"""

from __future__ import annotations

import json
import os
import stat
import sys
import tempfile
import urllib.error
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from vision.ocr import (
    HttpOCREngine,
    OCRBox,
    OCREngine,
    OCRError,
    OCRImage,
    OCRResult,
    OCRUnavailable,
    OCRRouter,
    ScreenOCR,
    SyntheticOCREngine,
    TesseractEngine,
    default_ocr_router,
    normalize_text,
    parse_tsv,
)

SAMPLE_TSV = (
    "level\tpage_num\tblock_num\tpar_num\tline_num\tword_num\tleft\ttop\twidth\theight\tconf\ttext\n"
    "1\t1\t0\t0\t0\t0\t0\t0\t640\t480\t-1\t\n"
    "5\t1\t1\t1\t1\t1\t10\t20\t60\t24\t95.5\tПривет\n"
    "5\t1\t1\t1\t1\t2\t80\t20\t50\t24\t88.0\tмир\n"
    "5\t1\t1\t1\t1\t3\t140\t20\t30\t24\t-1\t\n"      # не слово (conf < 0)
    "5\t1\t1\t1\t1\t4\t180\t20\t30\t24\t70.0\t  \n"  # пустой текст
    "5\t1\t1\t1\t1\t5\t220\t20\tXX\t24\t70.0\tбитый\n"  # битая геометрия
    "5\t1\t1\t1\t1\t6\t220\t60\t40\t24\t99.0\tJARVIS\n"
)


# ---------------------------------------------------------------------------
# Растр: валидация и предобработка
# ---------------------------------------------------------------------------
def test_image_validation_and_preprocess() -> None:
    img = OCRImage(2, 2, bytes([0, 128, 255, 64]), "L")
    assert img.channels == 1
    # RGB → серый (луминансность)
    rgb = OCRImage(1, 1, bytes([255, 0, 0]), "RGB")
    gray = rgb.to_gray()
    assert gray.mode == "L" and gray.data == bytes([76])  # 299*255//1000
    # бинаризация: < порога → 0, иначе 255
    assert img.binarize(100).data == bytes([0, 255, 255, 0])
    # инверсия
    assert img.invert().data == bytes([255, 127, 0, 191])
    # масштабирование ближайшим соседом
    big = img.scale(2.0)
    assert (big.width, big.height) == (4, 4)
    assert big.data[0] == 0 and big.data[15] == 64
    assert img.scale(1.0) is img
    # PNG: сигнатура + IHDR
    png = img.to_png()
    assert png.startswith(b"\x89PNG\r\n\x1a\n") and b"IHDR" in png[:30]
    # невалидные растрЫ отклоняются
    for bad in [
        (0, 1, b"", "L"),
        (1, 1, b"\x00\x00", "L"),
        (1, 1, b"\x00", "RGB"),
        (1, 1, b"\x00", "X"),
        (1, 1, "bytes", "L"),
        (100_000, 100_000, b"", "L"),  # память-бомба
    ]:
        try:
            OCRImage(*bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"растр {bad!r} должен быть отклонён")
    for bad_step in [100.0, 300, "x", True]:
        try:
            img.binarize(bad_step)  # type: ignore[arg-type]
        except ValueError:
            pass
        else:
            raise AssertionError(f"binarize({bad_step!r}) должен быть отклонён")
    for bad_step in ["scale:abc", "scale:9", "blur", 5]:
        try:
            ScreenOCR(OCRRouter(), preprocess=[bad_step])  # type: ignore[list-item]
        except ValueError:
            pass
        else:
            raise AssertionError(f"шаг {bad_step!r} должен быть отклонён")
    print("  ✓ image: валидация, gray/binary/invert/scale, PNG")


# ---------------------------------------------------------------------------
# TSV tesseract
# ---------------------------------------------------------------------------
def test_tsv_parsing() -> None:
    boxes = parse_tsv(SAMPLE_TSV)
    # валидные слова: Привет, мир, JARVIS (битая строка и conf<0 и пустые — в мусор)
    assert [b.text for b in boxes] == ["Привет", "мир", "JARVIS"]
    first = boxes[0]
    assert (first.x, first.y, first.width, first.height) == (10, 20, 60, 24)
    assert abs(first.confidence - 95.5) < 1e-6
    # порог уверенности
    assert [b.text for b in parse_tsv(SAMPLE_TSV, min_confidence=90.0)] == ["Привет", "JARVIS"]
    # пустой/мусорный ввод
    assert parse_tsv("") == ()
    assert parse_tsv("a\tb\nмусор") == ()
    for bad in [None, 5]:
        try:
            parse_tsv(bad)  # type: ignore[arg-type]
        except ValueError:
            pass
        else:
            raise AssertionError(f"вход {bad!r} должен быть отклонён")
    try:
        parse_tsv(SAMPLE_TSV, min_confidence=150.0)
    except ValueError:
        pass
    else:
        raise AssertionError("min_confidence=150 должен быть отклонён")
    print("  ✓ tsv: слова/боксы/уверенность, порог, мусор")


# ---------------------------------------------------------------------------
# Результат и поиск
# ---------------------------------------------------------------------------
def test_result_search() -> None:
    assert normalize_text("  Ёлка   GREEN ") == "елка green"
    try:
        normalize_text(5)  # type: ignore[arg-type]
    except ValueError:
        pass
    else:
        raise AssertionError("normalize_text(5) должен быть отклонён")
    for bad in [
        dict(text=5, x=0, y=0, width=1, height=1),
        dict(text="a", x=0, y=0, width=-1, height=1),
        dict(text="a", x=True, y=0, width=1, height=1),
        dict(text="a", x=0, y=0, width=1, height=1, confidence=120),
    ]:
        try:
            OCRBox(**bad)  # type: ignore[arg-type]
        except ValueError:
            pass
        else:
            raise AssertionError(f"OCRBox {bad!r} должен быть отклонён")
    boxes = (
        OCRBox("Пуск", 0, 0, 10, 10, 100.0),
        OCRBox("пуск", 20, 0, 10, 10, 50.0),
    )
    res = OCRResult(text="Пуск\nпуск", boxes=boxes, engine="synthetic")
    assert abs(res.confidence - 75.0) < 1e-6  # среднее по длине слов
    assert len(res.find("ПУСК")) == 2 and res.find("  ") == []
    assert res.contains("пус к") is False and res.contains("Пуск") is True
    assert OCRResult(text="   ").is_empty
    assert not res.is_empty
    try:
        OCRResult(text="x" * 300_000)
    except ValueError:
        pass
    else:
        raise AssertionError("слишком длинный текст должен быть отклонён")
    print("  ✓ result: normalize/find/contains, взвешенная уверенность")


# ---------------------------------------------------------------------------
# Синтетика + роутер
# ---------------------------------------------------------------------------
def test_synthetic_and_router() -> None:
    def provider(image: OCRImage) -> OCRResult:
        return OCRResult(text="синтетика", boxes=(OCRBox("синтетика", 0, 0, 5, 5, 90.0),))

    syn = SyntheticOCREngine(provider)
    assert syn.is_available()
    res = syn.recognize(OCRImage(1, 1, b"\x00"))
    assert res.text == "синтетика" and res.confidence == 90.0
    # пустой провайдер по умолчанию → пустой результат (без падений)
    assert SyntheticOCREngine().recognize(OCRImage(1, 1, b"\x00")).is_empty
    # битый провайдер → OCRError
    try:
        SyntheticOCREngine(lambda img: "не результат").recognize(OCRImage(1, 1, b"\x00"))
    except OCRError:
        pass
    else:
        raise AssertionError("битый провайдер должен давать OCRError")

    class FailEngine(OCREngine):
        name = "fail"

        def is_available(self) -> bool:
            return True

        def recognize(self, image: OCRImage, *, lang: str = "rus+eng") -> OCRResult:
            raise OCRError("движок сломан")

    router = OCRRouter(
        {"fail": FailEngine(), "syn": syn, "off": SyntheticOCREngine(available=False)},
        primary="fail",
        fallback_chain=["fail", "off", "syn"],
    )
    # fail падает, off недоступен → срабатывает syn
    assert router.recognize(OCRImage(1, 1, b"\x00")).text == "синтетика"
    assert router.available() == ["fail", "syn"]
    router.set_primary("syn")
    assert router.primary == "syn"
    try:
        router.set_primary("нет-такого")
    except OCRError:
        pass
    else:
        raise AssertionError("set_primary с неизвестным именем должен падать")
    # все отказали → OCRError с последней ошибкой
    dead = OCRRouter({"fail": FailEngine()}, primary="fail", fallback_chain=["fail"])
    try:
        dead.recognize(OCRImage(1, 1, b"\x00"))
    except OCRError as exc:
        assert "сломан" in str(exc)
    else:
        raise AssertionError("полный отказ должен давать OCRError")
    # явный движок без fallback
    try:
        router.recognize(OCRImage(1, 1, b"\x00"), engine="fail")
    except OCRError:
        pass
    else:
        raise AssertionError("явный fail-движок должен падать без fallback")
    assert router.describe()["primary"] == "syn"
    print("  ✓ router: fallback-цепочка, смена движка, деградация")


# ---------------------------------------------------------------------------
# Tesseract: валидация + subprocess через фейковый бинарник
# ---------------------------------------------------------------------------
def _fake_tesseract(dirname: str, body: str, *, name: str = "tesseract") -> str:
    """Создаёт исполняемый скрипт-заменитель tesseract в каталоге dirname."""
    path = os.path.join(dirname, name)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("#!/usr/bin/env python3\n")
        fh.write("import sys\n")
        fh.write("sys.stdin.buffer.read()\n")
        fh.write(body)
    os.chmod(path, os.stat(path).st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return path


def test_tesseract_engine() -> None:
    # валидация параметров
    for kwargs in [dict(psm=7), dict(timeout=0), dict(timeout=120), dict(min_confidence=200), dict(binary="")]:
        try:
            TesseractEngine(**kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError(f"TesseractEngine {kwargs!r} должен быть отклонён")
    # недоступный бинарник
    missing = TesseractEngine("/nonexistent/tesseract")
    assert not missing.is_available()
    try:
        missing.recognize(OCRImage(1, 1, b"\x00"))
    except OCRUnavailable:
        pass
    else:
        raise AssertionError("отсутствующий бинарник должен давать OCRUnavailable")

    with tempfile.TemporaryDirectory() as tmp:
        # штатный сценарий: TSV из stdout
        ok = _fake_tesseract(
            tmp,
            "print('level\\tpage_num\\tblock_num\\tpar_num\\tline_num\\tword_num\\tleft\\ttop\\twidth\\theight\\tconf\\ttext')\n"
            "print('5\\t1\\t1\\t1\\t1\\t1\\t3\\t4\\t10\\t12\\t91.0\\tJARVIS')\n",
        )
        engine = TesseractEngine(ok, min_confidence=50.0)
        assert engine.is_available()
        result = engine.recognize(OCRImage(2, 2, b"\x00\x40\x80\xff", "L"))
        assert result.text == "JARVIS" and result.engine == "tesseract"
        assert result.boxes[0].x == 3 and result.confidence == 91.0
        assert engine.describe()["psm"] == 3
        # ошибка движка (exit 1) → OCRError с stderr
        boom = _fake_tesseract(tmp, "import sys\nsys.stderr.write('нет словаря')\nsys.exit(1)\n", name="boom")
        try:
            TesseractEngine(boom).recognize(OCRImage(1, 1, b"\x00"))
        except OCRError as exc:
            assert "нет словаря" in str(exc)
        else:
            raise AssertionError("exit 1 должен давать OCRError")
        # таймаут → OCRError
        slow = _fake_tesseract(tmp, "import time\ntime.sleep(3)\n", name="slow")
        try:
            TesseractEngine(slow, timeout=0.3).recognize(OCRImage(1, 1, b"\x00"))
        except OCRError as exc:
            assert "не уложился" in str(exc)
        else:
            raise AssertionError("таймаут должен давать OCRError")
        # недопустимый язык → OCRError
        try:
            engine.recognize(OCRImage(1, 1, b"\x00"), lang="rus; rm -rf /")
        except OCRError:
            pass
        else:
            raise AssertionError("инъекция языка должна быть отклонена")
    print("  ✓ tesseract: валидация, subprocess/TSV, ошибки и таймаут")


# ---------------------------------------------------------------------------
# Облако: HttpOCREngine с фейковым opener
# ---------------------------------------------------------------------------
class _FakeResponse:
    def __init__(self, raw: bytes) -> None:
        self._raw = raw

    def read(self, n: int = -1) -> bytes:
        return self._raw if n < 0 else self._raw[:n]

    def __enter__(self) -> "_FakeResponse":
        return self

    def __exit__(self, *exc: object) -> None:
        return None


def test_http_engine() -> None:
    # валидация
    for kwargs in [
        dict(endpoint="ftp://x"),
        dict(endpoint=""),
        dict(endpoint="https://x", timeout=0),
        dict(endpoint="https://x", api_key_env=""),
    ]:
        try:
            HttpOCREngine(**kwargs)  # type: ignore[arg-type]
        except ValueError:
            pass
        else:
            raise AssertionError(f"HttpOCREngine {kwargs!r} должен быть отклонён")

    captured: dict[str, object] = {}

    def opener(request: object, timeout: float = 0) -> _FakeResponse:
        captured["request"] = request
        captured["timeout"] = timeout
        doc = {
            "text": "Настройки",
            "blocks": [
                {"text": "Настройки", "confidence": 93.0, "x": 5, "y": 6, "width": 7, "height": 8},
                {"text": "  ", "confidence": 10.0},
            ],
        }
        return _FakeResponse(json.dumps(doc).encode("utf-8"))

    old_key = os.environ.pop("JARVIS_OCR_API_KEY", None)
    try:
        engine = HttpOCREngine("https://ocr.example/api", opener=opener)
        assert engine.is_available()
        result = engine.recognize(OCRImage(1, 1, b"\xff", "L"), lang="rus")
        assert result.text == "Настройки" and result.engine == "http"
        assert result.boxes[0].confidence == 93.0 and len(result.boxes) == 1
        request = captured["request"]
        assert request.full_url == "https://ocr.example/api"  # type: ignore[attr-defined]
        assert request.get_header("Content-type") == "application/json"  # type: ignore[attr-defined]
        payload = json.loads(request.data.decode("utf-8"))  # type: ignore[attr-defined]
        assert payload["lang"] == "rus"
        assert payload["image"]  # base64 PNG
        # без текста — собираем из блоков
        os.environ["JARVIS_OCR_API_KEY"] = "secret-key"

        def opener_blocks(request: object, timeout: float = 0) -> _FakeResponse:
            captured["request2"] = request
            return _FakeResponse(
                json.dumps({"blocks": [{"text": "ОК", "confidence": 80.0}]}).encode("utf-8")
            )

        engine2 = HttpOCREngine("https://ocr.example/api", opener=opener_blocks)
        assert engine2.recognize(OCRImage(1, 1, b"\x00")).text == "ОК"
        # ключ ушёл в заголовок (и не в логи/URL)
        request2 = captured["request2"]
        assert request2.get_header("Authorization") == "Bearer secret-key"  # type: ignore[attr-defined]
    finally:
        if old_key is not None:
            os.environ["JARVIS_OCR_API_KEY"] = old_key
        else:
            os.environ.pop("JARVIS_OCR_API_KEY", None)

    # не-JSON ответ → OCRError
    def opener_html(request: object, timeout: float = 0) -> _FakeResponse:
        return _FakeResponse(b"<html>502</html>")

    try:
        HttpOCREngine("https://ocr.example/api", opener=opener_html).recognize(
            OCRImage(1, 1, b"\x00")
        )
    except OCRError:
        pass
    else:
        raise AssertionError("не-JSON ответ должен давать OCRError")

    # сеть недоступна → OCRUnavailable (fallback)
    def opener_dead(request: object, timeout: float = 0) -> _FakeResponse:
        raise urllib.error.URLError("нет сети")

    try:
        HttpOCREngine("https://ocr.example/api", opener=opener_dead).recognize(
            OCRImage(1, 1, b"\x00")
        )
    except OCRUnavailable:
        pass
    else:
        raise AssertionError("URLError должен давать OCRUnavailable")

    # битый блок в ответе → OCRError
    def opener_bad_block(request: object, timeout: float = 0) -> _FakeResponse:
        return _FakeResponse(json.dumps({"blocks": [{"text": "x", "confidence": "много"}]}).encode())

    try:
        HttpOCREngine("https://ocr.example/api", opener=opener_bad_block).recognize(
            OCRImage(1, 1, b"\x00")
        )
    except OCRError:
        pass
    else:
        raise AssertionError("битый блок должен давать OCRError")
    print("  ✓ http: запрос/заголовки/JSON, ошибки сети и формата")


# ---------------------------------------------------------------------------
# Фасад ScreenOCR + сборка по умолчанию
# ---------------------------------------------------------------------------
def test_screen_ocr_facade() -> None:
    def provider(image: OCRImage) -> OCRResult:
        return OCRResult(text="ПУСК", boxes=(OCRBox("ПУСК", 1, 2, 3, 4, 80.0),))

    router = OCRRouter({"syn": SyntheticOCREngine(provider)}, primary="syn")
    ocr = ScreenOCR(router, preprocess=("gray", "binary", "scale:2.0"))
    img = OCRImage(1, 1, b"\x80", "L")
    assert ocr.prepare(img).width == 2  # масштаб применён
    result = ocr.recognize(img)
    assert result.text == "ПУСК"
    assert ocr.read_text(img) == "ПУСК"
    hits = ocr.find_text(img, "пуск")
    assert len(hits) == 1 and hits[0].x == 1
    info = ocr.describe()
    assert info["preprocess"] == ["gray", "binary", "scale:2.0"]
    # неверный router/шаги отклоняются
    try:
        ScreenOCR("router")  # type: ignore[arg-type]
    except TypeError:
        pass
    else:
        raise AssertionError("не-router должен быть отклонён")
    try:
        ScreenOCR(router, preprocess="gray")  # type: ignore[arg-type]
    except ValueError:
        pass
    else:
        raise AssertionError("строка вместо списка шагов должна быть отклонена")
    # сборка по умолчанию: локально-first, синтетика — страховка
    d1 = default_ocr_router()
    assert d1.describe()["primary"] == "tesseract"
    assert "synthetic" in d1.describe()["engines"]
    assert isinstance(d1.recognize(img), OCRResult)  # падений нет ни при каком окружении
    d2 = default_ocr_router(cloud_endpoint="https://ocr.example/api")
    assert set(d2.describe()["engines"]) == {"tesseract", "http", "synthetic"}
    # детерминированная проверка fallback: локальный и облако отказали → синтетика
    def opener_dead(request: object, timeout: float = 0) -> _FakeResponse:
        raise urllib.error.URLError("нет сети")

    dead_chain = OCRRouter(
        {
            "tesseract": TesseractEngine("/nonexistent/tesseract"),
            "http": HttpOCREngine("https://ocr.example/api", opener=opener_dead),
            "synthetic": SyntheticOCREngine(),
        },
        primary="tesseract",
        fallback_chain=["tesseract", "http", "synthetic"],
    )
    assert dead_chain.recognize(img).engine == "synthetic"
    print("  ✓ facade: предобработка, recognize/read_text/find_text, default_ocr_router")


def main() -> int:
    print("JARVIS CORE — проверка vision/ocr")
    try:
        test_image_validation_and_preprocess()
        test_tsv_parsing()
        test_result_search()
        test_synthetic_and_router()
        test_tesseract_engine()
        test_http_engine()
        test_screen_ocr_facade()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки vision/ocr прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
