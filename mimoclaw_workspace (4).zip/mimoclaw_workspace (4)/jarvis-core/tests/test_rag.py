"""
Проверка memory/rag.py — адаптер памяти для ai/context_builder (RAG top-8):
контракт MemorySearch, гибрид «факты + семантика», дедуп, мягкая деградация
при сломанных источниках, интеграция с ContextBuilder.

Без тяжёлых зависимостей (chromadb/sentence-transformers не нужны) — всё
работает в песочнице на in-memory реализациях.

Запуск:  python3 tests/test_rag.py
Или:     pytest tests/test_rag.py -q
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ai.context_builder import ContextBuilder
from ai.personas import JARVIS
from memory.rag import (
    DEFAULT_RAG_TOP_K,
    MAX_RESULT_CHARS,
    MemorySearch,
    RagMemory,
    default_rag,
    format_record,
)
from memory.store import InMemoryMemoryStore, MemoryKind, MemoryRecord
from memory.vector_store import InMemoryVectorStore, MAX_TOP_K, VectorStore

RAG_MARKER = "Релевантные воспоминания:\n"


# ---------------------------------------------------------------------------
# Сломанные источники (эмуляция недоступной подсистемы)
# ---------------------------------------------------------------------------
class BrokenVectors(InMemoryVectorStore):
    """Векторный индекс, который падает на каждом обращении."""

    def add(self, id, text, metadata=None):  # type: ignore[no-untyped-def]
        raise RuntimeError("векторный индекс недоступен")

    def search(self, query, top_k=8):  # type: ignore[no-untyped-def]
        raise RuntimeError("векторный индекс недоступен")

    def count(self) -> int:
        raise RuntimeError("векторный индекс недоступен")

    def delete(self, id) -> bool:  # type: ignore[no-untyped-def]
        raise RuntimeError("векторный индекс недоступен")

    def clear(self) -> int:
        raise RuntimeError("векторный индекс недоступен")


class BrokenFacts(InMemoryMemoryStore):
    """Хранилище фактов, которое падает при поиске."""

    def search(self, query, **kwargs):  # type: ignore[no-untyped-def]
        raise RuntimeError("хранилище фактов недоступно")


class SpyMemory:
    """Шпион: записывает, с каким top_k вызвали поиск (контракт контекста)."""

    def __init__(self) -> None:
        self.calls: list[tuple[str, int]] = []

    def search(self, query: str, top_k: int) -> list[str]:
        self.calls.append((query, top_k))
        return ["воспоминание-шпион"]


class BrokenSearch:
    """Память, падающая при поиске — для проверки «не роняет сборку контекста»."""

    def search(self, query: str, top_k: int) -> list[str]:
        raise RuntimeError("память полностью недоступна")


# ---------------------------------------------------------------------------
# Контракт MemorySearch (совместим с ai.context_builder)
# ---------------------------------------------------------------------------
def test_memory_search_contract() -> None:
    rag = RagMemory(vectors=InMemoryVectorStore())
    assert isinstance(rag, MemorySearch), "RagMemory реализует контракт MemorySearch"
    assert isinstance(InMemoryVectorStore(), MemorySearch), "VectorStore тоже подходит в ContextBuilder"
    assert DEFAULT_RAG_TOP_K == 8, "top-8 по умолчанию (ТЗ)"
    rag.remember("памятка про чай")
    hits = rag.search("чай")
    assert isinstance(hits, list) and all(isinstance(h, str) for h in hits), "search -> list[str]"
    assert hits == ["памятка про чай"]
    print("  ✓ rag: контракт MemorySearch(search(query, top_k) -> list[str]) соблюдён")


def test_top_k_default_and_clamp() -> None:
    rag = RagMemory(vectors=InMemoryVectorStore())
    for i in range(12):
        rag.remember(f"памятка номер {i} про память")
    assert len(rag.search("память")) == 8, "без top_k — ровно top-8"
    assert len(rag.search("память", 3)) == 3
    assert rag.search("память", 0) == []
    assert len(rag.search("память", 100)) == 12, "top_k больше числа записей — просто все"
    assert rag.search("память", "пять") == [], "некорректный top_k — мягко [], не падение"
    assert rag.search("") == [], "пустой запрос — []"
    for i in range(12, 80):
        rag.remember(f"памятка номер {i} про память")
    assert len(rag.search("память", 100)) == MAX_TOP_K, f"жёсткий потолок MAX_TOP_K={MAX_TOP_K}"
    print("  ✓ rag: top-8 по умолчанию, зажим top_k, мягкая обработка ошибок")


def test_long_result_truncated() -> None:
    rag = RagMemory(vectors=InMemoryVectorStore())
    rag.remember("тирада " * 300)
    hits = rag.search("тирада")
    assert len(hits) == 1
    assert len(hits[0]) <= MAX_RESULT_CHARS, f"усечение до {MAX_RESULT_CHARS}: {len(hits[0])}"
    assert hits[0].endswith("…")
    print("  ✓ rag: длинные воспоминания усекаются по границе слова")


# ---------------------------------------------------------------------------
# Гибрид: факты (MemoryStore) + семантика (VectorStore)
# ---------------------------------------------------------------------------
def test_hybrid_facts_and_vectors() -> None:
    facts = InMemoryMemoryStore()
    facts.add(MemoryRecord(kind=MemoryKind.FACT, content="пользователь любит чай без сахара"))
    rag = RagMemory(vectors=InMemoryVectorStore(), facts=facts)
    rag.remember("сэр включил тёмную тему в редакторе")

    fact_hits = rag.search("чай")
    assert fact_hits == ["[fact] пользователь любит чай без сахара"], fact_hits
    sem_hits = rag.search("тёмную тему")
    assert sem_hits == ["сэр включил тёмную тему в редакторе"], sem_hits

    mixed = rag.search("чай тему")  # оба источника отвечают, факты — первыми
    assert len(mixed) == 2, mixed
    assert mixed[0].startswith("[fact]") and "тёмную тему" in mixed[1], mixed
    assert rag.search("чай тему", 1) == ["[fact] пользователь любит чай без сахара"]
    print("  ✓ rag: гибрид «факты + семантика» с ранжированием фактов первыми")


def test_dedup_between_sources() -> None:
    facts = InMemoryMemoryStore()
    facts.add(MemoryRecord(kind=MemoryKind.NOTE, content="чай без сахара"))
    rag = RagMemory(vectors=InMemoryVectorStore(), facts=facts)
    rag.remember("чай без сахара")  # то же самое в векторном индексе
    hits = rag.search("чай")
    assert hits == ["[note] чай без сахара"], f"дубль из двух источников схлопнут: {hits}"
    print("  ✓ rag: дубли фактов и фрагментов дедуплицируются")


def test_format_record() -> None:
    rec = MemoryRecord(kind=MemoryKind.PREFERENCE, content="люблю чай")
    assert format_record(rec) == "[preference] люблю чай"
    long_rec = MemoryRecord(kind=MemoryKind.SUMMARY, content="слово " * 300)
    assert len(format_record(long_rec)) <= MAX_RESULT_CHARS
    print("  ✓ rag: форматирование записи для промпта корректно")


# ---------------------------------------------------------------------------
# Мягкая деградация: сломанные источники не роняют конвейер
# ---------------------------------------------------------------------------
def test_soft_fallback_on_broken_sources() -> None:
    facts = InMemoryMemoryStore()
    facts.add(MemoryRecord(kind=MemoryKind.FACT, content="пользователь живёт в Москве"))

    # сломан векторный индекс — факты продолжают отвечать
    rag = RagMemory(vectors=BrokenVectors(), facts=facts)
    assert rag.search("Москве") == ["[fact] пользователь живёт в Москве"], "факты работают"

    # сломаны факты — семантика продолжает отвечать
    rag2 = RagMemory(vectors=InMemoryVectorStore(), facts=BrokenFacts())
    rag2.remember("заметка про погоду")
    assert rag2.search("погоду") == ["заметка про погоду"], "семантика работает"

    # сломано всё — тихий пустой список вместо исключения
    rag3 = RagMemory(vectors=BrokenVectors(), facts=BrokenFacts())
    assert rag3.search("что угодно") == []
    print("  ✓ rag: сломанный источник мягко пропускается, остальные отвечают")


# ---------------------------------------------------------------------------
# Интеграция с ContextBuilder (top-8 воспоминаний в системном промпте)
# ---------------------------------------------------------------------------
def test_context_builder_top8_contract() -> None:
    assert ContextBuilder().rag_top_k == 8, "дефолт ContextBuilder — top-8 (ТЗ)"
    spy = SpyMemory()
    cb = ContextBuilder(memory=spy)
    msgs = cb.build_messages(user_text="что по проекту?")
    assert spy.calls == [("что по проекту?", 8)], f"top_k=8 уходит в память: {spy.calls}"
    assert "воспоминание-шпион" in msgs[0]["content"]
    print("  ✓ rag: ContextBuilder запрашивает ровно top-8 воспоминаний")


def test_context_builder_with_rag_memory() -> None:
    rag = RagMemory(vectors=InMemoryVectorStore())
    for i in range(12):
        rag.remember(f"памятка про проект номер {i}", metadata={"kind": "note"})

    cb = ContextBuilder(memory=rag, persona_key="jarvis")
    msgs = cb.build_messages(
        persona=JARVIS,
        history=[{"role": "user", "content": "старое"}, {"role": "assistant", "content": "ответ"}],
        user_text="расскажи про проект",
    )
    assert msgs[0]["role"] == "system"
    sys_prompt = msgs[0]["content"]
    assert "JARVIS" in sys_prompt, "персона на месте"
    assert RAG_MARKER in sys_prompt, "блок воспоминаний добавлен"
    block = sys_prompt.split(RAG_MARKER, 1)[1]
    lines = [line for line in block.splitlines() if line.startswith("- ")]
    assert len(lines) == 8, f"в промпт попало ровно 8 воспоминаний: {len(lines)}"
    assert all("проект" in line for line in lines), lines
    assert msgs[-1] == {"role": "user", "content": "расскажи про проект"}
    print("  ✓ rag: ContextBuilder(memory=RagMemory) получает top-8 воспоминаний в промпт")


def test_context_builder_never_fails_on_broken_memory() -> None:
    cb = ContextBuilder(memory=BrokenSearch(), persona_key="jarvis")
    msgs = cb.build_messages(persona=JARVIS, user_text="привет")
    assert msgs[0]["role"] == "system"
    assert RAG_MARKER not in msgs[0]["content"], "упавшая память просто не добавляется"
    assert msgs[-1] == {"role": "user", "content": "привет"}
    print("  ✓ rag: упавшая память не роняет сборку контекста")


def test_vector_store_as_context_memory() -> None:
    vectors = InMemoryVectorStore()
    vectors.add("m1", "проект X готов к демо")
    cb = ContextBuilder(memory=vectors, persona_key="jarvis", rag_top_k=2)
    msgs = cb.build_messages(persona=JARVIS, user_text="расскажи про проект")
    assert "проект X готов к демо" in msgs[0]["content"], "VectorStore напрямую в ContextBuilder"
    print("  ✓ rag: VectorStore напрямую совместим с ContextBuilder (без адаптера)")


# ---------------------------------------------------------------------------
# Администрирование и фабрика
# ---------------------------------------------------------------------------
def test_remember_forget_count_clear() -> None:
    rag = RagMemory(vectors=InMemoryVectorStore())
    doc_id = rag.remember("первая заметка")
    rag.remember("вторая заметка", id="own-id")
    assert rag.count() == 2
    assert rag.forget(doc_id) is True
    assert rag.forget(doc_id) is False, "повторный forget — False"
    assert rag.forget("нет-такого") is False
    assert rag.count() == 1
    assert rag.clear() == 1 and rag.count() == 0
    print("  ✓ rag: remember/forget/count/clear работают")


def test_default_rag_factory() -> None:
    base = Path(".openclaw/tmp")
    base.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(dir=base))

    rag = default_rag(db_path=str(tmp / "jarvis.db"))
    assert isinstance(rag.vectors, VectorStore)
    assert rag.facts is not None, "факты подключены к SQLite"
    rag.remember("диалоговая заметка про чай")
    rag.facts.add(MemoryRecord(kind=MemoryKind.FACT, content="пользователь живёт в Москве"))
    assert rag.count() == 1
    assert rag.search("чай") == ["диалоговая заметка про чай"]
    assert rag.search("Москве") == ["[fact] пользователь живёт в Москве"]
    rag.facts.close()

    # без путей — рабочая in-memory память (fallback, без падений)
    rag2 = default_rag(prefer_chroma=False)
    assert rag2.facts is None
    rag2.remember("быстрая заметка")
    assert rag2.search("заметка") == ["быстрая заметка"]
    print("  ✓ rag: default_rag собирает факты + векторный индекс с мягким fallback")


if __name__ == "__main__":
    import traceback

    tests = [(k, v) for k, v in sorted(globals().items()) if k.startswith("test_")]
    failed = 0
    print("JARVIS CORE — проверка RAG-адаптера памяти")
    for name, fn in tests:
        try:
            fn()
            print(f"  ok  {name}")
        except Exception:
            failed += 1
            print(f"FAIL  {name}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
