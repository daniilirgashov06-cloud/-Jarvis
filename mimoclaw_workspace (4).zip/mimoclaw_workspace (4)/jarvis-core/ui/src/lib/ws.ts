/**
 * WebSocket-клиент панели JARVIS CORE.
 *
 * Протокол `ui_server/app.py` (JSON-строки):
 *   -> {"type": "text"|"ping"|"status"|"subscribe"}
 *   <- {"type": "status"|"event"|"reply"|"pong"|"subscribed"|"error"}
 *
 * Особенности: авто-переподключение с бэкоффом, keepalive-ping,
 * FIFO-сопоставление команд и reply-кадров (сервер обрабатывает сообщения
 * соединения последовательно).
 */

import type {
  ClientFrame,
  CommandReply,
  ConnectionState,
  ServerFrame,
} from "../types/api";

type FrameListener = (frame: ServerFrame) => void;
type ConnListener = (state: ConnectionState) => void;

const frameListeners = new Set<FrameListener>();
const connListeners = new Set<ConnListener>();

let socket: WebSocket | null = null;
let connState: ConnectionState = "offline";
let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
let heartbeatTimer: ReturnType<typeof setInterval> | null = null;
let attempts = 0;

/** Ожидающие ответа команды (FIFO — сервер отвечает в порядке получения). */
const pending: Array<{ resolve: (reply: CommandReply) => void }> = [];

const RECONNECT_MAX_MS = 15000;
const HEARTBEAT_MS = 25000;

function wsUrl(): string {
  const explicit = import.meta.env.VITE_WS_URL as string | undefined;
  if (explicit) return explicit;
  const apiBase = (import.meta.env.VITE_API_BASE as string | undefined) ?? "";
  if (/^https?:\/\//.test(apiBase)) {
    const url = new URL(apiBase);
    return `${url.protocol === "https:" ? "wss" : "ws"}://${url.host}/ws`;
  }
  const proto = window.location.protocol === "https:" ? "wss" : "ws";
  return `${proto}://${window.location.host}/ws`;
}

function setConnState(next: ConnectionState): void {
  if (connState === next) return;
  connState = next;
  for (const cb of connListeners) cb(next);
}

function scheduleReconnect(): void {
  if (reconnectTimer !== null) return;
  const delay = Math.min(RECONNECT_MAX_MS, 1000 * 2 ** attempts);
  attempts += 1;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    connectSocket();
  }, delay);
}

function startHeartbeat(): void {
  stopHeartbeat();
  heartbeatTimer = setInterval(() => {
    sendFrame({ type: "ping" });
  }, HEARTBEAT_MS);
}

function stopHeartbeat(): void {
  if (heartbeatTimer !== null) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
}

/** Подключиться к WS ядра (идемпотентно). */
export function connectSocket(): void {
  if (
    socket &&
    (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)
  ) {
    return;
  }
  setConnState("connecting");
  let ws: WebSocket;
  try {
    ws = new WebSocket(wsUrl());
  } catch {
    setConnState("offline");
    scheduleReconnect();
    return;
  }
  socket = ws;

  ws.onopen = () => {
    attempts = 0;
    setConnState("online");
    // Подписка на все события шины (фильтр топиков — wildcard).
    sendFrame({ type: "subscribe", topics: ["*"] });
    startHeartbeat();
  };

  ws.onmessage = (ev: MessageEvent<string>) => {
    let frame: ServerFrame;
    try {
      frame = JSON.parse(ev.data) as ServerFrame;
    } catch {
      return; // некорректный кадр — игнорируем, соединение не роняем
    }
    if (frame.type === "reply") {
      pending.shift()?.resolve(frame);
    } else if (frame.type === "error" && pending.length > 0) {
      pending.shift()?.resolve({
        ok: false,
        text: "",
        error: frame.message,
        actions: [],
        provider: "",
        tts: "",
      });
    }
    for (const cb of frameListeners) cb(frame);
  };

  ws.onclose = () => {
    if (socket === ws) socket = null;
    stopHeartbeat();
    setConnState("offline");
    scheduleReconnect();
  };

  ws.onerror = () => {
    ws.close();
  };
}

/** Принудительно переподключиться. */
export function reconnectSocket(): void {
  if (reconnectTimer !== null) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  attempts = 0;
  if (socket) {
    const stale = socket;
    socket = null;
    stale.onclose = null;
    stale.close();
  }
  connectSocket();
}

/** Отправить кадр. Возвращает false, если сокет не открыт. */
export function sendFrame(frame: ClientFrame): boolean {
  if (!socket || socket.readyState !== WebSocket.OPEN) return false;
  socket.send(JSON.stringify(frame));
  return true;
}

/**
 * Отправить команду и дождаться reply-кадра.
 * Если WS не открыт — промис отклоняется (вызывающая стор использует REST).
 */
export function sendCommandWs(text: string, timeoutMs = 30000): Promise<CommandReply> {
  return new Promise((resolve, reject) => {
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      reject(new Error("WebSocket не подключён"));
      return;
    }
    const entry = { resolve };
    pending.push(entry);
    const timer = setTimeout(() => {
      const idx = pending.indexOf(entry);
      if (idx >= 0) pending.splice(idx, 1);
      resolve({
        ok: false,
        text: "",
        error: "Таймаут ответа ядра (30 с)",
        actions: [],
        provider: "",
        tts: "",
      });
    }, timeoutMs);
    entry.resolve = (reply: CommandReply) => {
      clearTimeout(timer);
      resolve(reply);
    };
    socket.send(JSON.stringify({ type: "text", text } satisfies ClientFrame));
  });
}

export function onFrame(cb: FrameListener): () => void {
  frameListeners.add(cb);
  return () => {
    frameListeners.delete(cb);
  };
}

export function onConnectionChange(cb: ConnListener): () => void {
  connListeners.add(cb);
  return () => {
    connListeners.delete(cb);
  };
}

export function getConnState(): ConnectionState {
  return connState;
}

export function isOnline(): boolean {
  return connState === "online";
}
