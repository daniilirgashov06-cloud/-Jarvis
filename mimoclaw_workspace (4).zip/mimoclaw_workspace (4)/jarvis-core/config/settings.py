"""
Конфигурация JARVIS CORE.

Все настройки приложения валидируются через Pydantic и хранятся в
``config/settings.yaml`` (перезаписываемом из GUI). Секреты (API-ключи)
читаются из переменных окружения / ``config/.env`` и НИКОГДА не пишутся в YAML.

Использование:
    from config.settings import load_settings
    cfg = load_settings()          # читает default.yaml + settings.yaml + .env
    cfg.voice.vad_threshold        # доступ к секциям
"""

from __future__ import annotations

import os
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, SecretStr, field_validator

# Базовая директория проекта (jarvis-core/)
BASE_DIR: Path = Path(__file__).resolve().parent.parent
CONFIG_DIR: Path = BASE_DIR / "config"
DATA_DIR: Path = BASE_DIR / "data"


# ---------------------------------------------------------------------------
# Перечисления
# ---------------------------------------------------------------------------
class RiskLevel(str, Enum):
    """Уровень риска команды — определяет подтверждение."""

    SAFE = "safe"
    MEDIUM = "medium"
    HIGH = "high"
    FORBIDDEN = "forbidden"


class MicMode(str, Enum):
    """Режим работы микрофона."""

    ALWAYS = "always"        # всегда слушает
    WAKEWORD = "wakeword"    # по wake-word / хлопку
    PUSH = "push"            # по хоткею
    MUTED = "muted"          # выключен


class PrivacyMode(str, Enum):
    """Режим приватности памяти и сетевых вызовов."""

    NORMAL = "normal"
    INCOGNITO = "incognito"  # диалоги не сохраняются
    LOCAL = "local"          # только локальные модели, без интернета


# ---------------------------------------------------------------------------
# Секции конфигурации
# ---------------------------------------------------------------------------
class CoreConfig(BaseModel):
    """Общие параметры ядра."""

    user_name: str = Field("сэр", description="Обращение к пользователю")
    language: str = Field("ru", description="Основной язык (ru/en)")
    persona: str = Field("jarvis", description="Активная персона по умолчанию")
    privacy_mode: PrivacyMode = PrivacyMode.NORMAL
    offline_only: bool = Field(False, description="Только локальные модели (без интернета)")
    data_dir: Path = DATA_DIR


class AudioConfig(BaseModel):
    """Захват и воспроизведение звука."""

    sample_rate: int = Field(16000, description="Частота дискретизации, Гц")
    channels: int = Field(1, description="Моно")
    frame_ms: int = Field(20, description="Размер буфера, мс")
    input_device: str | int | None = Field(None, description="Имя/индекс микрофона")
    output_device: str | int | None = Field(None, description="Имя/индекс динамиков")
    mic_mode: MicMode = MicMode.WAKEWORD
    agc: bool = Field(True, description="Автоматическая регулировка усиления")
    noise_suppression: bool = True
    # VAD
    vad_threshold: float = Field(0.5, ge=0.0, le=1.0, description="Порог VAD")
    silence_ms: int = Field(1200, description="Пауза до конца реплики, мс")
    # SFX
    sfx_volume: float = Field(0.7, ge=0.0, le=1.0)
    speech_volume: float = Field(1.0, ge=0.0, le=1.0)
    interrupt_user: bool = Field(False, description="Перебивать ли пользователя")


class WakeWordConfig(BaseModel):
    """Детекторы активации."""

    enabled: bool = True
    words: list[str] = Field(
        default_factory=lambda: ["джарвис", "jarvis", "пятница", "friday"],
        description="Слова активации",
    )
    custom_word: str = Field("", description="Пользовательское слово")
    confidence: float = Field(0.5, ge=0.0, le=1.0, description="Порог уверенности")
    # Хлопки
    clap_enabled: bool = True
    clap_rms_threshold: float = Field(0.35, ge=0.0, le=1.0)
    clap_gap_ms_min: int = 150
    clap_gap_ms_max: int = 450
    clap_double: bool = Field(True, description="Активация по двойному хлопку")
    # Фразы-стоп
    stop_phrases: list[str] = Field(
        default_factory=lambda: ["хватит", "отбой", "замолчи", "стоп", "отмена"]
    )


class STTConfig(BaseModel):
    """Распознавание речи."""

    engine: str = Field("faster_whisper", description="faster_whisper | openai | deepgram")
    model: str = Field("large-v3", description="tiny|base|medium|large-v3")
    language: str = Field("auto", description="auto | ru | en")
    auto_punctuate: bool = True
    api_key: SecretStr | None = None  # для облачных fallback


class TTSConfig(BaseModel):
    """Синтез речи."""

    engine: str = Field("local", description="elevenlabs | xtts | piper | local")
    voice: str = Field("jarvis", description="Имя пресета голоса")
    speed: float = Field(0.96, ge=0.5, le=2.0)
    pitch: float = Field(0.0, ge=-12.0, le=12.0)
    api_key: SecretStr | None = None
    effects: list[str] = Field(
        default_factory=lambda: ["eq_british", "subtle_reverb", "radio_clarity"]
    )


class LLMProviderConfig(BaseModel):
    """Настройки одного LLM-провайдера."""

    enabled: bool = False
    model: str = ""
    api_key: SecretStr | None = None
    base_url: str | None = None
    temperature: float = Field(0.7, ge=0.0, le=2.0)
    max_tokens: int = Field(2048, gt=0)


class AIConfig(BaseModel):
    """ИИ-ядро: провайдеры и роутинг."""

    primary: str = Field("ollama", description="Основной провайдер")
    fallback_chain: list[str] = Field(
        default_factory=lambda: ["ollama", "openai", "anthropic"],
        description="Цепочка автопереключения",
    )
    openai: LLMProviderConfig = LLMProviderConfig(model="gpt-4o-mini")
    anthropic: LLMProviderConfig = LLMProviderConfig(model="claude-3-5-sonnet-latest")
    gemini: LLMProviderConfig = LLMProviderConfig(model="gemini-1.5-pro")
    ollama: LLMProviderConfig = LLMProviderConfig(enabled=True, model="llama3")
    daily_token_limit: int = Field(0, description="0 = без лимита")
    daily_spend_limit_usd: float = 0.0


class VisionConfig(BaseModel):
    """Зрение и работа с экраном."""

    enabled: bool = True
    screen_awareness: bool = Field(False, description="Периодический анализ экрана")
    awareness_interval_s: int = Field(60, gt=0)
    capture_fps: int = 2
    ocr_language: str = "rus+eng"
    store_screenshots: bool = False
    retention_days: int = Field(7, gt=0)
    mask_passwords: bool = True


class MemoryConfig(BaseModel):
    """Память."""

    enabled: bool = True
    sqlite_path: Path = DATA_DIR / "jarvis.db"
    chroma_path: Path = DATA_DIR / "chroma"
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    summarize_every_messages: int = Field(30, gt=0)
    rag_top_k: int = Field(8, gt=0)
    context_messages: int = Field(20, gt=0)


class TelegramConfig(BaseModel):
    """Telegram-бот."""

    enabled: bool = False
    token: SecretStr | None = None
    chat_id: str | None = None
    access_level: str = Field("view", description="full | view | notify")
    require_pin_for_high: bool = True
    pin: SecretStr | None = None
    notify_errors: bool = True


class SecurityConfig(BaseModel):
    """Безопасность и подтверждения."""

    require_confirmation_medium: bool = True
    pin_for_high: bool = True
    audit_log: bool = True
    allow_shell_scripts: bool = Field(False, description="Разрешить Python/PowerShell песочницу")
    whitelist_paths: list[str] = Field(default_factory=list)
    forbidden_paths: list[str] = Field(
        default_factory=lambda: [r"C:\Windows", r"C:\Program Files"]
    )


class UIConfig(BaseModel):
    """Внешний вид HUD/панели."""

    theme: str = Field("jarvis", description="jarvis | friday | custom")
    accent_color: str = "#00E5FF"
    transparency: float = Field(0.85, ge=0.0, le=1.0)
    overlay_enabled: bool = True
    boot_animation: bool = True
    show_subtitles: bool = True


class FunConfig(BaseModel):
    """Фишки и пасхалки."""

    easter_eggs: bool = True
    greetings: bool = True
    emotional_tone: bool = True
    mode: str = Field("normal", description="normal | stealth | focus | party | alarm")


class LoggingConfig(BaseModel):
    """Логирование."""

    level: str = Field("INFO", description="DEBUG|INFO|WARNING|ERROR")
    dir: Path = DATA_DIR / "logs"
    rotation: str = "10 MB"
    retention: str = "30 days"


class Settings(BaseModel):
    """Корневая модель всех настроек JARVIS CORE."""

    core: CoreConfig = CoreConfig()
    audio: AudioConfig = AudioConfig()
    wakeword: WakeWordConfig = WakeWordConfig()
    stt: STTConfig = STTConfig()
    tts: TTSConfig = TTSConfig()
    ai: AIConfig = AIConfig()
    vision: VisionConfig = VisionConfig()
    memory: MemoryConfig = MemoryConfig()
    telegram: TelegramConfig = TelegramConfig()
    security: SecurityConfig = SecurityConfig()
    ui: UIConfig = UIConfig()
    fun: FunConfig = FunConfig()
    logging: LoggingConfig = LoggingConfig()

    @field_validator("core", mode="before")
    @classmethod
    def _ensure_data_dir(cls, v: Any) -> Any:
        return v


# ---------------------------------------------------------------------------
# Загрузка
# ---------------------------------------------------------------------------
def _load_yaml(path: Path) -> dict[str, Any]:
    """Безопасно читает YAML-файл; возвращает {} если его нет."""
    if not path.exists():
        return {}
    import yaml  # локальный импорт, чтобы не тянуть зависимость при импорте модуля

    with path.open("r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def _apply_env_overrides(cfg: Settings) -> Settings:
    """Подтягивает секреты из окружения (JARVIS_<SECTION>_<KEY>)."""
    env_map: dict[str, tuple[str, str]] = {
        "OPENAI_API_KEY": ("ai", "openai"),
        "ANTHROPIC_API_KEY": ("ai", "anthropic"),
        "GEMINI_API_KEY": ("ai", "gemini"),
        "ELEVENLABS_API_KEY": ("tts", "api_key"),
        "TELEGRAM_BOT_TOKEN": ("telegram", "token"),
    }
    for env_name, (section, field_name) in env_map.items():
        val = os.environ.get(env_name)
        if not val:
            continue
        if section == "ai":
            getattr(cfg.ai, field_name).api_key = SecretStr(val)
        elif section == "tts":
            cfg.tts.api_key = SecretStr(val)
        elif section == "telegram":
            cfg.telegram.token = SecretStr(val)
    return cfg


def load_settings(
    default_path: Path | None = None,
    user_path: Path | None = None,
) -> Settings:
    """
    Собирает настройки: default.yaml -> settings.yaml -> переменные окружения.

    Приоритет (нарастающий): дефолт -> пользовательский YAML -> env.
    """
    default_path = default_path or CONFIG_DIR / "default.yaml"
    user_path = user_path or CONFIG_DIR / "settings.yaml"

    merged: dict[str, Any] = _load_yaml(default_path)
    # Поверх — пользовательский settings.yaml (из GUI)
    user_cfg = _load_yaml(user_path)
    for key, value in user_cfg.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = {**merged[key], **value}
        else:
            merged[key] = value

    settings = Settings.model_validate(merged)
    settings = _apply_env_overrides(settings)
    return settings


# Для быстрого доступа при старте
settings: Settings = load_settings()
