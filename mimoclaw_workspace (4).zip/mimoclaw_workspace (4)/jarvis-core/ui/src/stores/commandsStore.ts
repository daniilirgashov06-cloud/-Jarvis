/**
 * Стор реестра команд: список, поиск, фильтр по риску, вкл/выкл.
 */

import { create } from "zustand";
import { fetchCommands, updateCommand } from "../lib/api";
import type { CommandInfo, RiskLevel } from "../types/commands";

export type RiskFilter = RiskLevel | "all";

interface CommandsState {
  items: CommandInfo[];
  loaded: boolean;
  remote: boolean;
  query: string;
  riskFilter: RiskFilter;

  load: () => Promise<void>;
  toggle: (name: string) => void;
  setQuery: (query: string) => void;
  setRiskFilter: (filter: RiskFilter) => void;
}

export const useCommandsStore = create<CommandsState>((set, get) => ({
  items: [],
  loaded: false,
  remote: false,
  query: "",
  riskFilter: "all",

  load: async () => {
    const { commands, remote } = await fetchCommands();
    set({ items: commands, loaded: true, remote });
  },

  toggle: (name) => {
    set((state) => ({
      items: state.items.map((item) =>
        item.name === name ? { ...item, enabled: !item.enabled } : item,
      ),
    }));
    const item = get().items.find((c) => c.name === name);
    if (item && get().remote) {
      void updateCommand(name, { enabled: item.enabled });
    }
  },

  setQuery: (query) => set({ query }),
  setRiskFilter: (riskFilter) => set({ riskFilter }),
}));

/** Отфильтрованный список: поиск по имени/описанию + уровень риска. */
export function selectFiltered(commands: CommandInfo[], query: string, filter: RiskFilter): CommandInfo[] {
  const q = query.trim().toLowerCase();
  return commands.filter((c) => {
    if (filter !== "all" && c.risk !== filter) return false;
    if (!q) return true;
    return (
      c.name.toLowerCase().includes(q) ||
      c.description.toLowerCase().includes(q) ||
      c.params.some((p) => p.name.toLowerCase().includes(q))
    );
  });
}
