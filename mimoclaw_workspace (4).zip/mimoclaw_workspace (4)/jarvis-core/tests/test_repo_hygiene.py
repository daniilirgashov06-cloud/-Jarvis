"""
Проверка репозиторной гигиены: .gitignore, config/.env.example, синхронизация
шаблона секретов с реальным перечнем переменных окружения в config/settings.py.

Запуск:  python3 tests/test_repo_hygiene.py

Логика: если в config/settings.py появится новый ключ (env_map), а в
config/.env.example его не будет — тест упадёт и напомнит обновить шаблон.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from config.settings import _apply_env_overrides  # noqa: E402  (нужен env_map)

GITIGNORE = ROOT / ".gitignore"
ENV_EXAMPLE = ROOT / "config" / ".env.example"


def _env_map_keys() -> set[str]:
    """Достаёт перечень имён переменных окружения из config/settings.py."""
    src = (ROOT / "config" / "settings.py").read_text(encoding="utf-8")
    match = re.search(r"env_map[^{]*\{(.*?)\}", src, re.DOTALL)
    assert match, "env_map не найден в config/settings.py"
    keys = set(re.findall(r'"([A-Z0-9_]+)":\s*\(', match.group(1)))
    assert keys, "env_map пуст — изменился формат config/settings.py?"
    return keys


def _env_example_keys() -> set[str]:
    """Достаёт имена переменных из шаблона (строки вида `KEY=`)."""
    keys: set[str] = set()
    for line in ENV_EXAMPLE.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and "=" in stripped:
            keys.add(stripped.split("=", 1)[0].strip())
    return keys


def test_gitignore_exists_and_covers_secrets() -> None:
    """.gitignore существует и защищает секреты/мусор."""
    assert GITIGNORE.is_file(), ".gitignore отсутствует"
    lines = [
        line.strip()
        for line in GITIGNORE.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]
    for pattern in ("__pycache__/", "config/.env", "*.log", ".venv/", "node_modules/"):
        assert pattern in lines, f".gitignore не покрывает {pattern!r}"
    # сам шаблон НЕ игнорируется — он должен попадать в git
    assert "config/.env.example" not in lines, (
        ".gitignore должен игнорировать config/.env, но не config/.env.example"
    )


def test_env_example_exists_and_never_has_values() -> None:
    """config/.env.example существует и не содержит реальных значений."""
    assert ENV_EXAMPLE.is_file(), "config/.env.example отсутствует"
    for key in _env_example_keys():
        for line in ENV_EXAMPLE.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if stripped.startswith(f"{key}="):
                value = stripped.split("=", 1)[1].strip()
                assert value == "", f"в шаблоне заполнено значение {key!r} — секреты в git не попадают"
                break


def test_env_example_in_sync_with_settings() -> None:
    """Ключи шаблона и env_map в config/settings.py совпадают 1:1."""
    expected = _env_map_keys()
    actual = _env_example_keys()
    missing = expected - actual
    extra = actual - expected
    assert not missing, f"в config/.env.example не хватает ключей: {sorted(missing)}"
    assert not extra, f"лишние ключи в config/.env.example: {sorted(extra)}"


def test_env_overrides_mapping_is_callable() -> None:
    """_apply_env_overrides доступна и не падает на пустом окружении (импорт-контракт)."""
    assert callable(_apply_env_overrides)


def test_readme_documents_env_copy_command() -> None:
    """README указывает существующий путь шаблона (config/.env.example)."""
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    assert "config/.env.example" in readme, "README не упоминает config/.env.example"


# --- Зафиксированные инженерные решения (README ↔ ROADMAP) -----------------

DECISIONS_SECTION = "Ключевые инженерные решения"

# Маркеры решений 1-8 из ROADMAP.md: по одному ключевому слову на решение
DECISION_MARKERS = (
    "MVP-first",           # 1. MVP-first
    "Локально-first",      # 2. локально-first для ИИ/речи
    "LLMRouter",           # 3. единый роутер провайдеров
    "Tauri",               # 4. веб-панель за FastAPI + Tauri
    "event_bus",           # 5. модульность через шину
    "Pydantic",            # 6. конфиг через Pydantic + yaml
    "Windows",             # 7. разработка на Linux, запуск на Windows
    "стилизация",          # 8. голоса — стилизация, не клонирование
)


def _decisions_section(text: str) -> str:
    """Вырезает раздел с решениями (от заголовка `## ...` до следующего `## `).

    Якорь — именно заголовок уровня 2, чтобы упоминания фразы в других
    разделах (например, в чек-листе) не подменяли сам раздел.
    """
    marker = f"## {DECISIONS_SECTION}"
    assert marker in text, "раздел с инженерными решениями не найден"
    tail = text.split(marker, 1)[1]
    return tail.split("\n## ", 1)[0]


def test_readme_fixes_all_engineering_decisions() -> None:
    """README содержит все 8 зафиксированных решений, пронумерованных 1-8."""
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    section = _decisions_section(readme)
    numbers = [int(n) for n in re.findall(r"(?m)^(\d+)\. \*\*", section)]
    assert numbers == [1, 2, 3, 4, 5, 6, 7, 8], (
        f"ожидалась нумерация решений 1-8, найдено: {numbers}"
    )
    for marker in DECISION_MARKERS:
        assert marker.lower() in section.lower(), (
            f"решение с маркером {marker!r} не зафиксировано в README"
        )


def test_readme_decisions_not_diverging_from_roadmap() -> None:
    """README и ROADMAP фиксируют одни и те же опорные понятия решений 1-8.

    Если в ROADMAP решение переформулировано так, что маркер из списка
    пропал — зафиксированные решения разъехались, и README надо обновить.
    """
    roadmap = (ROOT / "ROADMAP.md").read_text(encoding="utf-8")
    r_section = _decisions_section(roadmap).lower()
    for marker in DECISION_MARKERS:
        assert marker.lower() in r_section, (
            f"в ROADMAP нет маркера {marker!r} — решения README и ROADMAP разъехались"
        )


# ---------------------------------------------------------------------------
# Мини-раннер (как в остальных tests/)
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for fn in tests:
        try:
            fn()
            print(f"  ok   {fn.__name__}")
        except AssertionError as exc:
            failed += 1
            print(f"  FAIL {fn.__name__}: {exc}")
    print(f"{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
