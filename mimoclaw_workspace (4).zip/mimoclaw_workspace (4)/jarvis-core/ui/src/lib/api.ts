/**
 * REST-клиент панели JARVIS CORE.
 *
 * Контракт ядра (`ui_server/app.py`):
 *   GET  /api/status        -> StatusSnapshot
 *   GET  /api/history       -> BusEvent[]
 *   POST /api/text {text}   -> CommandReply
 *
 * Дополнительно панель умеет работать с REST настроек/команд, когда ядро
 * их отдаёт (добавляются на бэкенде):
 *   GET  /api/settings      -> Settings | { settings: Settings }
 *   PATCH/PUT /api/settings -> сохранить изменённые секции
 *   GET  /api/commands      -> CommandInfo[] | { commands: CommandInfo[] }
 *   PATCH /api/commands/{name}
 *
 * Если эндпоинта нет (404/405) или ядро оффлайн — панель переключается в
 * демо-режим: локальные дефолты, изменения копятся локально.
 */

import type { BusEvent, CommandReply, StatusSnapshot } from "../types/api";
import type { CommandInfo } from "../types/commands";
import type { Settings } from "../types/settings";
import { DEFAULT_SETTINGS } from "../types/settings";
import { DEMO_COMMANDS } from "./demoData";

/** База REST. По умолчанию — тот же origin (dev через vite-proxy -> 127.0.0.1:8765). */
const API_BASE = ((import.meta.env.VITE_API_BASE as string | undefined) ?? "").replace(/\/$/, "");

const JSON_HEADERS = { "Content-Type": "application/json", Accept: "application/json" };

async function request<T>(path: string, init?: RequestInit): Promise<T | null> {
  try {
    const res = await fetch(`${API_BASE}${path}`, init);
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

/** POST /api/text — отправить текстовую команду (fallback для WS). */
export async function sendTextRest(text: string): Promise<CommandReply> {
  const data = await request<CommandReply>("/api/text", {
    method: "POST",
    headers: JSON_HEADERS,
    body: JSON.stringify({ text }),
  });
  if (data && typeof data === "object" && "text" in data) {
    return { ok: true, actions: [], provider: "", tts: "", ...data };
  }
  return {
    ok: false,
    text: "",
    error: "Ядро недоступно (POST /api/text не ответил). Запустите ui_server на 127.0.0.1:8765.",
    actions: [],
    provider: "",
    tts: "",
  };
}

/** GET /api/status */
export async function fetchStatus(): Promise<StatusSnapshot | null> {
  return request<StatusSnapshot>("/api/status");
}

/** GET /api/history?limit=N */
export async function fetchHistory(limit = 50): Promise<BusEvent[]> {
  const data = await request<BusEvent[]>(`/api/history?limit=${limit}`);
  return Array.isArray(data) ? data : [];
}

interface SettingsResponse {
  settings: Settings;
  remote: boolean;
}

function mergeSettings(base: Settings, patch: Partial<Settings>): Settings {
  const merged = { ...base };
  for (const key of Object.keys(patch) as Array<keyof Settings>) {
    const section = patch[key];
    if (section && typeof section === "object") {
      merged[key] = { ...base[key], ...section } as never;
    }
  }
  return merged;
}

/** GET /api/settings — настройки ядра; при отсутствии эндпоинта: демо-дефолты. */
export async function fetchSettings(): Promise<SettingsResponse> {
  const data = await request<Settings | { settings: Settings }>("/api/settings");
  const raw = data && typeof data === "object" && "settings" in data ? data.settings : data;
  if (raw && typeof raw === "object" && "core" in raw && "audio" in raw) {
    return { settings: mergeSettings(DEFAULT_SETTINGS, raw as Partial<Settings>), remote: true };
  }
  return { settings: DEFAULT_SETTINGS, remote: false };
}

export interface SaveResult {
  /** Изменения приняты ядром. */
  saved: boolean;
  /** Ядро отвечает на REST настроек. */
  remote: boolean;
}

/** PATCH/PUT /api/settings — сохранить изменённые секции. */
export async function saveSettings(patch: Partial<Settings>): Promise<SaveResult> {
  try {
    const res = await fetch(`${API_BASE}/api/settings`, {
      method: "PATCH",
      headers: JSON_HEADERS,
      body: JSON.stringify(patch),
    });
    if (res.ok) return { saved: true, remote: true };
    if (res.status === 404 || res.status === 405) {
      const put = await fetch(`${API_BASE}/api/settings`, {
        method: "PUT",
        headers: JSON_HEADERS,
        body: JSON.stringify(patch),
      });
      return { saved: put.ok, remote: put.ok };
    }
    return { saved: false, remote: true };
  } catch {
    return { saved: false, remote: false };
  }
}

interface CommandsResponse {
  commands: CommandInfo[];
  remote: boolean;
}

/** GET /api/commands — реестр команд; при отсутствии эндпоинта: демо-каталог. */
export async function fetchCommands(): Promise<CommandsResponse> {
  const data = await request<CommandInfo[] | { commands: CommandInfo[] }>("/api/commands");
  const list = Array.isArray(data) ? data : data?.commands;
  if (Array.isArray(list) && list.length > 0) {
    return {
      commands: list.map((c) => ({ ...c, params: c.params ?? [], source: "core" })),
      remote: true,
    };
  }
  return { commands: DEMO_COMMANDS, remote: false };
}

/** PATCH /api/commands/{name} — включить/выключить команду. */
export async function updateCommand(name: string, patch: Partial<CommandInfo>): Promise<boolean> {
  try {
    const res = await fetch(`${API_BASE}/api/commands/${encodeURIComponent(name)}`, {
      method: "PATCH",
      headers: JSON_HEADERS,
      body: JSON.stringify(patch),
    });
    return res.ok;
  } catch {
    return false;
  }
}
