/**
 * Диагностика / Логи — состояние подключений, счётчики, живая лента событий
 * и служебные инструменты (ping, статус, переподключение).
 */

import { Badge, Card, Notice, PageHeader } from "../components/ui/panels";
import { Button } from "../components/ui/controls";
import { EventLog } from "../components/EventLog";
import { useSocket } from "../hooks/useSocket";
import { clsx, formatUptime } from "../lib/format";
import { useSettingsStore } from "../stores/settingsStore";
import { useSystemStore } from "../stores/systemStore";

const ENDPOINTS: Array<[string, string]> = [
  ["GET  /api/status", "снимок статуса панели и пайплайна"],
  ["GET  /api/history", "лента событий шины"],
  ["POST /api/text", "текстовая команда оркестратору"],
  ["WS   /ws", "живые события и команды"],
  ["GET  /api/settings", "чтение настроек (если доступно)"],
  ["PATCH /api/settings", "сохранение настроек (если доступно)"],
  ["GET  /api/commands", "реестр команд (если доступен)"],
];

export function DiagnosticsPage() {
  const { ping, requestStatus, reconnect, connection } = useSocket();
  const status = useSystemStore((s) => s.status);
  const events = useSystemStore((s) => s.events);
  const clearEvents = useSystemStore((s) => s.clearEvents);
  const replies = useSystemStore((s) => s.replies);
  const remoteSettings = useSettingsStore((s) => s.remote);

  const counters = status?.counters ?? { events: 0, commands: 0, errors: 0 };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Диагностика"
        subtitle="Состояние связей с ядром JARVIS CORE, счётчики и журнал событий."
        actions={
          <>
            <Button onClick={ping}>Ping</Button>
            <Button onClick={requestStatus}>Статус</Button>
            <Button variant="primary" onClick={reconnect}>Переподключиться</Button>
          </>
        }
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Tile label="WS СОЕДИНЕНИЕ" value={connection} accent={connection === "online"} />
        <Tile label="АПТАЙМ ЯДРА" value={status ? formatUptime(status.uptime_s) : "—"} />
        <Tile label="КЛИЕНТОВ WS" value={String(status?.clients ?? 0)} />
        <Tile
          label="ОРКЕСТРАТОР"
          value={status?.orchestrator ? "подключён" : "отключён"}
          accent={Boolean(status?.orchestrator)}
        />
        <Tile label="СОБЫТИЙ" value={String(counters.events)} />
        <Tile label="КОМАНД" value={String(counters.commands)} />
        <Tile label="ОШИБОК" value={String(counters.errors)} accent={counters.errors > 0} />
        <Tile label="СООБЩЕНИЙ ОТВЕТА" value={String(replies.length)} />
      </div>

      {connection !== "online" ? (
        <Notice tone="warn">
          WebSocket отключён от ws://127.0.0.1:8765/ws. Проверьте, что запущен ядро-сервер:
          <code className="mx-1">python main.py</code> или <code>uvicorn ui_server.app:app</code>.
        </Notice>
      ) : null}
      {!remoteSettings ? (
        <Notice tone="info">
          REST <code>/api/settings</code> недоступен — панель работает с локальными дефолтами.
          Настройки сохраняются после появления эндпоинта.
        </Notice>
      ) : null}

      <Card
        title="Журнал событий"
        subtitle="Все топики шины в реальном времени"
        right={<Button variant="soft" onClick={clearEvents}>Очистить</Button>}
      >
        <EventLog events={events} limit={200} height="h-[420px]" />
      </Card>

      <Card title="Эндпоинты ядра" subtitle="Контракт FastAPI + WebSocket (127.0.0.1:8765)">
        <ul className="space-y-1.5">
          {ENDPOINTS.map(([endpoint, hint]) => (
            <li key={endpoint} className="flex flex-wrap items-center gap-2 text-sm">
              <code className={clsx("rounded-md border border-line bg-panel-2 px-2 py-0.5 text-accent")}>
                {endpoint}
              </code>
              <span className="text-muted">{hint}</span>
            </li>
          ))}
        </ul>
      </Card>

      <Card title="Последние ответы" subtitle="Реплики оркестратора (обмен с панелью)">
        {replies.length === 0 ? (
          <p className="text-sm text-muted">Ответов пока нет.</p>
        ) : (
          <ul className="space-y-2">
            {replies
              .slice(-8)
              .reverse()
              .map((reply, i) => (
                <li key={i} className="rounded-lg border border-line bg-panel-2/50 px-3 py-2 text-sm">
                  <Badge className={reply.ok ? "border-ok/40 bg-ok/10 text-ok" : "border-danger/40 bg-danger/10 text-danger"}>
                    {reply.ok ? "ok" : "error"}
                  </Badge>{" "}
                  <span className="text-text">{reply.text || reply.error || "—"}</span>
                  <span className="ml-2 text-xs text-muted">
                    {reply.provider ? `модель: ${reply.provider}` : ""}
                    {reply.tts ? ` · tts: ${reply.tts}` : ""}
                  </span>
                </li>
              ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function Tile({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="rounded-xl border border-line bg-panel/70 px-4 py-3">
      <p className="text-[10px] tracking-[0.22em] text-muted">{label}</p>
      <p className={clsx("mt-1 font-heading text-lg tabular-nums", accent ? "text-accent" : "text-text")}>
        {value}
      </p>
    </div>
  );
}
