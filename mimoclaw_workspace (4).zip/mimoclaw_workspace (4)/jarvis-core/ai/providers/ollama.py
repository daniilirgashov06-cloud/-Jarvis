"""
Локальный LLM-провайдер Ollama (без интернета и ключей).

Работает с локальным REST-сервером Ollama (по умолчанию http://localhost:11434).
Используется как основной провайдер в режиме «локально-first».
"""

from __future__ import annotations

from typing import Any

from .base import (
    BaseLLMProvider,
    LLMMessage,
    LLMResponse,
    ProviderError,
    ProviderUnavailable,
    ToolCall,
    Usage,
)


class OllamaProvider(BaseLLMProvider):
    """Чат с локальными моделями Ollama (llama3, qwen, mistral и др.)."""

    name = "ollama"

    def __init__(
        self,
        model: str = "llama3",
        base_url: str = "http://localhost:11434",
        timeout: float = 120.0,
    ) -> None:
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def is_available(self) -> bool:
        """Проверяет, поднят ли локальный сервер Ollama."""
        try:
            import httpx

            resp = httpx.get(f"{self.base_url}/api/tags", timeout=2.0)
            return resp.status_code == 200
        except Exception:  # noqa: BLE001
            return False

    async def complete(
        self,
        messages: list[LLMMessage],
        tools: list[dict[str, Any]] | None = None,
        *,
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> LLMResponse:
        """Запрос к /api/chat с опциональным function calling."""
        try:
            import httpx
        except ImportError as exc:  # pragma: no cover
            raise ProviderUnavailable("httpx не установлен") from exc

        payload: dict[str, Any] = {
            "model": self.model,
            "messages": self._to_ollama_messages(messages),
            "stream": False,
            "options": {"temperature": temperature, "num_predict": max_tokens},
        }
        if tools:
            payload["tools"] = self._to_ollama_tools(tools)

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(f"{self.base_url}/api/chat", json=payload)
        except Exception as exc:  # noqa: BLE001 — сеть/сервер недоступны
            raise ProviderUnavailable(f"Ollama недоступен: {exc}") from exc

        if resp.status_code != 200:
            raise ProviderError(f"Ollama HTTP {resp.status_code}: {resp.text[:200]}")

        data = resp.json()
        msg = data.get("message", {}) or {}
        tool_calls = self._parse_tool_calls(msg.get("tool_calls"))
        usage = Usage(
            prompt_tokens=int(data.get("prompt_eval_count", 0) or 0),
            completion_tokens=int(data.get("eval_count", 0) or 0),
        )
        return LLMResponse(
            content=msg.get("content", "") or "",
            tool_calls=tool_calls,
            usage=usage,
            provider=self.name,
            model=self.model,
            raw=data,
        )

    # -- конвертация форматов ------------------------------------------------
    @staticmethod
    def _to_ollama_messages(messages: list[LLMMessage]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for m in messages:
            item: dict[str, Any] = {"role": m.role, "content": m.content}
            if m.tool_calls:
                item["tool_calls"] = [
                    {"function": {"name": tc.name, "arguments": tc.arguments}}
                    for tc in m.tool_calls
                ]
            out.append(item)
        return out

    @staticmethod
    def _to_ollama_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        # Ollama принимает схемы в формате, совместимом с OpenAI tools.
        return tools

    @staticmethod
    def _parse_tool_calls(raw: Any) -> list[ToolCall]:
        calls: list[ToolCall] = []
        for i, tc in enumerate(raw or []):
            fn = tc.get("function", {}) if isinstance(tc, dict) else {}
            calls.append(
                ToolCall(
                    id=str(tc.get("id", f"call_{i}")),
                    name=fn.get("name", ""),
                    arguments=fn.get("arguments", {}) or {},
                )
            )
        return calls

    def describe(self) -> dict[str, Any]:
        return {**super().describe(), "model": self.model, "base_url": self.base_url}
