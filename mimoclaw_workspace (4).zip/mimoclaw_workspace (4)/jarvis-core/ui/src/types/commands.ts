/**
 * Команда реестра действий (`actions/registry.py`).
 *
 * REST-контракт (когда его отдаёт ядро):
 *   GET   /api/commands            -> { commands: CommandInfo[] }
 *   PATCH /api/commands/{name}     -> { enabled: boolean, ... }
 * Если эндпоинта нет — панель работает на встроенном демо-каталоге.
 */

export type RiskLevel = "safe" | "medium" | "high" | "forbidden" | (string & {});

export interface CommandParam {
  name: string;
  type: string;
  description?: string;
  required?: boolean;
}

export interface CommandInfo {
  name: string;
  description: string;
  risk: RiskLevel;
  enabled: boolean;
  requires_confirmation: boolean;
  params: CommandParam[];
  /** Источник записи: ядро или демо-каталог панели. */
  source?: "core" | "demo";
}

export interface RiskMeta {
  label: string;
  hint: string;
  /** CSS-классы бейджа уровня риска. */
  className: string;
}

export const RISK_META: Record<string, RiskMeta> = {
  safe: {
    label: "Безопасно",
    hint: "Выполняется без подтверждения",
    className: "border-ok/40 bg-ok/10 text-ok",
  },
  medium: {
    label: "Средний",
    hint: "Требует подтверждения оператора",
    className: "border-warn/40 bg-warn/10 text-warn",
  },
  high: {
    label: "Высокий",
    hint: "Подтверждение + PIN",
    className: "border-danger/50 bg-danger/10 text-danger",
  },
  forbidden: {
    label: "Запрещено",
    hint: "Только через явный whitelist",
    className: "border-danger bg-danger/20 text-danger",
  },
};
