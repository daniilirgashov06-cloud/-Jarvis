"""
Проверка AI-ядра JARVIS CORE (без сети — мок-провайдеры).

Запуск:  python3 tests/test_ai_core.py
Или:     pytest tests/test_ai_core.py -q
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ai.function_calling import Tool, to_openai_tools
from ai.llm_router import LLMRouter
from ai.personas import FRIDAY, JARVIS, make_custom
from ai.providers import (
    BaseLLMProvider,
    LLMMessage,
    LLMResponse,
    ProviderError,
    ProviderUnavailable,
    Usage,
)


# ---------------------------------------------------------------------------
# Мок-провайдеры
# ---------------------------------------------------------------------------
class MockProvider(BaseLLMProvider):
    """Мок: отвечает фиксированной строкой; можно заставить падать/быть недоступным."""

    def __init__(
        self,
        name: str,
        reply: str = "ok",
        available: bool = True,
        fail_mode: str | None = None,  # None | "unavailable" | "error"
        usage: Usage | None = None,
    ) -> None:
        self.name = name
        self.reply = reply
        self.available = available
        self.fail_mode = fail_mode
        self.usage = usage or Usage(prompt_tokens=10, completion_tokens=5)
        self.calls = 0

    def is_available(self) -> bool:
        return self.available

    async def complete(self, messages, tools=None, *, temperature=0.7, max_tokens=2048):
        self.calls += 1
        if self.fail_mode == "unavailable":
            raise ProviderUnavailable(f"{self.name}: нет")
        if self.fail_mode == "error":
            raise ProviderError(f"{self.name}: ошибка")
        return LLMResponse(
            content=self.reply,
            usage=self.usage,
            provider=self.name,
            model=f"{self.name}-model",
        )


# ---------------------------------------------------------------------------
# Тесты
# ---------------------------------------------------------------------------
def test_function_calling_schema() -> None:
    tool = Tool.from_command(
        name="set volume!",
        description="Установить громкость",
        params={
            "level": {"type": "number", "description": "0..100", "required": True},
            "device": {"type": "string", "description": "устройство", "required": False},
        },
    )
    assert tool.name == "set_volume", f"санитизация имени: {tool.name}"
    schema = tool.parameters_schema()
    assert schema["type"] == "object"
    assert set(schema["properties"].keys()) == {"level", "device"}
    assert schema["required"] == ["level"], schema["required"]
    payload = to_openai_tools([tool])
    assert payload[0]["type"] == "function"
    assert payload[0]["function"]["name"] == "set_volume"
    print("  ✓ function_calling: схема и санитизация имени корректны")


def test_personas() -> None:
    ctx = {"datetime": "2026-10-08 22:00", "system_status": "CPU 12%, RAM 40%"}
    sp = JARVIS.system_prompt(ctx)
    assert "JARVIS" in sp and "сэр" in sp and "2026-10-08" in sp and "CPU" in sp
    fsp = FRIDAY.system_prompt({})
    assert "FRIDAY" in fsp
    custom = make_custom("Тони", "Ты — мой личный помощник.", address="босс", humor=80)
    assert custom.address == "босс" and custom.humor == 80
    print("  ✓ personas: сборка системного промпта и custom работают")


async def test_router_selection_and_switch() -> None:
    local = MockProvider("ollama", reply="local-answer")
    cloud = MockProvider("openai", reply="cloud-answer")
    router = LLMRouter(
        providers={"ollama": local, "openai": cloud},
        primary="ollama",
        fallback_chain=["ollama", "openai"],
    )
    r1 = await router.ask([LLMMessage.user("привет")])
    assert r1.content == "local-answer" and r1.provider == "ollama"

    await router.set_primary("openai")  # смена на облако
    r2 = await router.ask([LLMMessage.user("привет")])
    assert r2.content == "cloud-answer" and r2.provider == "openai"
    assert router.primary == "openai"
    print("  ✓ router: выбор и живая смена провайдера (локально↔облако) работают")


async def test_router_fallback() -> None:
    broken = MockProvider("ollama", fail_mode="unavailable")
    healthy = MockProvider("openai", reply="rescued")
    router = LLMRouter(
        providers={"ollama": broken, "openai": healthy},
        primary="ollama",
        fallback_chain=["ollama", "openai"],
    )
    resp = await router.ask([LLMMessage.user("x")])
    assert resp.content == "rescued" and resp.provider == "openai"
    assert broken.calls == 1 and healthy.calls == 1
    print("  ✓ router: fallback при недоступном основном провайдере работает")


async def test_router_fallback_on_error() -> None:
    flaky = MockProvider("ollama", fail_mode="error")
    healthy = MockProvider("openai", reply="rescued")
    router = LLMRouter(
        providers={"ollama": flaky, "openai": healthy},
        primary="ollama",
        fallback_chain=["ollama", "openai"],
    )
    resp = await router.ask([LLMMessage.user("x")])
    assert resp.provider == "openai"
    print("  ✓ router: fallback при ошибке провайдера работает")


async def test_router_offline_only() -> None:
    local = MockProvider("ollama", reply="local")
    cloud = MockProvider("openai", reply="cloud")
    router = LLMRouter(
        providers={"ollama": local, "openai": cloud},
        primary="openai",  # основной — облако...
        fallback_chain=["openai", "ollama"],
        offline_only=True,  # ...но режим «локально» должен увести на ollama
    )
    resp = await router.ask([LLMMessage.user("x")])
    assert resp.provider == "ollama", f"offline_only должен выбрать локального, выбрано {resp.provider}"
    print("  ✓ router: режим offline_only выбирает локального провайдера")


async def test_router_explicit_provider_no_fallback() -> None:
    a = MockProvider("ollama", fail_mode="unavailable")
    b = MockProvider("openai", reply="should-not-run")
    router = LLMRouter(providers={"ollama": a, "openai": b}, primary="ollama")
    try:
        await router.ask([LLMMessage.user("x")], provider="ollama")
        assert False, "ожидали исключение без fallback"
    except ProviderError:
        pass
    assert b.calls == 0, "явный провайдер не должен был падать на fallback"
    print("  ✓ router: явный провайдер не использует fallback")


async def test_router_budget() -> None:
    p = MockProvider("ollama", usage=Usage(prompt_tokens=500, completion_tokens=500))
    router = LLMRouter(providers={"ollama": p}, primary="ollama")
    await router.ask([LLMMessage.user("x")])
    snap = router.budget_snapshot()
    assert snap["total_tokens"] == 1000 and snap["calls"] == 1
    router.daily_token_limit = 1500
    await router.ask([LLMMessage.user("y")])  # 2000 > 1500 -> должно стопорнуть
    # Третий вызов уже за лимитом
    try:
        await router.ask([LLMMessage.user("z")])
        assert False, "ожидали превышение бюджета"
    except ProviderError:
        pass
    print("  ✓ router: учёт бюджета и стоп по лимиту работают")


async def test_router_all_fail() -> None:
    router = LLMRouter(
        providers={"ollama": MockProvider("ollama", fail_mode="unavailable")},
        primary="ollama",
        fallback_chain=["ollama"],
    )
    try:
        await router.ask([LLMMessage.user("x")])
        assert False, "ожидали ошибку, когда не ответил никто"
    except ProviderError:
        pass
    print("  ✓ router: корректная ошибка, когда не ответил ни один провайдер")


def test_config_builds_router() -> None:
    # Проверяем сборку роутера из реального конфига (local-first по умолчанию).
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from config.settings import load_settings

    cfg = load_settings()
    router = LLMRouter.from_config(cfg.ai)
    assert "ollama" in router._providers and "openai" in router._providers
    assert router.primary == cfg.ai.primary
    assert router.offline_only is False
    # ollama локальный -> is_available зависит от сервера; но провайдер создан
    status = router.provider_status()
    assert {s["name"] for s in status} == {"ollama", "openai", "anthropic", "gemini"}
    print("  ✓ router: сборка из конфига (все 4 провайдера) работает")


# ---------------------------------------------------------------------------
# Раннер (без pytest)
# ---------------------------------------------------------------------------
async def _run_async() -> None:
    await test_router_selection_and_switch()
    await test_router_fallback()
    await test_router_fallback_on_error()
    await test_router_offline_only()
    await test_router_explicit_provider_no_fallback()
    await test_router_budget()
    await test_router_all_fail()


def main() -> int:
    print("JARVIS CORE — проверка AI-ядра")
    try:
        test_function_calling_schema()
        test_personas()
        test_config_builds_router()
        asyncio.run(_run_async())
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки AI-ядра прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
