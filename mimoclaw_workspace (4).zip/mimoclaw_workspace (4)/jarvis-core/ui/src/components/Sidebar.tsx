/**
 * Левое меню разделов панели JARVIS CORE.
 */

import { NavLink } from "react-router-dom";
import { motion } from "framer-motion";
import { clsx } from "../lib/format";
import { useUiStore } from "../stores/uiStore";
import { useSystemStore } from "../stores/systemStore";

interface NavItem {
  to: string;
  label: string;
  icon: string;
  end?: boolean;
}

const NAV: NavItem[] = [
  { to: "/", label: "Обзор", icon: "◈", end: true },
  { to: "/voice", label: "Голос", icon: "◉" },
  { to: "/commands", label: "Команды и доступы", icon: "⚡" },
  { to: "/models", label: "Модели", icon: "✦" },
  { to: "/vision", label: "Экран / зрение", icon: "▣" },
  { to: "/memory", label: "Память", icon: "❐" },
  { to: "/telegram", label: "Telegram", icon: "✈" },
  { to: "/security", label: "Безопасность", icon: "⛊" },
  { to: "/fun", label: "Fun", icon: "☻" },
  { to: "/diagnostics", label: "Диагностика", icon: "≡" },
  { to: "/settings", label: "Настройки", icon: "⚙" },
];

export function Sidebar() {
  const collapsed = useUiStore((s) => s.sidebarCollapsed);
  const toggleSidebar = useUiStore((s) => s.toggleSidebar);
  const connection = useSystemStore((s) => s.connection);

  return (
    <motion.aside
      animate={{ width: collapsed ? 72 : 244 }}
      transition={{ type: "spring", stiffness: 260, damping: 30 }}
      className="relative z-20 flex h-full shrink-0 flex-col border-r border-line bg-panel/70 backdrop-blur-xl"
    >
      {/* Логотип */}
      <div className="flex items-center gap-3 px-4 py-5">
        <motion.div
          animate={{ boxShadow: ["0 0 10px rgb(var(--accent-rgb) / 0.5)", "0 0 22px rgb(var(--accent-rgb) / 0.9)", "0 0 10px rgb(var(--accent-rgb) / 0.5)"] }}
          transition={{ duration: 2.6, repeat: Infinity }}
          className="h-2.5 w-2.5 shrink-0 rounded-full bg-accent"
        />
        {!collapsed ? (
          <div className="overflow-hidden">
            <h1 className="font-display text-base font-bold tracking-[0.28em] text-accent">JARVIS</h1>
            <p className="text-[10px] uppercase tracking-[0.34em] text-muted">Core Panel</p>
          </div>
        ) : null}
      </div>

      {/* Навигация */}
      <nav className="flex-1 space-y-1 overflow-y-auto px-2.5 pb-4">
        {NAV.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            title={item.label}
            className={({ isActive }) =>
              clsx(
                "group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors",
                isActive
                  ? "bg-accent/10 text-accent"
                  : "text-muted hover:bg-panel-2 hover:text-text",
              )
            }
          >
            {({ isActive }) => (
              <>
                {isActive ? (
                  <motion.span
                    layoutId="nav-marker"
                    className="absolute inset-y-1 left-0 w-1 rounded-full bg-accent"
                    style={{ boxShadow: "0 0 12px rgb(var(--accent-rgb))" }}
                  />
                ) : null}
                <span className="w-5 shrink-0 text-center text-base">{item.icon}</span>
                {!collapsed ? <span className="truncate">{item.label}</span> : null}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Подвал: статус связи + сворачивание */}
      <div className="space-y-2 border-t border-line px-3 py-3">
        {!collapsed ? (
          <div className="flex items-center gap-2 text-[11px] text-muted">
            <span
              className={clsx(
                "h-2 w-2 rounded-full",
                connection === "online"
                  ? "bg-ok shadow-[0_0_8px_#2ECC71]"
                  : connection === "connecting"
                    ? "bg-warn shadow-[0_0_8px_#F5A623]"
                    : "bg-danger shadow-[0_0_8px_#FF3B30]",
              )}
            />
            {connection === "online"
              ? "Ядро на связи"
              : connection === "connecting"
                ? "Подключение…"
                : "Нет соединения с ядром"}
          </div>
        ) : null}
        <button
          type="button"
          onClick={toggleSidebar}
          className="w-full rounded-lg border border-line px-2 py-1.5 text-xs text-muted transition-colors hover:border-accent/50 hover:text-accent"
        >
          {collapsed ? "»" : "« Свернуть"}
        </button>
      </div>
    </motion.aside>
  );
}
