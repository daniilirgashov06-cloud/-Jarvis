"""
Проверка core/security.py.

Запуск:  python3 tests/test_security.py
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.security import AccessLevel, Decision, SecurityManager


def test_risk_decisions() -> None:
    sm = SecurityManager()
    assert sm.decide("safe") is Decision.ALLOW
    assert sm.decide("medium") is Decision.CONFIRM
    assert sm.decide("high") is Decision.CONFIRM
    assert sm.decide("forbidden") is Decision.DENY
    assert sm.needs_pin("high") is True and sm.needs_pin("medium") is False
    print("  ✓ security: вердикты по уровням риска + флаг PIN")


def test_pin_and_lockout() -> None:
    sm = SecurityManager(pin="1234", max_pin_attempts=3)
    assert sm.verify_pin("u1", "1234") is True
    assert sm.verify_pin("u1", "0000") is False
    assert sm.verify_pin("u1", "0000") is False
    assert sm.verify_pin("u1", "0000") is False
    assert sm.is_locked_out("u1") is True
    assert sm.verify_pin("u1", "1234") is False  # заблокирован даже с верным PIN
    print("  ✓ security: PIN + блокировка после неудач")


def test_authorize_whitelist() -> None:
    sm = SecurityManager(allowed_users=["chat1"])
    assert sm.authorize("chat1") is True
    assert sm.authorize("intruder") is False
    sm2 = SecurityManager()  # пустой whitelist = все
    assert sm2.authorize("anyone") is True
    print("  ✓ security: whitelist пользователей")


def test_forbidden_path() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        sm = SecurityManager(forbidden_paths=[tmp])
        assert sm.check_path(tmp) is False
        assert sm.check_path(str(Path(tmp) / "sub" / "f.txt")) is False
    print("  ✓ security: запрещённые пути блокируются")


def test_authorize_action_flow() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        sm = SecurityManager(pin="9999", allowed_users=["u"], forbidden_paths=[tmp])
        # SAFE -> allow
        assert sm.authorize_action(user_id="u", risk="safe", command="list") is Decision.ALLOW
        # MEDIUM без подтверждения -> confirm
        assert sm.authorize_action(user_id="u", risk="medium", command="del") is Decision.CONFIRM
        # MEDIUM с подтверждением -> allow
        assert sm.authorize_action(user_id="u", risk="medium", command="del", confirmed=True) is Decision.ALLOW
        # HIGH с подтверждением, но неверный PIN -> confirm
        assert sm.authorize_action(user_id="u", risk="high", command="shutdown",
                                   confirmed=True, provided_pin="0000") is Decision.CONFIRM
        # HIGH с верным PIN -> allow
        assert sm.authorize_action(user_id="u", risk="high", command="shutdown",
                                   confirmed=True, provided_pin="9999") is Decision.ALLOW
        # FORBIDDEN -> deny
        assert sm.authorize_action(user_id="u", risk="forbidden", command="wipe") is Decision.DENY
        # не в whitelist -> deny
        assert sm.authorize_action(user_id="evil", risk="safe", command="list") is Decision.DENY
        # путь под запретом -> deny
        assert sm.authorize_action(user_id="u", risk="safe", command="read",
                                   args={"path": tmp}) is Decision.DENY
    print("  ✓ security: полный флоу authorize_action (allow/confirm/deny + PIN + whitelist + пути)")


def main() -> int:
    print("JARVIS CORE — проверка security")
    try:
        test_risk_decisions()
        test_pin_and_lockout()
        test_authorize_whitelist()
        test_forbidden_path()
        test_authorize_action_flow()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки security прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
