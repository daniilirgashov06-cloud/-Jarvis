"""
Проверка vision/scene.py (анализ сцены vision-моделью, клик по описанию,
голосовое редактирование).

Запуск:  python3 tests/test_scene.py
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from vision.capture import CaptureRegion, ScreenFrame  # noqa: F401 — единый импорт vision
from vision.detector import DetectionBox, DetectorRouter, ScreenDetector, TemplateDetectorEngine
from vision.ocr import OCRImage
from vision.scene import (
    EDIT_ACTIONS,
    EditPlan,
    HttpVisionEngine,
    OllamaVisionEngine,
    SceneAnalysis,
    SceneError,
    SceneRouter,
    SceneUnavailable,
    ScreenAnalyst,
    SyntheticVisionEngine,
    VisionEngine,
    default_scene_router,
    parse_edit_instruction,
)


# ---------------------------------------------------------------------------
# Вспомогательные построители
# ---------------------------------------------------------------------------
def checkerboard(size: int = 4) -> OCRImage:
    data = bytearray()
    for y in range(size):
        for x in range(size):
            data.append(255 if (x + y) % 2 == 0 else 0)
    return OCRImage(size, size, bytes(data), "L")


def blank_image(width: int = 8, height: int = 8, value: int = 128) -> OCRImage:
    return OCRImage(width, height, bytes([value]) * (width * height), "L")


def stamp(canvas: OCRImage, template: OCRImage, x: int, y: int) -> OCRImage:
    data = bytearray(canvas.data)
    gray = template.to_gray()
    for row in range(gray.height):
        for col in range(gray.width):
            data[(y + row) * canvas.width + (x + col)] = gray.data[row * gray.width + col]
    return OCRImage(canvas.width, canvas.height, bytes(data), "L")


class FakeResponse:
    """Минимальная замена HTTP-ответа для opener."""

    def __init__(self, payload: bytes) -> None:
        self._payload = payload

    def read(self, _n: int = -1) -> bytes:
        return self._payload

    def __enter__(self) -> "FakeResponse":
        return self

    def __exit__(self, *exc: object) -> None:
        return None


def make_opener(payload: bytes, calls: list):
    def opener(request, timeout=None):  # noqa: ANN001 — сигнатура urlopen
        calls.append((request, timeout))
        return FakeResponse(payload)

    return opener


def failing_opener(exc: Exception):
    def opener(request, timeout=None):  # noqa: ANN001
        raise exc

    return opener


# ---------------------------------------------------------------------------
# 1. Валидация и SceneAnalysis
# ---------------------------------------------------------------------------
def test_analysis_validation_and_search() -> None:
    box = DetectionBox(label="Кнопка", x=1, y=2, width=3, height=4, confidence=80.0)
    analysis = SceneAnalysis(
        description="Экран с кнопкой",
        objects=(box,),
        answer="Кнопка справа",
        question="Где кнопка?",
        engine="synthetic",
        elapsed_ms=12.5,
    )
    assert analysis.find("кнопка")[0] is box
    assert analysis.best("кнопка") is box
    assert analysis.best("нет такой") is None
    assert analysis.labels == ("Кнопка",)
    d = analysis.to_dict()
    assert d["objects"][0]["label"] == "Кнопка" and d["elapsed_ms"] == 12.5
    prompt = analysis.to_prompt_text()
    assert "Сцена: Экран с кнопкой" in prompt and "Ответ: Кнопка справа" in prompt

    empty = SceneAnalysis()
    assert empty.labels == () and "без описания" in empty.to_prompt_text()

    for kwargs in [
        {"description": "a\x00b"},
        {"answer": "x\x07y"},
        {"objects": tuple(DetectionBox("о", 0, 0, 1, 1) for _ in range(257))},
        {"elapsed_ms": "fast"},
    ]:
        try:
            SceneAnalysis(**kwargs)  # type: ignore[arg-type]
        except SceneError:
            pass
        else:
            raise AssertionError(f"SceneAnalysis({kwargs!r}) должен быть отклонён")
    print("  ✓ SceneAnalysis: валидация, поиск объектов, to_dict/to_prompt_text")


# ---------------------------------------------------------------------------
# 2. Разбор голосовых инструкций
# ---------------------------------------------------------------------------
def test_parse_edit_instruction() -> None:
    plan = parse_edit_instruction("кликни на кнопку «Пуск»")
    assert plan.action == "click" and plan.target == "Пуск", plan
    assert plan.needs_confirmation is False and plan.point is None

    plan = parse_edit_instruction("нажми кнопку сохранить")
    assert plan.action == "click" and "сохранить" in plan.target

    plan = parse_edit_instruction("введи «привет мир»")
    assert plan.action == "type" and plan.text == "привет мир", plan
    assert plan.target == "" and plan.needs_confirmation is False

    plan = parse_edit_instruction("прокрути вниз")
    assert plan.action == "scroll" and plan.target == "down"
    assert plan.needs_confirmation is False

    plan = parse_edit_instruction("scroll up")
    assert plan.action == "scroll" and plan.target == "up"

    plan = parse_edit_instruction("расскажи анекдот")
    assert plan.action == "unknown" and plan.needs_confirmation is True

    plan = parse_edit_instruction("кликни")
    assert plan.action == "click" and plan.needs_confirmation is True

    assert EDIT_ACTIONS == frozenset({"click", "type", "scroll", "unknown"})
    for bad in ["", "   ", "кликни \x00", "x" * 2000]:
        try:
            parse_edit_instruction(bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"parse_edit_instruction({bad[:20]!r}) должен быть отклонён")
    try:
        EditPlan(action="dance")  # type: ignore[arg-type]
    except SceneError:
        pass
    else:
        raise AssertionError("EditPlan с неизвестным действием должен быть отклонён")
    try:
        EditPlan(action="click", point=(-1, 2))  # type: ignore[arg-type]
    except SceneError:
        pass
    else:
        raise AssertionError("EditPlan с отрицательной точкой должен быть отклонён")
    print("  ✓ parse_edit_instruction: ru/en глаголы, кавычки, unknown, валидация EditPlan")


# ---------------------------------------------------------------------------
# 3. Синтетика + роутер (смена движков + fallback)
# ---------------------------------------------------------------------------
class BrokenEngine(VisionEngine):
    """Движок, всегда падающий — проверка fallback."""

    name = "broken"

    def is_available(self) -> bool:
        return True

    def analyze(self, image, *, question=None):  # noqa: ANN001
        raise SceneError("сломанный движок")


def test_synthetic_and_router() -> None:
    img = blank_image()
    box = DetectionBox(label="иконка", x=0, y=0, width=2, height=2, confidence=50.0)
    synth = SyntheticVisionEngine(
        description="рабочий стол", objects=(box,), answer_template="ответ: {question}"
    )
    result = synth.analyze(img, question="что на экране?")
    assert result.description == "рабочий стол"
    assert result.answer == "ответ: что на экране?"
    assert result.best("Иконка") is box and result.engine == "synthetic"

    router = SceneRouter(
        {"broken": BrokenEngine(), "synthetic": synth},
        primary="broken",
        fallback_chain=["broken", "synthetic"],
    )
    result = router.analyze(img)
    assert result.engine == "synthetic", "fallback обязан уйти в synthetic"

    router.set_primary("synthetic")
    assert router.primary == "synthetic"
    assert router.available() == ["broken", "synthetic"]
    assert router.analyze(img).engine == "synthetic"

    try:
        router.set_primary("ghost")
    except SceneError:
        pass
    else:
        raise AssertionError("неизвестный движок должен быть отклонён")

    empty_router = SceneRouter({}, primary="none")
    try:
        empty_router.analyze(img)
    except SceneError:
        pass
    else:
        raise AssertionError("пустой роутер должен падать SceneError")

    info = router.describe()
    assert info["primary"] == "synthetic" and "synthetic" in info["engines"]
    print("  ✓ синтетика + SceneRouter: fallback, set_primary, describe")


# ---------------------------------------------------------------------------
# 4. Облачный движок (HTTP)
# ---------------------------------------------------------------------------
def test_http_engine() -> None:
    calls: list = []
    payload = json.dumps(
        {
            "description": "окно браузера",
            "answer": "вкладка открыта",
            "objects": [
                {"label": "вкладка", "x": 1, "y": 2, "width": 3, "height": 4, "confidence": 90}
            ],
        }
    ).encode("utf-8")
    engine = HttpVisionEngine(
        "https://example.test/vision", opener=make_opener(payload, calls)
    )
    assert engine.is_available()
    os.environ["JARVIS_VISION_API_KEY"] = "secret-123"
    try:
        result = engine.analyze(blank_image(), question="что открыто?")
    finally:
        os.environ.pop("JARVIS_VISION_API_KEY", None)
    assert result.description == "окно браузера" and result.answer == "вкладка открыта"
    assert result.objects[0].label == "вкладка" and result.engine == "http"

    request, timeout = calls[0]
    body = json.loads(request.data.decode("utf-8"))
    assert body["question"] == "что открыто?" and len(body["image"]) > 16
    assert request.get_header("Authorization") == "Bearer secret-123"
    assert timeout == 30.0
    assert engine.describe()["endpoint"] == "https://example.test/vision"

    # битый JSON → SceneError; сеть → SceneUnavailable
    bad = HttpVisionEngine(
        "https://example.test/vision", opener=make_opener("не json".encode("utf-8"), [])
    )
    try:
        bad.analyze(blank_image())
    except SceneError as exc:
        assert not isinstance(exc, SceneUnavailable)
    else:
        raise AssertionError("не-JSON ответ должен давать SceneError")

    dead = HttpVisionEngine(
        "https://example.test/vision",
        opener=failing_opener(urllib.error.URLError("нет сети")),
    )
    try:
        dead.analyze(blank_image())
    except SceneUnavailable:
        pass
    else:
        raise AssertionError("сетевой сбой должен давать SceneUnavailable")

    for bad_endpoint in ["ftp://x", "", 42]:
        try:
            HttpVisionEngine(bad_endpoint)  # type: ignore[arg-type]
        except ValueError:
            pass
        else:
            raise AssertionError(f"endpoint {bad_endpoint!r} должен быть отклонён")
    print("  ✓ HttpVisionEngine: запрос/ответ, Authorization из env, ошибки")


# ---------------------------------------------------------------------------
# 5. Локальный движок (Ollama)
# ---------------------------------------------------------------------------
def test_ollama_engine() -> None:
    calls: list = []
    content = json.dumps(
        {
            "description": "терминал",
            "answer": "идёт сборка",
            "objects": [{"label": "окно", "x": 0, "y": 0, "width": 10, "height": 10, "confidence": 70}],
        }
    )
    payload = json.dumps({"message": {"content": content}}).encode("utf-8")
    engine = OllamaVisionEngine(opener=make_opener(payload, calls))
    result = engine.analyze(blank_image(), question="что происходит?")
    assert result.description == "терминал" and result.answer == "идёт сборка"
    assert result.objects[0].label == "окно" and result.engine == "ollama"

    request, _timeout = calls[0]
    body = json.loads(request.data.decode("utf-8"))
    assert body["model"] == "llava" and body["stream"] is False
    assert request.full_url.endswith("/api/chat")
    assert "Вопрос: что происходит?" in body["messages"][0]["content"]
    assert len(body["messages"][0]["images"][0]) > 16

    # свободный текст без JSON — нормальная деградация в описание
    plain = OllamaVisionEngine(
        opener=make_opener(
            json.dumps({"message": {"content": "На экране открыт редактор."}}).encode("utf-8"), []
        )
    )
    result = plain.analyze(blank_image())
    assert result.description == "На экране открыт редактор." and result.objects == ()

    empty = OllamaVisionEngine(
        opener=make_opener(json.dumps({"message": {"content": "  "}}).encode("utf-8"), [])
    )
    try:
        empty.analyze(blank_image())
    except SceneError:
        pass
    else:
        raise AssertionError("пустой ответ модели должен давать SceneError")

    dead = OllamaVisionEngine(opener=failing_opener(OSError("connection refused")))
    try:
        dead.analyze(blank_image())
    except SceneUnavailable:
        pass
    else:
        raise AssertionError("сбой Ollama должен давать SceneUnavailable")

    for kwargs in [{"endpoint": "x"}, {"model": " "}, {"timeout": 0}, {"prompt": "a\x00b"}]:
        try:
            OllamaVisionEngine(**kwargs)  # type: ignore[arg-type]
        except ValueError:
            pass
        else:
            raise AssertionError(f"OllamaVisionEngine({kwargs!r}) должен быть отклонён")
    print("  ✓ OllamaVisionEngine: JSON/свободный текст, /api/chat, ошибки")


# ---------------------------------------------------------------------------
# 6. ScreenAnalyst: описание, клик по описанию, голосовое редактирование
# ---------------------------------------------------------------------------
def test_screen_analyst() -> None:
    template = checkerboard(4)
    canvas = blank_image(16, 16)
    canvas = stamp(canvas, template, 6, 5)
    box = DetectionBox(label="шаблон", x=6, y=5, width=4, height=4, confidence=100.0)
    synth = SyntheticVisionEngine(
        description="сцена",
        objects=(DetectionBox(label="шаблон", x=0, y=0, width=2, height=2, confidence=10.0),),
    )
    detector = ScreenDetector(
        DetectorRouter({"template": TemplateDetectorEngine({"шаблон": template})}),
        preprocess=(),
    )
    analyst = ScreenAnalyst(SceneRouter({"synthetic": synth}, primary="synthetic"), detector=detector)

    # описание / вопрос-ответ
    assert analyst.describe(canvas).description == "сцена"
    assert analyst.ask(canvas, "что тут?").answer == "Синтетический ответ на вопрос: что тут?"

    # клик по описанию: точность детектора важнее коробки vision-модели
    found = analyst.locate(canvas, "шаблон")
    assert found is not None and found.x == 6 and found.y == 5, found
    assert analyst.click_point(canvas, "шаблон") == (8, 7)

    clicks: list = []
    assert analyst.click(canvas, "шаблон", click=lambda x, y: clicks.append((x, y)))
    assert clicks == [(8, 7)]
    assert not analyst.click(canvas, "нет такого объекта", click=lambda x, y: clicks.append((x, y)))
    assert clicks == [(8, 7)]

    # без детектора коробку даёт vision-модель
    plain = ScreenAnalyst(SceneRouter({"synthetic": synth}, primary="synthetic"))
    assert plain.click_point(canvas, "шаблон") == (1, 1)

    # голосовое редактирование: план → исполнение
    plan = analyst.plan_edit(canvas, "кликни на «шаблон»")
    assert plan.action == "click" and plan.point == (8, 7) and not plan.needs_confirmation
    clicks.clear()
    assert analyst.apply_edit(canvas, plan, click=lambda x, y: clicks.append((x, y)))
    assert clicks == [(8, 7)]

    plan = analyst.plan_edit(canvas, "введи «привет»")
    assert plan.action == "type" and plan.text == "привет"
    assert plan.point is None  # ввод в активное поле — без клика
    typed: list = []
    clicks.clear()
    assert analyst.apply_edit(
        canvas, plan, click=lambda x, y: clicks.append((x, y)), type_text=typed.append
    )
    assert clicks == [] and typed == ["привет"]

    # ввод с явной целью-полем: клик по полю → ввод текста
    plan_field = analyst.plan_edit(canvas, "кликни на «шаблон» и введи «раз»")
    assert plan_field.action == "click"  # первый глагол — клик
    assert plan_field.point == (8, 7)
    typed.clear()
    clicks.clear()
    plan_type = EditPlan(action="type", text="раз", point=(8, 7), needs_confirmation=False)
    assert analyst.apply_edit(
        canvas, plan_type, click=lambda x, y: clicks.append((x, y)), type_text=typed.append
    )
    assert clicks == [(8, 7)] and typed == ["раз"]

    scrolled: list = []
    plan = parse_edit_instruction("прокрути вниз")
    assert analyst.apply_edit(canvas, plan, scroll=scrolled.append)
    assert scrolled == ["down"]

    # неоднозначное НЕ исполняется
    assert not analyst.apply_edit(
        canvas, parse_edit_instruction("сделай красиво"), click=lambda x, y: None
    )
    plan_noobj = analyst.plan_edit(canvas, "кликни на «фантом»")
    assert plan_noobj.needs_confirmation and plan_noobj.point is None
    assert not analyst.apply_edit(canvas, plan_noobj, click=lambda x, y: None)

    for bad in ["not-analyst", None]:
        try:
            ScreenAnalyst(bad)  # type: ignore[arg-type]
        except TypeError:
            pass
        else:
            raise AssertionError("ScreenAnalyst с не-роутером должен быть отклонён")
    try:
        analyst.apply_edit(canvas, "plan")  # type: ignore[arg-type]
    except TypeError:
        pass
    else:
        raise AssertionError("apply_edit с не-планом должен быть отклонён")
    print("  ✓ ScreenAnalyst: describe/ask, locate/click по описанию, plan_edit/apply_edit")


# ---------------------------------------------------------------------------
# 7. Сборка по умолчанию
# ---------------------------------------------------------------------------
def test_default_router() -> None:
    router = default_scene_router()
    assert router.primary == "ollama" and set(router.available()) == {"ollama", "synthetic"}

    router = default_scene_router(cloud_endpoint="https://example.test/vision")
    assert "http" in router.available() and router.describe()["primary"] == "ollama"
    print("  ✓ default_scene_router: локально-first, облако opt-in")


def main() -> int:
    print("JARVIS CORE — проверка vision/scene")
    try:
        test_analysis_validation_and_search()
        test_parse_edit_instruction()
        test_synthetic_and_router()
        test_http_engine()
        test_ollama_engine()
        test_screen_analyst()
        test_default_router()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки vision/scene прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
