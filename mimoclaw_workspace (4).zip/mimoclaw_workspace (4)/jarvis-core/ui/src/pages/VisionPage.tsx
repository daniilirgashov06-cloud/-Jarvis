/**
 * Экран / зрение — скриншоты, OCR, фоновая осведомлённость о экране.
 */

import { useEffect } from "react";
import { Card, Notice, PageHeader } from "../components/ui/panels";
import { SettingsSaveBar } from "../components/SettingsSaveBar";
import { FieldRow, Slider, TextField, Toggle } from "../components/ui/controls";
import { useSettingsStore } from "../stores/settingsStore";

export function VisionPage() {
  const vision = useSettingsStore((s) => s.data.vision);
  const loaded = useSettingsStore((s) => s.loaded);
  const patch = useSettingsStore((s) => s.patch);

  useEffect(() => {
    if (!loaded) void useSettingsStore.getState().load();
  }, [loaded]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Экран / зрение"
        subtitle="Захват экрана, распознавание текста и периодический анализ рабочего пространства."
      />

      <Notice tone="info">
        Скриншоты обрабатываются локально. Маскирование паролей включено по умолчанию —
        поля ввода с текстом-пароля не попадают в снимки и OCR.
      </Notice>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card title="Основные параметры">
          <FieldRow
            label="Зрение включено"
            hint="Разрешить ассистенту «видеть» экран"
            control={<Toggle checked={vision.enabled} onChange={(v) => patch("vision", { enabled: v })} />}
          />
          <FieldRow
            label="Фоновый анализ экрана"
            hint="Периодически осматривать рабочее пространство"
            control={
              <Toggle checked={vision.screen_awareness} onChange={(v) => patch("vision", { screen_awareness: v })} />
            }
          />
          <div className="mt-3">
            <Slider
              label="Интервал анализа"
              min={10}
              max={600}
              step={10}
              value={vision.awareness_interval_s}
              onChange={(v) => patch("vision", { awareness_interval_s: v })}
              format={(v) => `${v} с`}
              hint="Как часто ядро осматривает экран"
            />
          </div>
          <div className="mt-3">
            <Slider
              label="Частота кадров захвата"
              min={1}
              max={10}
              step={1}
              value={vision.capture_fps}
              onChange={(v) => patch("vision", { capture_fps: v })}
              format={(v) => `${v} FPS`}
            />
          </div>
        </Card>

        <Card title="OCR и хранение" subtitle="Распознавание текста и приватность" delay={0.05}>
          <TextField
            label="Языки OCR"
            value={vision.ocr_language}
            placeholder="rus+eng"
            onChange={(e) => patch("vision", { ocr_language: e.target.value })}
            hint="Формат Tesseract, например: rus+eng"
          />
          <div className="mt-3 divide-y divide-line">
            <FieldRow
              label="Хранить скриншоты"
              hint="Сохранять снимки на диск"
              control={
                <Toggle checked={vision.store_screenshots} onChange={(v) => patch("vision", { store_screenshots: v })} />
              }
            />
            <FieldRow
              label="Маскировать пароли"
              hint="Прятать поля ввода паролей"
              control={<Toggle checked={vision.mask_passwords} onChange={(v) => patch("vision", { mask_passwords: v })} />}
            />
          </div>
          <div className="mt-3">
            <Slider
              label="Хранить снимки, дней"
              min={1}
              max={90}
              step={1}
              value={vision.retention_days}
              onChange={(v) => patch("vision", { retention_days: v })}
              format={(v) => `${v} дн.`}
              hint="После срока файлы удаляются автоматически"
            />
          </div>
        </Card>
      </div>

      <SettingsSaveBar />
    </div>
  );
}
