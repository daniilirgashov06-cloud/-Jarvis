/**
 * Демо-каталог команд панели.
 *
 * Используется, когда ядро не отдаёт REST `/api/commands` (эндпоинт ещё не
 * поднят или панель открыта без бэкенда). Имена и уровни риска отражают
 * реальные модули `actions/*`, `vision/*`, `fun/*`.
 */

import type { CommandInfo } from "../types/commands";

function cmd(
  name: string,
  description: string,
  risk: CommandInfo["risk"],
  params: CommandInfo["params"] = [],
): CommandInfo {
  return {
    name,
    description,
    risk,
    params,
    enabled: true,
    requires_confirmation: risk !== "safe",
    source: "demo",
  };
}

export const DEMO_COMMANDS: CommandInfo[] = [
  // --- звук и медиа -------------------------------------------------------
  cmd("set_volume", "Установить громкость системы (0..100)", "safe", [
    { name: "level", type: "number", description: "Уровень 0..100", required: true },
  ]),
  cmd("get_volume", "Текущая громкость системы", "safe"),
  cmd("play_music", "Запустить воспроизведение медиа", "safe"),
  cmd("pause_media", "Пауза/продолжить медиа", "safe"),
  cmd("next_track", "Следующий трек", "safe"),
  cmd("mute_mic", "Включить/выключить микрофон", "safe"),

  // --- приложения и окна --------------------------------------------------
  cmd("open_app", "Запустить приложение по имени", "medium", [
    { name: "app", type: "string", description: "Имя приложения", required: true },
  ]),
  cmd("close_app", "Закрыть приложение", "medium", [
    { name: "app", type: "string", description: "Имя приложения", required: true },
  ]),
  cmd("lock_screen", "Заблокировать экран", "medium"),
  cmd("minimize_all", "Свернуть все окна", "safe"),

  // --- ввод ---------------------------------------------------------------
  cmd("type_text", "Напечатать текст в активном поле", "medium", [
    { name: "text", type: "string", description: "Текст для ввода", required: true },
  ]),
  cmd("press_hotkey", "Нажать сочетание клавиш", "medium", [
    { name: "keys", type: "string", description: "Напр. ctrl+shift+p", required: true },
  ]),
  cmd("mouse_click", "Кликнуть мышью по координатам", "medium", [
    { name: "x", type: "number", required: true },
    { name: "y", type: "number", required: true },
  ]),

  // --- файлы --------------------------------------------------------------
  cmd("list_files", "Показать файлы в папке", "safe", [
    { name: "path", type: "string", description: "Путь к папке", required: true },
  ]),
  cmd("search_files", "Найти файлы по маске", "safe", [
    { name: "pattern", type: "string", description: "Маска, напр. *.pdf", required: true },
  ]),
  cmd("open_file", "Открыть файл в приложении по умолчанию", "medium", [
    { name: "path", type: "string", required: true },
  ]),
  cmd("copy_file", "Скопировать файл", "medium", [
    { name: "src", type: "string", required: true },
    { name: "dst", type: "string", required: true },
  ]),
  cmd("delete_file", "Удалить файл (в корзину)", "high", [
    { name: "path", type: "string", required: true },
  ]),

  // --- код и оболочка -----------------------------------------------------
  cmd("run_python", "Выполнить Python-скрипт в песочнице", "high", [
    { name: "script", type: "string", required: true },
  ]),
  cmd("run_shell", "Выполнить команду оболочки (PowerShell/bash)", "forbidden", [
    { name: "command", type: "string", required: true },
  ]),

  // --- браузер ------------------------------------------------------------
  cmd("open_url", "Открыть URL в браузере", "safe", [
    { name: "url", type: "string", required: true },
  ]),
  cmd("browser_search", "Поиск в интернете", "safe", [
    { name: "query", type: "string", required: true },
  ]),
  cmd("browser_extract", "Извлечь текст текущей страницы", "safe"),

  // --- экран и зрение -----------------------------------------------------
  cmd("take_screenshot", "Сделать скриншот экрана", "safe"),
  cmd("describe_screen", "Описать, что сейчас на экране (vision)", "safe"),
  cmd("read_text_ocr", "Распознать текст на экране (OCR)", "safe"),

  // --- продуктивность -----------------------------------------------------
  cmd("set_timer", "Поставить таймер", "safe", [
    { name: "duration_sec", type: "number", required: true },
  ]),
  cmd("add_note", "Заметка в память", "safe", [
    { name: "text", type: "string", required: true },
  ]),
  cmd("add_reminder", "Напоминание", "safe", [
    { name: "text", type: "string", required: true },
    { name: "when", type: "string", description: "Когда напомнить" },
  ]),
  cmd("show_calendar", "Ближайшие события календаря", "safe"),

  // --- память и персона ---------------------------------------------------
  cmd("remember_fact", "Запомнить факт о пользователе", "safe", [
    { name: "fact", type: "string", required: true },
  ]),
  cmd("forget_memory", "Удалить запись из памяти", "high", [
    { name: "query", type: "string", required: true },
  ]),
  cmd("switch_persona", "Переключить персону (JARVIS/FRIDAY)", "safe", [
    { name: "persona", type: "string", description: "jarvis | friday" },
  ]),
  cmd("system_stats", "Статистика системы (ЦП/ОЗУ/диски)", "safe"),

  // --- сеть/внешние действия ---------------------------------------------
  cmd("send_telegram", "Отправить сообщение в Telegram", "high", [
    { name: "text", type: "string", required: true },
  ]),
  cmd("shutdown_pc", "Выключить компьютер", "forbidden"),
  cmd("reboot_pc", "Перезагрузить компьютер", "forbidden"),
];
