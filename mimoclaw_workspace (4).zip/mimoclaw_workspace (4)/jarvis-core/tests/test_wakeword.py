"""
Проверка модуля audio/wakeword: конфиг, движки (openwakeword / template),
роутер с fallback, детектор слова активации с cooldown.

Запуск:  python3 tests/test_wakeword.py
"""

from __future__ import annotations

import math
import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from audio.wakeword import (
    OpenWakeWordEngine,
    TemplateWakeWordEngine,
    WakeWordConfig,
    WakeWordDetector,
    WakeWordEngine,
    WakeWordError,
    WakeWordEvent,
    WakeWordResult,
    WakeWordRouter,
    WakeWordUnavailable,
    create_default_router,
    normalize_word,
)


# ---------------------------------------------------------------------------
# Хелперы синтеза PCM (s16le, 16 кГц, моно)
# ---------------------------------------------------------------------------
def silence_ms(duration_ms: int = 1000, sample_rate: int = 16000) -> bytes:
    return b"\x00\x00" * (sample_rate * duration_ms // 1000)


def pattern_ms(
    duration_ms: int = 1000,
    bursts: int = 4,
    burst_ms: int = 120,
    amplitude: float = 0.5,
    freq: float = 440.0,
    sample_rate: int = 16000,
) -> bytes:
    """PCM с «слоговым» ритмом: bursts коротких тоновых пачек через паузы."""
    total = sample_rate * duration_ms // 1000
    cycle = max(1, total // max(1, bursts))
    burst_len = sample_rate * burst_ms // 1000
    out = bytearray()
    for i in range(total):
        pos = i % cycle
        env = 1.0 if pos < burst_len else 0.0
        sample = env * amplitude * 32767.0 * math.sin(2.0 * math.pi * freq * i / sample_rate)
        out += struct.pack("<h", int(sample))
    return bytes(out)


def tone_ms(duration_ms: int = 1000, amplitude: float = 0.5,
            freq: float = 440.0, sample_rate: int = 16000) -> bytes:
    """Сплошной тон (равномерная огибающая)."""
    out = bytearray()
    for i in range(sample_rate * duration_ms // 1000):
        sample = amplitude * 32767.0 * math.sin(2.0 * math.pi * freq * i / sample_rate)
        out += struct.pack("<h", int(sample))
    return bytes(out)


class ScriptedEngine(WakeWordEngine):
    """Движок-заглушка: вернёт заранее заданные вердикты по очереди."""

    name = "scripted"

    def __init__(self, results: list[WakeWordResult], available: bool = True,
                 fail: bool = False) -> None:
        self.results = list(results)
        self.available = available
        self.fail = fail
        self.calls = 0

    def is_available(self) -> bool:
        return self.available

    def detect(self, pcm: bytes, *, sample_rate: int = 16000) -> WakeWordResult:
        self.calls += 1
        if self.fail:
            raise WakeWordUnavailable("scripted: отказ")
        if not self.results:
            return WakeWordResult(detected=False, engine=self.name)
        r = self.results.pop(0)
        return WakeWordResult(
            detected=r.detected, word=r.word, score=r.score, engine=self.name
        )


# ---------------------------------------------------------------------------
def test_config_geometry_and_words() -> None:
    cfg = WakeWordConfig()
    assert cfg.frame_samples == 320, f"frame_samples={cfg.frame_samples}"
    assert cfg.frame_bytes == 640, f"frame_bytes={cfg.frame_bytes}"
    assert cfg.window_samples == 28800, f"window_samples={cfg.window_samples}"
    assert cfg.ms_to_frames(1500) == 75, "cooldown_ms=1500 → 75 кадров"
    assert cfg.ms_to_frames(0) == 1, "0 мс → минимум 1 кадр"
    assert normalize_word("  ДЖАРВИС ") == "джарвис", "нормализация слова"
    cfg2 = WakeWordConfig(words=("  Джарвис ", "Пятница"))
    assert cfg2.words == ("джарвис", "пятница"), f"words не нормализованы: {cfg2.words}"
    print("  ✓ config: геометрия кадров/окна, нормализация слов")


def test_result_and_event_clamping() -> None:
    res = WakeWordResult(detected=True, word="Пятница", score=1.7, engine="x")
    assert res.score == 1.0, f"score не прижат сверху: {res.score}"
    assert res.word == "пятница", f"word не нормализован: {res.word}"
    res2 = WakeWordResult(detected=False, score=-0.2)
    assert res2.score == 0.0, f"score не прижат снизу: {res2.score}"
    ev = WakeWordEvent(word="Джарвис", score=0.9)
    assert ev.word == "джарвис", f"слово события не нормализовано: {ev.word}"
    print("  ✓ result/event: score в [0..1], слово в нижнем регистре")


def test_template_requires_templates() -> None:
    eng = TemplateWakeWordEngine()
    assert not eng.is_available(), "пустой template-движок не должен считаться доступным"
    try:
        eng.detect(pattern_ms(200))
    except WakeWordUnavailable:
        pass
    else:
        assert False, "без шаблонов detect() обязан бросать WakeWordUnavailable"
    try:
        eng.add_template("джарвис", b"\x00\x00\x00\x00")
    except WakeWordError:
        pass
    else:
        assert False, "слишком короткий шаблон должен давать WakeWordError"
    print("  ✓ template: без шаблонов → WakeWordUnavailable, короткий шаблон → ошибка")


def test_template_matches_itself_and_rejects_noise() -> None:
    tpl = pattern_ms(1000)
    eng = TemplateWakeWordEngine(threshold=0.5)
    eng.add_template("джарвис", tpl)
    assert eng.is_available(), "после add_template движок должен быть доступен"
    assert eng.words() == ["джарвис"], f"words()={eng.words()}"

    res = eng.detect(tpl)
    assert res.detected, f"шаблон не распознал сам себя: {res}"
    assert res.word == "джарвис", f"слово: {res.word}"
    assert res.score >= 0.9, f"score копии шаблона: {res.score}"

    eng.reset()
    res_quiet = eng.detect(silence_ms(1000))
    assert not res_quiet.detected, f"тишина распознана как wake-word: {res_quiet}"

    eng.reset()
    res_tone = eng.detect(tone_ms(1000))
    assert not res_tone.detected, f"сплошной тон распознан как wake-word: {res_tone}"

    eng.reset()
    res_amp = eng.detect(pattern_ms(1000, amplitude=0.1))
    assert res_amp.detected, f"тихая копия шаблона не распознана: {res_amp}"
    assert res_amp.score >= 0.9, f"score тихой копии: {res_amp.score}"

    eng.reset()
    res_half = eng.detect(pattern_ms(500))  # половина ритма — не слово
    assert not res_half.detected, f"половина шаблона сработала: {res_half}"

    try:
        eng.detect(b"")
    except WakeWordError:
        pass
    else:
        assert False, "пустой PCM должен давать WakeWordError"
    print("  ✓ template: копия шаблона ✓, тишина/тон/половина ✗, амплитудо-инвариантность")


def test_template_word_filtering() -> None:
    tpl = pattern_ms(1000)
    cfg = WakeWordConfig(words=("пятница",))
    eng = TemplateWakeWordEngine(threshold=0.5, config=cfg)
    eng.add_template("джарвис", tpl)
    res = eng.detect(tpl)
    assert not res.detected, f"слово вне списка активации сработало: {res}"

    eng2 = TemplateWakeWordEngine(threshold=0.5, config=cfg)
    eng2.add_template("пятница", tpl)
    res2 = eng2.detect(tpl)
    assert res2.detected, f"слово из списка активации не сработало: {res2}"
    assert res2.word == "пятница", f"word: {res2.word}"
    print("  ✓ template: фильтр по списку слов активации")


def test_openwakeword_contract() -> None:
    eng = OpenWakeWordEngine()
    if not eng.is_available():
        try:
            eng.detect(pattern_ms(200))
        except WakeWordUnavailable:
            pass
        else:
            assert False, "без openwakeword detect() обязан бросать WakeWordUnavailable"
        print("  ✓ openwakeword: не установлен → WakeWordUnavailable (контракт fallback)")
    else:
        try:
            res = eng.detect(pattern_ms(200))
        except WakeWordUnavailable:
            pass  # модель не загрузилась — тоже легальный контракт
        else:
            assert isinstance(res, WakeWordResult), f"не WakeWordResult: {res}"
        print("  ✓ openwakeword: установлен → контракт вердикта проверен")

    eng2 = OpenWakeWordEngine(words=("пятница",))  # без model_paths
    assert not eng2.is_available(), "слово без модели не должно считаться доступным"
    try:
        eng2.detect(pattern_ms(200))
    except WakeWordUnavailable:
        pass
    else:
        assert False, "слово без модели → WakeWordUnavailable"


def test_router_fallback_and_switch() -> None:
    fake_fail = ScriptedEngine([], fail=True)
    eng = TemplateWakeWordEngine(threshold=0.5)
    eng.add_template("джарвис", pattern_ms(1000))
    router = WakeWordRouter(
        engines={"scripted": fake_fail, "template": eng},
        primary="scripted",
        fallback_chain=["scripted", "template"],
    )
    res = router.detect(pattern_ms(1000))
    assert res.engine == "template", f"fallback не сработал: {res}"
    assert fake_fail.calls == 1, "scripted должен был попробоваться первым"

    router.set_primary("template")
    assert router.primary == "template", "set_primary не переключил"
    res2 = router.detect(pattern_ms(1000))
    assert res2.engine == "template", f"primary не template: {res2}"
    assert "template" in router.available(), "template должен быть в available()"

    try:
        router.set_primary("nope")
    except WakeWordError:
        pass
    else:
        assert False, "неизвестный движок должен давать WakeWordError"

    dead = WakeWordRouter(engines={"x": ScriptedEngine([], available=False)}, primary="x")
    try:
        dead.detect(pattern_ms(200))
    except WakeWordError:
        pass
    else:
        assert False, "без рабочих движков — WakeWordError"
    print("  ✓ router: fallback, смена primary, недоступные движки")


def test_router_forced_engine() -> None:
    fake = ScriptedEngine([WakeWordResult(detected=True, word="джарвис", score=0.9)])
    eng = TemplateWakeWordEngine(threshold=0.5)
    eng.add_template("джарвис", pattern_ms(1000))
    router = WakeWordRouter(
        engines={"scripted": fake, "template": eng}, primary="template"
    )
    res = router.detect(pattern_ms(200), engine="scripted")
    assert res.engine == "scripted", f"явный движок не использован: {res}"
    assert fake.calls == 1, "scripted должен был вызваться ровно один раз"
    print("  ✓ router: принудительный выбор движка")


def test_detector_events_and_cooldown() -> None:
    cfg = WakeWordConfig(cooldown_ms=200)  # 10 кадров
    script = ScriptedEngine(
        [
            WakeWordResult(detected=True, word="джарвис", score=0.4),  # ниже порога
            WakeWordResult(detected=True, word="пятница", score=0.9),  # событие
            WakeWordResult(detected=True, word="пятница", score=1.0),  # в cooldown
        ]
    )
    router = WakeWordRouter(engines={"scripted": script}, primary="scripted")
    det = WakeWordDetector(router=router, config=cfg)

    frame = b"\x01\x00" * cfg.frame_samples
    assert det.feed(b"\x00\x00") == [], "хвост короче кадра должен игнорироваться"
    assert script.calls == 0, "неполный кадр не должен попадать в движок"

    assert det.feed(frame) == [], "score ниже порога не должен давать событие"
    assert not det.in_cooldown, "cooldown не должен включаться без срабатывания"

    events = det.feed(frame)
    assert len(events) == 1, f"ожидалось 1 событие, получено {len(events)}"
    ev = events[0]
    assert isinstance(ev, WakeWordEvent), f"не WakeWordEvent: {ev}"
    assert ev.word == "пятница", f"word: {ev.word}"
    assert ev.score >= cfg.threshold, f"score: {ev.score}"
    assert ev.pcm, "PCM окна в событии пуст"
    assert det.in_cooldown, "после срабатывания должен включиться cooldown"

    # Всё окно cooldown — без событий и без походов в движок.
    calls_before = script.calls
    for _ in range(10):
        assert det.feed(frame) == [], "в cooldown не должно быть событий"
    assert script.calls == calls_before, "в cooldown движок вызываться не должен"

    events2 = det.feed(frame)  # cooldown истёк → третий вердикт из сценария
    assert len(events2) == 1, f"после cooldown ожидалось событие: {events2}"
    assert det.flush() == [], "flush не должен выдавать событий"
    assert not det.in_cooldown, "после flush cooldown должен сброситься"
    print("  ✓ detector: порог, событие, cooldown, flush")


def test_detector_template_integration() -> None:
    cfg = WakeWordConfig(cooldown_ms=1500)
    tpl = pattern_ms(1000)
    eng = TemplateWakeWordEngine(threshold=cfg.threshold, config=cfg)
    eng.add_template("джарвис", tpl)
    router = WakeWordRouter(engines={"template": eng}, primary="template")
    det = WakeWordDetector(router=router, config=cfg)

    events = det.feed(tpl)
    assert len(events) == 1, f"ожидалось ровно 1 событие, получено {len(events)}"
    assert events[0].word == "джарвис", f"word: {events[0].word}"
    assert events[0].score >= cfg.threshold, f"score: {events[0].score}"
    assert events[0].pcm, "PCM окна в событии пуст"

    assert det.feed(tpl) == [], "повтор в cooldown не должен срабатывать"
    assert det.feed(silence_ms(2000)) == [], "тишина не должна давать событий"
    events2 = det.feed(tpl)
    assert len(events2) == 1, f"после cooldown ожидалось повторное событие: {events2}"
    print("  ✓ detector + template: интеграция «шаблон → событие → cooldown»")


def test_default_router() -> None:
    router = create_default_router()
    assert router.primary == "openwakeword", f"primary: {router.primary}"
    assert set(router._chain(None)) == {"openwakeword", "template"}, "цепочка fallback"
    assert "openwakeword" in router._engines and "template" in router._engines
    print("  ✓ default router: openwakeword → template")


# ---------------------------------------------------------------------------
def main() -> int:
    print("JARVIS CORE — проверка audio/wakeword")
    try:
        test_config_geometry_and_words()
        test_result_and_event_clamping()
        test_template_requires_templates()
        test_template_matches_itself_and_rejects_noise()
        test_template_word_filtering()
        test_openwakeword_contract()
        test_router_fallback_and_switch()
        test_router_forced_engine()
        test_detector_events_and_cooldown()
        test_detector_template_integration()
        test_default_router()
    except AssertionError as e:
        print(f"\n✗ FAIL: {e}")
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модуля прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
