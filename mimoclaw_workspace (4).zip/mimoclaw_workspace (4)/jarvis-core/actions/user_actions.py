"""
Пользовательские команды JARVIS CORE (ТЗ-6, каталог user).

Три группы возможностей:

1. **Fuzzy-поиск программ** — ``ProgramCatalog`` + ``fuzzy_score``:
   поиск по имени/алиасам с нечётким соответствием (опечатки, частичные
   совпадения), чтобы «открой хром» находило ``google-chrome``.
2. **Макросы** — именованные цепочки команд реестра (``Macro`` →
   список ``MacroStep``) с хранилищем в памяти или в JSON-файле
   (атомарная запись) и исполнителем ``MacroRunner``: последовательное
   выполнение шагов, отказ от запрещённых/неподтверждённых команд,
   остановка на первой ошибке и пошаговый отчёт.
3. **Пользовательские команды** — свои фразы-триггеры («включи кино»)
   → ответ-текст или макрос: ``UserCommandStore`` с нечётким поиском
   триггера по сказанной фразе.

Архитектура — в стиле ``actions/app_actions.py``:

- валидация входа на границе (антиинъекция в именах команд/параметрах);
- хранилища отделены от логики (``MacroStore``, ``UserCommandStore``):
  ``Memory*`` — потокобезопасный fallback/тесты, ``Json*`` — JSON-файл
  с атомарной записью и деградацией при битом файле;
- «Локально ↔ облако» неприменимо: всё локально, без внешних вызовов.

Использование:
    from actions.registry import CommandRegistry
    from actions.user_actions import UserActions, register_user_actions

    registry = CommandRegistry()
    register_user_actions(registry)            # или со своей UserActions
"""

from __future__ import annotations

import abc
import contextlib
import json
import logging
import os
import re
import tempfile
import threading
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Callable, Iterable

from actions.registry import REQUIRES_CONFIRMATION, Command, CommandRegistry, RiskLevel
from ai.function_calling import ParamSpec

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Ошибки
# ---------------------------------------------------------------------------
class UserActionError(Exception):
    """Базовая ошибка пользовательских команд."""


class MacroError(UserActionError):
    """Ошибка макроса (создание/выполнение)."""


class MacroNotFound(MacroError):
    """Макрос не найден в хранилище."""


class UserCommandError(UserActionError):
    """Ошибка пользовательской команды."""


class UserCommandNotFound(UserCommandError):
    """Пользовательская команда не найдена."""


# ---------------------------------------------------------------------------
# Константы и валидация
# ---------------------------------------------------------------------------
#: имя макроса/программы: буквы (в т.ч. кириллица), цифры, пробел, -._+()
_NAME_RE = re.compile(r"^[A-Za-zА-Яа-яЁё0-9][A-Za-zА-Яа-яЁё0-9 _.\-+()]{0,63}$")
#: имя команды реестра: snake_case
_COMMAND_RE = re.compile(r"^[a-z][a-z0-9_]{0,63}$")
#: управляющие символы в триггерах запрещены
_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]")

MAX_MACRO_STEPS = 32          #: максимальное число шагов в макросе
MAX_PARAMS = 16               #: максимальное число параметров шага
MAX_PARAM_VALUE_CHARS = 4096  #: лимит сериализации значения параметра
MAX_TRIGGER_CHARS = 128       #: максимальная длина триггера
MIN_MATCH_SCORE = 0.6         #: порог нечёткого совпадения триггера


def validate_name(name: Any, what: str = "имя") -> str:
    """
    Проверяет имя макроса/программы: буквы/цифры/пробел/-._+(),
    длина 1..64, без ведущего дефиса (антиинъекция опций в argv).
    """
    if not isinstance(name, str):
        raise ValueError(f"{what} должно быть строкой, получено: {name!r}")
    cleaned = name.strip()
    if not cleaned:
        raise ValueError(f"{what} не может быть пустым")
    if cleaned.startswith("-"):
        raise ValueError(f"{what} не может начинаться с '-': {name!r}")
    if not _NAME_RE.fullmatch(cleaned):
        raise ValueError(
            f"недопустимые символы в {what}: {name!r} "
            "(разрешены буквы, цифры, пробел, -._+())"
        )
    return cleaned


def validate_command_name(name: Any) -> str:
    """Проверяет имя команды реестра (snake_case) для шага макроса."""
    if not isinstance(name, str):
        raise ValueError(f"имя команды должно быть строкой, получено: {name!r}")
    if not _COMMAND_RE.fullmatch(name):
        raise ValueError(f"недопустимое имя команды: {name!r} (ожидается snake_case)")
    return name


def validate_trigger(phrase: Any) -> str:
    """Проверяет фразу-триггер пользовательской команды."""
    if not isinstance(phrase, str):
        raise ValueError(f"триггер должен быть строкой, получено: {phrase!r}")
    cleaned = phrase.strip()
    if not cleaned:
        raise ValueError("триггер не может быть пустым")
    if _CONTROL_RE.search(cleaned):
        raise ValueError("триггер не может содержать управляющие символы")
    if len(cleaned) > MAX_TRIGGER_CHARS:
        raise ValueError(f"триггер длиннее {MAX_TRIGGER_CHARS} символов: {phrase!r}")
    if not any(ch.isalnum() for ch in cleaned):
        raise ValueError(f"триггер должен содержать хотя бы одну букву/цифру: {phrase!r}")
    return cleaned


def _validate_param_value(value: Any, depth: int = 0) -> None:
    """Проверяет, что значение параметра JSON-безопасно и ограничено по размеру."""
    if value is None or isinstance(value, (str, bool, int, float)):
        return
    if isinstance(value, (list, tuple)):
        if depth >= 2:
            raise ValueError(f"слишком глубокая вложенность параметра: {value!r}")
        for item in value:
            _validate_param_value(item, depth + 1)
        return
    if isinstance(value, dict):
        if depth >= 2:
            raise ValueError(f"слишком глубокая вложенность параметра: {value!r}")
        for key, item in value.items():
            if not isinstance(key, str):
                raise ValueError(f"ключ параметра должен быть строкой: {key!r}")
            _validate_param_value(item, depth + 1)
        return
    raise ValueError(f"недопустимое значение параметра (не JSON): {value!r}")


def _validate_params(params: Any) -> dict[str, Any]:
    """Проверяет словарь параметров шага и возвращает его копию."""
    if not isinstance(params, dict):
        raise ValueError(f"параметры шага должны быть словарём, получено: {params!r}")
    if len(params) > MAX_PARAMS:
        raise ValueError(f"слишком много параметров шага: {len(params)} > {MAX_PARAMS}")
    for key, value in params.items():
        if not isinstance(key, str) or not _COMMAND_RE.fullmatch(key):
            raise ValueError(f"недопустимое имя параметра: {key!r}")
        _validate_param_value(value)
    try:
        serialized = json.dumps(params, ensure_ascii=False)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"параметры шага не сериализуются в JSON: {exc}") from exc
    if len(serialized) > MAX_PARAM_VALUE_CHARS:
        raise ValueError(
            f"параметры шага слишком велики: {len(serialized)} > {MAX_PARAM_VALUE_CHARS}"
        )
    return dict(params)


# ---------------------------------------------------------------------------
# Нечёткое сравнение (fuzzy)
# ---------------------------------------------------------------------------
def normalize_text(text: Any) -> str:
    """Нормализует текст для сравнения: нижний регистр, ё→е, схлопывание пробелов."""
    if not isinstance(text, str):
        return ""
    cleaned = _CONTROL_RE.sub(" ", text).strip().lower().replace("ё", "е")
    return " ".join(cleaned.split())


def fuzzy_score(query: str, candidate: str) -> float:
    """
    Оценивает близость ``query`` к ``candidate`` в диапазоне 0.0..1.0.

    1.0 — точное совпадение после нормализации; высокие баллы — за
    подстроку и совпадение токенов; ниже — частичное сходство
    (``difflib``). 0.0 — ничего общего.
    """
    q = normalize_text(query)
    c = normalize_text(candidate)
    if not q or not c:
        return 0.0
    if q == c:
        return 1.0
    if q in c:
        return round(0.7 + 0.29 * (len(q) / len(c)), 4)
    q_tokens = set(q.split())
    c_tokens = set(c.split())
    if q_tokens <= c_tokens:
        return 0.65
    ratio = SequenceMatcher(None, q, c).ratio()
    return round(0.9 * ratio, 4) if ratio >= 0.5 else 0.0


# ---------------------------------------------------------------------------
# Fuzzy-поиск программ
# ---------------------------------------------------------------------------
@dataclass
class ProgramEntry:
    """Запись каталога программ: каноническое имя + алиасы."""

    name: str
    aliases: list[str] = field(default_factory=list)
    description: str = ""

    def candidates(self) -> list[str]:
        """Все строки для сопоставления (имя + алиасы)."""
        return [self.name, *self.aliases]


@dataclass
class ProgramMatch:
    """Результат fuzzy-поиска программы."""

    name: str
    score: float
    description: str = ""


class ProgramCatalog:
    """Каталог программ с нечётким поиском по имени/алиасам."""

    def __init__(self, entries: Iterable[ProgramEntry] | None = None) -> None:
        self._entries: dict[str, ProgramEntry] = {}
        for entry in entries or ():
            self.add(entry)

    def add(self, entry: ProgramEntry) -> ProgramEntry:
        """Добавляет запись (перезаписывает при дубликате имени)."""
        name = validate_name(entry.name, "имя программы")
        aliases = [validate_name(a, "алиас программы") for a in entry.aliases]
        self._entries[name] = ProgramEntry(
            name=name, aliases=aliases, description=str(entry.description)
        )
        return self._entries[name]

    def get(self, name: str) -> ProgramEntry | None:
        return self._entries.get(name)

    def names(self) -> list[str]:
        return sorted(self._entries.keys())

    def search(
        self, query: str, limit: int = 5, min_score: float = 0.3
    ) -> list[ProgramMatch]:
        """
        Нечёткий поиск программ: лучший балл по имени и алиасам.

        Сортировка — по убыванию балла, затем по имени; пустой запрос
        или несвязанный запрос дают пустой список.
        """
        if not isinstance(query, str) or not normalize_text(query):
            raise ValueError("поисковый запрос не может быть пустым")
        if limit < 1:
            raise ValueError(f"limit должен быть >= 1, получено: {limit}")
        matches: list[ProgramMatch] = []
        for entry in self._entries.values():
            score = max(fuzzy_score(query, alias) for alias in entry.candidates())
            if score >= min_score:
                matches.append(
                    ProgramMatch(name=entry.name, score=score, description=entry.description)
                )
        matches.sort(key=lambda m: (-m.score, m.name))
        return matches[:limit]


def default_program_catalog() -> ProgramCatalog:
    """
    Базовый каталог на основе алиасов ``actions.app_actions``.

    Связка с существующим модулем: дружественные имена («браузер» →
    firefox…) переиспользуются как алиасы для fuzzy-поиска. При
    недоступности ``actions.app_actions`` деградирует в пустой каталог.
    """
    try:
        from actions.app_actions import DEFAULT_ALIASES
    except Exception as exc:  # noqa: BLE001 — деградация без падения
        logger.warning("Алиасы app_actions недоступны (%s) — каталог программ пуст", exc)
        return ProgramCatalog()

    by_name: dict[str, set[str]] = {}
    for alias, target in DEFAULT_ALIASES.items():
        by_name.setdefault(target, set()).add(alias)
    entries = [
        ProgramEntry(name=name, aliases=sorted(aliases))
        for name, aliases in sorted(by_name.items())
    ]
    return ProgramCatalog(entries)


# ---------------------------------------------------------------------------
# Макросы
# ---------------------------------------------------------------------------
@dataclass
class MacroStep:
    """Один шаг макроса: имя команды реестра + JSON-параметры."""

    command: str
    params: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def make(cls, command: Any, params: Any = None) -> "MacroStep":
        """Создаёт шаг с полной валидацией (антиинъекция в argv команд)."""
        return cls(
            command=validate_command_name(command),
            params=_validate_params(params or {}),
        )

    @classmethod
    def from_dict(cls, raw: Any) -> "MacroStep":
        """Создаёт шаг из словаря ``{"command": ..., "params": {...}}``."""
        if not isinstance(raw, dict):
            raise ValueError(f"шаг макроса должен быть словарём, получено: {raw!r}")
        if "command" not in raw:
            raise ValueError(f"в шаге макроса нет поля 'command': {raw!r}")
        extra = set(raw) - {"command", "params"}
        if extra:
            raise ValueError(f"неизвестные поля шага макроса: {sorted(extra)}")
        return cls.make(raw["command"], raw.get("params") or {})

    def to_dict(self) -> dict[str, Any]:
        return {"command": self.command, "params": dict(self.params)}


@dataclass
class Macro:
    """Именованный макрос: упорядоченная цепочка шагов."""

    name: str
    steps: list[MacroStep]
    description: str = ""

    @classmethod
    def make(
        cls,
        name: Any,
        steps: Iterable[Any],
        description: Any = "",
        max_steps: int = MAX_MACRO_STEPS,
    ) -> "Macro":
        """Создаёт макрос с валидацией имени, шагов и их количества."""
        clean_name = validate_name(name, "имя макроса")
        raw_steps = list(steps or ())
        if not raw_steps:
            raise ValueError("макрос должен содержать хотя бы один шаг")
        if len(raw_steps) > max_steps:
            raise ValueError(f"слишком много шагов в макросе: {len(raw_steps)} > {max_steps}")
        parsed = [s if isinstance(s, MacroStep) else MacroStep.from_dict(s) for s in raw_steps]
        if not isinstance(description, str):
            raise ValueError(f"описание макроса должно быть строкой: {description!r}")
        return cls(name=clean_name, steps=parsed, description=description.strip())

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "steps": [s.to_dict() for s in self.steps],
        }

    @classmethod
    def from_dict(cls, raw: Any) -> "Macro":
        """Создаёт макрос из словаря (формат JSON-хранилища)."""
        if not isinstance(raw, dict):
            raise ValueError(f"макрос должен быть словарём, получено: {raw!r}")
        return cls.make(
            name=raw.get("name"),
            steps=raw.get("steps") or (),
            description=raw.get("description") or "",
        )


class MacroStore(abc.ABC):
    """Контракт хранилища макросов."""

    @abc.abstractmethod
    def list(self) -> list[Macro]:
        """Все макросы (по имени)."""

    @abc.abstractmethod
    def get(self, name: str) -> Macro | None:
        """Макрос по имени или None."""

    @abc.abstractmethod
    def add(self, macro: Macro, overwrite: bool = True) -> Macro:
        """Сохраняет макрос (перезапись по умолчанию)."""

    @abc.abstractmethod
    def remove(self, name: str) -> bool:
        """Удаляет макрос; True — если был удалён."""


class MemoryMacroStore(MacroStore):
    """Потокобезопасное хранилище макросов в памяти (fallback/тесты)."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._macros: dict[str, Macro] = {}

    def list(self) -> list[Macro]:
        with self._lock:
            return [self._macros[name] for name in sorted(self._macros)]

    def get(self, name: str) -> Macro | None:
        with self._lock:
            return self._macros.get(name)

    def add(self, macro: Macro, overwrite: bool = True) -> Macro:
        with self._lock:
            if macro.name in self._macros and not overwrite:
                raise MacroError(f"макрос '{macro.name}' уже существует")
            self._macros[macro.name] = macro
        return macro

    def remove(self, name: str) -> bool:
        with self._lock:
            return self._macros.pop(name, None) is not None


def _atomic_write_json(path: Path, data: Any) -> None:
    """Атомарно записывает JSON: tmp-файл в той же папке + os.replace."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(dir=str(path.parent), prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
        os.replace(tmp_name, path)
    except OSError:
        with contextlib.suppress(OSError):
            os.unlink(tmp_name)
        raise


class JsonMacroStore(MemoryMacroStore):
    """
    JSON-файл макросов с атомарной записью.

    Битый/нечитаемый файл не роняет работу: содержимое игнорируется
    с предупреждением в лог (деградация — пустое хранилище).
    """

    def __init__(self, path: str | os.PathLike[str]) -> None:
        super().__init__()
        self.path = Path(path)
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            logger.warning("Файл макросов %s нечитаем (%s) — начинаю с пустого", self.path, exc)
            return
        if not isinstance(raw, list):
            logger.warning("Файл макросов %s: ожидался список — начинаю с пустого", self.path)
            return
        for item in raw:
            try:
                macro = Macro.from_dict(item)
            except ValueError as exc:
                logger.warning("Пропущен битый макрос в %s: %s", self.path, exc)
                continue
            self._macros[macro.name] = macro

    def _save(self) -> None:
        with self._lock:
            payload = [m.to_dict() for m in self.list()]
        try:
            _atomic_write_json(self.path, payload)
        except OSError as exc:
            logger.error("Не удалось сохранить макросы в %s: %s", self.path, exc)
            raise MacroError(f"не удалось сохранить макросы: {exc}") from exc

    def add(self, macro: Macro, overwrite: bool = True) -> Macro:
        super().add(macro, overwrite=overwrite)
        self._save()
        return macro

    def remove(self, name: str) -> bool:
        removed = super().remove(name)
        if removed:
            self._save()
        return removed


# ---------------------------------------------------------------------------
# Исполнение макросов
# ---------------------------------------------------------------------------
@dataclass
class StepResult:
    """Результат одного шага макроса."""

    command: str
    ok: bool
    output: Any = None
    error: str = ""


@dataclass
class MacroRunReport:
    """Отчёт о выполнении макроса."""

    name: str
    steps: list[StepResult] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        """True — все шаги выполнены успешно."""
        return bool(self.steps) and all(s.ok for s in self.steps)

    def summary(self) -> str:
        """Короткий текстовый отчёт (для ответа голосом/LLM)."""
        done = sum(1 for s in self.steps if s.ok)
        status = "выполнен" if self.ok else "прерван"
        return f"Макрос '{self.name}' {status}: шагов {done}/{len(self.steps)}."


class MacroRunner:
    """
    Исполнитель макросов поверх ``CommandRegistry``.

    Правила безопасности:
      - неизвестная/выключенная команда → ``MacroError``;
      - команда уровня FORBIDDEN в макрос не допускается;
      - шаг, требующий подтверждения, выполняется только при
        ``confirmed=True`` (подтверждение уже получено на уровне реестра).
    """

    def __init__(self, registry: CommandRegistry, stop_on_error: bool = True) -> None:
        self.registry = registry
        self.stop_on_error = stop_on_error

    async def run(self, macro: Macro, confirmed: bool = False) -> MacroRunReport:
        """Выполняет шаги макроса последовательно, собирая пошаговый отчёт."""
        report = MacroRunReport(name=macro.name)
        for index, step in enumerate(macro.steps, start=1):
            cmd = self.registry.get(step.command)
            if cmd is None:
                raise MacroError(f"шаг {index}: команда '{step.command}' не зарегистрирована")
            if not cmd.enabled:
                raise MacroError(f"шаг {index}: команда '{step.command}' выключена")
            if cmd.risk == RiskLevel.FORBIDDEN:
                raise MacroError(
                    f"шаг {index}: команда '{step.command}' запрещена (FORBIDDEN) в макросах"
                )
            if cmd.requires_confirmation and not confirmed:
                raise MacroError(
                    f"шаг {index}: команда '{step.command}' требует подтверждения"
                )
            try:
                output = await cmd.run(**step.params)
            except Exception as exc:  # noqa: BLE001 — ошибка шага не должна утекать
                report.steps.append(
                    StepResult(command=step.command, ok=False, error=str(exc) or type(exc).__name__)
                )
                logger.warning("Макрос '%s': шаг %d (%s) упал: %s",
                               macro.name, index, step.command, exc)
                if self.stop_on_error:
                    break
                continue
            report.steps.append(StepResult(command=step.command, ok=True, output=output))
        return report


# ---------------------------------------------------------------------------
# Пользовательские команды (триггер → ответ/макрос)
# ---------------------------------------------------------------------------
@dataclass
class UserCommand:
    """Пользовательская команда: фраза-триггер → текст-ответ или макрос."""

    trigger: str
    reply: str = ""
    macro: str = ""
    enabled: bool = True

    @classmethod
    def make(
        cls, trigger: Any, reply: Any = "", macro: Any = "", enabled: Any = True
    ) -> "UserCommand":
        """Создаёт команду с валидацией триггера и связи ответ↔макрос."""
        clean_trigger = validate_trigger(trigger)
        if not isinstance(reply, str):
            raise ValueError(f"ответ должен быть строкой: {reply!r}")
        if not isinstance(macro, str):
            raise ValueError(f"имя макроса должно быть строкой: {macro!r}")
        clean_reply = reply.strip()
        clean_macro = validate_name(macro, "имя макроса") if macro.strip() else ""
        if not clean_reply and not clean_macro:
            raise ValueError(
                f"команда '{clean_trigger}' должна иметь ответ-текст или макрос"
            )
        return cls(
            trigger=clean_trigger,
            reply=clean_reply,
            macro=clean_macro,
            enabled=bool(enabled),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "trigger": self.trigger,
            "reply": self.reply,
            "macro": self.macro,
            "enabled": self.enabled,
        }

    @classmethod
    def from_dict(cls, raw: Any) -> "UserCommand":
        if not isinstance(raw, dict):
            raise ValueError(f"команда должна быть словарём, получено: {raw!r}")
        return cls.make(
            trigger=raw.get("trigger"),
            reply=raw.get("reply") or "",
            macro=raw.get("macro") or "",
            enabled=raw.get("enabled", True),
        )


class UserCommandStore:
    """
    Хранилище пользовательских команд с нечётким поиском триггера.

    ``path=None`` — только память (fallback/тесты); иначе JSON-файл
    с атомарной записью и деградацией при битом содержимом.
    """

    def __init__(self, path: str | os.PathLike[str] | None = None) -> None:
        self._lock = threading.RLock()
        self._commands: dict[str, UserCommand] = {}
        self.path = Path(path) if path is not None else None
        if self.path is not None:
            self._load()

    def _load(self) -> None:
        assert self.path is not None
        if not self.path.exists():
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            logger.warning("Файл команд %s нечитаем (%s) — начинаю с пустого", self.path, exc)
            return
        if not isinstance(raw, list):
            logger.warning("Файл команд %s: ожидался список — начинаю с пустого", self.path)
            return
        for item in raw:
            try:
                cmd = UserCommand.from_dict(item)
            except ValueError as exc:
                logger.warning("Пропущена битая команда в %s: %s", self.path, exc)
                continue
            self._commands[normalize_text(cmd.trigger)] = cmd

    def _save(self) -> None:
        if self.path is None:
            return
        with self._lock:
            payload = [c.to_dict() for c in self.list()]
        try:
            _atomic_write_json(self.path, payload)
        except OSError as exc:
            logger.error("Не удалось сохранить команды в %s: %s", self.path, exc)
            raise UserCommandError(f"не удалось сохранить команды: {exc}") from exc

    def list(self) -> list[UserCommand]:
        with self._lock:
            return sorted(self._commands.values(), key=lambda c: c.trigger.lower())

    def get(self, trigger: str) -> UserCommand | None:
        key = normalize_text(validate_trigger(trigger))
        with self._lock:
            return self._commands.get(key)

    def add(self, cmd: UserCommand, overwrite: bool = False) -> UserCommand:
        """Добавляет команду; дубликат триггера — ошибка, если не ``overwrite``."""
        key = normalize_text(cmd.trigger)
        with self._lock:
            if key in self._commands and not overwrite:
                raise UserCommandError(f"команда с триггером '{cmd.trigger}' уже существует")
            self._commands[key] = cmd
        self._save()
        return cmd

    def remove(self, trigger: str) -> bool:
        key = normalize_text(validate_trigger(trigger))
        with self._lock:
            removed = self._commands.pop(key, None) is not None
        if removed:
            self._save()
        return removed

    def match(
        self, utterance: str, min_score: float = MIN_MATCH_SCORE
    ) -> tuple[UserCommand, float] | None:
        """
        Находит лучшую команду по сказанной фразе.

        Точное совпадение триггера (после нормализации) — всегда score 1.0;
        иначе нечёткий поиск с порогом ``min_score``.
        """
        key = normalize_text(validate_trigger(utterance))
        with self._lock:
            exact = self._commands.get(key)
            if exact is not None and exact.enabled:
                return exact, 1.0
            best: tuple[UserCommand, float] | None = None
            for cmd in self._commands.values():
                if not cmd.enabled:
                    continue
                score = fuzzy_score(utterance, cmd.trigger)
                if score >= min_score and (best is None or score > best[1]):
                    best = (cmd, score)
            return best


# ---------------------------------------------------------------------------
# Служба пользовательских команд
# ---------------------------------------------------------------------------
@dataclass
class UserActions:
    """
    Служба «user»-команд: каталог программ + макросы + пользовательские
    команды. Все операции локальные, вход валидируется на границе.
    """

    programs: ProgramCatalog = field(default_factory=default_program_catalog)
    macros: MacroStore = field(default_factory=MemoryMacroStore)
    user_commands: UserCommandStore = field(default_factory=UserCommandStore)
    registry: CommandRegistry | None = None

    def _validate_steps_against_registry(self, macro: Macro) -> None:
        """Если реестр известен, шаги должны существовать и быть разрешены."""
        if self.registry is None:
            return
        for index, step in enumerate(macro.steps, start=1):
            cmd = self.registry.get(step.command)
            if cmd is None:
                raise MacroError(f"шаг {index}: команда '{step.command}' не зарегистрирована")
            if cmd.risk == RiskLevel.FORBIDDEN:
                raise MacroError(f"шаг {index}: команда '{step.command}' запрещена (FORBIDDEN)")

    # -- программы ---------------------------------------------------------
    def search_programs(self, query: str, limit: int = 5) -> list[ProgramMatch]:
        """Fuzzy-поиск программ по имени/алиасам."""
        return self.programs.search(query, limit=limit)

    # -- макросы -----------------------------------------------------------
    def list_macros(self) -> list[str]:
        """Имена всех макросов."""
        return [m.name for m in self.macros.list()]

    def get_macro(self, name: str) -> Macro:
        """Макрос по имени или ``MacroNotFound``."""
        macro = self.macros.get(validate_name(name, "имя макроса"))
        if macro is None:
            raise MacroNotFound(f"макрос '{name}' не найден")
        return macro

    def save_macro(
        self, name: str, steps: Iterable[Any], description: str = "", overwrite: bool = True
    ) -> str:
        """Создаёт/обновляет макрос (шаги валидируются и против реестра)."""
        macro = Macro.make(name, steps, description=description)
        self._validate_steps_against_registry(macro)
        self.macros.add(macro, overwrite=overwrite)
        logger.info("Сохранён макрос '%s' (%d шагов)", macro.name, len(macro.steps))
        return f"Макрос '{macro.name}' сохранён ({len(macro.steps)} шагов)."

    def delete_macro(self, name: str) -> str:
        """Удаляет макрос; отсутствие — ошибка."""
        clean = validate_name(name, "имя макроса")
        if not self.macros.remove(clean):
            raise MacroNotFound(f"макрос '{clean}' не найден")
        return f"Макрос '{clean}' удалён."

    async def run_macro(self, name: str, confirmed: bool = True) -> str:
        """
        Выполняет макрос и возвращает пошаговый отчёт.

        ``confirmed=True`` по умолчанию: подтверждение уже получено
        реестром на уровне команды ``run_macro`` (HIGH).
        """
        macro = self.get_macro(name)
        runner = MacroRunner(self.registry) if self.registry is not None else None
        if runner is None:
            raise MacroError("для выполнения макроса нужен реестр команд")
        report = await runner.run(macro, confirmed=confirmed)
        return report.summary()

    # -- пользовательские команды ------------------------------------------
    def list_user_commands(self) -> list[str]:
        """Триггеры всех пользовательских команд."""
        return [c.trigger for c in self.user_commands.list()]

    def add_user_command(
        self,
        trigger: str,
        reply: str = "",
        macro: str = "",
        overwrite: bool = False,
    ) -> str:
        """Добавляет фразу-триггер → ответ-текст или макрос."""
        cmd = UserCommand.make(trigger, reply=reply, macro=macro)
        if cmd.macro:
            self.get_macro(cmd.macro)  # макрос обязан существовать
        self.user_commands.add(cmd, overwrite=overwrite)
        return f"Команда '{cmd.trigger}' сохранена."

    def remove_user_command(self, trigger: str) -> str:
        """Удаляет пользовательскую команду; отсутствие — ошибка."""
        clean = validate_trigger(trigger)
        if not self.user_commands.remove(clean):
            raise UserCommandNotFound(f"команда '{clean}' не найдена")
        return f"Команда '{clean}' удалена."

    def match_user_command(self, utterance: str) -> tuple[UserCommand, float] | None:
        """Нечёткий поиск пользовательской команды по сказанной фразе."""
        return self.user_commands.match(utterance)


# ---------------------------------------------------------------------------
# Регистрация команд в реестре
# ---------------------------------------------------------------------------
def _spec(name: str, type_: str, description: str, **kw: Any) -> ParamSpec:
    return ParamSpec(
        name=name,
        type=type_,
        description=description,
        required=kw.get("required", True),
        enum=kw.get("enum"),
        default=kw.get("default"),
    )


def register_user_actions(
    registry: CommandRegistry,
    actions: UserActions | None = None,
) -> list[str]:
    """
    Регистрирует user-команды в ``registry`` (возвращает их имена).

    Уровни риска (ТЗ-6.7):
      - SAFE:   search_programs, list_macros, list_user_commands
      - MEDIUM: save_macro, delete_macro, add_user_command,
                remove_user_command (изменяют пользовательские данные)
      - HIGH:   run_macro (цепочка действий — только с подтверждением)
    """
    svc = actions or UserActions()
    svc.registry = registry

    async def _save_macro(name: str, steps: Iterable[Any], description: str = "") -> str:
        return svc.save_macro(name, steps, description=description)

    defs: list[tuple[str, str, list[ParamSpec], str, Callable[..., Any]]] = [
        (
            "search_programs",
            "Нечёткий поиск программ по имени/алиасам (опечатки допустимы)",
            [
                _spec("query", "string", "часть имени программы или алиас"),
                _spec("limit", "integer", "максимум результатов", required=False, default=5),
            ],
            RiskLevel.SAFE,
            lambda query, limit=5: [
                f"{m.name} ({m.score:.2f})" for m in svc.search_programs(query, int(limit))
            ]
            or ["ничего не найдено"],
        ),
        (
            "list_macros",
            "Список сохранённых макросов",
            [],
            RiskLevel.SAFE,
            svc.list_macros,
        ),
        (
            "list_user_commands",
            "Список пользовательских фраз-триггеров",
            [],
            RiskLevel.SAFE,
            svc.list_user_commands,
        ),
        (
            "save_macro",
            "Создать или обновить макрос (цепочку команд)",
            [
                _spec("name", "string", "имя макроса"),
                _spec(
                    "steps",
                    "array",
                    'шаги: [{"command": "имя_команды", "params": {...}}, ...]',
                ),
                _spec("description", "string", "описание макроса", required=False, default=""),
            ],
            RiskLevel.MEDIUM,
            _save_macro,
        ),
        (
            "delete_macro",
            "Удалить макрос по имени (после подтверждения)",
            [_spec("name", "string", "имя макроса")],
            RiskLevel.MEDIUM,
            svc.delete_macro,
        ),
        (
            "run_macro",
            "Выполнить сохранённый макрос (после подтверждения)",
            [_spec("name", "string", "имя макроса")],
            RiskLevel.HIGH,
            svc.run_macro,
        ),
        (
            "add_user_command",
            "Добавить свою фразу-триггер → ответ-текст или макрос",
            [
                _spec("trigger", "string", "фраза-триггер"),
                _spec("reply", "string", "текстовый ответ", required=False, default=""),
                _spec("macro", "string", "имя макроса", required=False, default=""),
            ],
            RiskLevel.MEDIUM,
            svc.add_user_command,
        ),
        (
            "remove_user_command",
            "Удалить пользовательскую фразу-триггер (после подтверждения)",
            [_spec("trigger", "string", "фраза-триггер")],
            RiskLevel.MEDIUM,
            svc.remove_user_command,
        ),
    ]

    names: list[str] = []
    for name, description, params, risk, handler in defs:
        registry.register(
            Command(
                name=name,
                description=description,
                params=params,
                handler=handler,
                risk=risk,
                requires_confirmation=REQUIRES_CONFIRMATION.get(risk, False),
            )
        )
        names.append(name)
    logger.debug("Зарегистрированы пользовательские команды: %s", ", ".join(names))
    return names
