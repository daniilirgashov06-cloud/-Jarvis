"""
HUD-оверлей JARVIS CORE (фишки «Железного человека»): данные и состояние.

Модуль ничего не рисует — он готовит **данные для любого рендера**:
веб-оверлей (Tauri/React в ``ui/``), терминальную панель или графику на
Pillow. Здесь живут «железночеловеческие» элементы HUD:

- ``RingState`` / ``arc_polyline``  — «дуговое кольцо» с прогрессом
  (геометрия дуги в пикселях для canvas/SVG);
- ``VoiceWaveform``                — осциллограмма голоса (кольцевой буфер
  сэмплов → точки для осциллографа + уровень RMS);
- ``ReactorMeter``                 — «дуговой реактор»: активность ИИ
  (слушает/думает/говорит) → плавное свечение и пульсация;
- ``SystemStatus`` / ``StatusItem`` — статус системы (CPU, память, сеть…)
  с уровнем OK/WARN/CRIT и сводкой;
- ``HudState``                     — единый снимок состояния для оверлея
  (``snapshot()`` → dict, ``to_json()`` → строка для WebSocket/IPC).

Всё локально и детерминированно: ни сети, ни глобального состояния —
значения передаются снаружи, что удобно для тестов и прогнозов.

Типовой сценарий::

    hud = HudState(theme=HudTheme())
    hud.waveform.push(samples)          # из audio/capture
    hud.reactor.set_activity(0.8)       # «ИИ думает»
    send_to_overlay(hud.to_json())      # WS-сообщение в ui/
"""

from __future__ import annotations

import json
import math
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Sequence

__all__ = [
    "HudTheme",
    "RingState",
    "arc_polyline",
    "VoiceWaveform",
    "ActivityLevel",
    "ReactorMeter",
    "StatusLevel",
    "StatusItem",
    "SystemStatus",
    "HudState",
]


# ---------------------------------------------------------------------------
# Тема оформления
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class HudTheme:
    """
    Параметры оформления HUD (в стиле ``config.settings.UIConfig``).

    Цвета — CSS-строки, чтобы оверлей мог использовать их напрямую.
    """

    accent: str = "#00E5FF"
    background: str = "#0A0F14"
    glow: float = 0.6  # 0..1 — сила свечения элементов
    ring_radius: float = 120.0
    ring_thickness: float = 8.0
    show_subtitles: bool = True

    def to_dict(self) -> dict[str, Any]:
        """Снимок темы (JSON-сериализуемый)."""
        return {
            "accent": self.accent,
            "background": self.background,
            "glow": self.glow,
            "ring_radius": self.ring_radius,
            "ring_thickness": self.ring_thickness,
            "show_subtitles": self.show_subtitles,
        }


# ---------------------------------------------------------------------------
# Кольцо-прогресс
# ---------------------------------------------------------------------------
def _clamp01(value: float) -> float:
    """Ограничивает значение диапазоном 0..1 (NaN → 0)."""
    if value != value:  # NaN
        return 0.0
    return max(0.0, min(1.0, float(value)))


def arc_polyline(
    cx: float,
    cy: float,
    radius: float,
    start_deg: float,
    sweep_deg: float,
    segments: int = 48,
) -> list[tuple[float, float]]:
    """
    Полилиния дуги окружности — готовые точки для canvas/SVG.

    ``start_deg`` — угол начала (0° = восток, по часовой стрелке в экранных
    координатах), ``sweep_deg`` — охват в градусах (может быть отрицательным),
    ``segments`` — количество отрезков (минимум 1).
    """
    if segments < 1:
        raise ValueError(f"segments должен быть >= 1, получено: {segments!r}")
    if radius < 0:
        raise ValueError(f"radius должен быть >= 0, получено: {radius!r}")
    points: list[tuple[float, float]] = []
    for i in range(segments + 1):
        frac = i / segments
        angle = math.radians(start_deg + sweep_deg * frac)
        points.append((cx + radius * math.cos(angle), cy + radius * math.sin(angle)))
    return points


@dataclass
class RingState:
    """
    Состояние «дугового кольца» HUD: прогресс-дуга + пульсация.

    ``progress`` — 0..1 (что угодно: загрузка модели, прогресс задачи,
    уровень заряда костюма).
    """

    progress: float = 0.0
    start_deg: float = -90.0  # начало дуги — «12 часов»
    full_sweep_deg: float = 360.0
    pulse: float = 0.0  # 0..1 — дополнительная пульсация (вспышка)

    def __post_init__(self) -> None:
        self.progress = _clamp01(self.progress)
        self.pulse = _clamp01(self.pulse)

    def set_progress(self, value: float) -> float:
        """Установить прогресс (0..1) и вернуть его после ограничения."""
        self.progress = _clamp01(value)
        return self.progress

    def polyline(
        self, cx: float = 0.0, cy: float = 0.0, radius: float = 120.0, segments: int = 48
    ) -> list[tuple[float, float]]:
        """Точки дуги от начала до текущего прогресса."""
        sweep = self.full_sweep_deg * self.progress
        if sweep == 0:
            return []
        return arc_polyline(cx, cy, radius, self.start_deg, sweep, segments)

    def to_dict(self) -> dict[str, Any]:
        """Снимок состояния кольца."""
        return {
            "progress": self.progress,
            "start_deg": self.start_deg,
            "sweep_deg": self.full_sweep_deg * self.progress,
            "pulse": self.pulse,
        }


# ---------------------------------------------------------------------------
# Осциллограмма голоса
# ---------------------------------------------------------------------------
@dataclass
class VoiceWaveform:
    """
    Осциллограмма голоса: кольцевой буфер последних сэмплов (-1.0..1.0).

    ``push`` добавляет новые сэмплы (например, кадр из ``audio/capture``),
    ``points`` превращает буфер в точки для отрисовки, ``level`` — RMS
    текущей громкости (для индикатора «говорит/молчит»).
    """

    capacity: int = 512
    _buffer: deque[float] = field(default_factory=deque, init=False, repr=False)

    def __post_init__(self) -> None:
        if self.capacity < 2:
            raise ValueError(f"capacity должен быть >= 2, получено: {self.capacity!r}")
        self._buffer = deque(maxlen=self.capacity)

    def push(self, samples: Sequence[float]) -> None:
        """Добавить сэмплы (значения ограничиваются диапазоном -1..1)."""
        for s in samples:
            v = float(s)
            if v != v:  # NaN — тишина
                v = 0.0
            self._buffer.append(max(-1.0, min(1.0, v)))

    def clear(self) -> None:
        """Очистить буфер."""
        self._buffer.clear()

    def samples(self) -> list[float]:
        """Текущее содержимое буфера (от старых к новым)."""
        return list(self._buffer)

    @property
    def level(self) -> float:
        """RMS-уровень громкости 0..1."""
        if not self._buffer:
            return 0.0
        power = sum(s * s for s in self._buffer) / len(self._buffer)
        return _clamp01(math.sqrt(power))

    @property
    def peak(self) -> float:
        """Пиковая амплитуда 0..1."""
        return max((abs(s) for s in self._buffer), default=0.0)

    def points(self, width: float = 640.0, height: float = 120.0) -> list[tuple[float, float]]:
        """
        Точки осциллограммы для отрисовки: x растёт 0..``width``,
        y — от ``height`` (верх, +1.0) до 0 (низ, -1.0), центр = height/2.

        Пустой буфер → ровная линия по центру.
        """
        if width <= 0 or height <= 0:
            raise ValueError("width и height должны быть положительными")
        n = self.capacity
        buf = list(self._buffer)
        mid = height / 2.0
        amp = height / 2.0
        out: list[tuple[float, float]] = []
        for i in range(n):
            x = width * i / (n - 1)
            if buf:
                # линейная интерполяция буфера на n точек
                pos = i * (len(buf) - 1) / (n - 1)
                lo = int(pos)
                hi = min(lo + 1, len(buf) - 1)
                frac = pos - lo
                v = buf[lo] * (1.0 - frac) + buf[hi] * frac
            else:
                v = 0.0
            out.append((x, mid - v * amp))
        return out


# ---------------------------------------------------------------------------
# «Дуговой реактор»: активность ИИ
# ---------------------------------------------------------------------------
class ActivityLevel(str, Enum):
    """Фаза активности ИИ — цвет/режим реактора на HUD."""

    IDLE = "idle"            # ожидание
    LISTENING = "listening"  # слушает пользователя
    THINKING = "thinking"    # думает (LLM)
    SPEAKING = "speaking"    # говорит
    ERROR = "error"          # сбой


#: базовая интенсивность свечения по фазам (0..1)
_ACTIVITY_GLOW: dict[ActivityLevel, float] = {
    ActivityLevel.IDLE: 0.25,
    ActivityLevel.LISTENING: 0.55,
    ActivityLevel.THINKING: 0.85,
    ActivityLevel.SPEAKING: 0.7,
    ActivityLevel.ERROR: 1.0,
}


@dataclass
class ReactorMeter:
    """
    «Дуговой реактор»: плавное свечение по активности ИИ.

    ``target`` — целевая интенсивность (0..1), ``level`` — сглаженное
    текущее значение (EMA), ``update(dt_s)`` продвигает ``level`` к цели.
    ``glow(t_s)`` добавляет синусоидальный пульс — реактор «дышит».
    """

    target: float = 0.25
    level: float = 0.25
    smoothing: float = 3.0  # скорость сглаживания, 1/с
    activity: ActivityLevel = ActivityLevel.IDLE
    pulse_hz: float = 1.2  # частота пульсации, Гц

    def __post_init__(self) -> None:
        self.target = _clamp01(self.target)
        self.level = _clamp01(self.level)

    def set_activity(self, activity: ActivityLevel | str) -> float:
        """Задать фазу активности; цель берётся из таблицы свечения."""
        act = ActivityLevel(activity) if not isinstance(activity, ActivityLevel) else activity
        self.activity = act
        self.target = _ACTIVITY_GLOW[act]
        return self.target

    def set_target(self, value: float) -> float:
        """Задать цель вручную (0..1)."""
        self.target = _clamp01(value)
        return self.target

    def update(self, dt_s: float = 0.05) -> float:
        """Продвинуть сглаживание к цели на ``dt_s`` секунд; вернуть level."""
        if dt_s < 0:
            raise ValueError(f"dt_s должен быть >= 0, получено: {dt_s!r}")
        step = min(1.0, self.smoothing * dt_s)
        self.level = _clamp01(self.level + (self.target - self.level) * step)
        return self.level

    def glow(self, t_s: float = 0.0) -> float:
        """Текущее свечение 0..1: сглаженный уровень + пульсация ±20%."""
        pulse = 0.5 + 0.5 * math.sin(2.0 * math.pi * self.pulse_hz * t_s)
        return _clamp01(self.level * (0.8 + 0.2 * pulse))

    def to_dict(self, t_s: float = 0.0) -> dict[str, Any]:
        """Снимок состояния реактора."""
        return {
            "activity": self.activity.value,
            "level": self.level,
            "target": self.target,
            "glow": self.glow(t_s),
            "pulse_hz": self.pulse_hz,
        }


# ---------------------------------------------------------------------------
# Статус системы
# ---------------------------------------------------------------------------
class StatusLevel(str, Enum):
    """Уровень состояния пункта статуса."""

    OK = "ok"
    WARN = "warn"
    CRIT = "crit"


#: порядок серьёзности уровней (для выбора «худшего»)
_LEVEL_RANK: dict[StatusLevel, int] = {
    StatusLevel.OK: 0,
    StatusLevel.WARN: 1,
    StatusLevel.CRIT: 2,
}


@dataclass(frozen=True)
class StatusItem:
    """Один пункт статуса: имя, значение, единицы, уровень, пояснение."""

    name: str
    value: float | str
    unit: str = ""
    level: StatusLevel = StatusLevel.OK
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        """JSON-сериализуемый снимок пункта."""
        return {
            "name": self.name,
            "value": self.value,
            "unit": self.unit,
            "level": self.level.value,
            "detail": self.detail,
        }


def _level_by_thresholds(value: float, warn_at: float, crit_at: float) -> StatusLevel:
    """Уровень по порогам: >= crit_at → CRIT, >= warn_at → WARN, иначе OK."""
    if value >= crit_at:
        return StatusLevel.CRIT
    if value >= warn_at:
        return StatusLevel.WARN
    return StatusLevel.OK


@dataclass
class SystemStatus:
    """
    Сводка состояния системы для HUD.

    ``from_metrics`` строит пункты из сырых метрик (CPU %, память %,
    диск %, задержка сети мс) с типовыми порогами.
    """

    items: list[StatusItem] = field(default_factory=list)

    def add(self, item: StatusItem) -> None:
        """Добавить пункт статуса."""
        self.items.append(item)

    def overall(self) -> StatusLevel:
        """Худший уровень среди пунктов (пустой список → OK)."""
        worst = StatusLevel.OK
        for item in self.items:
            if _LEVEL_RANK[item.level] > _LEVEL_RANK[worst]:
                worst = item.level
        return worst

    @classmethod
    def from_metrics(
        cls,
        *,
        cpu_percent: float | None = None,
        memory_percent: float | None = None,
        disk_percent: float | None = None,
        latency_ms: float | None = None,
    ) -> "SystemStatus":
        """Собрать статус из сырых метрик с типовыми порогами."""
        status = cls()
        if cpu_percent is not None:
            status.add(
                StatusItem(
                    "CPU",
                    round(float(cpu_percent), 1),
                    "%",
                    _level_by_thresholds(cpu_percent, 70.0, 90.0),
                )
            )
        if memory_percent is not None:
            status.add(
                StatusItem(
                    "Память",
                    round(float(memory_percent), 1),
                    "%",
                    _level_by_thresholds(memory_percent, 75.0, 92.0),
                )
            )
        if disk_percent is not None:
            status.add(
                StatusItem(
                    "Диск",
                    round(float(disk_percent), 1),
                    "%",
                    _level_by_thresholds(disk_percent, 85.0, 96.0),
                )
            )
        if latency_ms is not None:
            status.add(
                StatusItem(
                    "Сеть",
                    round(float(latency_ms), 1),
                    "мс",
                    _level_by_thresholds(latency_ms, 250.0, 1000.0),
                )
            )
        return status

    def to_dict(self) -> dict[str, Any]:
        """Снимок статуса: пункты + общий уровень."""
        return {
            "overall": self.overall().value,
            "items": [item.to_dict() for item in self.items],
        }


# ---------------------------------------------------------------------------
# Единый снимок HUD
# ---------------------------------------------------------------------------
@dataclass
class HudState:
    """
    Единое состояние HUD-оверлея: тема + кольцо + реактор + голос + статус.

    ``snapshot()`` возвращает JSON-сериализуемый dict, ``to_json()`` —
    строку для отправки в оверлей (WebSocket/IPC/Tauri-events).
    """

    theme: HudTheme = field(default_factory=HudTheme)
    ring: RingState = field(default_factory=RingState)
    reactor: ReactorMeter = field(default_factory=ReactorMeter)
    waveform: VoiceWaveform = field(default_factory=VoiceWaveform)
    status: SystemStatus = field(default_factory=SystemStatus)
    subtitles: str = ""

    def snapshot(self, now: float | None = None, t_s: float | None = None) -> dict[str, Any]:
        """
        Снимок состояния для рендера.

        ``now`` — метка времени (по умолчанию ``time.time()``),
        ``t_s`` — «анимационное» время для пульсации реактора.
        """
        stamp = time.time() if now is None else float(now)
        anim = stamp if t_s is None else float(t_s)
        return {
            "updated_at": stamp,
            "theme": self.theme.to_dict(),
            "ring": self.ring.to_dict(),
            "reactor": self.reactor.to_dict(anim),
            "waveform": {
                "level": self.waveform.level,
                "peak": self.waveform.peak,
                "points": [[round(x, 2), round(y, 2)] for x, y in self.waveform.points()],
            },
            "status": self.status.to_dict(),
            "subtitles": self.subtitles,
        }

    def to_json(self, now: float | None = None, t_s: float | None = None) -> str:
        """Снимок состояния в виде JSON-строки (компактно, без пробелов)."""
        return json.dumps(self.snapshot(now=now, t_s=t_s), ensure_ascii=False, separators=(",", ":"))
