/**
 * Dashboard — обзор состояния ядра JARVIS.
 *
 * Крупный статус пайплайна, VU-метр, карточки персоны/модели/памяти/Telegram,
 * мини-графики метрик и живая лента событий.
 */

import { motion } from "framer-motion";
import { Badge, Card, Notice } from "../components/ui/panels";
import { Button } from "../components/ui/controls";
import { EventLog } from "../components/EventLog";
import { Sparkline } from "../components/Sparkline";
import { StatusOrb } from "../components/StatusOrb";
import { VUMeter } from "../components/VUMeter";
import { useSocket } from "../hooks/useSocket";
import { clsx, formatNumber, formatUptime } from "../lib/format";
import { useSettingsStore } from "../stores/settingsStore";
import { useSystemStore } from "../stores/systemStore";
import { useUiStore, type Persona } from "../stores/uiStore";

const STATE_HINT: Record<string, string> = {
  idle: "Ожидание",
  listening: "Слушаю",
  thinking: "Думаю",
  speaking: "Говорю",
};

export function DashboardPage() {
  const { requestStatus, online } = useSocket();
  const status = useSystemStore((s) => s.status);
  const metrics = useSystemStore((s) => s.metrics);
  const events = useSystemStore((s) => s.events);
  const settings = useSettingsStore((s) => s.data);
  const remoteSettings = useSettingsStore((s) => s.remote);
  const persona = useUiStore((s) => s.persona);
  const setPersona = useUiStore((s) => s.setPersona);

  const counters = status?.counters ?? { events: 0, commands: 0, errors: 0 };
  const primary = settings.ai.primary as keyof typeof settings.ai;
  const primaryModel =
    primary in settings.ai && typeof settings.ai[primary] === "object"
      ? (settings.ai[primary] as { model: string }).model
      : "—";

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold uppercase tracking-[0.18em] text-text">
            Обзор системы
          </h1>
          <p className="mt-1.5 text-sm text-muted">
            Живой статус ядра, уровень сигнала и ключевые модули — в реальном времени.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="border-accent/40 bg-accent/10 text-accent" pulse={online}>
            {online ? "WS подключён" : "WS отключён"}
          </Badge>
          <Badge className="border-line-bright bg-panel-2 text-muted">
            Аптайм {status ? formatUptime(status.uptime_s) : "—"}
          </Badge>
          <Button onClick={requestStatus}>Обновить</Button>
        </div>
      </header>

      {!online ? (
        <Notice tone="warn">
          Нет соединения с ядром (ws://127.0.0.1:8765/ws). Данные могут быть устаревшими —
          запустите <code>ui_server</code> и нажмите «Обновить».
        </Notice>
      ) : null}

      {/* --- статус + VU + счётчики ------------------------------------- */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2" title="Состояние пайплайна" subtitle={STATE_HINT[status?.state ?? "idle"]}>
          <div className="flex flex-wrap items-center justify-around gap-8">
            <StatusOrb state={status?.state ?? "idle"} />
            <div className="min-w-[240px] flex-1">
              <VUMeter history={metrics.vu} />
              <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                <Counter label="СОБЫТИЙ" value={formatNumber(counters.events)} />
                <Counter label="КОМАНД" value={formatNumber(counters.commands)} />
                <Counter label="ОШИБОК" value={formatNumber(counters.errors)} />
              </div>
            </div>
          </div>
        </Card>

        <Card title="Последний ответ" subtitle="Реплика оркестратора" delay={0.06}>
          <p className="min-h-[92px] rounded-xl border border-line bg-panel-2/50 p-3 text-sm leading-relaxed text-text">
            {status?.last_reply ? (
              <>
                <span className="mr-2 text-accent">JARVIS:</span>
                {status.last_reply}
              </>
            ) : (
              <span className="text-muted">Пока нет реплик — отправьте команду в разделе «Голос».</span>
            )}
          </p>
          <div className="mt-4 space-y-2">
            <MiniRow label="Клиентов WS" value={String(status?.clients ?? 0)} />
            <MiniRow label="Оркестратор" value={status?.orchestrator ? "подключён" : "отключён"} />
            <MiniRow label="Событий в ленте" value={String(status?.history_size ?? events.length)} />
          </div>
        </Card>
      </div>

      {/* --- карточки модулей ------------------------------------------- */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-4">
        <Card title="Персона" subtitle="Активный характер ассистента" delay={0.04}>
          <p className="mb-3 text-sm text-muted">
            Акцент интерфейса и стиль речи. Переключение меняет HUD-тему панели.
          </p>
          <div className="flex gap-2">
            {(["jarvis", "friday"] as Persona[]).map((p) => (
              <Button
                key={p}
                variant={persona === p ? "primary" : "ghost"}
                onClick={() => setPersona(p)}
                className="flex-1 uppercase tracking-[0.22em]"
              >
                {p}
              </Button>
            ))}
          </div>
        </Card>

        <Card title="Модель" subtitle="LLM-провайдер и роутинг" delay={0.08}>
          <p className="font-heading text-lg text-accent">{settings.ai.primary}</p>
          <p className="mt-0.5 text-sm text-text">{primaryModel}</p>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {settings.ai.fallback_chain.map((name) => (
              <Badge key={name} className="border-line-bright bg-panel-2 text-muted">
                {name}
              </Badge>
            ))}
          </div>
        </Card>

        <Card title="Память" subtitle="Долговременное хранилище" delay={0.12}>
          <MiniRow label="Статус" value={settings.memory.enabled ? "включена" : "выключена"} />
          <MiniRow label="RAG top-k" value={String(settings.memory.rag_top_k)} />
          <MiniRow label="Контекст" value={`${settings.memory.context_messages} сообщ.`} />
          <p className="mt-2 truncate text-xs text-muted" title={settings.memory.embedding_model}>
            {settings.memory.embedding_model}
          </p>
        </Card>

        <Card title="Telegram" subtitle="Удалённый доступ" delay={0.16}>
          <MiniRow label="Бот" value={settings.telegram.enabled ? "включён" : "выключен"} />
          <MiniRow label="Уровень доступа" value={settings.telegram.access_level} />
          <MiniRow label="PIN для опасных" value={settings.telegram.require_pin_for_high ? "требуется" : "нет"} />
          <Badge
            className={clsx(
              "mt-3",
              settings.telegram.enabled
                ? "border-ok/40 bg-ok/10 text-ok"
                : "border-line-bright bg-panel-2 text-muted",
            )}
          >
            {settings.telegram.enabled ? "на связи" : "не активен"}
          </Badge>
        </Card>
      </div>

      {/* --- мини-графики ------------------------------------------------ */}
      <Card title="Метрики" subtitle="Активность за последние интервалы (тик 1.5 с)">
        <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
          <Sparkline data={metrics.events} label="СОБЫТИЯ" suffix=" /тик" />
          <Sparkline data={metrics.commands} label="КОМАНДЫ" suffix=" /тик" />
          <Sparkline data={metrics.errors} label="ОШИБКИ" suffix=" /тик" color="#FF3B30" />
          <Sparkline data={metrics.vu.map((v) => Math.round(v * 100))} label="VU %" suffix="%" />
        </div>
        {!remoteSettings ? (
          <p className="mt-3 text-xs text-muted">
            ⚠ REST настроек недоступен — карточки показывают локальные дефолты (демо-режим).
          </p>
        ) : null}
      </Card>

      {/* --- лента событий ------------------------------------------------ */}
      <Card title="Живая лента событий" subtitle="Топики шины core.event_bus (последние 12)">
        <EventLog events={events} limit={12} height="h-64" />
      </Card>

      {/* тонкая декоративная полоса состояния */}
      <motion.div
        animate={{ opacity: [0.35, 0.8, 0.35] }}
        transition={{ duration: 3.2, repeat: Infinity }}
        className="h-px w-full"
        style={{ background: "linear-gradient(90deg, transparent, rgb(var(--accent-rgb)), transparent)" }}
      />
    </div>
  );
}

function Counter({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-line bg-panel-2/50 px-2 py-2">
      <p className="font-display text-base tabular-nums text-accent">{value}</p>
      <p className="text-[9px] tracking-[0.22em] text-muted">{label}</p>
    </div>
  );
}

function MiniRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 text-sm">
      <span className="text-muted">{label}</span>
      <span className="tabular-nums text-text">{value}</span>
    </div>
  );
}
