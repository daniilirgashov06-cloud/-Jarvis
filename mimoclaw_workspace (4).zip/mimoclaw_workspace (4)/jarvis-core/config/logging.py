"""
Логирование JARVIS CORE (loguru + ротация файлов).

Настраивается из конфига: уровень, папка, ротация/ретеншн.
Использование:
    from config.logging import setup_logging, logger
    setup_logging(cfg.logging)
    logger.info("ядро запущено")

Надёжность:
- если loguru не установлен — прозрачный fallback на stdlib ``logging`` с
  ``RotatingFileHandler`` (ротация/ретеншн парсятся приближённо);
- если папка логов недоступна/занята файлом — старт не падает, пишем только
  в консоль;
- повторный вызов ``setup_logging`` идемпотентен (прошлые файловые sink-и
  снимаются, новых дублей не появляется).
"""

from __future__ import annotations

import logging as _logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from config.settings import LoggingConfig

__all__ = ["HAS_LOGURU", "logger", "setup_logging"]

# Разрешённые уровни (валидируются, неверное значение деградирует до INFO)
_LEVELS = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")
_DEFAULT_LEVEL = "INFO"
_DEFAULT_ROTATION = "10 MB"
_DEFAULT_RETENTION = "30 days"

# Глобальный логгер (loguru; если его нет — fallback на stdlib)
try:
    from loguru import logger  # type: ignore

    HAS_LOGURU = True
except ImportError:  # pragma: no cover - зависит от окружения
    HAS_LOGURU = False

    _root = _logging.getLogger()
    if not _root.handlers:  # не трогаем чужую конфигурацию
        _logging.basicConfig(
            level=_logging.INFO,
            format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
        )
    logger = _logging.getLogger("jarvis")  # type: ignore


# ---------------------------------------------------------------------------
# Вспомогательные разборы значений конфига
# ---------------------------------------------------------------------------
def _normalize_level(level: Any) -> str:
    """Нормализует уровень логирования; мусор → INFO (без исключений)."""
    value = str(level).strip().upper() if level is not None else _DEFAULT_LEVEL
    return value if value in _LEVELS else _DEFAULT_LEVEL


def _coerce_dir(value: Any) -> Path | None:
    """Приводит путь папки логов к ``Path``; None/мусор → None (только консоль)."""
    if value is None:
        return None
    try:
        return Path(value)
    except TypeError:
        return None


def _parse_size(text: Any, default: int = 10 * 1024 * 1024) -> int:
    """Разбирает размер ротации («10 MB», «512 KB», «1 GB») в байты.

    Непонятное значение → ``default`` (10 MB).
    """
    try:
        parts = str(text).strip().split()
        number = float(parts[0])
        unit = parts[1].lower() if len(parts) > 1 else "b"
        scale = {"b": 1, "kb": 1024, "mb": 1024**2, "gb": 1024**3}.get(unit)
        if scale is None or number <= 0:
            return default
        return int(number * scale)
    except (TypeError, ValueError, IndexError):
        return default


def _parse_retention_days(text: Any, default: int = 30) -> int:
    """Разбирает ретеншн («30 days», «2 weeks») в число бэкапов (приближённо).

    stdlib-RotatingFileHandler хранит ограниченное число бэкапов, поэтому
    дни/недели аппроксимируем счётчиком файлов. Непонятное → ``default``.
    """
    try:
        parts = str(text).strip().split()
        number = float(parts[0])
        unit = parts[1].lower() if len(parts) > 1 else "d"
        if number <= 0:
            return default
        if unit.startswith("w"):  # weeks
            number *= 7
        return max(1, int(number))
    except (TypeError, ValueError, IndexError):
        return default


# ---------------------------------------------------------------------------
# Настройка
# ---------------------------------------------------------------------------
def _setup_stdlib(
    level: str,
    log_dir: Path | None,
    rotation: str,
    retention: str,
) -> None:
    """Fallback-настройка stdlib-логгера: уровень + файл с ротацией."""
    std = logger  # stdlib.Logger
    std.setLevel(level)  # type: ignore[attr-defined]

    # Идемпотентность: снимаем прошлые файловые обработчики
    for handler in list(std.handlers):  # type: ignore[attr-defined]
        if isinstance(handler, RotatingFileHandler):
            std.removeHandler(handler)  # type: ignore[attr-defined]
            handler.close()

    if log_dir is None:
        return

    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        handler = RotatingFileHandler(
            log_dir / "jarvis.log",
            maxBytes=_parse_size(rotation),
            backupCount=_parse_retention_days(retention),
            encoding="utf-8",
        )
        handler.setFormatter(
            _logging.Formatter("%(asctime)s | %(levelname)-7s | %(name)s | %(message)s")
        )
        std.addHandler(handler)  # type: ignore[attr-defined]
    except (OSError, ValueError) as exc:  # не роняем старт
        std.warning("Не удалось создать файл-лог (%s), только консоль", exc)  # type: ignore[attr-defined]


def _setup_loguru(
    level: str,
    log_dir: Path | None,
    rotation: str,
    retention: str,
) -> None:
    """Настройка loguru: консоль + файл с ротацией (потокобезопасно)."""
    logger.remove()  # убираем дефолтный sink (идемпотентно)
    logger.add(
        sys.stderr,
        level=level,
        format="<green>{time:HH:mm:ss}</green> | <level>{level:<7}</level> | "
        "<cyan>{name}</cyan>:<cyan>{function}</cyan> | {message}",
        colorize=True,
    )
    if log_dir is None:
        return

    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        logger.add(
            str(log_dir / "jarvis_{time}.log"),
            level=level,
            rotation=rotation,
            retention=retention,
            encoding="utf-8",
            enqueue=True,  # потокобезопасно
        )
    except (OSError, ValueError) as exc:  # диск недоступен/кривые параметры
        logger.warning("Не удалось создать файл-лог (%s), только консоль", exc)


def setup_logging(cfg: "LoggingConfig | Any") -> None:
    """
    Настраивает вывод в консоль и файл с ротацией.

    Принимает ``LoggingConfig`` или любой объект с атрибутами
    ``level`` / ``dir`` / ``rotation`` / ``retention`` (все необязательны).
    Безопасно идемпотентно: повторный вызов перенастраивает sink-и.
    Никогда не бросает исключений при битых значениях — деградирует
    до консольного INFO-логирования.
    """
    level = _normalize_level(getattr(cfg, "level", None))
    log_dir = _coerce_dir(getattr(cfg, "dir", None))
    rotation = str(getattr(cfg, "rotation", None) or _DEFAULT_ROTATION)
    retention = str(getattr(cfg, "retention", None) or _DEFAULT_RETENTION)

    if HAS_LOGURU:
        _setup_loguru(level, log_dir, rotation, retention)
    else:
        _setup_stdlib(level, log_dir, rotation, retention)
