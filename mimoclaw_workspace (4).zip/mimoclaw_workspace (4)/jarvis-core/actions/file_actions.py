"""
Файловые команды JARVIS CORE (ТЗ-6.3).

Класс ``FileActions`` — операции с файлами/папками; ``register_file_actions``
регистрирует их в реестр команд с уровнями риска.

Уровни риска:
  - SAFE:   list_dir, file_info, find_files, read_file (только чтение)
  - MEDIUM: create_folder, rename, copy, move
  - HIGH:   delete (в корзину; требует подтверждения)

Все пути проходят проверку запретов (``SecurityConfig.forbidden_paths``),
чтобы ассистент не трогал системные директории.
"""

from __future__ import annotations

import fnmatch
import os
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from actions.registry import Command, CommandRegistry, RiskLevel
from ai.function_calling import ParamSpec


class FileError(Exception):
    """Ошибка файловой операции."""


class FileUnavailable(FileError):
    """Файловая подсистема недоступна."""


def _spec(name: str, type_: str, description: str, required: bool = True) -> ParamSpec:
    return ParamSpec(name=name, type=type_, description=description, required=required)


@dataclass
class FileActions:
    """
    Операции с файлами.

    :param forbidden_paths: префиксы путей, которые нельзя трогать (безопасность).
    :param trash: если True — delete уводит в корзину, а не удаляет физически.
    """

    forbidden_paths: list[str] = field(default_factory=list)
    trash: bool = True

    # -- проверка безопасности ------------------------------------------------
    def _safe(self, path: str | Path) -> Path:
        p = Path(path).expanduser().resolve()
        for bad in self.forbidden_paths:
            if bad and str(p).startswith(str(Path(bad).expanduser().resolve())):
                raise FileError(f"Путь запрещён политикой безопасности: {p}")
        return p

    # -- чтение (SAFE) --------------------------------------------------------
    def list_dir(self, path: str = ".") -> list[str]:
        """Список файлов и папок в директории."""
        p = self._safe(path)
        if not p.is_dir():
            raise FileError(f"Не директория: {p}")
        return sorted(os.listdir(p))

    def file_info(self, path: str) -> dict[str, Any]:
        """Метаданные файла/папки."""
        p = self._safe(path)
        if not p.exists():
            raise FileError(f"Нет такого пути: {p}")
        st = p.stat()
        return {
            "name": p.name,
            "path": str(p),
            "is_dir": p.is_dir(),
            "size": st.st_size,
            "modified": st.st_mtime,
        }

    def find_files(
        self,
        root: str = ".",
        pattern: str = "*",
        max_results: int = 200,
    ) -> list[str]:
        """Поиск файлов по glob-маске (рекурсивно)."""
        base = self._safe(root)
        found: list[str] = []
        for p in base.rglob(pattern):
            if len(found) >= max_results:
                break
            found.append(str(p))
        return found

    def read_file(self, path: str, max_bytes: int = 100_000) -> str:
        """Чтение текстового файла (с лимитом)."""
        p = self._safe(path)
        if not p.is_file():
            raise FileError(f"Не файл: {p}")
        data = p.read_bytes()[:max_bytes]
        return data.decode("utf-8", errors="replace")

    # -- запись/переименование (MEDIUM) --------------------------------------
    def create_folder(self, path: str) -> str:
        p = self._safe(path)
        p.mkdir(parents=True, exist_ok=True)
        return str(p)

    def rename(self, path: str, new_name: str) -> str:
        p = self._safe(path)
        if not p.exists():
            raise FileError(f"Нет такого пути: {p}")
        dest = p.with_name(new_name)
        if dest.exists():
            raise FileError(f"Уже существует: {dest}")
        p.rename(dest)
        return str(dest)

    def copy(self, src: str, dst: str) -> str:
        s, d = self._safe(src), self._safe(dst)
        if not s.exists():
            raise FileError(f"Нет источника: {s}")
        if s.is_dir():
            shutil.copytree(s, d, dirs_exist_ok=True)
        else:
            d.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(s, d)
        return str(d)

    def move(self, src: str, dst: str) -> str:
        s, d = self._safe(src), self._safe(dst)
        if not s.exists():
            raise FileError(f"Нет источника: {s}")
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(s), str(d))
        return str(d)

    # -- удаление (HIGH) ------------------------------------------------------
    def delete(self, path: str) -> str:
        """Удаление. По умолчанию — в корзину (если доступна), иначе физически."""
        p = self._safe(path)
        if not p.exists():
            raise FileError(f"Нет такого пути: {p}")
        if self.trash:
            try:
                from send2trash import send2trash  # type: ignore

                send2trash(str(p))
                return f"в корзину: {p}"
            except ImportError:
                pass  # нет send2trash — удаляем физически (ниже)
        if p.is_dir():
            shutil.rmtree(p)
        else:
            p.unlink()
        return f"удалено: {p}"


# ---------------------------------------------------------------------------
# Регистрация команд
# ---------------------------------------------------------------------------
def register_file_actions(
    registry: CommandRegistry,
    actions: FileActions | None = None,
) -> list[str]:
    """
    Регистрирует файловые команды в ``registry`` (возвращает имена).

    Опции безопасности (forbidden_paths) подставляются из конфига при сборке
    в main.py; здесь — безопасные дефолты.
    """
    svc = actions or FileActions(forbidden_paths=[r"C:\Windows", "/etc", "/usr", "/bin"])

    defs: list[tuple[str, str, list[ParamSpec], str, Callable[..., Any]]] = [
        ("list_dir", "Показать файлы в папке",
         [_spec("path", "string", "путь к папке", required=False)], RiskLevel.SAFE, svc.list_dir),
        ("file_info", "Информация о файле или папке",
         [_spec("path", "string", "путь")], RiskLevel.SAFE, svc.file_info),
        ("find_files", "Найти файлы по маске",
         [_spec("root", "string", "где искать", required=False),
          _spec("pattern", "string", "маска, например *.txt", required=False)],
         RiskLevel.SAFE, svc.find_files),
        ("read_file", "Прочитать текстовый файл",
         [_spec("path", "string", "путь к файлу")], RiskLevel.SAFE, svc.read_file),
        ("create_folder", "Создать папку",
         [_spec("path", "string", "путь к новой папке")], RiskLevel.MEDIUM, svc.create_folder),
        ("rename_file", "Переименовать файл или папку",
         [_spec("path", "string", "что переименовать"),
          _spec("new_name", "string", "новое имя")], RiskLevel.MEDIUM, svc.rename),
        ("copy_file", "Скопировать файл или папку",
         [_spec("src", "string", "источник"), _spec("dst", "string", "куда")],
         RiskLevel.MEDIUM, svc.copy),
        ("move_file", "Переместить файл или папку",
         [_spec("src", "string", "источник"), _spec("dst", "string", "куда")],
         RiskLevel.MEDIUM, svc.move),
        ("delete_file", "Удалить файл или папку (в корзину)",
         [_spec("path", "string", "что удалить")], RiskLevel.HIGH, svc.delete),
    ]

    names: list[str] = []
    for name, desc, params, risk, handler in defs:
        registry.register(
            Command(
                name=name,
                description=desc,
                params=params,
                handler=handler,
                risk=risk,
                requires_confirmation=risk != RiskLevel.SAFE,
            )
        )
        names.append(name)
    return names
