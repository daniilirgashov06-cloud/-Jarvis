/**
 * Базовые элементы управления HUD-панели:
 * кнопки, тумблеры, слайдеры, селекты, поля ввода, чипы.
 */

import { motion } from "framer-motion";
import type {
  ButtonHTMLAttributes,
  InputHTMLAttributes,
  ReactNode,
  SelectHTMLAttributes,
  TextareaHTMLAttributes,
} from "react";
import { clsx } from "../../lib/format";

/* ---------------------------------------------------------------- Button */

type ButtonVariant = "primary" | "ghost" | "danger" | "soft";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  children: ReactNode;
}

const BUTTON_CLASSES: Record<ButtonVariant, string> = {
  primary:
    "bg-accent text-abyss font-semibold shadow-neon hover:shadow-neon-strong border border-transparent",
  ghost:
    "border border-line-bright text-text hover:border-accent/70 hover:text-accent bg-panel-2/60",
  danger: "border border-danger/60 text-danger hover:bg-danger/15 bg-danger/5",
  soft: "border border-line text-muted hover:text-text hover:border-line-bright bg-transparent",
};

export function Button({ variant = "ghost", className, children, ...rest }: ButtonProps) {
  return (
    <motion.button
      whileTap={{ scale: 0.96 }}
      className={clsx(
        "rounded-xl px-4 py-2 text-sm transition-colors disabled:cursor-not-allowed disabled:opacity-40",
        BUTTON_CLASSES[variant],
        className,
      )}
      {...(rest as object)}
    >
      {children}
    </motion.button>
  );
}

/* ---------------------------------------------------------------- Toggle */

interface ToggleProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label?: string;
  disabled?: boolean;
}

export function Toggle({ checked, onChange, label, disabled }: ToggleProps) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={clsx(
        "relative h-6 w-11 shrink-0 rounded-full border transition-colors disabled:opacity-40",
        checked ? "border-accent/70 bg-accent/25" : "border-line-bright bg-panel-2",
      )}
    >
      <motion.span
        layout
        transition={{ type: "spring", stiffness: 520, damping: 32 }}
        className={clsx(
          "absolute top-0.5 rounded-full",
          checked ? "left-[22px] bg-accent shadow-neon" : "left-0.5 bg-muted",
        )}
        style={{ height: 18, width: 18 }}
      />
    </button>
  );
}

/* ---------------------------------------------------------------- Slider */

interface SliderProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (value: number) => void;
  format?: (value: number) => string;
  hint?: string;
}

export function Slider({ label, value, min, max, step = 0.01, onChange, format, hint }: SliderProps) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-baseline justify-between gap-3">
        <span className="text-sm text-text">{label}</span>
        <span className="font-heading text-sm tabular-nums text-accent">
          {format ? format(value) : value}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
      />
      {hint ? <p className="text-xs text-muted">{hint}</p> : null}
    </div>
  );
}

/* ------------------------------------------------------------ SelectField */

interface SelectFieldProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  options: Array<{ value: string; label: string }>;
  hint?: string;
}

export function SelectField({ label, options, hint, className, ...rest }: SelectFieldProps) {
  return (
    <label className="block space-y-1.5">
      <span className="text-sm text-text">{label}</span>
      <select className={clsx("hud-input cursor-pointer", className)} {...rest}>
        {options.map((opt) => (
          <option key={opt.value} value={opt.value} className="bg-panel">
            {opt.label}
          </option>
        ))}
      </select>
      {hint ? <span className="block text-xs text-muted">{hint}</span> : null}
    </label>
  );
}

/* ------------------------------------------------------------- TextField */

interface TextFieldProps extends InputHTMLAttributes<HTMLInputElement | HTMLTextAreaElement> {
  label: string;
  hint?: string;
  /** Многострочный ввод (textarea). */
  multiline?: boolean;
  rows?: number;
}

export function TextField({ label, hint, className, multiline, rows = 4, ...rest }: TextFieldProps) {
  return (
    <label className="block space-y-1.5">
      <span className="text-sm text-text">{label}</span>
      {multiline ? (
        <textarea
          className={clsx("hud-input resize-y", className)}
          rows={rows}
          {...(rest as TextareaHTMLAttributes<HTMLTextAreaElement>)}
        />
      ) : (
        <input className={clsx("hud-input", className)} {...(rest as InputHTMLAttributes<HTMLInputElement>)} />
      )}
      {hint ? <span className="block text-xs text-muted">{hint}</span> : null}
    </label>
  );
}

/* ------------------------------------------------------------------ Chip */

interface ChipProps {
  children: ReactNode;
  onRemove?: () => void;
  accent?: boolean;
}

export function Chip({ children, onRemove, accent }: ChipProps) {
  return (
    <span
      className={clsx(
        "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs",
        accent
          ? "border-accent/50 bg-accent/10 text-accent"
          : "border-line-bright bg-panel-2 text-text",
      )}
    >
      {children}
      {onRemove ? (
        <button
          type="button"
          onClick={onRemove}
          className="text-muted transition-colors hover:text-danger"
          aria-label="Удалить"
        >
          ✕
        </button>
      ) : null}
    </span>
  );
}

/* -------------------------------------------------------------- FieldRow */

interface FieldRowProps {
  label: string;
  hint?: string;
  control: ReactNode;
}

/** Строка настроек: слева название+подсказка, справа контрол. */
export function FieldRow({ label, hint, control }: FieldRowProps) {
  return (
    <div className="flex items-center justify-between gap-4 py-2.5">
      <div className="min-w-0">
        <p className="text-sm text-text">{label}</p>
        {hint ? <p className="text-xs text-muted">{hint}</p> : null}
      </div>
      <div className="shrink-0">{control}</div>
    </div>
  );
}
