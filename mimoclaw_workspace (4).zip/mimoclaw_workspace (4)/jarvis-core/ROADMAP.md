# JARVIS CORE — ДОРОЖНАЯ КАРТА (ROADMAP)

> План работ по ТЗ. Реализуем **итеративно**, сначала рабочий MVP, затем расширяем.
> Каждый этап завершается **работающим, проверяемым** результатом и коммитом.

## Статус значков
`[ ]` не начат · `[~]` в работе · `[x]` готово

---

## Этап 0 — Каркас и инфраструктура  `[x]`
- [x] Структура папок по ТЗ (секция 3)
- [x] `ROADMAP.md` (этот файл)
- [x] `config/settings.py` — Pydantic-модели всех настроек
- [x] `config/default.yaml` — дефолтный конфиг
- [x] `core/event_bus.py` — шина событий pub/sub
- [x] `config/logging.py` — loguru + ротация
      ✅ logger + setup_logging (идемпотентно): loguru → консоль + файл
      `jarvis_{time}.log` (rotation/retention из конфига, enqueue-потокобезопасно);
      без loguru — stdlib-fallback с RotatingFileHandler (ротация/ретеншн парсятся
      приближённо); неверный уровень/путь/папка-занята-файлом → деградация
      до консоли без падения старта · тест 5/5 (tests/test_logging.py)
- [x] `requirements.txt` — зависимости (ядро + секции по этапам)
- [x] `main.py` — точка входа (каркас, argparse `--ui/--headless`)
      ✅ argparse (--text/--headless/--ui взаимоисключающие, --persona/--provider/--offline)
      ✅ сборка пайплайна (_load_action_modules c деградацией на битых модулях,
      build_orchestrator: LLMRouter + STT/TTS-роутеры с fallback + Orchestrator)
      ✅ режимы: текстовый прогон (коды 0/2 при отказе LLM), headless-каркас,
      UI-сервер (деградация в код 1 без uvicorn/FastAPI) · тест 8/8 (tests/test_main.py)
- [x] `git init` + `.gitignore`, `.env.example`, `requirements.txt`
      ✅ git init + первый коммит (5addf5b, идентити репо-локальный), .gitignore
      (секреты config/.env, логи, __pycache__, venv, node_modules, build-артефакты)
      ✅ config/.env.example: ключи 1:1 с env_map в config/settings.py (без значений),
      порядок применения через окружение описан в шапке файла · инвариант
      «шаблон ↔ settings» закрывает тест 5/5 (tests/test_repo_hygiene.py)
- [x] `README.md` с зафиксированными решениями
      ✅ раздел «Ключевые инженерные решения» приведён к 8 решениям ROADMAP
      (MVP-first, локально-first, единые роутеры, веб-панель+Tauri, event_bus,
      Pydantic+yaml, Linux-dev/Windows-run, стилизация голосов) + обновлены
      «что работает»/«как продолжать» под текущее состояние · инвариант
      «README ↔ ROADMAP» закрывают 2 новых теста (tests/test_repo_hygiene.py — 7/7)

## Этап 1 — MVP (ГЛАВНЫЙ ПРИОРИТЕТ)  `[x]`
Цель по ТЗ-14: **микрофон → STT → LLM → TTS + базовые команды + панель**.
- [x] `audio/capture.py` — захват микрофона (16 кГц, моно, 20 мс буфер)
      ✅ CaptureConfig/AudioFrame · AudioSource (MicrophoneSource via sounddevice + WavFileSource)
      ✅ AudioCapture: record / record_until / recent (RingBuffer) / async stream · тест 8/8
- [x] `audio/vad.py` — VAD (webrtcvad + silero-vad)
      ✅ VADEngine-контракт + WebRTCVAD / SileroVAD / EnergyVAD (fallback, без зависимостей)
      ✅ VADRouter (смена движков + fallback) + VoiceActivityDetector (сегментация:
      подтверждение начала, pre-roll, хвост тишины, max_speech) · тест 13/13
- [x] `audio/wakeword.py` — wake-word «Джарвис/Пятница» (openwakeword)
      ✅ WakeWordEngine + WakeWordRouter (смена движков + fallback): OpenWakeWordEngine
      (openwakeword, локально; hey_jarvis ↔ «Джарвис», custom через model_paths)
      + TemplateWakeWordEngine (чистый Python: DTW в полосе, fallback/отладка)
      ✅ WakeWordDetector: события WakeWordEvent с окном PCM для STT, cooldown,
      «поедание» активации · тест 11/11 (tests/test_wakeword.py)
- [x] `audio/clap_detector.py` — детектор хлопков (RMS+ZCR+спектр)
      ✅ признаки (rms_db / ZCR / спектральная плоскость) + SpectralClapEngine
      (жёсткие гейты энергия/ZCR/спектр, требование атаки, взвешенный score)
      ✅ ClapRouter (смена + fallback, опциональный prev_rms_db) +
      ClapDetector (события одиночный/двойной хлопок, cooldown, reset) · тест 7/7
- [x] `audio/playback.py` — воспроизведение речи и SFX
      ✅ AudioSink + SoundDeviceSink (sounddevice) / WavFileSink (отладка) / NullSink (fallback)
      ✅ PlaybackRouter (смена приёмника + fallback) + AudioPlayer (очередь с приоритетами,
      речь > SFX, stop/drain, громкость через apply_volume) + ToneGenerator/builtin_sfx
      ✅ тест 7/7 (tests/test_playback.py)
- [x] `speech/stt_engine.py` — faster-whisper (+ fallback API)
      ✅ STTEngine + STRouter (смена локально↔облако + fallback) + тест
- [x] `speech/tts_engine.py` — локальный TTS (+ ElevenLabs fallback)
      ✅ TTSEngine + TTSRouter (смена + fallback, VoicePreset) + тест
- [x] `ai/llm_router.py` + `ai/providers/*` — единый слой LLM (Ollama по умолчанию)
      ✅ base + Ollama/OpenAI/Anthropic/Gemini · смена локально↔облако · fallback · бюджет
      ✅ протестировано: tests/test_ai_core.py — 10/10
- [x] `ai/personas.py` — JARVIS / FRIDAY / Custom  ✅ + тест
- [x] `ai/context_builder.py` — сборка контекста (базовая)  ✅ + тест
- [x] `ai/function_calling.py` — схемы инструментов для function calling  ✅ + тест
- [x] `actions/registry.py` — `@command` + схемы для function calling
      ✅ CommandRegistry, уровни риска (SAFE/MEDIUM/HIGH/FORBIDDEN), подтверждения + тест
- [x] `actions/{system,app,media,productivity}_actions.py` — базовые команды
      ✅ `actions/system_actions.py`: SystemBackend + SubprocessBackend (Linux/macOS/Windows)
      + DryRunBackend (fallback/тесты) · громкость/мьют, блокировка, сон, выключение,
      перезагрузка, open_url (только http/https) · register_system_actions с уровнями
      риска (SAFE/MEDIUM/HIGH + подтверждения) · тест 7/7 (tests/test_system_actions.py)
      ✅ `actions/app_actions.py`: AppBackend + SubprocessAppBackend (Linux/macOS/Windows)
      + DryRunBackend (fallback/тесты) · AppCatalog (алиасы «браузер» → firefox),
      строгая валидация имён (антиинъекция argv) · launch/close/focus/list_running
      · register_app_actions (SAFE: list/focus, MEDIUM: launch/close) · тест 9/9 (tests/test_app_actions.py)
      ✅ `actions/media_actions.py`: MediaBackend + SubprocessMediaBackend
      (Linux playerctl / macOS osascript+Music / Windows media-клавиши keybd_event)
      + DryRunMediaBackend (fallback/тесты) · MediaInfo + статусы · play/pause/stop/
      next/previous/now_playing · register_media_actions (все SAFE) · тест 11/11 (tests/test_media_actions.py)
      ✅ `actions/productivity_actions.py`: ProductivityBackend + MemoryProductivityBackend
      (потокобезопасное хранилище, fallback/тесты) + LocalProductivityBackend
      (JSON-файл с атомарной записью + системный буфер обмена: Linux xclip/xsel,
      macOS pbcopy/pbpaste, Windows clip/PowerShell с деградацией в память)
      · заметки (add/list/remove/clear), таймеры (set/list/cancel/due), буфер
      (copy/paste) · register_productivity_actions: удаление заметок MEDIUM
      (подтверждение), остальные SAFE · тест 13/13 (tests/test_productivity_actions.py)
- [x] `core/orchestrator.py` — главный цикл пайплайна
      ✅ process_text/process_audio, function-calling цикл, риск-гейты, TTS + тест (5/5)
- [x] `ui_server/app.py` (FastAPI+WS) + минимальная панель (Dashboard/Голос)
      ✅ безфреймворковое ядро: ClientMessage/parse_client_message (JSON-протокол
      text/ping/status/subscribe, лимиты, ProtocolError) + PanelState (статус,
      счётчики, кольцевая лента событий) + UIServer (шина → лента + рассылка
      клиентам с wildcard-фильтрами, команда → оркестратор → reply, выживание
      при упавшем сокете, режим эха без оркестратора)
      ✅ FastAPI-обёртка: GET / (тёмная HUD-панель, вкладки Dashboard/Голос,
      vanilla JS + WS), GET /api/status, /api/history, POST /api/text, WS /ws
      ✅ локально-first (127.0.0.1:8765), create_app/run с ленивыми зависимостями
      ✅ тест 17/17 (tests/test_ui_server.py, в т.ч. TestClient HTTP + WS)
- [x] SFX-звуки активации/подтверждения (`fun/sfx.py`)
      ✅ DSP без numpy (sine/chirp/fade/mix/echo) + 7 событий (activate/confirm/
      error/cancel/thinking/greeting/farewell) × 4 темы (SCIFI/CLASSIC/MINIMAL/
      ROBOTIC) · SampleBank (WAV-сэмплы: стерео→моно, ресемплинг, устойчивость
      к битым файлам) · SfxLibrary (кэш, fallback-цепочка сэмпл → тема →
      builtin_sfx, громкость) · SfxPlayer поверх AudioPlayer · тест 5/5 блоков
      (tests/test_sfx.py)
- [x] Приёмка MVP: «Джарвис» → команда → голосовой ответ за <2 сек
      ✅ `core/mvp_acceptance.py`: MvpAcceptance — сквозной прогон wake → STT →
      LLM/действия → TTS → воспроизведение на реальном Orchestrator с инжектируемыми
      краями (WakeProbe/SpeechSink ≈ WakeWordRouter/AudioPlayer), замер каждого этапа,
      бюджет <2000 мс (и поэтапные лимиты), отчёт AcceptanceReport (ok/within_budget/
      summary); ошибки этапов фиксируются в отчёте, а не утекают исключениями
      ✅ тест tests/test_mvp_acceptance.py — 9/9 (цепочка, бюджет, отказы STT/TTS/wake,
      пропуски краёв); живая проверка микрофона/динамиков — на ПК пользователя (решение №7)

## Этап 2 — Панель настроек (GUI)  `[ ]`
- [ ] React 18 + Vite + Tailwind + Framer Motion, тёмная HUD-тема
- [ ] Все 12 разделов (Dashboard, Голос, Модели, Команды, Экран, Память,
      Telegram, Безопасность, Fun, Хоткеи, Диагностика, Плагины)
- [ ] zustand-сторы, WebSocket-связь с бэкендом
- [ ] Упаковка в Tauri 2 (обёртка над веб-панелью)

## Этап 3 — Полный каталог команд (actions)  `[x]`
- [x] system / app / file / media / input / screen / browser / code / productivity
      ✅ [x] system / app / media / productivity (Этап 1) · file (`actions/file_actions.py`)
      ✅ [x] `actions/input_actions.py` (ввод): InputBackend + SubprocessInputBackend
      (Linux xdotool/ydotool, macOS osascript+cliclick, Windows PowerShell+
      SendKeys/user32) + DryRunInputBackend · набор текста (строгая валидация:
      длина/управляющие символы/ведущий дефис → антиинъекция в argv),
      горячие клавиши (parse_hotkey, алиасы ru/en «ввод»/«пробел»…, канонизация
      порядка модификаторов, синтаксис под платформу), мышь (move/click/scroll)
      · риски: mouse_move/scroll SAFE, type_text/press_hotkey/mouse_click MEDIUM
      · тест 12/12 (tests/test_input_actions.py)
      ✅ [x] `actions/screen_actions.py` (экран): ScreenBackend + SubprocessScreenBackend
      (Linux xrandr/xdpyinfo + scrot/import/grim + wmctrl/xdotool, macOS system_profiler +
      screencapture + osascript, Windows PowerShell + System.Windows.Forms/Drawing/user32)
      + DryRunScreenBackend (fallback/тесты) · размер экрана, список окон, активное окно,
      скриншот в файл (валидация пути: расширения/ведущий дефис/управляющие символы/
      forbidden_paths) · риски: screen_info/list_windows/active_window SAFE,
      take_screenshot MEDIUM (приватность, подтверждение) · тест 5/5 (tests/test_screen_actions.py)
      ✅ [x] `actions/browser_actions.py` (браузер): BrowserBackend +
      SubprocessBrowserBackend (Linux xdg-open/xdg-settings + CLI браузеров +
      pgrep/pkill, macOS open/osascript, Windows PowerShell Start-Process/taskkill)
      + DryRunBrowserBackend · валидация URL (только http/https, запрет
      javascript:/data:/file:, длина/пробелы/ведущий дефис → антиинъекция argv),
      allow-list браузеров (KNOWN_BROWSERS), поиск через duckduckgo/google/
      yandex/wikipedia, закрытие — мягкий сигнал по allow-list процессов
      · риски: browser_status SAFE, open_url/open_search/close_browser MEDIUM
      · тест 8/8 (tests/test_browser_actions.py) · заодно подключены
      screen_actions/browser_actions в _load_action_modules (main.py)
      ✅ [x] `actions/code_actions.py` (код): CodeBackend + SubprocessCodeBackend
      (`sys.executable -c` для Python, интерпретатор по расширению для скриптов,
      фиксированный argv `git status/diff/log` — только чтение) + DryRunCodeBackend
      · запуск фрагмента кода и скриптов (allow-list расширений .py/.sh, без shell=True,
      вывод ≤ MAX_OUTPUT, таймаут 1..300 с → timed_out без исключения),
      git-статус/дифф/лог · риски: git_* SAFE, run_code/run_script HIGH (подтверждение)
      · подключён в _load_action_modules (main.py) · тест 9/9 (tests/test_code_actions.py)
- [x] Уровни риска SAFE/MEDIUM/HIGH/FORBIDDEN + подтверждения + аудит-лог
      ✅ уровни риска + подтверждения уже в `actions/registry.py` (RiskLevel,
      REQUIRES_CONFIRMATION, Command.requires_confirmation, Этап 1) · новый
      `core/audit_log.py`: AuditEvent (action/decision/risk/actor/params/detail,
      валидация decision) + AuditLog (JSONL-файл + кольцевой буфер в памяти,
      потокобезопасно, ротация max_bytes/keep, деградация в память при
      недоступном файле, запросы query/recent, экспорт), маскирование
      секретов (password/token/pin/key…) через `redact` · тест 9/9
      (tests/test_audit_log.py)
- [x] Fuzzy-поиск программ, макросы, пользовательские команды
      ✅ `actions/user_actions.py`: `normalize_text` + `fuzzy_score` (точное/префикс/
      подстрока/токены/difflib) + `ProgramCatalog` (fuzzy-поиск по имени и алиасам,
      `default_program_catalog` переиспользует DEFAULT_ALIASES из app_actions
      с деградацией в пустой каталог) · макросы: `MacroStep`/`Macro` (строгая
      валидация имён/параметров — антиинъекция, JSON-безопасность, лимиты),
      `MacroStore` + `MemoryMacroStore`/`JsonMacroStore` (атомарная запись,
      битый файл → деградация), `MacroRunner` (пошаговый отчёт, стоп на ошибке,
      запрет FORBIDDEN/без подтверждения) · пользовательские команды:
      `UserCommand` + `UserCommandStore` (триггер → ответ/макрос, нечёткий
      поиск фразы, JSON-хранилище) · `UserActions` + `register_user_actions`
      (SAFE: поиск/списки, MEDIUM: правка, HIGH: run_macro) · подключён
      в `_load_action_modules` (main.py) · тест 15/15 (tests/test_user_actions.py)

## Этап 4 — Зрение и экран  `[x]`
- [~] `vision/capture.py`, `ocr.py`, `detector.py`, `screen_tracker.py`
      ✅ [x] `vision/capture.py` (захват экрана): CaptureRegion/MonitorInfo/ScreenFrame
      (строгая валидация геометрии, лимит 32 Мпикс, пересечения/локальные координаты)
      + ScreenCaptureBackend: MssBackend (mss) / PillowBackend (ImageGrab) /
      SyntheticBackend (детерминированные кадры — тесты/отладка/fallback без дисплея)
      + CaptureRouter (смена бэкендов + fallback) + ScreenCapture (дедупликация
      по SHA-1-отпечатку capture_if_changed, маскирование приватных регионов,
      кольцевая история, сохранение PNG без зависимостей, политика путей
      как в screen_actions) · тест 6/6 (tests/test_vision_capture.py)
      ✅ [x] `vision/ocr.py` (OCR текста на экране): OCRImage (L/RGB, валидация
      32 Мпикс, gray/binary/invert/scale, PNG через кодировщик capture) +
      OCRBox/OCRResult (поиск find/contains с нормализацией ё↔е/регистра,
      средняя уверенность по длине слов) + OCREngine-контракт и движки:
      TesseractEngine (локально, CLI stdin/stdout + TSV, psm/таймаут/
      min_confidence, антиинъекция кода языка), HttpOCREngine (облако,
      пользовательский endpoint JSON+base64, ключ из env в Authorization,
      только по явной настройке — приватность), SyntheticOCREngine
      (детерминированные результаты для тестов/аварийного fallback) +
      OCRRouter (смена движков + fallback) + ScreenOCR (предобработка
      gray/binary/invert/scale:N → распознавание → read_text/find_text) +
      default_ocr_router (локально-first: tesseract → опц. облако → синтетика)
      · тест 7/7 (tests/test_ocr.py)
      ✅ [x] `vision/detector.py` (детекция объектов на экране): DetectionBox
      (геометрия: area/center/contains/iou/overlaps, строгая валидация подписей —
      длина/управляющие символы) + DetectionResult (find/best/top/labels,
      нормализация подписи ё↔е/регистр) + `nms` (non-maximum suppression:
      схлопывает дубли одной подписи, разные подписи не конкурируют) + движки:
      TemplateDetectorEngine (локально, чистый Python: ZNCC-поиск шаблонов +
      MAD-фолбэк для «плоских» шаблонов, stride, предохранитель max_work →
      DetectorUnavailable), HttpDetectorEngine (облако, opt-in endpoint,
      ключ из env в Authorization, не логируется), SyntheticDetectorEngine
      (детерминированный fallback) + DetectorRouter (смена + fallback) +
      ScreenDetector (предобработка gray/binary/invert/scale:N → detect →
      find/locate/click_point — готовая точка клика «по описанию») +
      default_detector_router (локально-first: шаблоны → опц. облако → синтетика)
      · тест 6/6 блоков (tests/test_detector.py)
- [x] Анализ скриншота vision-моделью, клик по описанию, редактирование голосом
      (база уже есть: `vision/detector.py` даёт поиск объекта и точку клика)
      ✅ `vision/scene.py`: контракт `VisionEngine` + движки: `OllamaVisionEngine`
      (локально, `/api/chat` + base64 PNG; ответ — свободный текст или JSON
      `{"description", "objects", "answer"}`), `HttpVisionEngine` (облако, opt-in
      endpoint, ключ из env в Authorization, не логируется), `SyntheticVisionEngine`
      (детерминированный fallback) + `SceneRouter` (смена движков + fallback) ·
      `SceneAnalysis` (описание/ответ/объекты `DetectionBox`, find/best,
      `to_prompt_text` для контекста LLM) · `ScreenAnalyst`: describe/ask,
      клик по описанию (`locate`/`click_point`/`click` через инжектируемый колбэк —
      модуль сам не трогает ОС-ввод) с приоритетом точности `ScreenDetector` над
      vision-моделью · голосовое редактирование: `parse_edit_instruction`
      (эвристика ru/en: клик/ввод/прокрутка, цель в кавычках) → `EditPlan`
      (`needs_confirmation`, неоднозначное НЕ исполняется) → `apply_edit` ·
      приватность: облако только осознанно, локально-first
      (`default_scene_router`: ollama → опц. облако → синтетика)
      · тест 7/7 блоков (tests/test_scene.py)
- [x] Screen Awareness + приватность (маскировка парольных полей)
      ✅ `vision/screen_awareness.py`: `SensitiveKind`/`SensitiveRegion`
      (строгая валидация геометрии/подписи, обрезка по кадру) + `PrivacyPolicy`
      (что маскируем / стиль BLACK-BLUR-PIXELATE / `allow_cloud` — облако только
      осознанно) + `mask_image` (заливка/box-blur/пикселизация в `OCRImage` без
      зависимостей, предохранитель MAX_BLUR_PIXELS) + `find_text_secrets`/
      `redact_text` (email, карты с проверкой Луна, телефоны, «пароль: значение»,
      разрешение пересечений) + `SensitiveFieldDetector` (парольные поля по OCR:
      подписи «пароль/PIN/CVV» + значения «••••» + ассоциация значения справа)
      + фасад `ScreenGuard` (`protect_image`/`protect_frame`/`protect_text`,
      `prepare_for_cloud` → `PrivacyBlocked` при секретах и запрете облака)
      · тест 5/5 блоков (tests/test_screen_awareness.py)

## Этап 5 — Память (вечная)  `[x]`
- [~] `memory/store.py` (SQLite-схема), `vector_store.py` (ChromaDB)
      ✅ [x] `memory/store.py` (персистентное хранилище памяти): `MemoryKind` /
      `MemoryRecord` (строгая валидация: длина контента, диапазон важности,
      нормализация и дедупликация тегов ё↔е/регистр, антиинъекция управляющих
      символов) + контракт `MemoryStore` (add/get/search/list_recent/update/
      delete/clear/count/export) и реализации: `InMemoryMemoryStore`
      (потокобезопасно, fallback/тесты/INCOGNITO) + `SQLiteMemoryStore`
      (sqlite3: WAL, индексы, атомарные транзакции, общий Lock, JSON-теги/
      метаданные) + `default_memory_store` (локально-first: SQLite → деградация
      в память `degraded=True`) · поиск с нормализацией ё↔е/регистр и важностью,
      фильтры kind/tag · приватность: INCOGNITO не пишет на диск и запрещает
      экспорт (`PrivacyError`), LOCAL — только локально · экспорт json/jsonl
      (валидация пути/формата, атомарно через tmp) · «забудь всё» (`clear`)
      · тест 6/6 (tests/test_memory_store.py)
- [x] `summarizer.py`, `profile.py`, RAG top-8 в context_builder
      ✅ [x] `memory/summarizer.py` (суммаризатор памяти): `SummaryResult`
      (метрики сжатия ratio/to_dict) + контракт `SummarizerEngine` и движки:
      `ExtractiveSummarizer` (локально, чистый Python: частотный скоринг
      предложений + позиционный бонус, сохранение порядка, укладывание
      в max_chars) + `LLMSummarizer` (абстрактивная сводка через любой
      LLM-клиент — Ollama локально или облако; сбой/пустой ответ →
      `SummarizerUnavailable`) + `SummarizerRouter` (смена локально↔облако,
      fallback-цепочка с гарантированной деградацией в extractive) +
      `MemorySummarizer` (сводка текста/записей/диалога + сохранение
      `MemoryRecord(kind=SUMMARY)` в хранилище) + `default_summarizer_router`
      (локально-first) · тест 8/8 (tests/test_summarizer.py)
      ✅ [x] `memory/profile.py` (профиль пользователя): `ProfileEntry` (ключ/значение/
      доверие, строгая валидация) + `UserProfile` (политика слияния: одиночные ключи
      заменяются по доверию, множественные likes/dislikes/hobbies копятся с
      дедупликацией ё↔е/регистр и лимитом) + движки экстракции:
      `HeuristicProfileExtractor` (локально, чистый Python: имя/город/работа/
      предпочтения, разделение клауз «люблю X и обожаю Y», отрицание не попадает
      в likes) + `LLMProfileExtractor` (облако/локально через любой LLM-клиент,
      JSON-ответ, сбой → `ProfileUnavailable`) + `ProfileExtractorRouter`
      (смена локально↔облако + гарантированный fallback в эвристику) +
      `ProfileStore`: `InMemoryProfileStore` / `JsonProfileStore` (атомарная
      запись, битый файл → пустой профиль) + `ProfileBuilder` (обучение из
      текста/записей MemoryRecord, `to_prompt_text` для промпта, INCOGNITO —
      без записи на диск, «забудь профиль») + `default_profile_extractor_router`
      (локально-first) · RAG top-8 уже в `ai/context_builder.py` (rag_top_k=8)
      · тест 11/11 (tests/test_profile.py)
- [x] Режимы приватности (INCOGNITO / ЛОКАЛЬНО), экспорт, «забудь всё»
      ✅ `memory/privacy.py`: единая точка приватности памяти — `PrivacySettings`
      (режим + правила экспорта, валидация) + `PrivacyController` (маршрутизация
      записей по режиму: INCOGNITO → сессионный буфер только в памяти, диск не
      трогаем; гейты `can_persist`/`can_export`/`can_send_to_cloud` — облако
      только в NORMAL, `set_mode` со сбросом/переносом сессии и синхронизацией
      режима профиля) · единый экспорт памяти + профиля в json/jsonl (атомарно,
      валидация пути/формата, маскировка секретов через `redact_text` —
      `ExportReport`) + «забудь всё» (хранилище + сессия + профиль —
      `ForgetReport`) + `save_profile`/`profile_text`/`status` для панели +
      `default_privacy_controller` (локально-first: SQLite+JSON, в INCOGNITO —
      только память, файлы не создаются) · тест 14/14 (tests/test_privacy.py)

## Этап 6 — Telegram-бот  `[ ]`
- [ ] aiogram 3: команды, голосовые, инлайн-пульт, уведомления
- [ ] Подтверждение опасных действий, файлы, уровни прав, whitelist+PIN

## Этап 7 — Фишки «Железного человека»  `[ ]`
- [ ] `fun/boot_sequence.py`, `hud.py`, `easter_eggs.py`
- [ ] Режимы СТЕЛС/ФОКУС/ВЕЧЕРИНКА/ТРЕВОГА, утренний брифинг, досье

## Этап 8 — Плагины и безопасность  `[ ]`
- [ ] `plugins/` + example_plugin + README
- [ ] `core/security.py` — уровни доступа, whitelist, PIN, аудит, откат

## Этап 9 — Упаковка и установка  `[ ]`
- [ ] `install.py`-мастер, автозагрузка, трей
- [ ] PyInstaller (backend) + Tauri bundler → единый .exe
- [ ] README: скриншоты, схема, чек-лист, FAQ, troubleshooting

## Этап 10 — Приёмка  `[ ]`
- [ ] Пройтись по чек-листу ТЗ-13, зафиксировать результат
- [ ] Режим «Локально» (Ollama + локальные STT/TTS без интернета)

---

## Ключевые инженерные решения (детали — в README.md)
1. **MVP-first** — как требует ТЗ-14. Никаких «TODO в критичных путях».
2. **Локально-first для ИИ/речи** — по умолчанию Ollama + faster-whisper + локальный
   TTS, чтобы запускалось без ключей и без интернета; облако — опционально.
3. **Провайдеры через единый `LLMRouter`** — автопереключение/fallback.
4. **GUI как веб-панель (React+Vite) за FastAPI** — сразу работает в браузере и
   тестируется; Tauri 2 — обёртка для нативного .exe на этапе упаковки.
5. **Модульность через event_bus** — плагины добавляются без правки ядра.
6. **Конфиг только через Pydantic + settings.yaml** — без хардкода.
7. **В разработке на Linux, запуск на Windows** — логика юнит-тестится здесь,
   аппаратные/OS-части (микрофон, трей, win-управление) проверяются на вашем ПК.
8. **Голоса — стилизация, не клонирование** актёров (юридически чисто, по примечанию ТЗ).
