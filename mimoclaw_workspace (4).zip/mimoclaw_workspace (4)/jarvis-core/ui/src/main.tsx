/**
 * Точка входа панели JARVIS CORE.
 */

import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import { applyAccent, useUiStore } from "./stores/uiStore";
import "./index.css";

// Акцент HUD (циан JARVIS / красный FRIDAY) применяется до первого рендера.
applyAccent(useUiStore.getState().persona);

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </StrictMode>,
);
