/**
 * Стор настроек JARVIS CORE.
 *
 * Данные приходят из REST `/api/settings`; если ядро не отвечает на этот
 * эндпоинт — работаем с дефолтами (`types/settings.ts`) в демо-режиме.
 * Изменения копятся посекционно и отправляются одним PATCH/PUT.
 */

import { create } from "zustand";
import { fetchSettings, saveSettings } from "../lib/api";
import type { Settings, SettingsSection } from "../types/settings";
import { DEFAULT_SETTINGS } from "../types/settings";

type DirtyMap = Partial<Record<SettingsSection, boolean>>;

interface SettingsState {
  data: Settings;
  loaded: boolean;
  /** Ядро отдаёт REST настроек (false = демо-режим). */
  remote: boolean;
  saving: boolean;
  dirty: DirtyMap;
  notice: string;

  load: () => Promise<void>;
  patch: <S extends SettingsSection>(section: S, values: Partial<Settings[S]>) => void;
  save: () => Promise<void>;
  reset: () => Promise<void>;
  isDirty: () => boolean;
}

export const useSettingsStore = create<SettingsState>((set, get) => ({
  data: DEFAULT_SETTINGS,
  loaded: false,
  remote: false,
  saving: false,
  dirty: {},
  notice: "",

  load: async () => {
    const { settings, remote } = await fetchSettings();
    set({ data: settings, loaded: true, remote, dirty: {}, notice: "" });
  },

  patch: (section, values) =>
    set((state) => ({
      data: { ...state.data, [section]: { ...state.data[section], ...values } },
      dirty: { ...state.dirty, [section]: true },
      notice: "",
    })),

  save: async () => {
    const { data, dirty } = get();
    const changedSections = (Object.keys(dirty) as SettingsSection[]).filter((k) => dirty[k]);
    if (changedSections.length === 0) {
      set({ notice: "Нет изменений для сохранения" });
      return;
    }
    const patch: Partial<Settings> = {};
    for (const section of changedSections) {
      patch[section] = data[section];
    }
    set({ saving: true, notice: "" });
    const result = await saveSettings(patch);
    set({
      saving: false,
      remote: result.remote,
      dirty: result.saved ? {} : dirty,
      notice: result.saved
        ? "Настройки сохранены"
        : result.remote
          ? "Ядро отклонило сохранение (см. лог)"
          : "Ядро недоступно — изменения хранятся локально (демо-режим)",
    });
  },

  reset: async () => {
    await get().load();
    set({ notice: "Изменения сброшены к состоянию ядра" });
  },

  isDirty: () => Object.values(get().dirty).some(Boolean),
}));
