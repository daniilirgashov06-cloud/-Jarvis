"""
Проверка actions/productivity_actions.py — заметки, таймеры, буфер обмена.

Запуск:  python3 tests/test_productivity_actions.py
"""

from __future__ import annotations

import json
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from actions.productivity_actions import (
    LocalProductivityBackend,
    MemoryProductivityBackend,
    Note,
    ProductivityActions,
    ProductivityInvalidInput,
    ProductivityUnavailable,
    TimerInfo,
    _format_seconds,
    _validate_duration,
    _validate_name,
    _validate_text,
    register_productivity_actions,
)
from actions.registry import CommandRegistry, RiskLevel


# ---------------------------------------------------------------------------
# Хелперы
# ---------------------------------------------------------------------------
def _raises(exc_type, fn, *args, **kwargs) -> str:
    """Проверяет, что fn бросает exc_type; возвращает текст ошибки."""
    try:
        fn(*args, **kwargs)
    except exc_type as e:
        return str(e)
    raise AssertionError(f"ожидался {exc_type.__name__}, но ошибки не было")


# ---------------------------------------------------------------------------
# Тесты: валидация и форматирование
# ---------------------------------------------------------------------------
def test_validate_inputs() -> None:
    assert _validate_text("  привет  ") == "привет"
    assert _validate_name(None) is None
    assert _validate_name("  чай  ") == "чай"
    assert _validate_duration(90) == 90.0

    assert "пуст" in _raises(ProductivityInvalidInput, _validate_text, "   ")
    assert "пуст" in _raises(ProductivityInvalidInput, _validate_text, "")
    assert "длинный" in _raises(ProductivityInvalidInput, _validate_text, "х" * 2001)
    assert "числом" in _raises(ProductivityInvalidInput, _validate_duration, "abc")
    assert "вне диапазона" in _raises(ProductivityInvalidInput, _validate_duration, 0)
    assert "вне диапазона" in _raises(ProductivityInvalidInput, _validate_duration, 999999)
    assert "символы" in _raises(ProductivityInvalidInput, _validate_name, "имя; rm -rf")
    assert "длинное" in _raises(ProductivityInvalidInput, _validate_name, "я" * 65)


def test_format_seconds() -> None:
    assert _format_seconds(45) == "45 сек"
    assert _format_seconds(90) == "1 мин 30 сек"
    assert _format_seconds(3600) == "1 ч 0 мин"


# ---------------------------------------------------------------------------
# Тесты: заметки (memory backend)
# ---------------------------------------------------------------------------
def test_notes_memory_flow() -> None:
    backend = MemoryProductivityBackend()
    svc = ProductivityActions(backend=backend)

    assert "нет" in svc.note_list()

    msg = svc.note_add("купить молоко")
    assert "сохранена" in msg

    note = backend.add_note("вторая заметка")
    notes = backend.list_notes()
    assert len(notes) == 2
    # свежие сверху
    assert notes[0].id == note.id

    # удаление по префиксу
    out = svc.note_remove(note.id[:6])
    assert "удалена" in out
    assert len(backend.list_notes()) == 1

    # неизвестный / неоднозначный id
    assert "не найдена" in _raises(ProductivityInvalidInput, svc.note_remove, "zzz")

    out = svc.note_clear()
    assert "Удалено заметок: 1" in out
    assert backend.list_notes() == []


def test_note_entities() -> None:
    note = Note(id="abcdef123", text="тест", created_at=1_700_000_000.0)
    restored = Note.from_dict(note.to_dict())
    assert restored == note
    assert "abcdef" in note.describe()
    assert "тест" in note.describe()


def test_notes_capacity_guard() -> None:
    backend = MemoryProductivityBackend()
    for i in range(500):
        backend.add_note(f"заметка {i}")
    assert "слишком много" in _raises(ProductivityUnavailable, backend.add_note, "лишняя")


# ---------------------------------------------------------------------------
# Тесты: таймеры
# ---------------------------------------------------------------------------
def test_timers_flow() -> None:
    backend = MemoryProductivityBackend()
    svc = ProductivityActions(backend=backend)

    assert "нет" in svc.timer_list()

    out = svc.timer_set(90, "чай")
    assert "«чай»" in out and "1 мин 30 сек" in out

    timer = backend.set_timer(300)
    assert not timer.is_due()
    assert timer.remaining_sec > 290

    listing = svc.timer_list()
    assert "Активных таймеров: 2" in listing

    # отмена по префиксу + неизвестный id
    assert "отменён" in svc.timer_cancel(timer.id[:6])
    assert "не найден" in _raises(ProductivityInvalidInput, svc.timer_cancel, "zzz")
    assert "не указан" in _raises(ProductivityInvalidInput, svc.timer_cancel, "  ")


def test_timer_due_semantics() -> None:
    timer = TimerInfo(id="t1", name=None, duration_sec=10, created_at=time.time() - 11)
    assert timer.is_due()
    assert timer.remaining_sec < 0

    backend = MemoryProductivityBackend()
    backend.set_timer(1)  # активный
    backend._timers["done"] = TimerInfo(
        id="done", name="прошло", duration_sec=1, created_at=time.time() - 5
    )
    assert len(backend.list_timers()) == 1                 # без сработавших
    assert len(backend.list_timers(include_due=True)) == 2
    due = backend.due_timers()
    assert len(due) == 1 and due[0].id == "done"


# ---------------------------------------------------------------------------
# Тесты: буфер обмена
# ---------------------------------------------------------------------------
def test_clipboard_memory() -> None:
    backend = MemoryProductivityBackend()
    svc = ProductivityActions(backend=backend)

    assert "пуст" in svc.clipboard_paste()
    assert "Скопировано" in svc.clipboard_copy("hello world")
    assert "hello world" in svc.clipboard_paste()
    assert "пуст" in _raises(ProductivityInvalidInput, svc.clipboard_copy, "  ")


def test_clipboard_local_fallback() -> None:
    """При недоступной системной утилите буфер работает через память."""
    backend = LocalProductivityBackend(store_path=Path(tempfile.mkdtemp()) / "s.json")
    backend.clipboard_copy("локальный текст")
    assert "локальный текст" in backend.clipboard_paste()


# ---------------------------------------------------------------------------
# Тесты: LocalProductivityBackend (JSON-персистентность)
# ---------------------------------------------------------------------------
def test_local_persistence_roundtrip() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "store" / "productivity.json"
        backend = LocalProductivityBackend(store_path=path)

        note = backend.add_note("персистентная заметка")
        timer = backend.set_timer(120, "будильник")
        assert path.exists()

        # файл — валидный JSON с нашими сущностями
        raw = json.loads(path.read_text(encoding="utf-8"))
        assert raw["notes"][0]["text"] == "персистентная заметка"
        assert raw["timers"][0]["name"] == "будильник"

        # перечитываем с диска
        backend2 = LocalProductivityBackend(store_path=path)
        assert [n.id for n in backend2.list_notes()] == [note.id]
        assert [t.id for t in backend2.list_timers()] == [timer.id]

        # удаление тоже сохраняется
        backend2.remove_note(note.id[:6])
        backend3 = LocalProductivityBackend(store_path=path)
        assert backend3.list_notes() == []
        assert len(backend3.list_timers()) == 1


def test_local_corrupted_store_recovers() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "productivity.json"
        path.write_text("{ это не json", encoding="utf-8")
        backend = LocalProductivityBackend(store_path=path)  # не падает
        assert backend.list_notes() == []
        backend.add_note("новая")
        assert len(backend.list_notes()) == 1


# ---------------------------------------------------------------------------
# Тесты: регистрация команд
# ---------------------------------------------------------------------------
def test_register_productivity_actions() -> None:
    registry = CommandRegistry()
    names = register_productivity_actions(registry)
    assert set(names) == {
        "note_add",
        "note_list",
        "note_remove",
        "note_clear",
        "timer_set",
        "timer_list",
        "timer_cancel",
        "clipboard_copy",
        "clipboard_paste",
    }
    assert set(registry.names()) == set(names)

    # уровни риска: удаление заметок требует подтверждения, остальное — нет
    for name in names:
        cmd = registry.get(name)
        assert cmd is not None
        if name in {"note_remove", "note_clear"}:
            assert cmd.risk == RiskLevel.MEDIUM
            assert cmd.requires_confirmation
        else:
            assert cmd.risk == RiskLevel.SAFE
            assert not cmd.requires_confirmation

    # схемы параметров доходят до function calling
    tool = registry.get("note_add").to_tool()
    assert tool.params[0].name == "text"
    timer_tool = registry.get("timer_set").to_tool()
    assert [p.name for p in timer_tool.params] == ["duration_sec", "name"]
    assert timer_tool.params[1].required is False


def test_commands_run_through_registry() -> None:
    registry = CommandRegistry()
    backend = MemoryProductivityBackend()
    register_productivity_actions(registry, ProductivityActions(backend=backend))

    import asyncio

    async def run_all() -> list[str]:
        return [
            await registry.get("note_add").run(text="через реестр"),
            await registry.get("note_list").run(),
            await registry.get("timer_set").run(duration_sec=60, name="тест"),
            await registry.get("timer_list").run(),
            await registry.get("clipboard_copy").run(text="буфер"),
            await registry.get("clipboard_paste").run(),
        ]

    results = asyncio.run(run_all())
    assert "сохранена" in results[0]
    assert "через реестр" in results[1]
    assert "«тест»" in results[2]
    assert "Активных таймеров: 1" in results[3]
    assert "Скопировано" in results[4]
    assert "буфер" in results[5]


# ---------------------------------------------------------------------------
def main() -> int:
    print("JARVIS CORE — проверка actions/productivity_actions")
    try:
        test_validate_inputs()
        test_format_seconds()
        test_notes_memory_flow()
        test_note_entities()
        test_notes_capacity_guard()
        test_timers_flow()
        test_timer_due_semantics()
        test_clipboard_memory()
        test_clipboard_local_fallback()
        test_local_persistence_roundtrip()
        test_local_corrupted_store_recovers()
        test_register_productivity_actions()
        test_commands_run_through_registry()
    except AssertionError as e:
        import traceback

        print(f"\n✗ FAIL: {e}")
        traceback.print_exc()
        return 1
    except Exception as e:  # noqa: BLE001
        print(f"\n✗ ERROR: {type(e).__name__}: {e}")
        raise
    print("\n✅ Все проверки модулей прошли.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
